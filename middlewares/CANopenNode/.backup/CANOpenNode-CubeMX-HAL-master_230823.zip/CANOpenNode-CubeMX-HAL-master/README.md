# CANOpenNode-CubeMX-HAL


Port of the CANOpenNode stack drivers to support STM32CubeMX HAL. 

Demo project for Atollic studio.

Cube MX driver can be found under Code/Lib/bsp/CANOpenNode/STM32HAL/

Tested on Nucleo STM32L452xx board. 

For more information and licensing, see https://github.com/CANopenNode/CANopenNode
