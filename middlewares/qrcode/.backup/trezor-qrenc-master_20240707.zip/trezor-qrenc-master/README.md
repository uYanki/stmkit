trezor-qrenc
============

[![Build Status](https://travis-ci.org/trezor/trezor-qrenc.svg?branch=master)](https://travis-ci.org/trezor/trezor-qrenc) [![gitter](https://badges.gitter.im/trezor/community.svg)](https://gitter.im/trezor/community)

Minimalistic QR Code Generator (Encoder)

- Originally written by Psytec Inc.
- Modified by Alexey Mednyy
- Heavily modified and maintained by Pavol Rusnak
- JavaScript cross-compilation by Karel Bilek using emscripten, with some code from Kazuhiko Arase

Licensed under MIT License
