#ifndef __IAP_H__
#define __IAP_H__
/*******************************************************************************************************/
#define IAP_BAK_ADDR        0               //APP���ݾ��񱣴�λ��

#ifdef FLASH_SIZE_256K
#define IAP_DIFF_NEW_ADDR   (28 * 1024)     //�������ʱ,�ϲ����ļ������ַ
#else
#define IAP_DIFF_NEW_ADDR   (60 * 1024)     //�������ʱ,�ϲ����ļ������ַ
#endif

#define IAP_MAGIC_FLG       (0xAA55)        //APP������־

/*******************************************************************************************************/
#include "stdint.h"

typedef struct
{
    uint16_t flg;            //������־
} IAP_AppBak_stk;

/*******************************************************************************************************/
void iap_download_flash_erase(void);
int  iap_download(uint32_t offset, uint8_t *datp, uint16_t len);
void iap_download_done(void);
void iap_upgrade_start(void);
void iap_task(void);
void iap_quit(void);

#endif
/*******************************************************************************************************
**                            End Of File
********************************************************************************************************/
