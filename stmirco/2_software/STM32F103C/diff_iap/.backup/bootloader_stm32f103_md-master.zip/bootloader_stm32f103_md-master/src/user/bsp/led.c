/**********************************************************************************
**--------------File Info----------------------------------------------------------
** File name:			led.c
** Last modified Date:  2012-09-19
** Last Version:		1.0
** Descriptions:		任务函数
**
**
**---------------------------------------------------------------------------------
** Created by:			Chen Y.M
** Created date:		2011-01-07
** Version:				1.0
** Descriptions:		The original version
**
**---------------------------------------------------------------------------------
** Modified by:
** Modified date:
** Version:
** Descriptions:
**
***********************************************************************************/
#include "stm32f10x.h"
#include "usr_cfg.h"
#include "led.h"

/**********************************************************************************/
#define  LED_RUN_PORT   GPIOA
#define  LED_RUN_PIN    GPIO_Pin_4  //RUN


void led_gpio_init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Pin 	= LED_RUN_PIN;
    GPIO_InitStructure.GPIO_Mode 	= GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed   = GPIO_Speed_50MHz;
    GPIO_Init(LED_RUN_PORT, &GPIO_InitStructure);
    
    GPIO_ResetBits(LED_RUN_PORT, LED_RUN_PIN);
}

void led_spark(void)
{
    static __IO uint32_t led1_delay_cnt = 0;
    
    if (led1_delay_cnt != 0x00)
    {
        if(led1_delay_cnt <= 5)
        {
            GPIO_ResetBits(LED_RUN_PORT, LED_RUN_PIN);
        }
        else
        {
            GPIO_SetBits(LED_RUN_PORT, LED_RUN_PIN);
        }
        led1_delay_cnt--;
    }
    else
    {
        led1_delay_cnt = 10;
    }
}

/*******************************************************************************************************
**                            End Of File
********************************************************************************************************/
