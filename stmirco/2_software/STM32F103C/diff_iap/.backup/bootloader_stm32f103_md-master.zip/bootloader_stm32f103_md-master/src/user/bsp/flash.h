#ifndef __FLASH_H__
#define __FLASH_H__
/*******************************************************************************************************/
#include "stdint.h"

#ifndef FLASH_PAGE_SIZE
#define FLASH_PAGE_SIZE			(1024)              //FLASHҳ��С,�����ֶ���
#endif

#define FLASH_PAGE_WORD			(256)               //FLASHҳ��С,�ֳ���

#ifdef FLASH_SIZE_128K
//FLASH����
#define FLASH_BOOT_BASE    		(0x08000000)        //bootloader��ʼ��ַ,20K - 64B								
#define FLASH_APP_BASE    		(0x08004FC0)        //Ӧ�ó�����ʼ��ַ,64B + 52KB
#define FLASH_APP_ENTRY         (0x08005000)        //Ӧ�ó������
#define FLASH_BAK_BASE    		(0x08012000)        //���ݺ���,54KB
#define FLASH_CFG_BASE          (0x0801E000)        //126K-128K,����һЩ��Ҫ��������Ϣ,2KB

#define FLASH_BOOT_SIZE			(20 * 1024 - 64)    //bootloader����
#define FLASH_APP_SIZE			(52 * 1024 + 64)    //Ӧ�ó��򳤶�,52KB
#define FLASH_BAK_SIZE			(54 * 1024)         //���ݺ�������,54KB
#define FLASH_CFG_SIZE          (2 * 1024)          //������Ϣ����
#endif


/*******************************************************************************************************/
typedef enum
{
    flash_boot,
    flash_app,
    flash_bak,
    flash_cfg
} flash_partition_enum;

/*******************************************************************************************************/
int flash_partition_addr(flash_partition_enum part, uint32_t *addr);
uint32_t flash_partition_size(flash_partition_enum part);
int flash_partition_erase(flash_partition_enum part, uint32_t addr, uint32_t size);
int flash_write_without_erase(flash_partition_enum part, uint32_t addr, const void *p, uint32_t len);
int flash_write(flash_partition_enum part, uint32_t addr, const void *p, uint32_t len);
int flash_read(flash_partition_enum part, uint32_t addr, void *p, uint32_t len);
uint8_t* flash_read_fp(flash_partition_enum part, uint32_t addr);
uint32_t flash_sum(uint32_t addr, uint32_t len);
uint32_t flash_crc(uint32_t addr, uint32_t len);
uint32_t flash_partition_crc(flash_partition_enum part, uint32_t addr, uint32_t len);

#endif
/*******************************************************************************************************
**                            End Of File
********************************************************************************************************/
