@[TOC](文章目录)

---


# 前言

为了演示[bootloader_stm32f103_md](https://gitee.com/eming/bootloader_stm32f103_md)项目升级功能。

------

# 一、bootloader_stm32f103_MD简介

bootloader_stm32f103_md恰如其名，就是一个bootloader，它支持中容量的STM32F103芯片。

# 二、这个demo的主要功能

1. 先上图：

![功能演示](images/demo.gif)

2. 上图演示的基本功能：
   - 在bootloader下烧录应用程序到app分区（分区2），然后跳转到应用程序运行。
   - 烧录差分升级包到patch分区（分区3），完成升级。
   - 其中bootloader包含烧录分区2和分区3的命令，应用程序只包含烧录分区3功能。
   
3. 涉及的命令说明：

   - `ymodem app`，烧录应用程序到app分区，bootloader收到这个命令后，会先擦除分区，因此需要等待片刻。然后发送ymodem文件（这里是uimage_128k.bin）到开发板。发送完成后，开发板会复位跳转到应用程序运行。

   - `ymodem patch`，烧录应用程序到patch分区，bootloader收到这个命令后，同样会先擦除分区。然后发送ymodem文件（新的uimage_128k.bin）到开发板。发送完成后，开发板会复位开始升级。

---
# 三、demo工程说明

1. 在工程目录tools下有生成所有文件的工具软件和脚本文件，这些脚本文件将在编译过程中调用，如下图
   ![脚本演示](images/bat.png)

3. 注意，为了正确编译，需要将`fromelf`命令路径加入系统环境变量，这个文件在`keil\ARM\ARMCC\bin`目录下。


#  四、项目地址

```
https://gitee.com/eming/bootloader_stm32f103_md 
https://gitee.com/eming/demo_stm32f103_md
```

