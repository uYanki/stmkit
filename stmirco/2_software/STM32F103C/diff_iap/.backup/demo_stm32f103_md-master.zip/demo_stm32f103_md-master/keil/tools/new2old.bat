CD output

if exist "old_128k.bin" del old_128k.bin
if exist "new_128k.bin" ren new_128k.bin old_128k.bin



