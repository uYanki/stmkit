CD tools

if exist "../output/image_128k.bin" mkuzimage -a 0x08004FC0 -e 0x08005000 -n demo -i ../output/image_128k.bin -o ../output/uimage_128k.bin



