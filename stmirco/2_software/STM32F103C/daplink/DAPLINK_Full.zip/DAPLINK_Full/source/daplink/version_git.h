#ifndef version_git
#define version_git

#define GIT_DESCRIPTION "11223344"
#define GIT_COMMIT_SHA  "44332211"

#endif  
