# Sone standard library functions.
