SHA1 encryption
