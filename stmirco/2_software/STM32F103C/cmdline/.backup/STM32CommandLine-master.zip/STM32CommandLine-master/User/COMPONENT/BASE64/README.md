base64 encryption
