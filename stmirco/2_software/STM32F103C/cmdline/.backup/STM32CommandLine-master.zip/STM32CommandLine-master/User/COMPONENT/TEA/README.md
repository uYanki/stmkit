TEA (Tiny Encryption Algorithm)
