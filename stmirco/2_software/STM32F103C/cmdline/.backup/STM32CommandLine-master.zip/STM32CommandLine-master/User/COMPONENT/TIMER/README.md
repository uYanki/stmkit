# Timer component.
