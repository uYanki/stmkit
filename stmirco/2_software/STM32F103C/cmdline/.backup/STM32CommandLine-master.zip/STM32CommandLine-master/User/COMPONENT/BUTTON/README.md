# Button scan.
