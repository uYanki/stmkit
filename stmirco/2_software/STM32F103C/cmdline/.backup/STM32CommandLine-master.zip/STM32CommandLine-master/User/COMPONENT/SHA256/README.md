SHA256 encryption
