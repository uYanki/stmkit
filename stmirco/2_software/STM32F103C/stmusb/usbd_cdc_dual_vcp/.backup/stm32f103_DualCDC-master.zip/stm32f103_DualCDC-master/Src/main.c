/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"
#include <stdarg.h>
#include <stdlib.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#ifndef USB_FS_DUAL_COM
int UsbDevRecvAvailableDataLen(void);
int UsbDevRecvs(unsigned char *buf, unsigned short want_len);
int UsbDevSends(unsigned char *buf, int len);
#else
int UsbDevRecvAvailableDataLen(uint32_t idx);
int UsbDevRecvs(uint32_t idx, unsigned char *buf, unsigned short want_len);
int UsbDevSends(uint32_t idx, unsigned char *buf, int len);
#endif
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

#define UART_BUFF_LEN 10240
struct uart_fifo
{
  unsigned short fin,fout;
  unsigned char data[UART_BUFF_LEN];
};
struct uart_fifo uart0_fifo;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
uint32_t len,tickstart;
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */

  uart0_fifo.fin = uart0_fifo.fout = 0;
  usb_printf("Hello Elmo[%s %s].\r\n", __DATE__, __TIME__);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  tickstart = HAL_GetTick();
  while (1)
  {
    /* USER CODE END WHILE */

    if(uart0_fifo.fin != uart0_fifo.fout){
      if(__HAL_UART_GET_FLAG(&huart1, UART_FLAG_TXE)){
        unsigned char ch = uart0_fifo.data[uart0_fifo.fout];
        huart1.Instance->DR = ch;
        if(++uart0_fifo.fout >= UART_BUFF_LEN){
          uart0_fifo.fout=0;
        }
      }
    }
#if 1
#ifndef USB_FS_DUAL_COM
    len = UsbDevRecvAvailableDataLen();
    if(len>16 || ((len>0) &&((HAL_GetTick() - tickstart)>10))){
      uint8_t buf[128];
      len = (len>128) ? 128 : len;
      UsbDevRecvs(buf,len);
      UsbDevSends(buf,len);
      tickstart = HAL_GetTick();
    }
#else
    len = UsbDevRecvAvailableDataLen(0);
    if(len>16 || ((len>0) &&((HAL_GetTick() - tickstart)>10))){
      uint8_t buf[128];
      len = (len>128) ? 128 : len;
      UsbDevRecvs(0,buf,len);
      UsbDevSends(0,buf,len);
      tickstart = HAL_GetTick();
    }

    len = UsbDevRecvAvailableDataLen(1);
    if(len>16 || ((len>0) &&((HAL_GetTick() - tickstart)>10))){
      uint8_t buf[128];
      len = (len>128) ? 128 : len;
      UsbDevRecvs(1,buf,len);
      UsbDevSends(1,buf,len);
      tickstart = HAL_GetTick();
    }

#endif
#endif
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

}

/* USER CODE BEGIN 4 */

unsigned char *pbuf_start = &uart0_fifo.data[0];
unsigned char *pbuf_end = &uart0_fifo.data[UART_BUFF_LEN];
void usb_printf(const char *fmt, ...)
{
#if 1
  va_list list;
  unsigned char *pbuf;

  va_start(list, fmt);
  pbuf = &uart0_fifo.data[uart0_fifo.fin];

  while(*fmt){
    if('%' != *fmt){
      *pbuf++ = *fmt++;
      if(pbuf == pbuf_end) pbuf = pbuf_start;
      continue;
    }

    ++fmt;
    switch(*fmt){
      case 's':{
        const char *str = va_arg(list, const char *);
        for(; *str!='\0'; str++){
          *pbuf++ = *str;
          if(pbuf == pbuf_end) pbuf = pbuf_start;
        }
        ++fmt;
        break;
      }
      case 'd':{
        char zero = 0;
        unsigned int div=1000000000;
        unsigned int value = (unsigned int)va_arg(list, const int);
        while(div){
          unsigned int val = value / div;
          if(val != 0){
            zero = 1;
            value -= val * div;
            *pbuf++ = val + '0';
            if(pbuf == pbuf_end) pbuf = pbuf_start;
          } else if(zero==1){
            *pbuf++ = '0';
            if(pbuf == pbuf_end) pbuf = pbuf_start;
          }
          div /= 10;
        }
        if(zero==0){
          *pbuf++ = '0';
          if(pbuf == pbuf_end) pbuf = pbuf_start;
        }
        ++fmt;
        break;
      }
      case 'x':{
        char zero = 0;
        int ulValue = va_arg(list, const int);
        unsigned char val;

        *pbuf++ = '0';
        if(pbuf == pbuf_end) pbuf = pbuf_start;
        *pbuf++ = 'x';
        if(pbuf == pbuf_end) pbuf = pbuf_start;

        if(ulValue & 0xff000000){
          val = ((ulValue >> 28) & 0xf);
          val += (val>9) ? 'W' : '0';
          *pbuf++ = val;
          if(pbuf == pbuf_end) pbuf = pbuf_start;

          val = ((ulValue >> 24) & 0xf);
          val += (val>9) ? 'W' : '0';
          *pbuf++ = val;
          if(pbuf == pbuf_end) pbuf = pbuf_start;
          zero = 1;
        }
        if((ulValue & 0xff0000) || (zero==1)){
          val = ((ulValue >> 20) & 0xf);
          val += (val>9) ? 'W' : '0';
          *pbuf++ = val;
          if(pbuf == pbuf_end) pbuf = pbuf_start;

          val = ((ulValue >> 16) & 0xf);
          val += (val>9) ? 'W' : '0';
          *pbuf++ = val;
          if(pbuf == pbuf_end) pbuf = pbuf_start;
          zero = 1;
        }
        if((ulValue & 0xff00) || (zero==1)){
          val = ((ulValue >> 12) & 0xf);
          val += (val>9) ? 'W' : '0';
          *pbuf++ = val;
          if(pbuf == pbuf_end) pbuf = pbuf_start;

          val = ((ulValue >> 8) & 0xf);
          val += (val>9) ? 'W' : '0';
          *pbuf++ = val;
          if(pbuf == pbuf_end) pbuf = pbuf_start;
          zero = 1;
        }
        if((ulValue & 0xff) || (zero==1)){
          val = ((ulValue >> 4) & 0xf);
          val += (val>9) ? 'W' : '0';
          *pbuf++ = val;
          if(pbuf == pbuf_end) pbuf = pbuf_start;

          val = (ulValue & 0xf);
          val += (val>9) ? 'W' : '0';
          *pbuf++ = val;
          if(pbuf == pbuf_end) pbuf = pbuf_start;
          zero = 1;
        }

        if(zero==0){
          *pbuf++ = '0';
          if(pbuf == pbuf_end) pbuf = pbuf_start;
          *pbuf++ = '0';
          if(pbuf == pbuf_end) pbuf = pbuf_start;
        }
        ++fmt;
        break;
      }
      default :{
        break;
      }
    }  //end switch
  } //end while
  uart0_fifo.fin = pbuf - pbuf_start;
#endif
}

void usb_printk(char *fmt, int len)
{
  if(uart0_fifo.fin+len <= UART_BUFF_LEN){
    memcpy(&uart0_fifo.data[uart0_fifo.fin], fmt, len);
  } else{
    unsigned short l = UART_BUFF_LEN-uart0_fifo.fin;
    memcpy(&uart0_fifo.data[uart0_fifo.fin], fmt, l);
    memcpy(&uart0_fifo.data[0], &fmt[l], len-l);
  }
  uart0_fifo.fin = (uart0_fifo.fin+len) % UART_BUFF_LEN;
}
void usb_printk_data(char *buff, int len)
{
  int i;
  unsigned short fin = uart0_fifo.fin;

  for(i=0; i<len; i++){
    uart0_fifo.data[fin++] = (buff[i]>>8)+'0';
    if(fin>UART_BUFF_LEN) fin = 0;
    uart0_fifo.data[fin++] = (buff[i]&0x0f)+'0';
    if(fin>UART_BUFF_LEN) fin = 0;
    uart0_fifo.data[fin++] = 0x20;
    if(fin>UART_BUFF_LEN) fin = 0;
  }
  uart0_fifo.fin = fin;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
