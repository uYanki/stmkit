/*
 * Note: This file is recreated by the project wizard whenever the MCU is
 *       changed and should not be edited by hand
 */

/* Include the derivative-specific header file */
#include <MC9S12XS128.h>
#include <hidef.h>

#pragma LINK_INFO DERIVATIVE "MC9S12XS128"

