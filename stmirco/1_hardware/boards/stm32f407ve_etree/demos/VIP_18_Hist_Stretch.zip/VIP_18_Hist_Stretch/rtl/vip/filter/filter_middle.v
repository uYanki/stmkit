//file name:	filter_middle.v
//author:      shugen.yin
//date:		   2017.10.18
//function:		中值滤波
//log:

module filter_middle(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [7:0] cmos_data_o
);

wire [7:0] shiftout;
wire [7:0] taps0x;
wire [7:0] taps1x;
wire [7:0] taps2x;

shift_ram shift_ram_inst
(
	.clock(cmos_pclk) ,		// input  clock_sig
	.clken(cmos_href),
	.shiftin(cmos_data) ,	// input [7:0] shiftin_sig
	.shiftout(shiftout) ,	// output [7:0] shiftout_sig
	.taps0x(taps0x) ,			// output [7:0] taps0x_sig
	.taps1x(taps1x) ,			// output [7:0] taps1x_sig
	.taps2x(taps2x)
);

reg [7:0] taps0x_r0;
reg [7:0] taps0x_r1;
reg [7:0] taps1x_r0;
reg [7:0] taps1x_r1;
reg [7:0] taps2x_r0;
reg [7:0] taps2x_r1;
		
always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps0x_r0 <= 0;
		taps0x_r1 <= 0;
	end
	else
	begin
		taps0x_r0 <= taps0x;
		taps0x_r1 <= taps0x_r0;
	end


always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps1x_r0 <= 0;
		taps1x_r1 <= 0;
	end
	else
	begin
		taps1x_r0 <= taps1x;
		taps1x_r1 <= taps1x_r0;
	end

always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps2x_r0 <= 0;
		taps2x_r1 <= 0;
	end
	else
	begin
		taps2x_r0 <= taps2x;
		taps2x_r1 <= taps2x_r0;
	end	

reg [3:0] cnt0;
reg [3:0] cnt1;
reg [3:0] cnt2;
reg [3:0] cnt3;
reg [3:0] cnt4;
reg [3:0] cnt5;
reg [3:0] cnt6;
reg [3:0] cnt7;
reg [3:0] cnt8;
	
always @(*)
	if(cmos_vsync)
		cnt0 <= 0;
	else
		cnt0 <= (taps0x>taps0x) + (taps0x_r0>taps0x) + (taps0x_r1>taps0x) +
				  (taps1x>taps0x) + (taps1x_r0>taps0x) + (taps1x_r1>taps0x) +
				  (taps2x>taps0x) + (taps2x_r0>taps0x) + (taps2x_r1>taps0x);
				 
always @(*)
	if(cmos_vsync)
		cnt1 <= 0;
	else
		cnt1 <= (taps0x>=taps0x_r0) + (taps0x_r0>taps0x_r0) + (taps0x_r1>taps0x_r0) +
				  (taps1x>taps0x_r0) + (taps1x_r0>taps0x_r0) + (taps1x_r1>taps0x_r0) +
				  (taps2x>taps0x_r0) + (taps2x_r0>taps0x_r0) + (taps2x_r1>taps0x_r0);	
	
	
always @(*)
	if(cmos_vsync)
		cnt2 <= 0;
	else
		cnt2 <= (taps0x>=taps0x_r1) + (taps0x_r0>=taps0x_r1) + (taps0x_r1>taps0x_r1) +
				  (taps1x>taps0x_r1) + (taps1x_r0>taps0x_r1) + (taps1x_r1>taps0x_r1) +
				  (taps2x>taps0x_r1) + (taps2x_r0>taps0x_r1) + (taps2x_r1>taps0x_r1);	

always @(*)
	if(cmos_vsync)
		cnt3 <= 0;
	else
		cnt3 <= (taps0x>=taps1x) + (taps0x_r0>=taps1x) + (taps0x_r1>=taps1x) +
				  (taps1x>taps1x) + (taps1x_r0>taps1x) + (taps1x_r1>taps1x) +
				  (taps2x>taps1x) + (taps2x_r0>taps1x) + (taps2x_r1>taps1x);					 

always @(*)
	if(cmos_vsync)
		cnt4 <= 0;
	else
		cnt4 <= (taps0x>=taps1x_r0) + (taps0x_r0>=taps1x_r0) + (taps0x_r1>=taps1x_r0) +
				  (taps1x>=taps1x_r0) + (taps1x_r0>taps1x_r0) + (taps1x_r1>taps1x_r0) +
				  (taps2x>taps1x_r0) + (taps2x_r0>taps1x_r0) + (taps2x_r1>taps1x_r0);		


always @(*)
	if(cmos_vsync)
		cnt5 <= 0;
	else
		cnt5 <= (taps0x>=taps1x_r1) + (taps0x_r0>=taps1x_r1) + (taps0x_r1>=taps1x_r1) +
				  (taps1x>=taps1x_r1) + (taps1x_r0>=taps1x_r1) + (taps1x_r1>taps1x_r1) +
				  (taps2x>taps1x_r1) + (taps2x_r0>taps1x_r1) + (taps2x_r1>taps1x_r1);

always @(*)
	if(cmos_vsync)
		cnt6 <= 0;
	else
		cnt6 <= (taps0x>=taps2x) + (taps0x_r0>=taps2x) + (taps0x_r1>=taps2x) +
				  (taps1x>=taps2x) + (taps1x_r0>=taps2x) + (taps1x_r1>=taps2x) +
				  (taps2x>taps2x) + (taps2x_r0>taps2x) + (taps2x_r1>taps2x);
				 
always @(*)
	if(cmos_vsync)
		cnt7 <= 0;
	else
		cnt7 <= (taps0x>=taps2x_r0) + (taps0x_r0>=taps2x_r0) + (taps0x_r1>=taps2x_r0) +
				  (taps1x>=taps2x_r0) + (taps1x_r0>=taps2x_r0) + (taps1x_r1>=taps2x_r0) +
				  (taps2x>=taps2x_r0) + (taps2x_r0>taps2x_r0) + (taps2x_r1>taps2x_r0);					
				
always @(*)
	if(cmos_vsync)
		cnt8 <= 0;
	else
		cnt8 <= (taps0x>=taps2x_r1) + (taps0x_r0>=taps2x_r1) + (taps0x_r1>=taps2x_r1) +
				  (taps1x>=taps2x_r1) + (taps1x_r0>=taps2x_r1) + (taps1x_r1>=taps2x_r1) +
				  (taps2x>=taps2x_r1) + (taps2x_r0>=taps2x_r1) + (taps2x_r1>taps2x_r1);	
			
reg cmos_href_r0;
reg cmos_href_r1;
reg [7:0] cmos_data_r0;
	
always @(posedge cmos_pclk)
begin
	cmos_href_r0 <= cmos_href;
	cmos_href_r1 <= cmos_href_r0;
end
	
always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		cmos_href_o  <= 0;
		cmos_data_o  <= 0;
	end	
	else
	begin
		cmos_href_o  <= cmos_href_r1;
		cmos_data_r0 <= (cnt0==4)?taps0x:
							 (cnt1==4)?taps0x_r0:
							 (cnt2==4)?taps0x_r1:
							 (cnt3==4)?taps1x:
							 (cnt4==4)?taps1x_r0:
							 (cnt5==4)?taps1x_r1:
							 (cnt6==4)?taps2x:
							 (cnt7==4)?taps2x_r0:
							 (cnt8==4)?taps2x_r1:8'h00;
		cmos_data_o <= cmos_data_r0;
	end
		

always @(posedge cmos_pclk)
	cmos_vsync_o <= cmos_vsync;
	
endmodule
