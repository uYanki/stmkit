//file name:	hist_stretch.v
//author:      shugen.yin
//date:		   2018.10.9
//function:		
//log:

module hist_stretch(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [7:0] cmos_data_o,
	output reg [10:0] v_cnt
);

parameter IMG_H = 640;

reg [7:0] min0;
reg [7:0] max0;
reg [7:0] min1;
reg [7:0] max1;
reg field;

reg cmos_vsync_r0;
reg cmos_vsync_r1;

//reg [10:0] v_cnt; 	
reg [11:0] h_cnt;

always @(posedge cmos_pclk)
	if(cmos_href_o)
		h_cnt <= h_cnt + 1'b1;
	else
		h_cnt <= 0;
	
always @(posedge cmos_pclk)
	if(cmos_vsync_o)
		v_cnt <= 0;
	else if(h_cnt==(IMG_H-1))
		v_cnt <= v_cnt + 1'b1;
	else
		v_cnt <= v_cnt;

always @(posedge cmos_pclk)
begin
	cmos_vsync_r0 <= cmos_vsync;
	cmos_vsync_r1 <= cmos_vsync_r0;
end

wire cmos_vsync_pos;
wire cmos_vsync_neg;

assign cmos_vsync_pos = (cmos_vsync_r0==1'b1 && cmos_vsync_r1==1'b0)?1'b1:1'b0;
assign cmos_vsync_neg = (cmos_vsync_r0==1'b0 && cmos_vsync_r1==1'b1)?1'b1:1'b0;

always @(posedge cmos_pclk)
	if(cmos_vsync_pos)
		field <= ~field;
	else
		field <= field;

//caculate the first min		
always @(posedge cmos_pclk)
	if(field==1'b0) 
		if(cmos_vsync_r1)
			min0 <= 8'hff;
		else if(cmos_href)
			if(min0>=cmos_data)
				min0 <= cmos_data;
			else
				min0 <= min0;
				
//caculate the second min	
always @(posedge cmos_pclk) 
	if(field==1'b1)         
		if(cmos_vsync_r1)
			min1 <= 8'hff;
		else if(cmos_href)
			if(min1>=cmos_data)
				min1 <= cmos_data;
			else
				min1 <= min1;


//caculate the first max				
always @(posedge cmos_pclk)
	if(field==1'b0) 
		if(cmos_vsync_r1)
			max0 <= 8'h00;
		else if(cmos_href)
			if(max0<=cmos_data)
				max0 <= cmos_data;
			else
				max0 <= max0;

//caculate the second max	
always @(posedge cmos_pclk)
	if(field==1'b1)
		if(cmos_vsync_r1)
			max1 <= 8'h00;
		else if(cmos_href)
			if(max1<=cmos_data)
				max1 <= cmos_data;
			else
				max1 <= max1;


wire [7:0]  differ;
wire [17:0] differ_out;
assign differ = (field==1'b0)?(max1-min1):(max0-min0);	

hist_para hist_para_inst
(
//	.clk(clk_sig) ,				// input  clk_sig
//	.rst_n(rst_n_sig) ,			// input  rst_n_sig
	.data_in(differ) ,		// input [7:0] data_in_sig
	.data_out(differ_out) 	// output [17:0] data_out_sig
);


always @(posedge cmos_pclk)
	if(field==1'b0)
		cmos_data_o <= (differ_out*(cmos_data - min1))/1024;
	else
		cmos_data_o <= (differ_out*(cmos_data - min0))/1024;
		
always @(posedge cmos_pclk)
	cmos_vsync_o <= cmos_vsync;
	
always @(posedge cmos_pclk)
	cmos_href_o <= cmos_href;
				

endmodule



