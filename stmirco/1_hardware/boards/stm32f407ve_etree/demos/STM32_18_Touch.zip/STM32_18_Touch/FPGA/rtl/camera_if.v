//file name			: camera_if.v
//data				: 2015.11.22
//author				: ETree
//function			: camera interface 
//log					:

module camera_if #(
	parameter IMG_H = 640
)
(
	//global signal
	input clk,
	input rst_n,
	
	//camera port	
	output cam_scl,
	inout  cam_sda,
	input [7:0] cam_data,
	input cam_vsync,	
	input cam_hsync,
	input cam_pclk,
	output cam_xclk,
	output cam_pdown,
	output cam_reset,
	
	//host port
	output [7:0] cam_data_out,
	output cam_vsync_out,
	output cam_hsync_out,
	
	output [15:0] line_count,
	output reg data_clr,
	output reg [7:0] cmos_average,
	input cam_en
);

reg [7:0] cam_data_r0;
reg [7:0] cam_data_r1;
reg [4:0] cam_hsync_r;
reg [4:0] cam_vsync_r;

reg [15:0] v_cnt;
reg [15:0] h_cnt;

wire  init_done;
wire	i2c_exc;
wire	i2c_done;
wire	[7:0]	i2c_addr;
wire	[7:0]	i2c_data_w;
wire	[7:0]	i2c_data_r;

wire	scl_wr;
wire	sda_wr;
wire	sda_dir;


always @(posedge cam_pclk)
begin
	cam_data_r0 <= cam_data;
	cam_data_r1 <= cam_data_r0;
end

always @(posedge cam_pclk)
begin
	cam_hsync_r <= {cam_hsync_r[3:0],cam_hsync};
	cam_vsync_r <= {cam_vsync_r[3:0],~cam_vsync};
end


always @(posedge cam_pclk)
	if(cam_hsync_r[0])
		h_cnt <= h_cnt + 1'b1;
	else
		h_cnt <= 0;

always @(posedge cam_pclk)
	if(cam_vsync_r[0])
		v_cnt <= 0;
	else if(h_cnt==(IMG_H-1))
		v_cnt <= v_cnt + 1'b1;
	else
		v_cnt <= v_cnt;

assign line_count = v_cnt;		

reg [19:0] cnt_vsync;

always @(posedge cam_pclk)
	if(cam_vsync_r[0])
		cnt_vsync <= cnt_vsync + 1'b1;
	else
		cnt_vsync <= 0;
		
always @(posedge cam_pclk)
begin
	if(~rst_n) 
	begin
		data_clr <= 0;	
	end	
	else if(cnt_vsync>=640)
	begin 
		data_clr <= 1;
	end	
	else
	begin
		data_clr <= 0;
	end
end		
		
wire cam_hsync_pos = (cam_hsync_r[3:2]==2'b01);
wire cam_vsync_pos = (cam_vsync_r[1:0]==2'b01);

assign cam_data_out = (v_cnt==0)?  0:cam_data_r1;
assign cam_vsync_out = cam_vsync_r[1];
assign cam_hsync_out = cam_hsync_r[1];

assign	cam_reset = rst_n;
assign   cam_pdown = ~rst_n;		
assign	cam_xclk = clk;	

//----------Avaerage Calc-------------

//reg [7:0] cmos_average;
reg [24:0] cmos_average_r;

always @(posedge cam_pclk)
	if(cnt_vsync>=640)
		cmos_average_r <= 0;
	else if(h_cnt>=64 && h_cnt<576 && v_cnt>=112 && v_cnt<368)
		cmos_average_r <= cmos_average_r + cam_data;
	else
		cmos_average_r <= cmos_average_r;
		
always @(posedge cam_pclk)
	if(cnt_vsync<640)
		cmos_average <= cmos_average_r[24:17];
	else
		cmos_average <= cmos_average;
	

//iic_com  iic2(
//		.clk	(clk),
//		.rst_n(rst_n),
//		.scl	(cam_scl),
//		.sda_out(cam_sda)		
//		);
		

endmodule
