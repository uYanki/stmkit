//file name:	top_fpga.v
//author:		ETree
//date:			2021.9.11
//function:		top file of project

module top_fpga(
	//global signal                           
	input  clk,
	input  rst_n,
	
	//CMOS Port
	output cam_scl,
	output cam_sda,
	input [7:0] cam_data,
	
	input cam_vsync,	
	input cam_hsync,
	input cam_pclk,
	output cam_xclk,

	output cam_pdown,
	output cam_reset,	
	
	//STM32
	//FSMC Bus
	inout [15:0] fsmc_data,
	input fsmc_noe,
	input fsmc_nwe,
	
	output fsmc_nbl0,
	output fsmc_nbl1,
	input fsmc_ne1, 
	input fsmc_a23,
	input fsmc_a22,
	input fsmc_a21,
	input fsmc_a20,
	input fsmc_a19,
	input fsmc_a18,
	input fsmc_a17,
	input fsmc_a16,
	input fsmc_nwait,
	input fsmc_clk,
	
	//sdram port
	output [12:0] sdram_addr, 
	output [1:0]  sdram_ba,   
	output sdram_cas_n,
	output sdram_cke  ,
	output sdram_cs_n ,
	inout  [15:0] sdram_dq,   
	output [1:0] sdram_dqm , 
	output sdram_ras_n,
	output sdram_we_n, 
	output sdram_clk,
	
	//TFT2.8
	output tft_cs,				//液晶屏片选，低电平有效
	output tft_wr,
	output tft_rs,
	output tft_rd,
	output tft_reset,			//液晶屏复位，低电平有效
	output [15:0] tft_data,
	output tft_blk,				//液晶屏背光，高电平有效
	//TFT Touch
	output tft_tclk,
	output tft_tcs,
	output tft_tmosi,
	input  tft_tmiso,
	input  tft_tpen,
	
	//VGA
	output vga_hsync,
	output vga_vsync,
	output [4:0] vga_red,
	output [5:0] vga_green,
	output [5:0] vga_blue,

   //ledsm
//	output [7:0] sm_dat,
	output [1:0] sm_sel,
	
	//NET
	output e_xi,
	output e_txen,
	output [1:0] e_tx,

	input e_rxer,
	input e_rxdv,
	input e_rxclk,
	input [1:0] e_rx,
	
	//led
	output led
	
);

//------------I2C---------------
assign cam_scl = fsmc_nbl0;
assign cam_sda = fsmc_nbl1;

//------------PLL----------------
wire clk_100m;
wire clk_100m_p;
wire clk_25m;
wire clk_xi;
wire locked;
	
my_pll my_pll_inst(
	.areset ( 0 ),
	.inclk0 ( clk ),
	.c0 ( clk_100m ),
	.c1 ( clk_100m_p ),
	.c2 ( clk_25m ),
	.c3 ( clk_xi ),
	.locked ( locked )
	);	
	
assign sm_sel = 2'b11;

//---------------Soft Reset--------------
reg [19:0] rst_cnt; 
reg rstn;

always @(posedge clk)
	if(~rst_n)
		rst_cnt <= 0;
	else if(rst_cnt>='hffffa)
		rst_cnt <= rst_cnt;
	else
		rst_cnt <= rst_cnt + 1'b1;
		
always @(posedge clk)
	if(rst_cnt>='hffff0)
		rstn <= 1'b1;
	else
		rstn <= 0;	

//---------------CMOS--------------------
wire [7:0] cam_data_out;
wire cam_vsync_out;
wire cam_hsync_out;
wire data_clr;
wire [7:0] cmos_average;

camera_if camera_if_inst
(
	.clk(clk_25m) ,	// input  clk_sig
	.rst_n(rstn) ,	// input  rst_n_sig
//	.cam_scl(cam_scl) ,	// output  cam_scl_sig
//	.cam_sda(cam_sda) ,	// inout  cam_sda_sig
	
	.cam_data(cam_data) ,	// input [7:0] cam_data_sig
	
	.cam_vsync(cam_vsync) ,	// input  cam_vsync_sig
	.cam_hsync(cam_hsync) ,	// input  cam_hsync_sig
	.cam_pclk(cam_pclk) ,	// input  cam_pclk_sig
	.cam_xclk(cam_xclk) ,	// output  cam_xclk_sig
	
	.cam_pdown(cam_pdown) ,	// output  cam_pdown_sig
	.cam_reset(cam_reset) ,	// output  cam_reset_sig
	
	.cam_data_out(cam_data_out),
	.cam_vsync_out(cam_vsync_out),
	.cam_hsync_out(cam_hsync_out),
	.line_count(line_count),
	.data_clr(data_clr),
	.cmos_average(cmos_average),
	.cam_en(1'b1)	// input  cam_en_sig
);	

defparam camera_if_inst.IMG_H = 640;		
		
//-------------CMOS FIFO-----------------
wire [11 : 0] fifo_data_count;
wire [7:0] fifo_data;
wire fifo_rd_en;
wire fifo_full;
wire fifo_empty;

cmos1_fifo cmos1_fifo_inst (
  .aclr                     (data_clr),   // input rst
  .wrclk                    (cam_pclk),                   // input wr_clk
  .data                     (cam_data_out),                   // input [7 : 0] din
  .wrreq                    (cam_hsync_out),                    // input wr_en
  
  .rdclk                    (fifo_rdclk),                         // input rd_clk
  .rdreq                    (fifo_rd_en),                    // input rd_en
  .q                        (fifo_data),                     // output [7 : 0] dout
  .wrfull                   (fifo_full),                     // output full
  .rdempty                  (fifo_empty),                    // output empty
  .rdusedw                  (fifo_data_count),               // output [10 : 0] rd_data_count
  .wrusedw                  ()
);
		
//-----------ETHernet-------------

wire [10:0] frame_index;
wire fifo_rdclk;

assign frame_index = 0;

udp udp_inst(
	.reset_n                 (rstn),
	.e_rxc                   (e_rxclk),
	.e_rxd                   (e_rx),
   .e_rxdv                  (e_rxdv),
	.e_txen                  (e_txen),
	.e_txd                   (e_tx),	

	.fifo_rdclk					 (fifo_rdclk),
	.fifo_data               (fifo_data),           //FIFO读出的8bit数据/
	.fifo_data_count         (fifo_data_count),     //FIFO中的数据数量
   .fifo_rd_en              (fifo_rd_en),          //FIFO读使能 
	.fifo_empty              (fifo_empty),

	.frame_index             (frame_index), 
	
	.tx_total_length         ('d1308),            //发送IP包的总长度/
	.tx_data_length          ('d1288)             //发送IP包的数据长度/		
);

assign e_xi = clk_xi;
		
		
//----------Touch----------
	
assign tft_tclk  = fsmc_a21;
assign tft_tcs   = fsmc_a22;
assign tft_tmosi = fsmc_a20;
assign fsmc_nbl0 = tft_tpen;	
assign fsmc_nbl1 = tft_tmiso;

//----------FSMC-----------	
wire [15:0] fsmc_register3;
wire fsmc_register3_valid;
wire [31:0] fsmc_addr_o;
wire fsmc_load;
wire [15:0] fsmc_rddata;
wire fsmc_rd_valid;


fsmc_reg fsmc_reg_inst
(
	.clk(clk_100m) ,	// input  clk_sig
	.rst_n(rstn) ,	// input  rst_n_sig
	
	.tft_cs(tft_cs) ,	// output  tft_cs_sig
	.tft_wr(tft_wr) ,	// output  tft_wr_sig
	.tft_rs(tft_rs) ,	// output  tft_rs_sig
	.tft_rd(tft_rd) ,	// output  tft_rd_sig
	.tft_reset(tft_reset) ,	// output  tft_reset_sig
	.tft_data(tft_data) ,	// output [15:0] tft_data_sig
	.tft_blk(tft_blk) ,	// output  tft_blk_sig
//	.tft_tclk(tft_tclk) ,	// output  tft_tclk_sig
//	.tft_tcs(tft_tcs) ,	// output  tft_tcs_sig
//	.tft_tmosi(tft_tmosi) ,	// output  tft_tmosi_sig
//	.tft_tmiso(tft_tmiso) ,	// input  tft_tmiso_sig
//	.tft_tpen(tft_tpen) ,	// input  tft_tpen_sig
	
	.fsmc_data(fsmc_data) ,	// inout [15:0] fsmc_data
	.fsmc_noe(fsmc_noe) ,	// input  fsmc_noe
	.fsmc_nwe(fsmc_nwe) ,	// input  fsmc_nwe
	.fsmc_ne1(fsmc_ne1) ,	// input  fsmc_ne1
	.fsmc_a23(fsmc_a23) ,	// input  fsmc_a23
	.fsmc_a22(fsmc_a22) ,	// input  fsmc_a22
	.fsmc_a21(fsmc_a21) ,	// input  fsmc_a21
	.fsmc_a20(fsmc_a20) ,	// input  fsmc_a20
	.fsmc_a19(fsmc_a19) ,	// input  fsmc_a19
	.fsmc_a18(fsmc_a18) ,	// input  fsmc_a18
	.fsmc_a17(fsmc_a17) ,	// input  fsmc_a17
	.fsmc_a16(fsmc_a16) ,	// input  fsmc_a16
	.fsmc_nwait(fsmc_nwait) ,	// input  fsmc_nwait
	
	.fsmc_register0(fsmc_register0) ,	// output [15:0] fsmc_register0_sig
	.fsmc_register0_valid(fsmc_register0_valid) ,	// output  fsmc_register0_valid_sig
	.fsmc_register1(fsmc_register1) ,	// output [15:0] fsmc_register1_sig
	.fsmc_register1_valid(fsmc_register1_valid) ,	// output  fsmc_register1_valid_sig
	.fsmc_register2(fsmc_register2) ,	// output [15:0] fsmc_register2_sig
	.fsmc_register2_valid(fsmc_register2_valid) ,	// output  fsmc_register2_valid_sig
	.fsmc_register3(fsmc_register3) ,	// output [15:0] fsmc_register3_sig
	.fsmc_register3_valid(fsmc_register3_valid) ,	// output  fsmc_register3_valid_sig
	.fsmc_register4(fsmc_register4) ,	// output [15:0] fsmc_register4_sig
	.fsmc_register4_valid(fsmc_register4_valid) ,	// output  fsmc_register4_valid_sig
	.fsmc_register5(fsmc_register5) ,	// output [15:0] fsmc_register5_sig
	.fsmc_register5_valid(fsmc_register5_valid) ,	// output  fsmc_register5_valid_sig
	.fsmc_register6(fsmc_register6) ,	// output [15:0] fsmc_register6_sig
	.fsmc_register6_valid(fsmc_register6_valid) ,	// output  fsmc_register6_valid_sig
	.fsmc_register7(fsmc_register7) ,	// output [15:0] fsmc_register7_sig
	.fsmc_register7_valid(fsmc_register7_valid) ,	// output  fsmc_register7_valid_sig
	.fsmc_rd_valid(fsmc_rd_valid) ,	// output  fsmc_rd_valid_sig
	.fsmc_rddata(fsmc_rddata) ,	// input [15:0] fsmc_rddata_sig
	.fsmc_addr_o(fsmc_addr_o) ,	// output [31:0] fsmc_addr_o_sig
	.fsmc_len_o(fsmc_len_o) ,	// output [31:0] fsmc_len_o_sig
	.fsmc_load(fsmc_load) 	// output  fsmc_load_sig
);
	

//----------SDRAM----------
wire [23:0]  av_address;
wire         av_chipselect;
wire [15:0]  av_writedata;
wire         av_write_n;
wire         av_read_n;
wire [15:0] av_readdata;
wire av_readdatavalid;
wire av_waitrequest;


sdram_ctrl sdram_ctrl_inst
(
	.clk_clk(clk_100m) ,	// input  clk_clk_sig
	.reset_reset_n(locked) ,	// input  reset_reset_n_sig
	
	.sdram_wire_addr(sdram_addr) ,	// output [12:0] sdram_wire_addr_sig
	.sdram_wire_ba(sdram_ba) ,	// output [1:0] sdram_wire_ba_sig
	.sdram_wire_cas_n(sdram_cas_n) ,	// output  sdram_wire_cas_n_sig
	.sdram_wire_cke(sdram_cke) ,	// output  sdram_wire_cke_sig
	.sdram_wire_cs_n(sdram_cs_n) ,	// output  sdram_wire_cs_n_sig
	.sdram_wire_dq(sdram_dq) ,	// inout [15:0] sdram_wire_dq_sig
	.sdram_wire_dqm(sdram_dqm) ,	// output [3:0] sdram_wire_dqm_sig
	.sdram_wire_ras_n(sdram_ras_n) ,	// output  sdram_wire_ras_n_sig
	.sdram_wire_we_n(sdram_we_n) ,	// output  sdram_wire_we_n_sig
	
	.sdram_s1_address(av_address) ,	// input [23:0] sdram_s1_address_sig
	.sdram_s1_byteenable_n(2'b00) ,	// input [1:0] sdram_s1_byteenable_n_sig
	.sdram_s1_chipselect(av_chipselect) ,	// input  sdram_s1_chipselect_sig
	.sdram_s1_writedata(av_writedata) ,	// input [15:0] sdram_s1_writedata_sig
	.sdram_s1_read_n(av_read_n) ,	// input  sdram_s1_read_n_sig
	.sdram_s1_write_n(av_write_n) ,	// input  sdram_s1_write_n_sig
	.sdram_s1_readdata(av_readdata) ,	// output [15:0] sdram_s1_readdata_sig
	.sdram_s1_readdatavalid(av_readdatavalid) ,	// output  sdram_s1_readdatavalid_sig
	.sdram_s1_waitrequest(av_waitrequest) 	// output  sdram_s1_waitrequest_sig
);

assign sdram_clk = clk_100m_p;

sdram_ops sdram_ops_inst
(
	.clk(clk_100m) ,	// input  clk_sig
	.rst_n(rstn) ,	// input  rst_n_sig
	.wr_en(fsmc_register3_valid) ,	// input  wr_en_sig
	.rd_en(fsmc_load) ,	// input  rd_en_sig
	.wrdata_i(fsmc_register3) ,	// input [15:0] wrdata_i_sig
	.address_i(fsmc_addr_o) ,	// input [23:0] address_i_sig
	
	.av_address(av_address) ,	// output [23:0] av_address_sig
	.av_chipselect(av_chipselect) ,	// output  av_chipselect_sig
	.av_writedata(av_writedata) ,	// output [15:0] av_writedata_sig
	.av_read_n(av_read_n) ,	// output  av_read_n_sig
	.av_write_n(av_write_n) ,	// output  av_write_n_sig
	.av_readdata(av_readdata) ,	// input [15:0] av_readdata_sig
	.av_readdatavalid(av_readdatavalid) ,	// input  av_readdatavalid_sig
	.av_waitrequest(av_waitrequest) ,	// input  av_waitrequest_sig
	
	.rddatavalid() ,	// output  rddatavalid_sig
	.readdata(fsmc_rddata) 	// output [15:0] readdata_sig
);


endmodule
