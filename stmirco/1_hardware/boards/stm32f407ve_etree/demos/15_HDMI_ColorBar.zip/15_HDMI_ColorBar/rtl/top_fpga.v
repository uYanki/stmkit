//file name:       top_fpga.v
//author:           ETree
//date:             2017.9.9
//function:        top file of project
//log:             

module top_fpga(
    //global signal
    input clk,  //50MHz
    input rst_n,//low active
	 
	 //HDMI
	 output hdmi_clk_p,
	 output hdmi_clk_n,
	 output [2:0] hdmi_data_p,
	 output [2:0] hdmi_data_n,
    
    //led
    output  led //high active
);

wire            vga_clk ;   //VGA工作时钟,频率25MHz
wire            clk_125m  ; //5倍vga_clk
wire            locked  ;   //PLL locked信号
wire    [11:0]  pix_x   ;   //VGA有效显示区域X轴坐标
wire    [11:0]  pix_y   ;   //VGA有效显示区域Y轴坐标
wire    [23:0]  pix_data;   //VGA像素点色彩信息
wire            hsync   ;   //输出行同步信号
wire            vsync   ;   //输出场同步信号
wire    [23:0]  rgb     ;   //输出像素信息
wire            rgb_valid;
wire sys_rstn;

assign sys_rstn = (rst_n & locked);


my_pll	my_pll_inst (
	.areset ( ~rst_n ),
	.inclk0 ( clk ),
	.c0 ( vga_clk ),
	.c1 ( clk_125m ),
	.locked ( locked )
	);

//------------- vga_ctrl_inst -------------
vga_ctrl  vga_ctrl_inst
(
    .vga_clk    (vga_clk    ),  //输入工作时钟,频率25MHz,1bit
    .rst_n      (sys_rstn   ),  //输入复位信号,低电平有效,1bit
    .pix_data   (pix_data   ),  //输入像素点色彩信息,24bit

    .pix_x      (pix_x      ),  //输出VGA有效显示区域像素点X轴坐标,12bit
    .pix_y      (pix_y      ),  //输出VGA有效显示区域像素点Y轴坐标,12bit
    .hsync      (hsync      ),  //输出行同步信号,1bit
    .vsync      (vsync      ),  //输出场同步信号,1bit
    .rgb_valid  (rgb_valid  ),
    .rgb        (rgb        )   //输出像素点色彩信息,24bit
);

//------------- vga_dat_inst -------------
vga_dat vga_dat_inst
(
    .vga_clk    (vga_clk    ),  //输入工作时钟,频率25MHz,1bit
    .rst_n      (sys_rstn   ),  //输入复位信号,低电平有效,1bit
    .pix_x      (pix_x      ),  //输入VGA有效显示区域像素点X轴坐标,10bit
    .pix_y      (pix_y      ),  //输入VGA有效显示区域像素点Y轴坐标,10bit

    .pix_data   (pix_data   )   //输出像素点色彩信息,16bit

);

//------------- hdmi_ctrl_inst -------------
hdmi_ctrl   hdmi_ctrl_inst
(
    .clk_1x      (vga_clk           ),   //输入系统时钟
    .clk_5x      (clk_125m          ),   //输入5倍系统时钟
    .rst_n       (sys_rstn          ),   //复位信号,低有效
    .rgb_blue    (rgb[7:0]          ),   //蓝色分量
    .rgb_green   (rgb[15:8]         ),   //绿色分量
    .rgb_red     (rgb[23:16]        ),   //红色分量
    .hsync       (hsync             ),   //行同步信号
    .vsync       (vsync             ),   //场同步信号
    .de          (rgb_valid         ),   //使能信号
    .hdmi_clk_p  (hdmi_clk_p        ),
    .hdmi_clk_n  (hdmi_clk_n        ),   //时钟差分信号
    .hdmi_r_p    (hdmi_data_p[2]    ),
    .hdmi_r_n    (hdmi_data_n[2]    ),   //红色分量差分信号
    .hdmi_g_p    (hdmi_data_p[1]    ),
    .hdmi_g_n    (hdmi_data_n[1]    ),   //绿色分量差分信号
    .hdmi_b_p    (hdmi_data_p[0]    ),
    .hdmi_b_n    (hdmi_data_n[0]    )    //蓝色分量差分信号
);

    
endmodule

