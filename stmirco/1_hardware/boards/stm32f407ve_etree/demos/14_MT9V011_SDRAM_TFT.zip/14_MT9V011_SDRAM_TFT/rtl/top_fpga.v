//file name:	top_fpga.v
//author:		ETree
//date:			2017.12.9
//function:		top file of project

module top_fpga(
	//global signal                           
	input  clk,
	input  rst_n,
	
	//CMOS Port
	output cam_scl,
	inout  cam_sda,
	input [7:0] cam_data,
	
	input cam_vsync,	
	input cam_hsync,
	input cam_pclk,
	output cam_xclk,

	output cam_pdown,
	output cam_reset,
	
	//sdram port
	output [12:0] sdram_addr, 
	output [1:0]  sdram_ba,   
	output sdram_cas_n,
	output sdram_cke  ,
	output sdram_cs_n ,
	inout  [15:0] sdram_dq,   
	output [1:0] sdram_dqm , 
	output sdram_ras_n,
	output sdram_we_n, 
	output sdram_clk,
	
	//TFT2.4
	output tft_cs,				//液晶屏片选，低电平有效
	output tft_wr,
	output tft_rs,
	output tft_rd,
	output tft_reset,			//液晶屏复位，低电平有效
	output [15:0] tft_data,
	output tft_blk,				//液晶屏背光，高电平有效
	//TFT Touch
	output tft_tclk,
	output tft_tcs,
	output tft_tmosi,
	input  tft_tmiso,
	input  tft_tpen,
	
	//VGA
	output vga_hsync,
	output vga_vsync,
	output [4:0] vga_red,
	output [5:0] vga_green,
	output [4:0] vga_blue,

   //ledsm
//	output [7:0] sm_dat,
	output [1:0] sm_sel,
	
	//led
	output led
	
);

//------------PLL----------------
wire clk_25m;
wire clk_100m;
wire clk_100m_p;
wire locked;
	
my_pll my_pll_inst(
	.areset ( 0 ),
	.inclk0 ( clk ),
	.c0 ( clk_100m ),
	.c1 ( clk_100m_p ),
	.c2 ( clk_25m ),
	.locked ( locked )
	);	
	
assign sm_sel = 2'b11;

//---------------Soft Reset--------------
reg [15:0] rst_cnt; 
reg rstn;

always @(posedge clk_25m)
	if(~rst_n)
		rst_cnt <= 0;
	else if(rst_cnt>='hfffa)
		rst_cnt <= rst_cnt;
	else
		rst_cnt <= rst_cnt + 1'b1;
		
always @(posedge clk_25m)
	if(rst_cnt>='hfff0)
		rstn <= 1'b1;
	else
		rstn <= 0;		
	
//---------------CMOS--------------------
wire [7:0] cam_data_out;
wire cam_vsync_out;
wire cam_hsync_out;
wire [15:0] cam_data_test;
wire cam_vsync_test;
wire cam_hsync_test;

camera_if camera_if_inst
(
	.clk(clk_25m) ,	// input  clk_sig
	.rst_n(rstn) ,	// input  rst_n_sig
	.cam_scl(cam_scl) ,	// output  cam_scl_sig
	.cam_sda(cam_sda) ,	// inout  cam_sda_sig
	
	.cam_data(cam_data) ,	// input [7:0] cam_data_sig
	
	.cam_vsync(cam_vsync) ,	// input  cam_vsync_sig
	.cam_hsync(cam_hsync) ,	// input  cam_hsync_sig
	.cam_pclk(cam_pclk) ,	// input  cam_pclk_sig
	.cam_xclk(cam_xclk) ,	// output  cam_xclk_sig
	
	.cam_pdown(cam_pdown) ,	// output  cam_pdown_sig
	.cam_reset(cam_reset) ,	// output  cam_reset_sig
	
	.cam_data_out(cam_data_out),
	.cam_vsync_out(cam_vsync_out),
	.cam_hsync_out(cam_hsync_out),
	
	.cam_data_test(cam_data_test),
	.cam_vsync_test(cam_vsync_test),
	.cam_hsync_test(cam_hsync_test),
	
	.line_count(line_count),
	.cam_en(1'b1)	// input  cam_en_sig
);	

defparam camera_if_inst.IMG_H=640;	  


//------------Video Image Process--------------

wire [15:0] dvp_data_o;
wire dvp_href_o;
wire dvp_vsync_o;

vip_top vip_top_inst
(
	.cmos_pclk(cam_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cam_hsync_out) ,	// input  cmos_href_sig
	.cmos_vsync(cam_vsync_out) ,	// input  cmos_vsync_sig
	.cmos_data(cam_data_out) ,	// input [7:0] cmos_data_sig
	.cmos_href_o(dvp_href_o) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(dvp_vsync_o) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(dvp_data_o) 	// output [7:0] cmos_data_o_sig
);


//----------SDRAM----------

Sdram_Control_2Port	Sdram_Control_2Port_inst
(
	//HOST
	.REF_CLK				(clk_100m),			//sdram module clock
	.OUT_CLK				(clk_100m_p),		//sdram clock input
	.RESET_N				(rstn),		      //sdram module reset

	//SDRAM
	.SDR_CLK				(sdram_clk),		//sdram clock
	.CKE					(sdram_cke),		//sdram clock enable
	.CS_N					(sdram_cs_n),		//sdram chip select
	.WE_N					(sdram_we_n),		//sdram write enable
	.CAS_N				(sdram_cas_n),		//sdram column address strobe
	.RAS_N				(sdram_ras_n),		//sdram row address strobe
	.DQM					(),//(sdram_dqm),		//sdram data output enable
	.BA					(sdram_ba),			//sdram bank address
	.SA					(sdram_addr),		//sdram address
	.DQ					(sdram_dq),		//sdram data

	//FIFO Write
	.WR_CLK				(cam_pclk),		//write fifo clock
	.WR_LOAD				(1'b0),				//write register load & fifo clear
	.WR_DATA				(dvp_data_o),		//write data input
	.WR					(dvp_href_o),			//write data request
	.WR_MIN_ADDR		(0),			//write start address
	.WR_MAX_ADDR		(307200-1),	//write max address
	.WR_LENGTH			(9'd128),			//write burst length

	//FIFO Read
	.RD_CLK				(clk),			//read fifo clock
	.RD_LOAD			   (1'b0),				//read register load & fifo clear
	.RD_DATA			   (fifo_q),		//read data output
	.RD					(fifo_rd),			//read request
	.RD_MIN_ADDR		(0),            //read start address
	.RD_MAX_ADDR		(76800-1),	//read max address
	.RD_LENGTH			(9'd128),			//read length
);

assign sdram_dqm = 2'b00;

//-----------TFT-------------	

wire config_done;
wire [15:0] fifo_q;

tft24 tft24_inst
(
	.clk(clk) ,	// input  clk_sig
	.rst_n(rstn) ,	// input  rst_n_sig
	.tft_cs(tft_cs) ,	// output  tft_cs_sig
	.tft_rs(tft_rs) ,	// output  tft_rs_sig
	.tft_rd(tft_rd) ,	// output  tft_rd_sig
	.tft_wr(tft_wr) ,	// output  tft_wr_sig
	.tft_dat(tft_data) ,	// output [15:0] tft_dat_sig
	.tft_res(tft_reset) ,	// output  tft_res_sig
	.data_in(fifo_q),
	.data_in_req(fifo_rd),
	.fifo_empty(0),
	.config_done(config_done) 	// output  config_done_sig
);

assign tft_blk     = 1'b1;


endmodule
