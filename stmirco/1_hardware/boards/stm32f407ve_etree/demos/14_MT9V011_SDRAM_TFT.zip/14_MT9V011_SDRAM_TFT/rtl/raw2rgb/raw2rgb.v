//file name:	raw2rgb.v
//author:      ETree
//date:		   2017.11.4
//function:		RAW8转RGB888
//log:			GB/RG

module raw2rgb(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg [10:0] v_cnt,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [15:0] cmos_data_o,
	output reg [7:0] cmos_data_red,
	output reg [7:0] cmos_data_green,
	output reg [7:0] cmos_data_blue
);

parameter IMG_H = 640;

//reg [10:0] v_cnt; 	
reg [11:0] h_cnt;

always @(posedge cmos_pclk)
	if(cmos_href)
		h_cnt <= h_cnt + 1'b1;
	else
		h_cnt <= 0;
	
always @(posedge cmos_pclk)
	if(cmos_vsync)
		v_cnt <= 0;
	else if(h_cnt==(IMG_H-1))
		v_cnt <= v_cnt + 1'b1;
	else
		v_cnt <= v_cnt;
		
wire [7:0] shiftout;
		
shift_ram1	shift_ram1_inst (
	.clock ( cmos_pclk ),
	.clken (cmos_href) ,
	.shiftin ( cmos_data ),
	.shiftout ( shiftout ),
	.taps (  )
	);
		
reg [7:0] shiftout_r0;

always @(posedge cmos_pclk)
	shiftout_r0 <= shiftout;
	
reg [7:0] cmos_data_r0;

always @(posedge cmos_pclk)
begin
	cmos_data_r0 <= cmos_data;
end

reg [7:0] red;
reg [7:0] green;
reg [7:0] blue;	
	
always @(posedge cmos_pclk)
	case({h_cnt[0],v_cnt[0]})
	2'b00:	//偶数行/偶数列
	begin
		red <= shiftout;
		green <= cmos_data/2 + shiftout_r0/2;
		blue <= cmos_data_r0;
	end
	2'b10:	//偶数行/奇数列
	begin
		red <= shiftout_r0;
		green <= cmos_data_r0/2 + shiftout/2;
		blue <= cmos_data;	
	end
	2'b01:	//奇数行/偶数列
	begin
		red <= cmos_data;
		green <= cmos_data_r0/2 + shiftout/2;
		blue <= shiftout_r0;	
	end
	2'b11:	//奇数行/奇数列
	begin
		red <= cmos_data_r0;
		green <= cmos_data/2 + shiftout_r0/2;
		blue <= shiftout;	
	end	
	default: 
	begin
		red <= 8'hff;
		green <= 8'hff;
		blue <= 8'hff;
	end
	endcase
	
	
reg cmos_href_r0;
reg cmos_href_r1;

always @(posedge cmos_pclk)
begin
	cmos_href_r0 <= cmos_href;
	cmos_href_r1 <= cmos_href_r0;
end
	
always @(posedge cmos_pclk)
begin
	cmos_href_o <= cmos_href_r0 & h_cnt[0] & v_cnt[0];
	cmos_vsync_o <= cmos_vsync;
	cmos_data_red <= red;
	cmos_data_green <= green;
	cmos_data_blue <= blue;
	cmos_data_o <= {red[7:3],green[7:2],blue[7:3]};
end


	
endmodule
