create_clock -name clk_50m -period 20.000 [get_ports {clk}]
create_clock -name cmos_pclk -period 40.000 [get_ports {cam_pclk}]



