//file name:	top_fpga.v
//author:		ETree
//date:			2017.12.9
//function:		top file of project

module top_fpga(
	//global signal                           
	input  clk,
	input  rst_n,
	
	//STM32
	//FSMC Bus
	inout [15:0] fsmc_data,
	input fsmc_noe,
	input fsmc_nwe,
	input fsmc_nbl0,
	
	input fsmc_nbl1,
	input fsmc_ne1, 
	input fsmc_a23,
	input fsmc_a22,
	input fsmc_a21,
	input fsmc_a20,
	input fsmc_a19,
	input fsmc_a18,
	input fsmc_a17,
	input fsmc_a16,
	input fsmc_nwait,
	input fsmc_clk,
	
	//sdram port
	output [12:0] sdram_addr, 
	output [1:0]  sdram_ba,   
	output sdram_cas_n,
	output sdram_cke  ,
	output sdram_cs_n ,
	inout  [15:0] sdram_dq,   
	output [1:0] sdram_dqm , 
	output sdram_ras_n,
	output sdram_we_n, 
	output sdram_clk,
	
	//VGA
	output vga_hsync,
	output vga_vsync,
	output [4:0] vga_red,
	output [5:0] vga_green,
	output [5:0] vga_blue,

   //ledsm
//	output [7:0] sm_dat,
	output [1:0] sm_sel,
	
	//led
	output led
	
);


//------------PLL----------------
wire clk_12m;
wire clk_25m;
wire clk_100m;
wire clk_100m_p;
wire locked;
	
my_pll my_pll_inst(
	.areset ( 0 ),
	.inclk0 ( clk ),
	.c0 ( clk_100m ),
	.c1 ( clk_100m_p ),
	.c2 ( clk_25m ),
	.locked ( locked )
	);	
	
assign sm_sel = 2'b11;

//---------------Soft Reset--------------
reg [15:0] rst_cnt; 
reg rstn;

always @(posedge clk_25m)
	if(~locked)
		rst_cnt <= 0;
	else if(rst_cnt>='hfffa)
		rst_cnt <= rst_cnt;
	else
		rst_cnt <= rst_cnt + 1'b1;
		
always @(posedge clk_25m)
	if(rst_cnt>='hfff0)
		rstn <= 1'b1;
	else
		rstn <= 0;	

//----------FSMC-----------	
wire [15:0] fsmc_register3;
wire fsmc_reg3_valid;
wire [31:0] fsmc_addr_o;
wire fsmc_load;

fsmc_reg fsmc_reg_inst
(
	.clk(clk_100m) ,	// input  clk_sig
	.rst_n(rst_n) ,	// input  rst_n_sig
	.fsmc_data(fsmc_data) ,	// inout [15:0] fsmc_data
	.fsmc_noe(fsmc_noe) ,	// input  fsmc_noe
	.fsmc_nwe(fsmc_nwe) ,	// input  fsmc_nwe
	.fsmc_ne1(fsmc_ne1) ,	// input  fsmc_ne1
	.fsmc_a23(fsmc_a23) ,	// input  fsmc_a23
	.fsmc_a22(fsmc_a22) ,	// input  fsmc_a22
	.fsmc_a21(fsmc_a21) ,	// input  fsmc_a21
	.fsmc_a20(fsmc_a20) ,	// input  fsmc_a20
	.fsmc_a19(fsmc_a19) ,	// input  fsmc_a19
	.fsmc_a18(fsmc_a18) ,	// input  fsmc_a18
	.fsmc_a17(fsmc_a17) ,	// input  fsmc_a17
	.fsmc_a16(fsmc_a16) ,	// input  fsmc_a16
	.fsmc_nwait(fsmc_nwait) ,	// input  fsmc_nwait
	.fsmc_register3(fsmc_register3), 	// output [15:0] fsmc_register0
	.fsmc_register3_valid(fsmc_reg3_valid),
	.fsmc_addr_o(fsmc_addr_o),
	.fsmc_load(fsmc_load)
);
	

//----------SDRAM----------

Sdram_Control_2Port	Sdram_Control_2Port_inst
(
	//HOST
	.REF_CLK				(clk_100m),			//sdram module clock
	.OUT_CLK				(clk_100m_p),		//sdram clock input
	.RESET_N				(locked),		      //sdram module reset

	//SDRAM
	.SDR_CLK				(sdram_clk),		//sdram clock
	.CKE					(sdram_cke),		//sdram clock enable
	.CS_N					(sdram_cs_n),		//sdram chip select
	.WE_N					(sdram_we_n),		//sdram write enable
	.CAS_N				(sdram_cas_n),		//sdram column address strobe
	.RAS_N				(sdram_ras_n),		//sdram row address strobe
	.DQM					(),//(sdram_dqm),		//sdram data output enable
	.BA					(sdram_ba),			//sdram bank address
	.SA					(sdram_addr),		//sdram address
	.DQ					(sdram_dq),		//sdram data

	//FIFO Write
	.WR_CLK				(clk_100m),		//write fifo clock
	.WR_LOAD				(1'b0),				//write register load & fifo clear
	.WR_DATA				(fsmc_register3),		//write data input
	.WR					(fsmc_reg3_valid),			//write data request
	.WR_MIN_ADDR		(fsmc_addr_o),			//write start address
	.WR_MAX_ADDR		(fsmc_addr_o),	//write max address
	.WR_LENGTH			(9'd1),			//write burst length

	//FIFO Read
	.RD_CLK				(vga_pclk),			//read fifo clock
	.RD_LOAD			   (1'b0),				//read register load & fifo clear
	.RD_DATA			   (vga_datain),		//read data output
	.RD					(vga_hs),			//read request
	.RD_MIN_ADDR		(0),            //read start address
	.RD_MAX_ADDR		(307200),	//read max address
	.RD_LENGTH			(9'd128),			//read length
);

assign sdram_dqm = 2'b00;

//--------------VGA-----------------
wire [15:0] vga_datain;
wire vga_vs;
wire vga_hs;
wire vga_pclk;

vga_interface vga_interface_inst
(
	.clk_25m(clk_25m) ,	// input  clk_25m_sig
	.rst_n(rstn) ,	// input  rst_n_sig

	.lcd_hs(vga_hsync) ,	// output  lcd_hs_sig
	.lcd_vs(vga_vsync) ,	// output  lcd_vs_sig
	.lcd_red(vga_red) ,	// output [9:0] lcd_red_sig
	.lcd_green(vga_green) ,	// output [9:0] lcd_green_sig
	.lcd_blue(vga_blue) ,	// output [9:0] lcd_blue_sig
	
	.vga_datain(vga_datain) ,	// input [15:0] vga_datain_sig
	.vga_pclk(vga_pclk) ,	// output  vga_pclk_sig
	.vga_vsync(vga_vs) ,	// output  vga_vsync_sig
	.vga_hsync(vga_hs) 	// output  vga_hsync_sig
);



endmodule
