//file name:	vip_top.v
//author:      ETree
//date:		   2017.10.18
//function:		VIP top file
//log:

module vip_top(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output cmos_href_o,
	output cmos_vsync_o,
	output [15:0] cmos_data_o
//	output [7:0] cmos_data_red,
//	output [7:0] cmos_data_green,
//	output [7:0] cmos_data_blue
);

wire [10:0] v_cnt;
wire cmos_href_raw2rgb;
wire cmos_vsync_raw2rgb;
wire [15:0] cmos_data_raw2rgb;
wire [7:0] cmos_data_cred;
wire [7:0] cmos_data_cgreen;
wire [7:0] cmos_data_cblue;

raw2rgb raw2rgb_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync) ,	// input  cmos_vsync_sig
	.cmos_data(cmos_data) ,	// input [7:0] cmos_data_sig
	.v_cnt(v_cnt) ,	      // output [10:0] v_cnt_sig
	.cmos_href_o(cmos_href_raw2rgb) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_raw2rgb) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_raw2rgb),
	.cmos_data_red(cmos_data_cred) ,	// output [7:0] cmos_data_red_sig
	.cmos_data_green(cmos_data_cgreen) ,	// output [7:0] cmos_data_green_sig
	.cmos_data_blue(cmos_data_cblue) 	// output [7:0] cmos_data_blue_sig
);


assign cmos_vsync_o = cmos_vsync_raw2rgb;
assign cmos_href_o  = cmos_href_raw2rgb;
assign cmos_data_o  = cmos_data_raw2rgb;

//assign cmos_data_red = (v_cnt==0)?0:cmos_data_cred;
//assign cmos_data_green = (v_cnt==0)?0:cmos_data_cgreen;
//assign cmos_data_blue = (v_cnt==0)?0:cmos_data_cblue;


endmodule
