module video_gen(
	input clk,//25.175MHz
	input rst_n,
	
	input  [15:0] vga_datain,
	
	output reg vsyn,
	output reg hsyn,
	output reg [15:0] video_data_out,		//VGA565
	output reg video_valid
);

parameter IMG_HDISP = 16'd640;
parameter IMG_VDISP = 16'd480; 

reg [11:0] hcnt;
reg [11:0] vcnt;

always @(posedge clk)
begin
	if(~rst_n)
		hcnt <= 0;
	else if(hcnt>=12'd799)
		hcnt <= 0;
	else 
		hcnt <= hcnt + 1'b1;
end


always @(posedge clk)
begin 
	if(~rst_n)
		vcnt <= 0;
	else if(hcnt>=12'd799)
		if(vcnt>=12'd524)
			vcnt <= 0;
		else
			vcnt <= vcnt + 1'b1;
	else
		vcnt <= vcnt;
end

always @(posedge clk)
begin
	hsyn <= (hcnt>=12'd13 && hcnt<12'd109);	//96
end

always @(posedge clk)
begin
	vsyn <= (vcnt>=12'd9 && vcnt<12'd11);
end

always @(posedge clk)
begin
	video_valid <= (hcnt>=12'd160 && hcnt<=12'd799) && (vcnt>=12'd45 && vcnt<=12'd524);
end

always @(*)
	if(video_valid)
		video_data_out <= vga_datain;
	else
		video_data_out <= 0;


endmodule

