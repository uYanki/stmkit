//file name:       fsmc_reg.v
//author:           ETree
//date:             2020.10.4
//function:        fsmc register 
//log:   

module fsmc_reg(
	input clk,
	input rst_n,
	
	//FSMC Bus
	inout [15:0] fsmc_data,
	input fsmc_noe,
	input fsmc_nwe,
	input fsmc_ne1, 	
	input fsmc_a23,
	input fsmc_a22,
	input fsmc_a21,
	input fsmc_a20,
	input fsmc_a19,
	input fsmc_a18,
	input fsmc_a17,
	input fsmc_a16,
	input fsmc_nwait,
	
		output reg [15:0] fsmc_register0,
	output reg fsmc_register0_valid,
		output reg [15:0] fsmc_register1,
	output reg fsmc_register1_valid,
		output reg [15:0] fsmc_register2,
	output reg fsmc_register2_valid,
		output reg [15:0] fsmc_register3,
	output reg fsmc_register3_valid,
		output reg [15:0] fsmc_register4,
	output reg fsmc_register4_valid,
		output reg [15:0] fsmc_register5,
	output reg fsmc_register5_valid,
		output reg [15:0] fsmc_register6,
	output reg fsmc_register6_valid,
		output reg [15:0] fsmc_register7,
	output reg fsmc_register7_valid,
	
	output reg [31:0] fsmc_addr_o,
	output reg [31:0] fsmc_len_o,
	output reg        fsmc_load
);


reg nwe_r0;
reg nwe_r1;
reg ne1_r0;
reg noe_r0;
reg noe_r1;

always @(posedge clk)
	if(~rst_n)
	begin
		nwe_r0 <= 0;
		nwe_r1 <= 0;
		ne1_r0 <= 0;
		noe_r0 <= 0;
		noe_r1 <= 0;
	end
	else
	begin
		nwe_r0 <= fsmc_nwe;
		nwe_r1 <= nwe_r0;
		ne1_r0 <= fsmc_ne1;
		noe_r0 <= fsmc_noe;
		noe_r1 <= noe_r0;
	end

wire nwe_neg;
assign nwe_neg = (nwe_r0==1'b0 && nwe_r1==1'b1);

wire noe_neg;
assign noe_neg = (noe_r0==1'b0 && noe_r1==1'b1);

parameter IDLE		= 0;
parameter FSMC_WR = 1;
parameter FSMC_RD = 2;
parameter END     = 3;

reg [1:0]  fsmc_state; 
//reg [15:0] fsmc_register0;
    
always @(posedge clk)
	if(~rst_n)
	begin
		fsmc_state <= IDLE;
				fsmc_register0 <= 0;
		fsmc_register0_valid <= 0;
				fsmc_register1 <= 0;
		fsmc_register1_valid <= 0;
				fsmc_register2 <= 0;
		fsmc_register2_valid <= 0;
				fsmc_register3 <= 0;
		fsmc_register3_valid <= 0;
				fsmc_register4 <= 0;
		fsmc_register4_valid <= 0;
				fsmc_register5 <= 0;
		fsmc_register5_valid <= 0;
				fsmc_register6 <= 0;
		fsmc_register6_valid <= 0;
				fsmc_register7 <= 0;
		fsmc_register7_valid <= 0;
		fsmc_load            <= 0;
	end
	else
	begin
		case(fsmc_state)
		IDLE:
		begin
			fsmc_register0_valid <= 0;
			fsmc_register1_valid <= 0;
			fsmc_register2_valid <= 0;
			fsmc_register3_valid <= 0;
			fsmc_register4_valid <= 0;
			fsmc_register5_valid <= 0;
			fsmc_register6_valid <= 0;
			fsmc_register7_valid <= 0;
			fsmc_load            <= 0;
			if(ne1_r0==1'b0 && nwe_neg==1'b1)
				fsmc_state <= FSMC_WR;	
			else if(ne1_r0==1'b0 && noe_neg==1'b1)
				fsmc_state <= FSMC_RD;
			else
				fsmc_state <= IDLE;	
		end
		FSMC_WR:
		begin
			case({fsmc_a18,fsmc_a17,fsmc_a16})
			3'b000:
			begin
				fsmc_register0 <= fsmc_data;
				fsmc_register0_valid <= 1'b1;
			end
			3'b001:
			begin
				fsmc_register1 <= fsmc_data;
				fsmc_register1_valid <= 1'b1;	
				fsmc_addr_o[15:0] <= fsmc_data;	
				
			end
			3'b010:
			begin
				fsmc_register2 <= fsmc_data;
				fsmc_register2_valid <= 1'b1;	
				fsmc_addr_o[31:16] <= fsmc_data;
				fsmc_load <= 1'b1;
			end
			3'b011:
			begin
				fsmc_register3 <= fsmc_data;
				fsmc_register3_valid <= 1'b1;	
				fsmc_load <= 1'b0;
			end
			3'b100:
			begin
				fsmc_register4 <= fsmc_data;
				fsmc_register4_valid <= 1'b1;	
			end
			3'b101:
			begin
				fsmc_register5 <= fsmc_data;
				fsmc_register5_valid <= 1'b1;	
				fsmc_load <= 0;	
			end
			3'b110:
			begin
				fsmc_register6 <= fsmc_data;
				fsmc_register6_valid <= 1'b1;	
				fsmc_load <= 0;		
			end
			3'h111:
			begin
				fsmc_register7 <= fsmc_data;
				fsmc_register7_valid <= 1'b1;	
				fsmc_load <= 0;				
			end
			default:;
			endcase
			fsmc_state <= END;
		end
		FSMC_RD:
		begin
			if(noe_r1==1'b1)
				fsmc_state <= END;
			else
				fsmc_state <= FSMC_RD;
		end
		END:
		begin
			fsmc_state <= IDLE;
			fsmc_register0_valid <= 0;
			fsmc_register1_valid <= 0;
			fsmc_register2_valid <= 0;
			fsmc_register3_valid <= 0;
			fsmc_register4_valid <= 0;
			fsmc_register5_valid <= 0;
			fsmc_register6_valid <= 0;
			fsmc_register7_valid <= 0;
			fsmc_load            <= 0;
		end
		default:
		begin
		
		end
		endcase
	end
	
assign fsmc_data = (fsmc_state==FSMC_RD)?fsmc_register3:'hzzzz;	 
			  
			  
endmodule
