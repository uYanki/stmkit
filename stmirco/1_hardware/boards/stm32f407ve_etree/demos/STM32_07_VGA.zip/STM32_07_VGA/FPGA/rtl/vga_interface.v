//file name			: vga_interface
//date				: 2015.10.22
//author				: ETree
//function			: vga interface
//log					:

module vga_interface(
	//global signal
	input clk_25m,	//25.175MHz	-- 640*480p60
	input rst_n,
	
	//vga port
	output			lcd_dclk,	//lcd pixel clock
	output			lcd_blank,	//lcd blank(L:blank)		
	output			lcd_sync,	//lcd sync	
	output			lcd_hs,		//lcd horizontal sync 
	output			lcd_vs,		//lcd vertical sync
	output	[4:0]	lcd_red,		//lcd red data
	output	[5:0]	lcd_green,	//lcd green data
	output	[4:0]	lcd_blue,	//lcd blue data	
	
	//export
	input [15:0] 	vga_datain,
	output 			vga_pclk,
	output			vga_vsync,
	output 			vga_hsync
);

wire [7:0] vga_red;
wire [7:0] vga_green;
wire [7:0] vga_blue;


wire vsyn;
wire hsyn;
wire [15:0] video_data_out;
wire video_valid;

assign lcd_vs = ~vsyn;
assign lcd_hs = ~hsyn;

assign lcd_red = video_data_out[15:11];
assign lcd_green = video_data_out[10:5];
assign lcd_blue = video_data_out[4:0];

assign lcd_blank = 1'b1;
assign lcd_sync  = 1'b0;
assign lcd_dclk  = clk_25m;

assign vga_pclk  = clk_25m;
assign vga_vsync = vsyn;
assign vga_hsync = video_valid;

video_gen video_gen_inst
(
	.clk(clk_25m) ,	// input  clk_sig
	.rst_n(rst_n) ,	// input  rst_n_sig
	.vga_datain(vga_datain),
	.vsyn(vsyn) ,	// output  vsyn_sig
	.hsyn(hsyn) ,	// output  hsyn_sig
	.video_data_out(video_data_out) ,	// output [15:0] video_data_out_sig
	.video_valid(video_valid) 	// output  video_valid_sig
);



endmodule
