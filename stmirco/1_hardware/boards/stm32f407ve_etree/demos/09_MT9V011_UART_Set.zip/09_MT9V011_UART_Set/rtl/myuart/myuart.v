//file name:       myuart.v
//author:           ETree
//date:             2017.7.29
//function:        串口发送与接收顶层模块
//log:  

module myuart(
		input clk,
		input rst_n,
		
		input rxd,
		output txd,
		
		output  rx_done,
		output [23:0] data_out
);

wire bps_start1;
wire bps_start2;
wire clk_bps1;
wire clk_bps2;


speed_select inst_rx(
		clk,
		rst_n,
		bps_start1,
		clk_bps1
);

myuart_rx inst_myuart_rx(
		clk,
		rst_n,
		bps_start1,
		clk_bps1,
		rxd,
		rx_done,
		data_out
);


endmodule

