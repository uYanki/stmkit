//file name			: frame_counter.v
//data				: 2017.10.1
//author				: etree
//function			: frame counter
//log					:

module frame_counter(
	input clk, //50MHz
	input rst_n,
	
	input cmos_vsync,
	
	//ledsm
	output [7:0] sm_dat,
	output [3:0] sm_sel
);

//--------frame count--------
reg [25:0] cnt_1sec;
reg [7:0] cnt_freq;
reg [1:0] cmos_vsync_r;
reg [15:0] frame_out;

always @(posedge clk)
	cmos_vsync_r <= {cmos_vsync_r[0],cmos_vsync};
	
wire cmos_vsync_pos = (cmos_vsync_r==2'b01);	

always @(posedge clk)
	if(~rst_n)
		cnt_1sec <= 0;
	else if(cnt_1sec==49_999_999)
		cnt_1sec <= 0;
	else
		cnt_1sec <= cnt_1sec + 1'b1;

		
always @(posedge clk)
	if(~rst_n)
	begin
		cnt_freq <= 0;
	end
	else if(cnt_1sec<49_999_999)
	begin
		if(cmos_vsync_pos)
			if(cnt_freq[3:0]>=4'd9)
			begin
				cnt_freq[3:0] <= 0;
				cnt_freq[7:4] <= cnt_freq[7:4] + 1'b1;
			end
			else
			begin
				cnt_freq[3:0] <= cnt_freq[3:0] + 1'b1;
				cnt_freq[7:4] <= cnt_freq[7:4];
			end
		else
			cnt_freq <= cnt_freq;
	end
	else
		cnt_freq <= 0;

always @(posedge clk)
	if(~rst_n)
		frame_out <= 0;
	else if(cnt_1sec==49_999_998)
		frame_out <= cnt_freq;
	else
		frame_out <= frame_out;

//--------数码管显示-------------
parameter ZERO    = 8'b0000_0011,//8'b1100_0000, 
			 ONE     = 8'b1001_1111,//8'b1111_1001,  
			 TWO     = 8'b0010_0101,//8'b1010_0100, 
			 THREE   = 8'b0000_1101,//8'b1011_0000,
			 FOUR    = 8'b1001_1001,//8'b1001_1001, 
			 FIVE    = 8'b0100_1001,//8'b1001_0010, 
			 SIX     = 8'b0100_0001,//8'b1000_0010,
			 SEVEN   = 8'b0001_1111,//8'b1111_1000, 
			 EIGHT   = 8'b0000_0001,//8'b1000_0000,
			 NINE    = 8'b0000_1001,//8'b1001_0000;
			 AA	   = 8'b0001_0001,
			 BB      = 8'b1100_0001,
			 CC      = 8'b0110_0011,
			 DD      = 8'b1000_0101,
			 EE      = 8'b0110_0001,
			 FF      = 8'b0111_0001;

reg [7:0] sm_dat_r;	//数码管段选
reg [3:0] sm_sel_r;	//数码管位选
reg [7:0] sm_dat_r0; //数码管段选寄存器0
reg [7:0] sm_dat_r1; //数码管段选寄存器1
reg [7:0] sm_dat_r2=0; //数码管段选寄存器0
reg [7:0] sm_dat_r3=0; //数码管段选寄存器1
reg [1:0] sm_cnt;		//数码管片选计数器
reg [19:0] timer1;	//1毫秒计数器

//--------数码管片选计数器-----------  
always @(posedge clk or negedge rst_n)
    if (~rst_n)
        timer1 <= 0; 							//计数器清零
    else if (timer1 == 32'd199_999)  
        timer1 <= 0;                    //计数器清零
    else
        timer1 <= timer1 + 1'b1;         //计数器加 1		  
	  
always @(posedge clk or negedge rst_n)
	if(~rst_n)
		sm_cnt <= 0;
	else if(timer1==0)
		sm_cnt <= sm_cnt + 1'b1;
	else
		sm_cnt <= sm_cnt;

//----------数码管译码----------
always @ (*)
	case( frame_out[3:0] )
	4'd0 : sm_dat_r0 <= ZERO;
	4'd1 : sm_dat_r0 <= ONE;
	4'd2 : sm_dat_r0 <= TWO;
	4'd3 : sm_dat_r0 <= THREE;
	4'd4 : sm_dat_r0 <= FOUR;
	4'd5 : sm_dat_r0 <= FIVE;
	4'd6 : sm_dat_r0 <= SIX;
	4'd7 : sm_dat_r0 <= SEVEN;
	4'd8 : sm_dat_r0 <= EIGHT;
	4'd9 : sm_dat_r0 <= NINE;
	4'd10: sm_dat_r0 <= AA ;
	4'd11: sm_dat_r0 <= BB ;
	4'd12: sm_dat_r0 <= CC ;
	4'd13: sm_dat_r0 <= DD ;
	4'd14: sm_dat_r0 <= EE ;
	4'd15: sm_dat_r0 <= FF ;
	default:sm_dat_r0 <= 8'hFF;
	endcase

always @ (*)
	case( frame_out[7:4] )
	4'd0 : sm_dat_r1 <= ZERO;
	4'd1 : sm_dat_r1 <= ONE;
	4'd2 : sm_dat_r1 <= TWO;
	4'd3 : sm_dat_r1 <= THREE;
	4'd4 : sm_dat_r1 <= FOUR;
	4'd5 : sm_dat_r1 <= FIVE;
	4'd6 : sm_dat_r1 <= SIX;
	4'd7 : sm_dat_r1 <= SEVEN;
	4'd8 : sm_dat_r1 <= EIGHT;
	4'd9 : sm_dat_r1 <= NINE;
	4'd10: sm_dat_r1 <= AA ;
	4'd11: sm_dat_r1 <= BB ;
	4'd12: sm_dat_r1 <= CC ;
	4'd13: sm_dat_r1 <= DD ;
	4'd14: sm_dat_r1 <= EE ;
	4'd15: sm_dat_r1 <= FF ;
	default:sm_dat_r1 <= 8'hFF;
	endcase


//---------数码管显示---------	
always @(sm_cnt)
	case(sm_cnt)
	'd0:
	begin
		sm_sel_r <= 4'b1101;
		sm_dat_r <= sm_dat_r0;	
	end
	'd1:
	begin
		sm_sel_r <= 4'b1110;
		sm_dat_r <= sm_dat_r1;	
	end
	'd2:
	begin
		sm_sel_r <= 4'b0111;
		sm_dat_r <= ZERO;	
	end	
	'd3:
	begin
		sm_sel_r <= 4'b1011;
		sm_dat_r <= ZERO;	
	end
	default:
	begin
		sm_sel_r <= 4'b1111;
		sm_dat_r <= ZERO;
	end
	endcase
	
assign sm_sel = sm_sel_r;
assign sm_dat = sm_dat_r;


endmodule

