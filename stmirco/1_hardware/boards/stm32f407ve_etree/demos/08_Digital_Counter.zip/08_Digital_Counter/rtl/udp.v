//file name: udp.v
//author:    shugenyin
//date:		 2018.1.2
//function:  UDP Sender
//log:


module udp(
			input           reset_n,
			
			input	          e_rxc,
			input 	[1:0]	 e_rxd, 
			input	          e_rxdv,
			output	       e_txen,
			output	[1:0]  e_txd,                              	
	
			output          fifo_rdclk,
			input  [7:0]    fifo_data,	
			input  [11:0]   fifo_data_count,
		   output          fifo_rd_en,   
			input           fifo_empty,

			input  [10:0]   frame_index,                          		
		
			input  [15:0]   tx_data_length,                       
			input  [15:0]   tx_total_length
);


wire [7:0] datain=8'h78; //发送的单位数据

wire	[31:0] crcnext;
wire	[31:0] crc32;
wire	crcreset;
wire	crcen;

//IP frame
ipsend ipsend_inst(
	.clk                     (~cnt_div[1]),
	.rst_n						 (reset_n),
	.txen                    (e_txen_w),
	.dataout                 (e_txd_8bit),
	
	.datain                  (fifo_data),
	.fifo_data_count         (fifo_data_count),     
   .fifo_rd_en              (fifo_rd_en),  
   .fifo_empty              (fifo_empty),	
	.frame_index             (frame_index), 		
	
	.crc                     (crc32),
	.crcen                   (crcen),
	.crcre                   (crcreset),
	.tx_state                (),
	.tx_data_length          (tx_data_length),
	.tx_total_length         (tx_total_length)

	);
	
//crc32
crc crc_inst(
	.Clk(cnt_div[1]),
	.Reset(crcreset),
	.Enable(crcen),
	.Data_in(e_txd_8bit),
	.Crc(crc32),
	.CrcNext(crcnext)
	);

reg [1:0] cnt_div;	

always @(posedge e_rxc)	
	cnt_div <= cnt_div + 1'b1;

wire [7:0] e_txd_8bit;
wire e_txen_w;
reg [1:0] e_txd_2bit;


always @(posedge e_rxc)
	case(cnt_div)
	'b00: e_txd_2bit <= e_txd_8bit[1:0];
	'b01: e_txd_2bit <= e_txd_8bit[3:2];
	'b10: e_txd_2bit <= e_txd_8bit[5:4];
	'b11: e_txd_2bit <= e_txd_8bit[7:6];
	default:;
	endcase
	
reg e_txen_r0;

always @(posedge e_rxc)
begin
	e_txen_r0 <= e_txen_w;
end
	
assign e_txen = e_txen_r0;
assign e_txd = e_txd_2bit;
assign fifo_rdclk = cnt_div[1];

	
endmodule
