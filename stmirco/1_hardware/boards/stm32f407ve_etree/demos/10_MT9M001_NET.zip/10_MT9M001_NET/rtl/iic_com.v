`timescale 1ns / 1ps

module iic_com(
			clk,
			rst_n,
			scl,
			//SCL_POS,SCL_HIG,SCL_NEG,SCL_LOW,
			sda_out
		);

input clk;						//  50MHz
input rst_n;					//  复位信号，低有效
output scl;						// 24C02的时钟端口
//output SCL_POS,SCL_HIG,SCL_NEG,SCL_LOW;
inout sda_out;


reg link;   					//sda输出标志
reg sda_buf;					//sda输出数据缓存

assign sda_out=link ? sda_buf:1'bz;



reg SCL_POS,SCL_HIG,SCL_NEG,SCL_LOW;	//SCL_POS 对应scl的上升沿时刻，
										//SCL_NEG 对应scl的下降沿时刻，
										//SCL_HIG 对应从scl高电平的中间时刻，
										//SCL_LOW 对应从scl低电平的中间时刻，
reg[15:0] clk_div;//分频计数器
//分频：系统时钟50M分频500倍，10KHZ
parameter div_parameter=5000;// 分频系数

always@(posedge clk or negedge rst_n)
begin
	if(!rst_n) begin
		clk_div<=0;
		SCL_POS<=0;
		SCL_HIG<=0;
		SCL_NEG<=0;
		SCL_LOW<=0;
	 end
	else begin
	
		if(clk_div!=div_parameter-1)
			clk_div<=clk_div+1'b1;
		else
			clk_div<=0;
			
		if(SCL_POS)
			SCL_POS<=0;	
		else if(clk_div==4999) 
			SCL_POS<=1;
			
		if(SCL_HIG)
			SCL_HIG<=0;
		else if(clk_div==1249)
			SCL_HIG<=1;
			
		if(SCL_NEG)
			SCL_NEG<=0;
		else if(clk_div==2499)
			SCL_NEG<=1;
			
		if(SCL_LOW)
			SCL_LOW<=0;
		else if(clk_div==3749)
			SCL_LOW<=1;
			
	 end
end
 
//器件地址
parameter  i2c_add	=8'hba;		
//寄存器地址和数据
wire [7:0]reg_add;
wire [15:0]reg_data;
reg [23:0]lut_data;

reg [7:0]lut_index;	

always @(*)
begin
    case(lut_index)
    0   :   lut_data    <=  24'h09_0419;//曝光时间  默认值 419
    1   :   lut_data    <=  {16'h3500,8'h51};//增益  0x08-0x20:1-4倍；   0x51-0x60 :4.25-8倍； 0x61-0x67: 9-15倍    
    2   :  lut_data     <=  24'h20_1180;
    3   :   lut_data    <=  24'h01000C; //row start
    4   :   lut_data    <=  24'h020014; //column start
    5   :   lut_data    <=  24'h0302cf; //number of rows -1:720
    6   :   lut_data    <=  24'h0404ff; //number of columns - 1:1280
    7   :   lut_data    <=  {8'h20,16'h9104};//SKIP=0   
	 8   :	lut_data		<=  24'h050059;
	 9	  :	lut_data    <=  24'h060019; 
    default:lut_data    <=  24'h000000;
    endcase
end


assign {reg_add,reg_data} = lut_data;



///////////////////////////I2C操作部分/////////////
reg scl;		
always@(posedge clk or negedge rst_n)
begin
	if(!rst_n) 
		scl<=1'b1;
	else
	begin
		if(SCL_POS)
			scl<=1;
		else if(SCL_NEG)
			scl<=0;
	end
end		
		

reg[3:0] i2c_state;				//对i2c操作的状态
reg[3:0] inner_state;			//i2c每一操作阶段内部状态


//I2C读写总线状态切换	i2c_state	  
parameter 
        wr_i2c_add=4'b0000, //初始化EEPROM状态， 写EEPROM器件地址（写操作）		
		  wr_reg_add=4'b0001, //发送地址状态	写字节地址			
		  wr_reg_highdata=4'b0010, //写数据状态	写字节地址对应的数据		
		  wr_reg_lowdata=4'b0011, //读数据状态	读数据									读IO低8位
		  i2c_idel=4'b0100; //发送读信息状态	 写EEPROM器件地址（读操作）

		  
//i2c每一操作阶段内部状态 inner_state
parameter 
        start=4'b0000, //开始
		  first=4'b0001, //第1位
		  second=4'b0010,//第2位
		  third=4'b0011, //第3位
		  fourth=4'b0100, //第4位
		  fifth=4'b0101, //第5位
		  sixth=4'b0110, //第6位
		  seventh=4'b0111, //第7位
		  eighth=4'b1000, //第8位
		  ack=4'b1001,   //确认位
		  stop=4'b1010; //结束位

always@(posedge clk or negedge rst_n)
begin
	if(!rst_n) 
	begin
		//start_delaycnt<=0;
		i2c_state<=i2c_idel;
		sda_buf<=1'b1;					//sda输入输出数据缓存
		link<=1'b0;					  //sda输出标志
		lut_index<=8'd0;
	 end
	else
	begin
		case(i2c_state)
			i2c_idel:
				begin					
				if(SCL_LOW) begin
					if(lut_index==11)
					begin	
						
						i2c_state<=i2c_idel;
					end
					else
					begin
					
					//	start_delaycnt<=1'b1;
						i2c_state<=wr_i2c_add;
						inner_state<=start;
					end	
				end
				end
				wr_i2c_add: begin  						 //写器件地址
						case(inner_state)
							start: begin
								if(SCL_HIG) begin
									link<=1;
									sda_buf<=0;				//起始位 0
								 end
								if(SCL_LOW&&link) begin
									inner_state<=first;
									sda_buf<=i2c_add[7];				//器件地址最高位
									link<=1;
								 end
							 end
							first: 
								if(SCL_LOW) begin
									sda_buf<=i2c_add[6];
									link<=1;
									inner_state<=second;
								 end
							second:
								if(SCL_LOW) begin
									sda_buf<=i2c_add[5];
									link<=1;
									inner_state<=third;
								 end
							third:
								if(SCL_LOW) begin
									sda_buf<=i2c_add[4];
									link<=1;
									inner_state<=fourth;
								 end
							fourth:
								if(SCL_LOW) begin
									sda_buf<=i2c_add[3];
									link<=1;
									inner_state<=fifth;
								 end
							fifth:
								if(SCL_LOW) begin
									sda_buf<=i2c_add[2];
									link<=1;
									inner_state<=sixth;
								 end
							sixth:
								if(SCL_LOW) begin
									sda_buf<=i2c_add[1];
									link<=1;
									inner_state<=seventh;
								 end
							seventh:
								if(SCL_LOW) begin
									sda_buf<=i2c_add[0];				//器件地址最低位
									link<=1;
									inner_state<=eighth;		
								 end
							eighth:
								if(SCL_LOW) begin
									link<=0;					
									inner_state<=ack;			
								 end
							ack: 
							begin					//应答
							//	if(SCL_POS) sda_buf<=sda_in;
								/*
								if(SCL_HIG)
								begin
									if(sda_buf==1) 			//应答不成功 返回到空闲状态
										main_state<=i2c_idel;
								 end
								 */
								if(SCL_LOW) begin			
									link<=1;
									sda_buf<=reg_add[7];
									inner_state<=first;
									i2c_state<=wr_reg_add;
								 end
							end
						 endcase
					 end
				wr_reg_add: begin  					//写寄存器地址
						case(inner_state)
							first: 
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_add[6];
									inner_state<=second;
								 end
							second:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_add[5];
									inner_state<=third;
								 end
							third:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_add[4];
									inner_state<=fourth;
								 end
							fourth:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_add[3];
									inner_state<=fifth;
								 end
							fifth:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_add[2];
									inner_state<=sixth;
								 end
							sixth:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_add[1];
									inner_state<=seventh;
								 end
							seventh:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_add[0];
									inner_state<=eighth;
								 end
							eighth:
								if(SCL_LOW) begin
									link<=0;
									inner_state<=ack;
								 end
							ack: begin
								//if(SCL_POS) sda_buf<=sda_in;
								/*	
								if(SCL_HIG) begin
									if(sda_buf==1) 
										main_state<=i2c_idel;
								 end
								 */
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[15];
									inner_state<=first;
									i2c_state<=wr_reg_highdata;
								 end
							 end
						 endcase
					 end
				wr_reg_highdata: 
				begin 					//发送高8位值
						case(inner_state)
							first: 
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[14];
									inner_state<=second;
								 end
							second:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[13];
									inner_state<=third;
								 end
							third:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[12];
									inner_state<=fourth;
								 end
							fourth:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[11];
									inner_state<=fifth;
								 end
							fifth:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[10];
									inner_state<=sixth;
								 end
							sixth:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[9];
									inner_state<=seventh;
								 end
							seventh:
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[8];
									inner_state<=eighth;
								 end
							eighth:
								if(SCL_LOW) begin
									link<=0;
									inner_state<=ack;
								 end
							ack: begin
								//if(SCL_POS) sda_buf<=sda_in;
								/*	
								if(SCL_HIG) begin
									if(sda_buf==1) 
										main_state<=i2c_idel;
								 end
								 
								else
								*/ 
								if(SCL_LOW) begin
									link<=1;
									sda_buf<=reg_data[7];				 
									inner_state<=first;
									i2c_state<=wr_reg_lowdata;
								 end
							 end
							
						 endcase
					end
				wr_reg_lowdata:		
				begin
					case(inner_state)
							first: 
								if(SCL_LOW) begin
									sda_buf<=reg_data[6];
									link<=1;
									inner_state<=second;
								 end
							second:
								if(SCL_LOW) begin
									sda_buf<=reg_data[5];
									link<=1;
									inner_state<=third;
								 end
							third:
								if(SCL_LOW) begin
									sda_buf<=reg_data[4];
									link<=1;
									inner_state<=fourth;
								 end
							fourth:
								if(SCL_LOW) begin
									sda_buf<=reg_data[3];
									link<=1;
									inner_state<=fifth;
								 end
							fifth:
								if(SCL_LOW) begin
									sda_buf<=reg_data[2];
									link<=1;
									inner_state<=sixth;
								 end
							sixth:
								if(SCL_LOW) begin
									sda_buf<=reg_data[1];
									link<=1;
									inner_state<=seventh;
								 end
							seventh:
								if(SCL_LOW) begin
									sda_buf<=reg_data[0];				//器件地址最低位
									link<=1;
									inner_state<=eighth;		
								 end
							eighth:
								if(SCL_LOW) begin
									link<=0;					
									inner_state<=ack;			
								 end
							ack: 
							begin					//应答
							//	if(SCL_POS) sda_buf<=sda_in;
								/*
								if(SCL_HIG)
								begin
									if(sda_buf==1) 			//应答不成功 返回到空闲状态
										main_state<=i2c_idel;
								 end
								*/ 
								if(SCL_LOW) begin			//应答成功 切换到写ROM字节地址状态
									link<=1;
									sda_buf<=0;
									inner_state<=stop;
									
								 end
							end
							
							stop: 
							begin
								if(SCL_HIG)
									sda_buf<=1;
								if(SCL_LOW) 
								begin
									link<=0;
									i2c_state<=i2c_idel;
									lut_index<=lut_index+1'b1;
								end
							 end

						 endcase
					 end

				default:
				i2c_state<=i2c_idel;
		 endcase
	
	
 end
end

endmodule 


