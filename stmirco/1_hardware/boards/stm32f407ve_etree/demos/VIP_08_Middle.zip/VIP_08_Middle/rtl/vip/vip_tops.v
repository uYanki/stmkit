//file name			: camera_if.v
//data				: 2017.10.8
//author				: ETree
//function			: Video Image Process, 提取R/G/B某一通道数据
//log					:


module vip_top(
	input clk,
	input rst_n,
	
	input dvp_pclk_i,
	input dvp_href_i,
	input dvp_vsync_i,
	input [7:0] dvp_data_i,
	
	output dvp_pclk_o,
	output dvp_href_o,
	output dvp_vsync_o,
	output [7:0] dvp_data_o
);

parameter IMG_H = 640;

reg [10:0] rdaddress;
reg [10:0] wraddress;
reg rdreq;
reg rd_flag;
wire [7:0] q;

assign dvp_pclk_o = dvp_pclk_i;
assign dvp_vsync_o = dvp_vsync_i;
assign dvp_data_o = (v_cnt==0)?0:dvp_data_p0;
assign dvp_href_o = dvp_href_p0;

always @(posedge dvp_pclk_i)
	if(dvp_vsync_i)
	begin
		wraddress <= 0;
	end
	else if(dvp_href_i)
		if(wraddress<1279)
			wraddress <= wraddress + 1'b1;
		else
			wraddress <= 0;
	else
		wraddress <= wraddress;


always @(posedge dvp_pclk_i)
	if(dvp_vsync_i)
		rdreq <= 0;
	else if(dvp_href_i)
		rdreq <= 1;
	else
		rdreq <= 0;

always @(posedge dvp_pclk_i)
	if(dvp_vsync_i)
		rd_flag <= 0;
	else 
		rd_flag <= ~rd_flag;
		
always @(posedge dvp_pclk_i)
	if(dvp_vsync_i)
		rdaddress <= 0;
	else if(dvp_href_i)
		if(rdaddress<639)
			rdaddress <= rdaddress + 1;
		else
			rdaddress <= 0;
	else
		rdaddress <= rdaddress;


line2_buf	line2_buf_inst (
	.clock ( dvp_pclk_i ),
	.data ( dvp_data_i ),
	.rdaddress ( {rdaddress[10:1],1'b1}),
	.rden ( rdreq ),
	.wraddress ( wraddress ),
	.wren ( dvp_href_i ),
	.q ( q )
	);


//-------------GAMMA-----------------
wire [7:0] q_gamma;

gamma_rom	gamma_rom_inst (
	.address ( q ),
	.clock ( dvp_pclk_i ),
	.q ( q_gamma )
	);
	
//-------------亮度增强---------------	
reg [7:0] dvp_data_p0;
reg dvp_href_p0;

always @(posedge dvp_pclk_i)
	dvp_data_p0 <= (q>=8'hdf)?8'hff:(q+8'h20);
//	dvp_data_p0 <= (q>=8'h7f)?8'hff:(q<<1);
//	dvp_data_p0 <= 8'hff-q;
//	dvp_data_p0 <= q_gamma;

always @(posedge dvp_pclk_i)
	dvp_href_p0 <= rdreq;	
	
reg [10:0] v_cnt; 	
reg [10:0] h_cnt;

always @(posedge dvp_pclk_i)
	if(dvp_href_i)
		h_cnt <= h_cnt + 1'b1;
	else
		h_cnt <= 0;
	
always @(posedge dvp_pclk_i)
	if(dvp_vsync_i)
		v_cnt <= 0;
	else if(h_cnt==(IMG_H-1))
		v_cnt <= v_cnt + 1'b1;
	else
		v_cnt <= v_cnt;



endmodule
