//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by USB_HID_LED.rc
//
#define IDD_USB_HID_LED_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDC_EDIT_VID                    1000
#define IDC_EDIT_PID                    1001
#define IDC_EDIT_PVN                    1002
#define IDC_EDIT_RECV                   1003
#define IDC_BTN_CLR_RECV                1004
#define IDC_EDIT_SEND                   1005
#define IDC_BTN_DEV_OPEN                1006
#define IDC_BTN_DEV_OFF                 1007
#define IDC_BTN_CTL_LED1                1008
#define IDC_BTN_CTL_LED2                1009
#define IDC_BTN_CTL_LED3                1010
#define IDC_BTN_M_SEND                  1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
