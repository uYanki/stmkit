; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CUSB_HID_LEDDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "USB_HID_LED.h"

ClassCount=2
Class1=CUSB_HID_LEDApp
Class2=CUSB_HID_LEDDlg

ResourceCount=3
Resource2=IDR_MAINFRAME
Resource3=IDD_USB_HID_LED_DIALOG

[CLS:CUSB_HID_LEDApp]
Type=0
HeaderFile=USB_HID_LED.h
ImplementationFile=USB_HID_LED.cpp
Filter=N

[CLS:CUSB_HID_LEDDlg]
Type=0
HeaderFile=USB_HID_LEDDlg.h
ImplementationFile=USB_HID_LEDDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_EDIT_VID



[DLG:IDD_USB_HID_LED_DIALOG]
Type=1
Class=CUSB_HID_LEDDlg
ControlCount=19
Control1=IDC_EDIT_VID,edit,1350631552
Control2=IDC_EDIT_PID,edit,1350631552
Control3=IDC_EDIT_PVN,edit,1350631552
Control4=IDC_BTN_DEV_OPEN,button,1342242816
Control5=IDC_BTN_DEV_OFF,button,1342242816
Control6=IDC_BTN_CTL_LED1,button,1342242816
Control7=IDC_BTN_CTL_LED2,button,1342242816
Control8=IDC_BTN_CTL_LED3,button,1342242816
Control9=IDC_EDIT_SEND,edit,1352728580
Control10=IDC_BTN_M_SEND,button,1342242817
Control11=IDC_BTN_CLR_RECV,button,1342242816
Control12=IDC_STATIC,static,1342308352
Control13=IDC_STATIC,static,1342308352
Control14=IDC_STATIC,static,1342308352
Control15=IDC_EDIT_RECV,edit,1352730628
Control16=IDC_STATIC,button,1342177287
Control17=IDC_STATIC,button,1342177287
Control18=IDC_STATIC,button,1342177287
Control19=IDC_STATIC,button,1342177287

