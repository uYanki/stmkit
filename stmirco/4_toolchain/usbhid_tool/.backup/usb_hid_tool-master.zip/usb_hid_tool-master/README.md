# usb_hid_tool

#### 介绍
- PC 端 USB HID 调试小工具，可以用于调试STM32 USB HID设备，如LED控制、数据采集，基于VS2019 VC++

#### 软件架构
- VS2019 VC++，USB HID 调试工具（收、发）


#### 安装教程
- 单可执行exe文件，无须安装

#### 使用说明

- 打开，输入USB HID的 VID、PID，即可进行USB HID 协议的收发

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 运行效果

<img src = "Release_exe/2022-02-05_220732.png">

