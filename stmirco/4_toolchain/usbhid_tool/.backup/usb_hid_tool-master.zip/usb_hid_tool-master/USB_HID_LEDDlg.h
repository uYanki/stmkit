// USB_HID_LEDDlg.h : header file
//

#if !defined(AFX_USB_HID_LEDDLG_H__962F572E_8CED_4AD5_9231_7AC800CFA2BE__INCLUDED_)
#define AFX_USB_HID_LEDDLG_H__962F572E_8CED_4AD5_9231_7AC800CFA2BE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
 
/////////////////////////////////////////////////////////////////////////////
// CUSB_HID_LEDDlg dialog

class CUSB_HID_LEDDlg : public CDialog
{
// Construction
public:
    UCHAR ASC2Hex(UCHAR ch);
    void AddToInfOut(CString InStr, BOOL AddTime=TRUE, BOOL NewLine=TRUE);
    void AddToInfOut(char *p, BOOL AddTime=TRUE, BOOL NewLine=TRUE);
    CString itos(INT value, INT radix=10);
    BOOL GetInputData(INT nID,CString ErrMsg,DWORD &Value);
    void GetMyIDS();
    CUSB_HID_LEDDlg(CWnd* pParent = NULL);    // standard constructor

// Dialog Data
    //{{AFX_DATA(CUSB_HID_LEDDlg)
    enum { IDD = IDD_USB_HID_LED_DIALOG };
        // NOTE: the ClassWizard will add data members here
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CUSB_HID_LEDDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    HICON m_hIcon;

    // Generated message map functions
    //{{AFX_MSG(CUSB_HID_LEDDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnBtnClrRecv();
    afx_msg void OnBtnCtlLed1();
    afx_msg void OnBtnCtlLed2();
    afx_msg void OnBtnCtlLed3();
    afx_msg void OnBtnDevOff();
    afx_msg void OnBtnDevOpen();
    afx_msg void OnBtnMSend();
    afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
    afx_msg void OnClose();
    afx_msg LRESULT OnDeviceChange(WPARAM wParam, LPARAM lParam);
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USB_HID_LEDDLG_H__962F572E_8CED_4AD5_9231_7AC800CFA2BE__INCLUDED_)
