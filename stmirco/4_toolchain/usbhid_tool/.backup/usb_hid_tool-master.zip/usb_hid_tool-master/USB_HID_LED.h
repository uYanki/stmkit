// USB_HID_LED.h : main header file for the USB_HID_LED application
//

#if !defined(AFX_USB_HID_LED_H__DAF4F2A7_0856_4A5A_A6BB_B408DF768ECF__INCLUDED_)
#define AFX_USB_HID_LED_H__DAF4F2A7_0856_4A5A_A6BB_B408DF768ECF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
    #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"        // main symbols

/////////////////////////////////////////////////////////////////////////////
// CUSB_HID_LEDApp:
// See USB_HID_LED.cpp for the implementation of this class
//

class CUSB_HID_LEDApp : public CWinApp
{
public:
    CUSB_HID_LEDApp();

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CUSB_HID_LEDApp)
    public:
    virtual BOOL InitInstance();
    //}}AFX_VIRTUAL

// Implementation

    //{{AFX_MSG(CUSB_HID_LEDApp)
        // NOTE - the ClassWizard will add and remove member functions here.
        //    DO NOT EDIT what you see in these blocks of generated code !
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USB_HID_LED_H__DAF4F2A7_0856_4A5A_A6BB_B408DF768ECF__INCLUDED_)
