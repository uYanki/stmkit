#ifndef __LED_H
#define	__LED_H

#include "HAL_conf.h"

#define LED1 PDout(8)// PE5	
void LED_Init(void);


#endif /* __LED_H */

