/**
******************************************************************************
* @file  can.h
* @author  IC Applications Department
* @version  V0.8
* @date  2020_07_02
* @brief  This file provides all the CAN firmware functions.
******************************************************************************
* @copy
*
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
* TIME. AS A RESULT, HOLOCENE SHALL NOT BE HELD LIABLE FOR ANY
* DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*
* <h2><center>&copy; COPYRIGHT 2020 HOLOCENE</center></h2>
*/ 
#ifndef __CAN_H
#define __CAN_H

#include "HAL_conf.h"
#define CAN_ID_STD                   0
#define CAN_ID_EXT                   1
#define CAN_DATA_FRAME       					0
#define CAN_REMOTE_FRAME              1
#define CAN_500K                     500000
#define CAN_250K                     250000
#define CAN_50K                       50000

#define TX_CANID1  									 0x172
#define TX_CANID2  									 0x325

#define TX_CANID  									 0x172
typedef struct
{
    uint32_t CANID;
    uint32_t CANIDtype;

    uint8_t RTR;

    uint8_t DLC;
    uint8_t Data[8];

} CanTxMsg;

typedef enum
{
    StandardFrame_SingleFilter = 0,
    ExtendedFrame_SingleFilter = 1,
    StandardFrame_DoubleFilter = 2,
    ExtendedFrame_DoubleFilter = 3,
} CAN_Mode;

extern CanPeliRxMsg CanPeliRxMsgStructure;
extern u8 flag;
void CANM_Init(CAN_TypeDef* CANx);
void CAN_Config(CAN_TypeDef* CANx, u32 CAN_Pre, CAN_Mode ID, u32 idCode1, u32 idCode2, u32 mask1, u32 mask2);
void Send_CANFrame(CAN_TypeDef* CANx, CanTxMsg* TxMessage);
#endif

/**
* @}
*/

/**
* @}
*/

/**
* @}
*/

/*-------------------------(C) COPYRIGHT 2020 HOLOCENE ----------------------*/
