#ifndef __MAIN_H
#define	__MAIN_H

#include "HAL_conf.h"
#include "UART.h"
#include "sys.h"
#include "LCD.h"
#include "stdio.h"
#include "TK499_I2C.h"
#include "touch_CTP.h"

#endif


