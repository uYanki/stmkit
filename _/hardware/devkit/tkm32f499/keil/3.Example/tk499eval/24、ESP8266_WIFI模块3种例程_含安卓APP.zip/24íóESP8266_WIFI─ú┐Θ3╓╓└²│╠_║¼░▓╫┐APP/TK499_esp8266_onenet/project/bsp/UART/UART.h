#ifndef _UART_H_
#define _UART_H_



#include "HAL_conf.h"
#include "stdio.h"
#include "time.h"
#include "string.h"
#include <stdarg.h>


#define UART_DEBUG		UART1		//���Դ�ӡ��ʹ�õĴ�����

void UartInit(UART_TypeDef* UARTx,int BaudRate);
void Uart2Init(int BaudRate);
void Uart_SendString(UART_TypeDef *UARTx, unsigned char *str, unsigned short len);
void UartPrintf(UART_TypeDef *UARTx, char *fmt,...);

#endif










