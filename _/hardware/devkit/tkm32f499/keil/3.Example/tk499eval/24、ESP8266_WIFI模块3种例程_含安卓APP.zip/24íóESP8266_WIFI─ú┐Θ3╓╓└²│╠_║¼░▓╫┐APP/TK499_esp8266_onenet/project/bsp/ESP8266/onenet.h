#ifndef _ONENET_H_
#define _ONENET_H_

#include "HAL_conf.h"
#include "UART.h"
#include "edpkit.h"
#include "esp8266.h"
#include <string.h>
#include <stdio.h>
#include "time.h"






typedef struct
{

	int fengshan;

} FENGSHAN_STATUS;

extern FENGSHAN_STATUS fengshan_status;


_Bool OneNet_DevLink(void);

void OneNet_SendData(void);

void OneNet_RevPro(unsigned char *cmd);

#endif





