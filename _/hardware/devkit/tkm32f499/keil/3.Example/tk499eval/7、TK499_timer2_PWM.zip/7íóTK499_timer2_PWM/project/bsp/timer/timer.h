#ifndef _TIMER_H
#define _TIMER_H
#include "sys.h"

void TIM2_Mode_Config(u16 arr,u16 psc);
void Times_Pwm_Config(u16 arr,u16 psc);
#endif
