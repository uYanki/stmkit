#ifndef __EXIT_H
#define __EXIT_H

#include "HAL_conf.h"

void EXIT_KEY_Init(void);

void EXIT2_Init(void);

void EXIT4_Init(void);

void EXIT8_Init(void);

void EXIT7_Init(void);

void EXIT1_Init(void);

void EXIT12_Init(void);

void EXIT13_Init(void);
#endif
