/******************** (C) COPYRIGHT 2009 STMicroelectronics ********************
* File Name          : mass_mal.c
* Author             : MCD Application Team
* Version            : V3.0.1
* Date               : 04/27/2009
* Description        : Medium Access Layer interface
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "qspi_fun.h"
#include "mass_mal.h"
#include "ff.h"			/* Declarations of FatFs API */
#include "diskio.h"	
#include "romPatch.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint32_t Mass_Memory_Size[2];
uint32_t Mass_Block_Size[2];
uint32_t Mass_Block_Count[2];

const u8 Virtual_Disk[512] = 
{
0xEB,0x3C,0x90,0x4D,0x53,0x44,0x4F,0x53,0x35,0x2E,0x30,0x00,0x02,0x01,0x08,0x00,
0x01/*FAT���������0x02*/,0x40,0x00,0x00,0xFF/*�ļ�ϵͳ��������0x4d,0x3b*/,0xF8,0x00/*FAT�����size 0xec*/,0x01,0x01,0x00,0x01,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x29,0x74,0x19,0x02,0x27, 'T', 'K', '4', '9', '9',
 ' ', ' ', 'U', 'S', 'B', ' ',0x46,0x41,0x54,0x31,0x36,0x20,0x20,0x20,0x33,0xC9,
0x8E,0xD1,0xBC,0xF0,0x7B,0x8E,0xD9,0xB8,0x00,0x20,0x8E,0xC0,0xFC,0xBD,0x00,0x7C,
0x38,0x4E,0x24,0x7D,0x24,0x8B,0xC1,0x99,0xE8,0x3C,0x01,0x72,0x1C,0x83,0xEB,0x3A,
0x66,0xA1,0x1C,0x7C,0x26,0x66,0x3B,0x07,0x26,0x8A,0x57,0xFC,0x75,0x06,0x80,0xCA,
0x02,0x88,0x56,0x02,0x80,0xC3,0x10,0x73,0xEB,0x33,0xC9,0x8A,0x46,0x10,0x98,0xF7,
0x66,0x16,0x03,0x46,0x1C,0x13,0x56,0x1E,0x03,0x46,0x0E,0x13,0xD1,0x8B,0x76,0x11,
0x60,0x89,0x46,0xFC,0x89,0x56,0xFE,0xB8,0x20,0x00,0xF7,0xE6,0x8B,0x5E,0x0B,0x03,
0xC3,0x48,0xF7,0xF3,0x01,0x46,0xFC,0x11,0x4E,0xFE,0x61,0xBF,0x00,0x00,0xE8,0xE6,
0x00,0x72,0x39,0x26,0x38,0x2D,0x74,0x17,0x60,0xB1,0x0B,0xBE,0xA1,0x7D,0xF3,0xA6,
0x61,0x74,0x32,0x4E,0x74,0x09,0x83,0xC7,0x20,0x3B,0xFB,0x72,0xE6,0xEB,0xDC,0xA0,
0xFB,0x7D,0xB4,0x7D,0x8B,0xF0,0xAC,0x98,0x40,0x74,0x0C,0x48,0x74,0x13,0xB4,0x0E,
0xBB,0x07,0x00,0xCD,0x10,0xEB,0xEF,0xA0,0xFD,0x7D,0xEB,0xE6,0xA0,0xFC,0x7D,0xEB,
0xE1,0xCD,0x16,0xCD,0x19,0x26,0x8B,0x55,0x1A,0x52,0xB0,0x01,0xBB,0x00,0x00,0xE8,
0x3B,0x00,0x72,0xE8,0x5B,0x8A,0x56,0x24,0xBE,0x0B,0x7C,0x8B,0xFC,0xC7,0x46,0xF0,
0x3D,0x7D,0xC7,0x46,0xF4,0x29,0x7D,0x8C,0xD9,0x89,0x4E,0xF2,0x89,0x4E,0xF6,0xC6,
0x06,0x96,0x7D,0xCB,0xEA,0x03,0x00,0x00,0x20,0x0F,0xB6,0xC8,0x66,0x8B,0x46,0xF8,
0x66,0x03,0x46,0x1C,0x66,0x8B,0xD0,0x66,0xC1,0xEA,0x10,0xEB,0x5E,0x0F,0xB6,0xC8,
0x4A,0x4A,0x8A,0x46,0x0D,0x32,0xE4,0xF7,0xE2,0x03,0x46,0xFC,0x13,0x56,0xFE,0xEB,
0x4A,0x52,0x50,0x06,0x53,0x6A,0x01,0x6A,0x10,0x91,0x8B,0x46,0x18,0x96,0x92,0x33,
0xD2,0xF7,0xF6,0x91,0xF7,0xF6,0x42,0x87,0xCA,0xF7,0x76,0x1A,0x8A,0xF2,0x8A,0xE8,
0xC0,0xCC,0x02,0x0A,0xCC,0xB8,0x01,0x02,0x80,0x7E,0x02,0x0E,0x75,0x04,0xB4,0x42,
0x8B,0xF4,0x8A,0x56,0x24,0xCD,0x13,0x61,0x61,0x72,0x0B,0x40,0x75,0x01,0x42,0x03,
0x5E,0x0B,0x49,0x75,0x06,0xF8,0xC3,0x41,0xBB,0x00,0x00,0x60,0x66,0x6A,0x00,0xEB,
0xB0,0x4E,0x54,0x4C,0x44,0x52,0x20,0x20,0x20,0x20,0x20,0x20,0x0D,0x0A,0x52,0x65,
0x6D,0x6F,0x76,0x65,0x20,0x64,0x69,0x73,0x6B,0x73,0x20,0x6F,0x72,0x20,0x6F,0x74,
0x68,0x65,0x72,0x20,0x6D,0x65,0x64,0x69,0x61,0x2E,0xFF,0x0D,0x0A,0x44,0x69,0x73,
0x6B,0x20,0x65,0x72,0x72,0x6F,0x72,0xFF,0x0D,0x0A,0x50,0x72,0x65,0x73,0x73,0x20,
0x61,0x6E,0x79,0x20,0x6B,0x65,0x79,0x20,0x74,0x6F,0x20,0x72,0x65,0x73,0x74,0x61,
0x72,0x74,0x0D,0x0A,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xAC,0xCB,0xD8,0x55,0xAA,
};

__IO uint32_t Status = 0;

#ifdef USE_STM3210E_EVAL
SD_CardInfo SDCardInfo;
#endif

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
int VD_WriteBlock(u32 Memory_Offset,u8* Writebuff,u32 Transfer_Length);
int VD_ReadBlock(u32 Memory_Offset,u8* Readbuff,u32 Transfer_Length);

/*******************************************************************************
* Function Name  : MAL_Init
* Description    : Initializes the Media on the STM32
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t MAL_Init(uint8_t lun)
{
  u16 status = MAL_OK;  
  switch (lun)
  {
    case 0:			    
      break;			   
    case 1:					  
      break;		  
    default:
      return MAL_FAIL;
  }
  return status;
}
/*******************************************************************************
* Function Name  : MAL_Write
* Description    : Write sectors
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

extern FATFS fs;
extern FIL fnew;


uint16_t MAL_Write(uint8_t lun, uint32_t Memory_Offset, uint8_t *Writebuff, uint16_t Transfer_Length)
{
	int i;
	u8 STA;
  switch (lun)
  {
    case 0:
    
      STA=VD_WriteBlock(Memory_Offset,Writebuff,Transfer_Length);
			break;
		case 1:		 
			STA=0;
		for(i = 0; i <= Transfer_Length + 0x1000 ;i += 0x1000)

                  {
                    QFLASH_FunErase(0x220000+i,0);//eType 0:SE_Com , 1:BE64K_Com
										QFLASH_FunCheckStatus();
                  }
			QFLASH_FunProgram(0x220000+Memory_Offset,(u8*)Writebuff,Transfer_Length);
	  
			break;

    default:
      return MAL_FAIL;
  }
  if(STA!=0)return MAL_FAIL;
	return MAL_OK;
}

/*******************************************************************************
* Function Name  : MAL_Read
* Description    : Read sectors
* Input          : None
* Output         : None
* Return         : Buffer pointer
*******************************************************************************/

 uint16_t MAL_Read(uint8_t lun, uint32_t Memory_Offset, uint8_t *Readbuff, uint16_t Transfer_Length)
{
	u8 STA;
  switch (lun)
  {
    case 0:
      STA = VD_ReadBlock(Memory_Offset, (u8*)Readbuff, Transfer_Length);
			break;
		case 1:		 
			STA=0;
			QFLASH_FunReadGroup(0x220000+Memory_Offset,(u8*)Readbuff,Transfer_Length);		  
			break;
		 // ebedFlashRead(FAT_INIT_ADD + Memory_Offset , (u8*)Readbuff ,Transfer_Length);
//      Status = SD_OK ;
//      if ( Status != SD_OK )
//      {
//        return MAL_FAIL;
//      }

      
#ifdef USE_STM3210E_EVAL
    case 1:
//      NAND_Read(Memory_Offset, Readbuff, Transfer_Length);
      ;
      break;
#endif
    default:
      return MAL_FAIL;
  }
  if(STA!=0)return MAL_FAIL;
	return MAL_OK;
}

/*******************************************************************************
* Function Name  : MAL_GetStatus
* Description    : Get status
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t MAL_GetStatus (uint8_t lun)
{
	switch(lun)
    {
    case 0:
        Mass_Block_Count[0] = 2*1024*32;
    Mass_Block_Size[0]  = 512;
    Mass_Memory_Size[0] = Mass_Block_Count[0] * Mass_Block_Size[0];
    return MAL_OK;
    case 1:
        return MAL_OK;
    case 2:
        return MAL_FAIL;
    default:
        return MAL_FAIL;
    }
  return MAL_FAIL;
}



int VD_BlockFATsInit(void)
{

    VD_WriteBlock(0,(u8*)Virtual_Disk,512);
    return 0;
}

void FileRegionSDRAM_Init(void)
{
    u32 i;
    u8 tempData[8]={0,0,0,0,0,0,0,0};

    for(i = 0;i < (Virtual_Disk[14]+(Virtual_Disk[23]<<8 | Virtual_Disk[22])*Virtual_Disk[16]+4)*512; i += 8)
    {
			
        VD_WriteBlock(512 + i, tempData , 8 );
				
    }
}


extern void QspiFlashProgram(u32 qSpiFlashAdd, u8 *inData, u32 len);
extern __IO uint32_t bDeviceState; /* USB device status */
extern void QSPI_Block64Erase(unsigned long address);
extern void QspiFlashSectorErase(u32 add);
extern char waitEraseFlag ;
extern void QSPIReadGroup(unsigned long address,u8* buf,uint32_t datanum);
extern u8 sdramLockFlag ;
void CheckStatus(void);

extern void sendGroupToUart(u8 *Writebuff,u32 size);

#define TEST_OFFSET   (0x000000+0x400)
int VD_WriteBlock(u32 Memory_Offset,u8* Writebuff,u32 Transfer_Length)
{
    u32 tempAdd;
    u32 i;

    if((Transfer_Length%4) == 0)
    {
        {
          for(i = 0;i < Transfer_Length ;i+=4)
          {
							if(sdramLockFlag == 0)
							{
								*(u32*)(SDRAM_FILE_SYS_ADD + Memory_Offset + i) = *(u32*)(Writebuff + i) ;  //over code
							}
          }
        } 
    }
    else
    {
        for(i = 0;i < Transfer_Length ;i++)
        {
					  if( sdramLockFlag == 0)
						{
							*(u8*)(SDRAM_FILE_SYS_ADD + Memory_Offset + i) = *(Writebuff + i) ;  
						}
        }
    }
    return 0;
}


/*******************************************************************************
* Function Name  : VD_ReadBlock
* Description    : Get data
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
int VD_ReadBlock(u32 Memory_Offset,u8* Readbuff,u32 Transfer_Length)
{
    u32 i;
    if((Transfer_Length%4) == 0)
    {
        for(i = 0;i < Transfer_Length ;i += 4)
        {
             *(u32*)(Readbuff + i) = *(u32*)(SDRAM_FILE_SYS_ADD + Memory_Offset + i);
        }
    }
    else
    {
        for(i = 0;i < Transfer_Length ;i++)
        {
             *(Readbuff + i) = *(u8*)(SDRAM_FILE_SYS_ADD + Memory_Offset + i);
        }
    }
    return 0;
}
//#define Bank5_SDRAM_ADDR 0x70008000
#define Bank5_SDRAM_ADDR 0x70020000
u8 EXT_SDRAM_WriteBuffer(u8 *pBuffer,u32 WriteAddr,u32 n)
{
    u16 i;
	for(;n!=0;n--)
	{
        for(i=0;i<512;i++)
        {
		*(vu8*)(Bank5_SDRAM_ADDR+WriteAddr)=*pBuffer;
		WriteAddr++;
		pBuffer++;
        }
	} 
    return 0;
}

//��ָ����ַ((WriteAddr+Bank5_SDRAM_ADDR))��ʼ,��������n���ֽ�.
//pBuffer:�ֽ�ָ��
//ReadAddr:Ҫ��������ʼ��ַ
//n:Ҫд����ֽ���
u8 EXT_SDRAM_ReadBuffer(u8 *pBuffer,u32 ReadAddr,u32 n)
{
    u16 i;
	for(;n!=0;n--)
	{   
        for(i=0;i<512;i++)
        {
		*pBuffer++=*(vu8*)(Bank5_SDRAM_ADDR+ReadAddr);
		ReadAddr++;
        }
	}
    return 0;
}


/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
