/*-----------------------------------------------------------------------*/
/* Low level disk I/O module skeleton for FatFs     (C)ChaN, 2016        */
/*-----------------------------------------------------------------------*/
/* If a working storage control module is available, it should be        */
/* attached to the FatFs via a glue function rather than modifying it.   */
/* This is an example of glue functions to attach various exsisting      */
/* storage control modules to the FatFs module with a defined API.       */
/*-----------------------------------------------------------------------*/

#include "diskio.h"		/* FatFs lower layer API */
#include "mass_mal.h"
#include "qspi_fun.h"

/* Definitions of physical drive number for each drive */
#define SDRAM		0	/* Example: Map Ramdisk to physical drive 0 */
#define QSPI_FLASH		1	/* Example: Map MMC/SD card to physical drive 1 */
#define DEV_USB		2	/* Example: Map USB MSD to physical drive 2 */


/*-----------------------------------------------------------------------*/
/* Get Drive Status                                                      */
/*-----------------------------------------------------------------------*/

DSTATUS disk_status (
	BYTE pdrv		/* Physical drive nmuber to identify the drive */
)
{ 
    
	return RES_OK;
    
} 



/*-----------------------------------------------------------------------*/
/* Inidialize a Drive                                                    */
/*-----------------------------------------------------------------------*/

DSTATUS disk_initialize (
	BYTE pdrv				/* Physical drive nmuber to identify the drive */
)
{
	VD_BlockFATsInit();
	return 0;
//	unsigned char res;
//	switch (pdrv) {
//	case SDRAM :
//        res = 0;
//        VD_BlockFATsInit();
//        break;
//	case QSPI_FLASH :
//        res = 0;
//        break;
//	} 
//	return res;
}



/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/

DRESULT disk_read (
	BYTE pdrv,		/* Physical drive nmuber to identify the drive */
	BYTE *buff,		/* Data buffer to store read data */
	DWORD sector,	/* Start sector in LBA */
	UINT count		/* Number of sectors to read */
)
{
	DRESULT res;

	switch (pdrv) {
	case SDRAM :
		// translate the arguments here     

        res = VD_ReadBlock( sector<<=9 , buff , count*512);
         break;
		case QSPI_FLASH :
				 QFLASH_FunReadGroup(0x220000+(sector<<9),buff,count<<9);
        res = 0;
        break;
	
	
	}
	return res;
}



/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/

DRESULT disk_write (
	BYTE pdrv,			/* Physical drive nmuber to identify the drive */
	const BYTE *buff,	/* Data to be written */
	DWORD sector,		/* Start sector in LBA */
	UINT count			/* Number of sectors to write */
)
{
	DRESULT res;
	int i;

	switch (pdrv) {
	case SDRAM :
		// translate the arguments here
       res = VD_WriteBlock(sector<<9, (u8*)buff ,count *512);
      break;
	case QSPI_FLASH :
			 for(i = 0; i <= (sector<<9) + 0x1000 ;i += 0x1000)

                  {
                    QFLASH_FunErase(0x220000+i,0);//eType 0:SE_Com , 1:BE64K_Com
										QFLASH_FunCheckStatus();
                  }

			 QFLASH_FunProgram(0x220000+(sector<<9),(u8*)buff,count<<9);
        res = 0;
        break;
	}

	return res;
}



/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/

DRESULT disk_ioctl (
        BYTE drv,                /* Physical drive nmuber (0..) */
        BYTE ctrl,                /* Control code */
        void *buff                /* Buffer to send/receive control data */
)
{
    DRESULT res;
    if (drv==SDRAM)
    {    
        switch(ctrl)
					{
					case CTRL_SYNC:

									res = RES_OK;
							break;
							
					case GET_BLOCK_SIZE:
							*(WORD*)buff = 512;
							res = RES_OK;
							break;

					case GET_SECTOR_COUNT:
							*(DWORD*)buff = 1024;
							res = RES_OK;
							break;
					default:
							res = RES_PARERR;
							break;
					}  
    }
//		else if(drv==QSPI_FLASH)	//�ⲿFLASH  
//			{
//					switch(ctrl)
//					{
//						case CTRL_SYNC:
//						res = RES_OK; 
//								break;	 
//						case GET_SECTOR_SIZE:
//								*(WORD*)buff = 512;
//								res = RES_OK;
//								break;	 
//						case GET_BLOCK_SIZE:
//								*(WORD*)buff = 8;//ÿ��BLOCK��8��SECTOR(����)
//								res = RES_OK;
//								break;	 
//						case GET_SECTOR_COUNT:
//								*(DWORD*)buff = 1024*2*6-128;
//								res = RES_OK;
//								break;
//						default:
//								res = RES_PARERR;
//								break;
//					}
//				}
		else res= RES_ERROR; 
    
    return res;
}


DWORD get_fattime (void)
{				 
	return 0;
}		
