
#include "uart_inttest.h"
#include "romPatch.h"
#include "qspi_fun.h"

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;

//for sprintf start

void Uart_ConfigInit(u32 bound);
void UartSendGroup(u8* buf,u16 len);
void UartSendAscii(char *str);
//UartSendGroup((u8*)printfBuf, sprintf(printfBuf,"sprintf ok\r\n"));//��ӡ��ʽ
//end 

void GPIO_ConfigInit(void);
void NVIC_ConfigInit(void);
u8 vaildUartRecProgram(void);
int headProgram;

extern Type_UartInfo uartInfo;
extern Type_ProgramInfo programInfo;
extern Type_TestMode strcTest;

/********************************************************************************************************
**������Ϣ ��TK499_GPIO_ConfigInit (void)                          
**�������� ��IO��ʼ��
**������� ��
**������� ��
********************************************************************************************************/
void TK499_GPIO_ConfigInit(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;   
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1|(0x1<<8)|(0x1<<13);   
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);  

}



/********************************************************************************************************
**������Ϣ ��TK499_GetModeStatus (void)                          
**�������� ����ȡ����ģʽ 
**������� ��
**������� ��
********************************************************************************************************/
u8 TK499_GetModeStatus(void)
{
    int temp=0,j,i = 0;
    while(1)
    {
        i++;
				#if ROM_DEBUG != 0
				for(j=0;j<100;j++)
			{
				temp += ((GPIO_ReadInputData(GPIOA)>>1)&0x1);
			}
			if(temp>10) return 1;
//        temp = ((GPIO_ReadInputData(GPIOA)>>1)&0x1);
//        j=200;while(j--);
//        if(temp == ((GPIO_ReadInputData(GPIOA)>>1)&0x1))
//        {
//            return temp;
//        }
				#else
				temp = ((GPIO_ReadInputData(GPIOA)>>13)&0x1);
        j=200;while(j--);
        if(temp == ((GPIO_ReadInputData(GPIOA)>>13)&0x1))
        {
            return temp;
        }	
				#endif
        if(i > 1000)
        {
            return 0;
        }
				
    }
}
/********************************************************************************************************
**������Ϣ ��u8 TK499_GetHighSpStatus(void)                        
**�������� ����ȡ����ģʽ
**������� ��
**������� ��
********************************************************************************************************/
u8 TK499_GetHighSpStatus(void)
{
    int temp,j,i = 0;
    while(1)
    {
        i++;
        temp = ((GPIO_ReadInputData(GPIOA)>>8)&0x1);
        j=200;while(j--);
        if(temp == ((GPIO_ReadInputData(GPIOA)>>8)&0x1))
        {
            return temp;
        }
        if(i > 1000000)
        {
            return 0xff;
        }
    }
}




/*
eg.
UartSendByte(0x66);
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1,UART_FLAG_TXEPT));
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
eg.
u8 buf[66];
UartSendGroup(buf,6);
eg2.
u8 printfBuf[66];
UartSendGroup((u8*)printfBuf, sprintf(printfBuf,"sprintf ok\r\n"));
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void UartSendGroup(u8* buf,u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
eg1.
char buf[66];
UartSendAscii(buf);
eg2.
char buf[66];
UartSendAscii("hello world\r\n");
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void UartSendAscii(char *str)
{
    while(*str)
        UartSendByte(*str++);
}

