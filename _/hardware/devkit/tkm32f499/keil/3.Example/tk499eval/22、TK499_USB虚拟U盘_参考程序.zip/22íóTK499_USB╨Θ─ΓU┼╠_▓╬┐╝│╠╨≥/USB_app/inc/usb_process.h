#ifndef __USB_PROCESS_H_
#define __USB_PROCESS_H_
#include "HAL_conf.h"
#include "usb_conf.h"
#include "usb_istr.h"


void bootByUSB(void);
void USB_IO_Config(void);

#endif








