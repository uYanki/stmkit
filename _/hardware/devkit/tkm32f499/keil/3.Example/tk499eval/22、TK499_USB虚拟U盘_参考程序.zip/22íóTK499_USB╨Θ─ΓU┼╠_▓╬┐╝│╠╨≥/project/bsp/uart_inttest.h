#ifndef __UART_INTTEST_H__
#define __UART_INTTEST_H__
#include "HAL_conf.h"
#include "QuadSPItest.h"
#include "stdio.h"
#include <ctype.h>
#include <string.h>
#include <stdarg.h>
#include "romPatch.h"




#define pVALUE32(add)           (*(u32*)(add))    
#define pVALUE16(add)           (*(u16*)(add)) 
#define pVALUE8(add)            (*(u8*)(add)) 



//for qspi space allocation
#define GPIOA_TOGGLE            0xffff
#define GPIOB_TOGGLE            0xffff
#define GPIOC_TOGGLE            0xffff
#define GPIOD_TOGGLE            0xffff
#define GPIOE_TOGGLE            0xffffff

typedef struct
{
u8   *buf;
u8   dataFlag ;
u8   frameFlag;
u32  len ;
u32  totalLen ;
u32  interval ;   
}Type_UartInfo;

typedef struct
{
u8   *buf;
u8   vaild ;
u32  add ;
u32  len ;
u32  sum;    
}Type_ProgramInfo;

typedef struct
{
u8  mode;
u8  step;
}Type_TestMode;

void UartIrq_ConfigInit(void);
void TK499_GPIO_ConfigInit(void);
void TK499_TESTMODE_GPIO_Config(void);
u8 TK499_IO_Toggle(void);
u8 TK499_GetModeStatus(void);
u8 TK499_GetHighSpStatus(void);
void UartInit(UART_TypeDef* UARTx,u32 baud);
void uart_printf( const char * ctrl1, ...);
void uartinttest(void);
void bootByUart(void);
//void bootJumpOrUpdate(void);
u8 judgeVaildIapProgarm(void);
u8 vaildSramAppSpace(void);
void qspi_process(u32 sdramOffset);
u8 judgeVaildSdramProgarm(void);
#endif


