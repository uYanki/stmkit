#include "my_appcation.h"
#include "CH57x_common.h"
#include "bat.h"

extern uint8 hidEmuTaskId;

time_t My_Time;

/*

  ��ʼ������

*/


//����ȫ�ֵı���
unsigned char Receive_ID=255;
extern uint8 LCD_Back_Value;



#if 1
uint8_t TxBuff[]="This is a tx exam\r\n";
uint8_t RxBuff[100];
uint8_t trigB;


void Uart_Init()//���ڳ�ʼ��
{

    uint8_t len;
	uint32_t	x;
    
/* ���ô���1��������IO��ģʽ�������ô��� */ 

#if 0  
    GPIOB_SetBits(GPIO_Pin_7);
    GPIOB_ModeCfg(GPIO_Pin_4, GPIO_ModeIN_PU);			// RXD-������������
    GPIOB_ModeCfg(GPIO_Pin_7, GPIO_ModeOut_PP_5mA);		// TXD-�������������ע������IO������ߵ�ƽ
    //UART1_DefInit();
	#else
	
	  GPIOPinRemap( ENABLE, RB_PIN_UART0);
	  GPIOA_SetBits(GPIO_Pin_14);
    GPIOA_ModeCfg(GPIO_Pin_15, GPIO_ModeIN_PU);			// RXD-������������
    GPIOA_ModeCfg(GPIO_Pin_14, GPIO_ModeOut_PP_5mA);		// TXD-�������������ע������IO������ߵ�ƽ
	
	
	#endif
	
	
	
	//���ò�����

    x = 10 * GetSysClock() / 8 / 115200;
    x = ( x + 5 ) / 10;
    R16_UART0_DL = (UINT16)x;
	
	
	
    R8_UART0_FCR = (2<<6) | RB_FCR_TX_FIFO_CLR | RB_FCR_RX_FIFO_CLR | RB_FCR_FIFO_EN;		// FIFO�򿪣�������4�ֽ�
    R8_UART0_LCR = RB_LCR_WORD_SZ;	
    R8_UART0_IER = RB_IER_TXD_EN;
    R8_UART0_DIV = 1;	

	
	
	
	
    
#if 1       // ���Դ��ڷ����ַ���
    UART0_SendString( TxBuff, sizeof(TxBuff) );

#endif  


  // �жϷ�ʽ���������ݺ��ͳ�ȥ
    UART0_ByteTrigCfg( UART_7BYTE_TRIG );//���ô����ж��ֽ���
    trigB = 7;
    UART0_INTCfg( ENABLE, RB_IER_RECV_RDY|RB_IER_LINE_STAT );
    NVIC_EnableIRQ( UART0_IRQn );




}

/*******************************************************************************
* Function Name  : UART1_ByteTrigCfg
* Description    : �����ֽڴ����ж�����
* Input          : b: �����ֽ���
                    refer to UARTByteTRIGTypeDef
* Return         : 
*******************************************************************************/
void UART0_ByteTrigCfg( UARTByteTRIGTypeDef b )
{
    R8_UART0_FCR = (R8_UART0_FCR&~RB_FCR_FIFO_TRIG)|(b<<6);
}



/*******************************************************************************
* Function Name  : UART0_INTCfg
* Description    : �����ж�����
* Input          : s:  �жϿ���״̬
					ENABLE  - ʹ����Ӧ�ж�    
					DISABLE - �ر���Ӧ�ж�
				   i:  �ж�����
					RB_IER_MODEM_CHG  - ���ƽ��������״̬�仯�ж�ʹ��λ���� UART0 ֧�֣�
					RB_IER_LINE_STAT  - ������·״̬�ж�
					RB_IER_THR_EMPTY  - ���ͱ��ּĴ������ж�
					RB_IER_RECV_RDY   - ���������ж�
* Return         : None
*******************************************************************************/
void UART0_INTCfg( UINT8 s,  UINT8 i )
{
    if( s )
    {
        R8_UART0_IER |= i;
        R8_UART0_MCR |= RB_MCR_INT_OE;
    }
    else
    {
        R8_UART0_IER &= ~i;
    }
}





/*******************************************************************************
* Function Name  : UART1_SendString
* Description    : ���ڶ��ֽڷ���
* Input          : buf - �����͵����������׵�ַ
                     l - �����͵����ݳ���
* Return         : None
*******************************************************************************/
void UART0_SendString( PUINT8 buf, UINT16 l )
{
    UINT16 len = l;

    while(len)
    {
        if(R8_UART0_TFC != UART_FIFO_SIZE)
        {
            R8_UART0_THR = *buf++;
            len--;
        }		
    }
}


extern uint8_t hidEmuTaskId;
#define START_REPORT_EVT                              0x0002

//����0�����жϺ���
void UART0_IRQHandler(void)
{
	#if 1
    UINT8 i;
    switch( UART0_GetITFlag() )
    {
        case UART_II_LINE_STAT:        // ��·״̬����
            UART0_GetLinSTA();
            break;
        
        case UART_II_RECV_RDY:          // ���ݴﵽ���ô�����
            for(i=0; i!=trigB; i++)
            {
                RxBuff[i] = UART0_RecvByte();
                UART0_SendByte(RxBuff[i]);
            }
			 //PRINT("%s\n",__FUNCTION__);
			//tmos_start_task( , , 2000 );
			#if 1
			switch(RxBuff[2])
			{
				
			case 0x31:Receive_ID=PLAY;
				PRINT("UART0_IRQHandler PLAY\r\n");
				break;
			case 0x32:Receive_ID=PAUSE;
				PRINT("UART0_IRQHandler PAUSE\r\n");
				break;
			case 0x33:Receive_ID=POWER;
				PRINT("UART0_IRQHandler POWER\r\n");
				break;
			case 0x34:Receive_ID=MENU;
			PRINT("UART0_IRQHandler MENU\r\n");
			break;
			case 0x35:Receive_ID=NEXT_SONG;
			PRINT("UART0_IRQHandler NEXT_SONG\r\n");
			break;
			case 0x36:Receive_ID=PREV_SONG;
			PRINT("UART0_IRQHandler PREV_SONG\r\n");
			break;
			case 0x37:Receive_ID=MUTE;
			PRINT("UART0_IRQHandler MUTE\r\n");
			break;
			case 0x38:Receive_ID=VOLUME_UP;
			PRINT("UART0_IRQHandler VOLUME_UP\r\n");
			break;
			case 0x39:Receive_ID=VOLUME_DOWN;
			PRINT("UART0_IRQHandler VOLUME_DOWN\r\n");
			break;
				
			default:break;
			}
			tmos_set_event(hidEmuTaskId,START_REPORT_EVT);//�����¼�����
			#endif
			 memset(RxBuff, 0, sizeof(RxBuff));
            break;
        
        case UART_II_RECV_TOUT:         // ���ճ�ʱ����ʱһ֡���ݽ������
            i = UART1_RecvString(RxBuff);
            UART0_SendString( RxBuff, i ); 
		    memset(RxBuff, 0, sizeof(RxBuff));
            break;
        
        case UART_II_THR_EMPTY:         // ���ͻ������գ��ɼ�������
            break;
        
        case UART_II_MODEM_CHG:         // ֻ֧�ִ���0
            break;
        
        default:
            break;
    }
		#endif
}

#endif






void PAJ7620_Result_Protocol()
{


Ges_Result_t  result= PAJ7620_Get_Result();//���ƴ����������ȡ

switch(result)
{
	case GES_NONE_STATUS:break;
  case GES_UP_STATUS:
		Receive_ID=NEXT_SONG;
	PRINT("UART0_IRQHandler NEXT_SONG\r\n");	
	break;
	case GES_DOWN_STATUS:
		Receive_ID=PREV_SONG;
	PRINT("UART0_IRQHandler PREV_SONG\r\n");		
	
	break;
	case GES_RIGHT_STATUS:
//	Receive_ID=NEXT_SONG;
//	PRINT("UART0_IRQHandler NEXT_SONG\r\n");	
	break;
	case GES_LEFT_STATUS:
//	Receive_ID=PREV_SONG;
//	PRINT("UART0_IRQHandler PREV_SONG\r\n");	
	break;
	case GES_FORWARD_STATUS: 
		Receive_ID=PLAY;
		PRINT("UART0_IRQHandler PLAY\r\n");
	break;
	case GES_BACKWARD_STATUS:
	Receive_ID=PAUSE;
	PRINT("UART0_IRQHandler PAUSE\r\n");	
	
	break;
	case GES_CLOCKWISE_STATUS:
	Receive_ID=VOLUME_UP;
			PRINT("UART0_IRQHandler VOLUME_UP\r\n");	
	
	 /*
	 if(LCD_Back_Value>=100)
	 {
	   LCD_Back_Value=100;
	 }else
	 {
	   LCD_Back_Value+=5;
	 
	 }
	 
	 LCD_Back_Light_Set(LCD_Back_Value);//��������
	*/
	break;
	case GES_COUNT_CLOCKWISE_STATUS:
	Receive_ID=VOLUME_DOWN;
			PRINT("UART0_IRQHandler VOLUME_DOWN\r\n");	
	
	/*	
	 if(LCD_Back_Value<=0)
	 {
	   LCD_Back_Value=0;
	 }else
	 {
	   LCD_Back_Value-=5;
	 
	 }
	
	LCD_Back_Light_Set(LCD_Back_Value);//��������
	 */
	break;
	case GES_WAVE_STATUS:
	Receive_ID=MUTE;
	PRINT("UART0_IRQHandler MUTE\r\n");	
	break;

}

tmos_set_event(hidEmuTaskId,START_REPORT_EVT);//�����¼�����


/*
			switch(RxBuff[2])
			{
				
			case 0x31:
				break;
			case 0x32:Receive_ID=PAUSE;
				PRINT("UART0_IRQHandler PAUSE\r\n");
				break;
			case 0x33:Receive_ID=POWER;
				PRINT("UART0_IRQHandler POWER\r\n");
				break;
			case 0x34:Receive_ID=MENU;
			PRINT("UART0_IRQHandler MENU\r\n");
			break;
			case 0x35:
			break;
			case 0x36:
			break;
			case 0x37:
			break;
			case 0x38:
			break;
			case 0x39:
			break;
				
			default:break;
			}
			tmos_set_event(hidEmuTaskId,START_REPORT_EVT);//�����¼�����
*/



}

// Gesure Task Events
#define START_Gesure_EVT                      0x0001   //�����¼�

#define START_Gsenor_EVT                      0x0001   //���ᴫ�����¼�

#define START_Time_EVT                      0x0001     //ʱ��ʱ��

#define START_UI_EVT                      0x0001       //UI����ʱ��


#define ADC_EVT                       0x0001           //UI����ʱ��

#define PWR_OFF_EVT                      0x0001           //�������

#define PWR_ON_EVT                      0x0010           //�������


// Task ID   ����ID
uint8 Gesture_TaskId=INVALID_TASK_ID;

uint8 Gsenor_TaskId=INVALID_TASK_ID;

uint8 Time_TaskId=INVALID_TASK_ID;

uint8 UI_TaskId=INVALID_TASK_ID;

uint8 ADC_TaskId=INVALID_TASK_ID;


uint8 PWR_TaskId=INVALID_TASK_ID;



extern unsigned int STEP;

void Application_Init()

{
	#include "bat.h"
  Bat_Init(); //��س�ʼ��
	UI_Init();  //UI��ܳ�ʼ��
	Time_Init();//ʱ��ṹ���ʼ��

	
	
  Gesture_TaskId = TMOS_ProcessEventRegister(Gesture_ProcessEvent);
   tmos_start_task( Gesture_TaskId , START_Gesure_EVT ,5000 ); 
	
	
	Gsenor_TaskId = TMOS_ProcessEventRegister(Gsenor_ProcessEvent);
   tmos_start_task( Gsenor_TaskId , START_Gsenor_EVT ,5000 ); 
	  
	
	Time_TaskId = TMOS_ProcessEventRegister(Time_ProcessEvent);
	 tmos_start_task( Time_TaskId , START_Time_EVT ,0 );    //���Ͻ���ʱ����ʾ
	
	
	 UI_TaskId = TMOS_ProcessEventRegister(UI_ProcessEvent);
	 tmos_start_task( UI_TaskId , START_UI_EVT ,0 );    //���Ͻ���UI��ʾ
	 
	 
	  ADC_TaskId = TMOS_ProcessEventRegister(ADC_ProcessEvent);
	 tmos_start_task( ADC_TaskId , ADC_EVT ,0 );    //���Ͻ���ADC�ɼ���ʾ
	
	
	 PWR_TaskId = TMOS_ProcessEventRegister(PWR_ProcessEvent); //����رպ���
	 tmos_start_task( PWR_TaskId , PWR_OFF_EVT ,10000 );           
	
	
}


uint16 Gesture_ProcessEvent( uint8 task_id, uint16 events )
{

	  if ( events & START_Gesure_EVT )
  {
		
	// printf("------------%s----------\r\n",__FUNCTION__);	
	 PAJ7620_Result_Protocol();
	 
   //RTC_GetTime(&ph,&pm,&ps);		
	 //printf("------------ph=%d,pm=%d,ps=%d----------\r\n",ph,pm,ps);	

		
	 tmos_start_task( Gesture_TaskId, START_Gesure_EVT, 1000 );
	
		
		
		
	 return (events ^ START_Gesure_EVT);
	}
	
	
	
	
	 return 0;
	
	
	
	

#if 0

  if ( events & START_REPORT_EVT )
  {
		
		/*
		  ���ͼ�ֵ
		*/
		//PRINT("START_REPORT_EVT send_char=%d\r\n",send_char);
		
    //hidEmuSendKbdReport( 4 );//���ͼ�����ֵhidEmuSendKbdReport����
		//hidEmuSendKbdReport( 0x00 );
		
		Send_To_Phone(Receive_ID);
		Send_To_Phone(RELEASE);
		
		//performPeriodicTask();//����֪ͨ
    Receive_ID=255;
		//tmos_start_task( hidEmuTaskId, START_REPORT_EVT, 2000 );
    return ( events ^ START_REPORT_EVT );
  }
 
	
	#endif
}


uint16 Gsenor_ProcessEvent( uint8 task_id, uint16 events )
{
 char result=0;
	
	  if ( events & START_Gsenor_EVT )
  {
		
	// printf("------------%s----------\r\n",__FUNCTION__);	
	 //PAJ7620_Result_Protocol();
	 
	STEP=SL_SC7A20_PEDO_KCAL_WRIST_SLEEP_INT_SWAY_ALGO();//�����㷨
	result=SL_WRIST_Result();                            //̧�����������ȡ
	if(result==1)
	{
		tmos_start_task( PWR_TaskId, PWR_ON_EVT, 0 );
	   printf("tai shou result=%d\r\n",result);
	}
	//printf("STEP=%d\r\n",STEP);
		
		
		
		
		
		
		
		
	 tmos_start_task( Gsenor_TaskId, START_Gsenor_EVT, 600 );
	
	 return (events ^ START_Gsenor_EVT);
	}
	
	
	
	
	 return 0;
	
	
	
	

#if 0

  if ( events & START_REPORT_EVT )
  {
		
		/*
		  ���ͼ�ֵ
		*/
		//PRINT("START_REPORT_EVT send_char=%d\r\n",send_char);
		
    //hidEmuSendKbdReport( 4 );//���ͼ�����ֵhidEmuSendKbdReport����
		//hidEmuSendKbdReport( 0x00 );
		
		Send_To_Phone(Receive_ID);
		Send_To_Phone(RELEASE);
		
		//performPeriodicTask();//����֪ͨ
    Receive_ID=255;
		//tmos_start_task( hidEmuTaskId, START_REPORT_EVT, 2000 );
    return ( events ^ START_REPORT_EVT );
  }
 
	
	#endif
}







uint16 Time_ProcessEvent( uint8 task_id, uint16 events )
{

	  if ( events & START_Time_EVT )
  {
		  My_Time.second++;
			UI_Time_Update(&My_Time);
      tmos_start_task( Time_TaskId, START_Time_EVT, 1500);
	 return (events ^ START_Time_EVT);
	}
	 return 0;
}



uint16 ADC_ProcessEvent( uint8 task_id, uint16 events )
{
	
	  if ( events & ADC_EVT )
  {
    Get_Bat_Voltage();//��ȡ��ص�ѹ
		Bat_Update();
   tmos_start_task( ADC_TaskId, ADC_EVT, 100000 );
	 return (events ^ ADC_EVT);
	}
	 return 0;
}

uint16 PWR_ProcessEvent( uint8 task_id, uint16 events )
{
	
	
	
	 
	
	
	  if ( events & PWR_OFF_EVT )
  {
   LCD_Back_Light_Set(0);//��������
   //tmos_start_task( ADC_TaskId, ADC_EVT, 10000 );
	 return (events ^ PWR_OFF_EVT);
	}
	
		
	  if ( events & PWR_ON_EVT )
  {
   LCD_Back_Light_Set(100);//��������
   tmos_start_task( PWR_TaskId, PWR_OFF_EVT, 10000 );
	 return (events ^ PWR_ON_EVT);
	}
	
	
	
	
	
	
	
	
	
	 return 0;
}








uint16 UI_ProcessEvent( uint8 task_id, uint16 events )
{
	  if ( events & START_UI_EVT )
  {
		  UI_Process();
      tmos_start_task( UI_TaskId, START_UI_EVT, 300 );	
	 return (events ^ START_UI_EVT);
	}
	
	
	
	
	 return 0;
	
	

}


void Time_Init()
{
  My_Time.year=2021;
  My_Time.month=7;
	My_Time.day=10;
	My_Time.hour=23;
	My_Time.minute=50;
	My_Time.second=23;

}

void Time_Update(time_t *time,uint8_t *buf)
{
   uint8_t temp=0;
	temp=buf[1];
  time->year=(temp<<8)|buf[2];
	time->month=buf[3];
	time->day=buf[4];
	time->hour=buf[5];
	time->minute=buf[6];
	time->second=buf[7];
	
	
	UI_Time_Update(&My_Time);

	
  //RTC_InitTime( time->hour, time->minute,time->second ); //RTCʱ�ӳ�ʼ����ǰʱ��

}

void  Android_Protol_Analysic(uint8_t *buf)
{

  switch(buf[0])
	{
	
		case SYNC_TIME:
			
		Time_Update(&My_Time,buf);
		printf("%s",__FUNCTION__);
		break;
	
	
	
	}

}


