
#ifndef SL_Watch_Pedo_Kcal_Wrist_Sleep_Int_Sway_Application__H__
#define SL_Watch_Pedo_Kcal_Wrist_Sleep_Int_Sway_Application__H__


extern signed char   SL_SC7A20_PEDO_KCAL_WRIST_SLEEP_INT_SWAY_INIT(void);
extern unsigned int  SL_SC7A20_PEDO_KCAL_WRIST_SLEEP_INT_SWAY_ALGO(void);
extern void          SL_MCU_WAKEUP_IN_INT_SERVICE_FUNCTION(void);
extern unsigned char SL_MCU_SLEEP_ALGO_FUNCTION(void);
#endif
