#include "UI_Framework.h"
#include "flash.h"
 Menu_Index Current_Index =TIME_Index;

extern time_t My_Time;
extern uint8_t Voltage;//��ص�ѹ�ٷֱ�



UI_Func_t Page[]=
{
{TIME_Index,NULL,Time_Show,NULL},
//{STEP_Index,NULL,Step_Show,NULL},


};

uint32_t Refesh_Flag=0;
uint32_t Address=as_background_1_ADDRESS;


Object_t UI_object[]=
{
/* 
	char *name;          //��ǰ���������
	uint32_t addr;       //��ǰ��ͼƬ��ַ
  uint8_t width_size;  //��ǰ�������
	uint8_t height_size; //��ǰ����߶�
	uint8_t x_start;     //x��ʼ����
	uint8_t x_end;       //x��������
	uint8_t y_start;     //y��ʼ����
	uint8_t y_end;       //y��������
	Status_t status;     //��ǰ����״̬��̬���Ǿ�̬
 */
  {"up_line",                             as_down_line_1_ADDRESS,240,46,0,240,0,46,STATIC},//�ϻ���
	{"bat_icon",             as_bat_1_ADDRESS,20,28,               130,130+20,5,5+28,STATIC},//����ͼ��
	{"bat_hight",as_hr_num44_1_ADDRESS,18,30,160+18*0,160+18*0+18,5,5+30,STATIC},//��������ͼ��
	{"bat_mid",  as_hr_num44_1_ADDRESS,18,30,160+18*1,160+18*1+18,5,5+30,STATIC},//��������ͼ��
	{"bat_little",as_hr_num44_1_ADDRESS,18,30,160+18*2,160+18*2+18,5,5+30,STATIC},//��������ͼ��
	
	{"ch_am",as_am_ch_1_ADDRESS,59,30,30,30+59,5,5+30,STATIC},                  //����
	{"ch_pm",as_pm_ch_1_ADDRESS,58,30,30,30+58,5,5+30,STATIC},                  //����
	
	
	{"hour_hight",as_num80_1_ADDRESS,33,53,85+0*33,85+0*33+33,70,70+53,STATIC}, //��ʾСʱ��λ
	{"hour_little",as_num80_1_ADDRESS,33,53,85+1*33,85+1*33+33,70,70+53,STATIC},//��ʾСʱ��λ
	{"colon",as_point_1_ADDRESS,6,29, 90+1*33+35,90+1*33+35+6,85,85+29,STATIC}, //��ʾð��
	{"minute_hight",as_num80_1_ADDRESS,33,53,105+2*33,105+0*33+33,70,70+53,STATIC}, //��ʾ���Ӹ�λ
	{"minute_little",as_num80_1_ADDRESS,33,53,105+3*33,105+1*33+33,70,70+53,STATIC},//��ʾ���ӵ�λ
	{"gif",as_background_1_ADDRESS,84,90,0,0+84,50,50+90,STATIC},                   //��ʾ����
};

uint8_t move_flag=0;
void  Time_Show(uint8_t xs,uint8_t xe,uint8_t ys,uint8_t ye)
{
		//printf("%s\r\n",__FUNCTION__);
	for(int j=0;j<sizeof(UI_object)/sizeof(Object_t);j++)
	{

		if((Page[Current_Index].object[j].status==STATIC)&& move_flag==0)
		{			
			//ˢ��һ��ȫ���ؼ�
				Flash_LCD_ShowPicture
				(
				Page[Current_Index].object[j].x_start,
				Page[Current_Index].object[j].y_start,
				Page[Current_Index].object[j].width_size,
				Page[Current_Index].object[j].height_size,
				Page[Current_Index].object[j].addr
				);
			
			  if(strcmp(Page[Current_Index].object[j].name,"gif")==0)
					{
					  move_flag=1;
						Page[Current_Index].object[j].status=DYNAMIC;
					}
			
		}else if(Page[Current_Index].object[j].status==DYNAMIC)
		{
			
			//�жϵ�ǰ�Ŀؼ�Ϊ��̬
			
			
			
			
		      //if(j==sizeof(UI_object)/sizeof(Object_t) -1)
			/*
			if(strcmp(Page[Current_Index].object[j].name,"minute_little")==0)
			{
						Flash_LCD_ShowPicture
				(
				Page[Current_Index].object[j].x_start,
				Page[Current_Index].object[j].y_start,
				Page[Current_Index].object[j].width_size,
				Page[Current_Index].object[j].height_size,
				Page[Current_Index].object[j].addr
				);
			}
			*/
			
			if(strcmp(Page[Current_Index].object[j].name,"gif")==0)
			{
	
			   //Page[Current_Index].object[j].addr=Address+Refesh_Flag*2*90*84;
				
				 Page[Current_Index].object[j].addr+=/*Refesh_Flag**/2*90*84;
							Flash_LCD_ShowPicture
				(
				Page[Current_Index].object[j].x_start,
				Page[Current_Index].object[j].y_start,
				Page[Current_Index].object[j].width_size,
				Page[Current_Index].object[j].height_size,
				Page[Current_Index].object[j].addr
				);
				
				UI_Time_Update(&My_Time);
				 Refesh_Flag++;
						if(Refesh_Flag==14)
				{
					
					#if 0
					for(int k=0;k<sizeof(UI_object)/sizeof(Object_t);k++)
					{
					  if(strcmp(Page[Current_Index].object[k].name,"minute_little")==0)
						{
							printf("-----------------------------------find ok\r\n");
						  Page[Current_Index].object[k].status=DYNAMIC;
							
							My_Time.minute/10;
							My_Time.minute%10;
							
							Page[Current_Index].object[k].addr= (My_Time.minute%9)2*33*53;//53;
							printf(" Page[Current_Index].object[i].status=%d\r\n",Page[Current_Index].object[k].status);
							printf(" Page[Current_Index].object[i].addr=%x\r\n",Page[Current_Index].object[k].addr);

							if(Page[Current_Index].object[k].addr==as_num80_1_ADDRESS+10*2*33*53)
							{
							  Page[Current_Index].object[k].addr=as_num80_1_ADDRESS;
							}
								Flash_LCD_ShowPicture
							(
							Page[Current_Index].object[k].x_start,
							Page[Current_Index].object[k].y_start,
							Page[Current_Index].object[k].width_size,
							Page[Current_Index].object[k].height_size,
							Page[Current_Index].object[k].addr
							);
							break;
						
						}
					}
					
					
					#endif
	
					
				   Refesh_Flag=0;
					 Page[Current_Index].object[j].addr=as_background_1_ADDRESS;
					
					
					//
//					UI_Time_Update(&My_Time);
					
				}
			}
			
			

					  if(strcmp(Page[Current_Index].object[j].name,"minute_little")==0)
						{
							
							
							 Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
		
								Page[Current_Index].object[j].addr=as_num80_1_ADDRESS+(My_Time.minute%10)*2*33*53;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);		
							
						}
			
						
						
									  if(strcmp(Page[Current_Index].object[j].name,"minute_hight")==0)
						{
							
							
							 Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
		
								Page[Current_Index].object[j].addr=as_num80_1_ADDRESS+(My_Time.minute/10)*2*33*53;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);		
							
						}		

						
					  if(strcmp(Page[Current_Index].object[j].name,"hour_little")==0)
						{
							
							 Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
		
								Page[Current_Index].object[j].addr=as_num80_1_ADDRESS+(My_Time.hour%10)*2*33*53;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);		
						}
						
						if(strcmp(Page[Current_Index].object[j].name,"hour_hight")==0)
						{
														
							 Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
		
								Page[Current_Index].object[j].addr=as_num80_1_ADDRESS+(My_Time.hour/10)*2*33*53;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);		
						}	
			
			
			
			
						
		
			
					if(My_Time.hour<12)
					{	
			
					  if(strcmp(Page[Current_Index].object[j].name,"ch_am")==0)
						{
				
						    Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
		
								Page[Current_Index].object[j].addr=as_am_ch_1_ADDRESS;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);	
						
							
						}
					}		
						else if(My_Time.hour>=12)
					{
						if(strcmp(Page[Current_Index].object[j].name,"ch_pm")==0)
						{
						   Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
		
								Page[Current_Index].object[j].addr=as_pm_ch_1_ADDRESS;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);	
						}					
					}
					
					
					
					
					
					

					
					
					///////////////////////////////////////////////////////////////////////
								if(strcmp(Page[Current_Index].object[j].name,"bat_hight")==0)
						{
							//printf("bat_hight-----------------------------------------------HIG=%d---------------------\r\n",Voltage/100);						

							
							 Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
		
								Page[Current_Index].object[j].addr=as_hr_num44_1_ADDRESS+(Voltage/100)*2*18*30;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);		
							
						}		

						
					  if(strcmp(Page[Current_Index].object[j].name,"bat_mid")==0)
						{
							
							 Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
	               
						//printf("bat_mid-----------------------------------------------MID=%d--------------------\r\n",Voltage/10%10);
								Page[Current_Index].object[j].addr=as_hr_num44_1_ADDRESS+((Voltage/10%10))*2*18*30;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);		
						}
						
						if(strcmp(Page[Current_Index].object[j].name,"bat_little")==0)
						{
													
							 Page[Current_Index].object[j].status= !Page[Current_Index].object[j].status;//�л���ǰ״̬
		//printf("bat_little-------------------------------------------LIT=%d------------------------\r\n",Voltage%100);	
								Page[Current_Index].object[j].addr=as_hr_num44_1_ADDRESS+((Voltage%10))*2*18*30;
											Flash_LCD_ShowPicture
								(
								Page[Current_Index].object[j].x_start,
								Page[Current_Index].object[j].y_start,
								Page[Current_Index].object[j].width_size,
								Page[Current_Index].object[j].height_size,
								Page[Current_Index].object[j].addr
								);		
						}	
			
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
		}
						
						
						
						
						
		

			
		
		
		
		/*printf("x_start=%d,y_start=%d,width_size=%d,height_size=%d,addr=%x\r\n",
		Page[Current_Index].object[j].x_start,
		Page[Current_Index].object[j].y_start,
		Page[Current_Index].object[j].width_size,
		Page[Current_Index].object[j].height_size,
		Page[Current_Index].object[j].addr
		
		);*/
	
	}
}
	
	


void  Step_Show(uint8_t xs,uint8_t xe,uint8_t ys,uint8_t ye)
{
	printf("%s\r\n",__FUNCTION__);
}


void Create_Object_In_Page(Menu_Index index,UI_Func_t page[])
{
	Object_t *object;
  Object_t *p; 

		//printf("%s\r\n",__FUNCTION__);
	for(int i=0;i<sizeof(Page)/sizeof(UI_Func_t);i++)
	{
	  if(page[i].index==index)
		{			    
		 object=(Object_t*)malloc(sizeof(Object_t)*sizeof(UI_object)/sizeof(Object_t));
		 page[i].object=object;
		 p=page[i].object;
			#if 1
		   for(int j=0;j<sizeof(UI_object)/sizeof(Object_t);j++)
			{
			  //object=(Object_t*)malloc(sizeof(Object_t)*sizeof(UI_object)/sizeof(Object_t));
        p->name=UI_object[j].name;
		    p->addr=UI_object[j].addr;
				p->width_size=UI_object[j].width_size;
				p->height_size=UI_object[j].height_size;
				p->x_start=UI_object[j].x_start;
				p->x_end=UI_object[j].x_end;
				p->y_start=UI_object[j].y_start;
				p->y_end=UI_object[j].y_end;
				p->status=UI_object[j].status;
	
			  //object->name= UI_object[j].name;
				//strcpy(page[i].object[j].name,UI_object[j].name);
				//page[i].object[j].    =&UI_object[j].addr;
			
        			
				//strcpy((&page[i].object[j])->name,UI_object[j].name);
	      //(page[i].object[j]).name  = UI_object[j].name;
				
				#if 0
			  printf("UI_object[%d].name=%s\r\n",j,UI_object[j].name);
			  printf("page[%d].object[%d].name=%s\r\n",i,j,page[i].object[j].name);
				printf("Page[%d].object[%d].name=%s\r\n",i,j,Page[i].object[j].name);
				printf("UI_object[%d].addr=%x\r\n",j,UI_object[j].addr);
				printf("Page[%d].object[%d].addr=%x\r\n",i,j,page[i].object[j].addr);
				#endif
				p++;
				  //page[i].object[j].name=UI_object[j].name;
				//page[i].object++;	
				 
				  //strcpy(page[i].object[j].name,UI_object[j].name);
				
				  //memcpy( page[i].object,UI_object, sizeof(UI_object));
					//page[i].object[j].addr=UI_object[j].addr;
				/*
		    Page[i].object[j].addr=UI_object[j].addr;
			  Page[i].object[j].height_size=UI_object[j].height_size;
				
				strcpy(Page[i].object[j].name,UI_object[j].name);
				//Page[i].object[j].name=UI_object[j].name;
				Page[i].object[j].status=UI_object[j].status;
				Page[i].object[j].width_size=UI_object[j].width_size;
				Page[i].object[j].x_end=UI_object[j].x_end;
				Page[i].object[j].x_start=UI_object[j].x_start;
				Page[i].object[j].y_end=UI_object[j].y_end;
				Page[i].object[j].y_start=UI_object[j].y_start;
				*/
				/*	printf("UI_object[%d].name=%s\r\n",j,UI_object[j].name);
					printf("Page[%d].object[%d].name=%s\r\n",i,j,page[i].object[j].name);

				printf("UI_object[%d].addr=%x\r\n",j,UI_object[j].addr);
				printf("Page[%d].object[%d].addr=%x\r\n",i,j,page[i].object[j].addr);*/
	/*			
	char *name;          //��ǰ���������
	uint32_t addr;       //��ǰ��ͼƬ��ַ
  uint8_t width_size;  //��ǰ�������
	uint8_t height_size; //��ǰ����߶�
	uint8_t x_start;     //x��ʼ����
	uint8_t x_end;       //x��������
	uint8_t y_start;     //y��ʼ����
	uint8_t y_end;       //y��������
	Status_t status;     //��ǰ����״̬��̬���Ǿ�̬
		*/		
				
				
				
				 /* Page[i].object =&UI_object[j];
				  *(Page[i].object++);*/
				
//			   printf("%s Page[%d].object[%d]=UI_object[%d],addr=%x,addr=%x\r\n",__FUNCTION__,i,j,j,UI_object[j].addr,Page[i].object[j].addr);
				
			}
			
			#endif
		}
	}
	
	
	//free(object);
}


void UI_Init()
{
		printf("%s\r\n",__FUNCTION__);
  for(int i=0;i<sizeof(Page)/sizeof(UI_Func_t);i++)
	{
   Create_Object_In_Page(i,Page);//��������
	}
}
	
void UI_Process()
{
	//printf("%s\r\n",__FUNCTION__);
  for(int i=0;i<sizeof(Page)/sizeof(UI_Func_t);i++)
	{
   if(Current_Index==Page[i].index)
	 {
		 //printf("Current_Index==Page[i].index   show\r\n");
	   Page[i].Show(0,0,0,0);
	  return;
	 }
	}

}

void Page_Change( Menu_Index  index)
{

   Current_Index=index;

}
	

void UI_Time_Update(time_t *time)
{
	//printf("------------------%s---------------\r\n",__FUNCTION__);
  /*uint8_t temp=0;
	temp=buf[1];
  time->year=(temp<<8)|buf[2];
	time->month=buf[3];
	time->day=buf[4];
	time->hour=buf[5];
	time->minute=buf[6];
	time->second=buf[7];
	*/
	
  //time->second++;
	
	if(time->second>=60)
	{
			printf("time->second=^%d\r\n",time->second);
			time->second=0;
			time->minute++;	
		

		
		
	}
	
	
	
		          for(int k=0;k<sizeof(UI_object)/sizeof(Object_t);k++)
		{
					  if(strcmp(Page[Current_Index].object[k].name,"minute_little")==0)
						{
							//printf(" if(strcmp(Page[Current_Index].object[k].name,minute_little)==0)\r\n");
							 Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
						}
						
						if(strcmp(Page[Current_Index].object[k].name,"minute_hight")==0)
						{
							Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
						}	
						
   
		}
	
	
	
				for(int k=0;k<sizeof(UI_object)/sizeof(Object_t);k++)
		{
			
			
			
					  if(strcmp(Page[Current_Index].object[k].name,"hour_little")==0)
						{
							//printf(" if(strcmp(Page[Current_Index].object[k].name,minute_little)==0)\r\n");
							 Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
						}
						
						if(strcmp(Page[Current_Index].object[k].name,"hour_hight")==0)
						{
							Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
						}					
   
		}
	
	
	
	

	
	if(time->minute>=60)
	{
		time->minute=0;
	//	printf("time->hour=%d\r\n",time->hour);
		
		
			for(int k=0;k<sizeof(UI_object)/sizeof(Object_t);k++)
		{
			
			
			
					  if(strcmp(Page[Current_Index].object[k].name,"hour_little")==0)
						{
							//printf(" if(strcmp(Page[Current_Index].object[k].name,minute_little)==0)\r\n");
							 Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
						}
						
						if(strcmp(Page[Current_Index].object[k].name,"hour_hight")==0)
						{
							Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
						}					
   
		}
		
		time->hour++;
		//printf("time->hour=%d\r\n",time->hour);
		
	}
	
	
	
	
	
	
	
//	
//	{"ch_am",as_am_ch_1_ADDRESS,59,30,30,30+59,5,5+30,STATIC},                  //����
//	{"ch_pm",as_pm_ch_1_ADDRESS,58,30,30,30+58,5,5+30,STATIC},                  //����
//	
	
	
					for(int k=0;k<sizeof(UI_object)/sizeof(Object_t);k++)
		{
			
					if(time->hour<12)
					{	
			
					  if(strcmp(Page[Current_Index].object[k].name,"ch_am")==0)
						{
							//printf(" if(strcmp(Page[Current_Index].object[k].name,minute_little)==0)\r\n");
							 Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
						}
					}		
						else if(time->hour>=12)
					{
						if(strcmp(Page[Current_Index].object[k].name,"ch_pm")==0)
						{
							Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
						}					
					}
		}
	
	
	if(time->hour>=24)
	{
		time->hour=0;
		time->day++;
	}
	
}



void Bat_Update()
{
	
	
						
//	{"bat_hight",as_hr_num44_1_ADDRESS,18,30,160+18*0,160+18*0+18,5,5+30,STATIC},//��������ͼ��
//	{"bat_mid",  as_hr_num44_1_ADDRESS,18,30,160+18*1,160+18*1+18,5,5+30,STATIC},//��������ͼ��
//	{"bat_little",as_hr_num44_1_ADDRESS,18,30,160+18*2,160+18*2+18,5,5+30,STATIC},//��������ͼ��
					
	
	
	

						for(int k=0;k<sizeof(UI_object)/sizeof(Object_t);k++)
					{
						
						
						
									if(strcmp(Page[Current_Index].object[k].name,"bat_hight")==0)
									{
										//printf(" if(strcmp(Page[Current_Index].object[k].name,minute_little)==0)\r\n");
										 Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
									}
									
									if(strcmp(Page[Current_Index].object[k].name,"bat_mid")==0)
									{
										Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
									}			

									if(strcmp(Page[Current_Index].object[k].name,"bat_little")==0)
									{
										Page[Current_Index].object[k].status=DYNAMIC;//�л���ǰ״̬
									}											
				 
					}


}

