#ifndef __I2C_H__
#define __I2C_H__
#include "CH57x_common.h"
#include "CH57xBLE_LIB.h"
void IIC_Init();




void IIC_Test(char txd);

void Read_Reg(uint8 ID,uint8 reg,uint8 *dat);



#endif