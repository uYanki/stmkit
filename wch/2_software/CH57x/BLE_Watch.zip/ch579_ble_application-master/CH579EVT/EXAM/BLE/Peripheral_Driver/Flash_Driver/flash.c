#include "flash.h"


void W25Q_flash_Init()
{
	uint16 count=0;
	uint32_t  Flash_Id=0;
	uint8 ID[3]={0};
 GPIOB_ModeCfg(FLASH_CS, GPIO_ModeOut_PP_5mA); //��ʼ��flash CS����
 Flash_Disble
 
 Flash_Enable
 SPI0_MasterSendByte(0x9F);
 SPI0_MasterRecv(ID,3);
 Flash_Id=	(ID[0]<<16)|(ID[1]<<8)|ID[2];
 Flash_Disble
 if(W25Q64==Flash_Id)	
 {
   printf("W25Q64\r\n");
 }
// printf("Flash_Id=%x\r\n",Flash_Id);
// printf("%x%x%x",ID[0],ID[1],ID[2]);
 

//Show_Chinese(0,0,"����������Ϊ�Լ�����",WHITE,0,16);

// #define                        0x23b30c//����*�߶�*2  60 55
//#define                        0x23ccd4//����*�߶�*2  60 50
//#define                        0x23e444//����*�߶�*2  60 50
//#define                        0x23fbb4//����*�߶�*2  80 65
 

 
 
// Flash_LCD_ShowPicture(0,0,240,135,zm_ADDRESS);
// Flash_LCD_ShowPicture(0,0,240,135,z_1_ADDRESS);
// Flash_LCD_ShowPicture(0,0,240,135,z_2_ADDRESS);
// 
// 
 
 
LCD_Fill(0,0,LCD_W,LCD_H,BLACK);

#if 0
Flash_LCD_ShowPicture(0,0,240,46,as_down_line_1_ADDRESS);

//Flash_LCD_ShowPicture(0,120,240,46,as_up_line_1_ADDRESS);

Flash_LCD_ShowPicture(130,5,20,28,as_bat_1_ADDRESS);//��ʾ����


Flash_LCD_ShowPicture(160+18*0,5,18,30,as_hr_num44_1_ADDRESS);//��ʾ����
Flash_LCD_ShowPicture(160+18*1,5,18,30,as_hr_num44_1_ADDRESS);//��ʾ����
Flash_LCD_ShowPicture(160+18*2,5,18,30,as_hr_num44_1_ADDRESS);//��ʾ����



Flash_LCD_ShowPicture(30,5,59,30,as_am_ch_1_ADDRESS);


//#define  as_num80_1_ADDRESS                      0x20b3f4//����*�߶�*2  33 530
//#define  as_point_1_ADDRESS                      0x21562c//����*�߶�*2  6 29

Flash_LCD_ShowPicture(85+0*33,70,33,53,as_num80_1_ADDRESS+0*33*53*2);
Flash_LCD_ShowPicture(85+1*33,70,33,53,as_num80_1_ADDRESS+1*33*53*2);

Flash_LCD_ShowPicture(85+1*33+35,70+15,6,29,as_point_1_ADDRESS);//��ʾð��

Flash_LCD_ShowPicture(105+2*33,70,33,53,as_num80_1_ADDRESS+2*33*53*2);
Flash_LCD_ShowPicture(105+3*33,70,33,53,as_num80_1_ADDRESS+3*33*53*2);


 
 for(int i=0;i<15;i++)
 {
	 if(i==14)
	 {
		 count++;
		 if(count>=10)break;
	   i=0;
	 }
   Flash_LCD_ShowPicture(0,135-85,84,90,as_background_1_ADDRESS+i*2*90*84);
 }
 #endif
 
 
 
 
#if 0 
 DelayMs( 1000 );
 LCD_Fill(0,0,LCD_W,LCD_H,BLACK);
 
 
 
 

Flash_LCD_ShowPicture(0,135-46,240,46,as_up_line_1_ADDRESS);//��ʾ�»���

Flash_LCD_ShowPicture(20,5,68,25,as_Steps_1_ADDRESS);//��ʾ����


Flash_LCD_ShowPicture(0+18*0,50,18,30,as_hr_num44_1_ADDRESS);//��ʾ����
Flash_LCD_ShowPicture(0+18*1,50,18,30,as_hr_num44_1_ADDRESS);//��ʾ����
Flash_LCD_ShowPicture(0+18*2,50,18,30,as_hr_num44_1_ADDRESS);//��ʾ����
Flash_LCD_ShowPicture(0+18*3,50,18,30,as_hr_num44_1_ADDRESS);//��ʾ����


   //��ʾ����
 Flash_LCD_ShowPicture(20,135-46+10,77,30,as_week_en_1_ADDRESS);
 
//Flash_LCD_ShowPicture(0,5,59,30,as_am_ch_1_ADDRESS);



Flash_LCD_ShowPicture(140+0*18,135-46+10,18,30,as_hr_num44_1_ADDRESS+0*18*30*2);
Flash_LCD_ShowPicture(140+1*18,135-46+10,18,30,as_hr_num44_1_ADDRESS+1*18*30*2);



//Flash_LCD_ShowPicture(20,20,100,99,cxy_11_ADDRESS);//��ʾ����
Flash_LCD_ShowPicture(240-100,20,100,63,cxy_10_ADDRESS);//��ʾ����



Flash_LCD_ShowPicture(140+2*18,135-46+10,7,33,as_line_1_ADDRESS);

Flash_LCD_ShowPicture(140+2*18+10,135-46+10,18,30,as_hr_num44_1_ADDRESS+2*18*30*2);
Flash_LCD_ShowPicture(140+3*18+10,135-46+10,18,30,as_hr_num44_1_ADDRESS+3*18*30*2);


 
#endif
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
// Flash_LCD_ShowPicture(0,70,60,50,cxy_03_ADDRESS);
// Flash_LCD_ShowPicture(80,70,80,65,cxy_04_ADDRESS);
// Flash_LCD_ShowPicture(0,0,68,25,as_Steps_1_ADDRESS);
// Flash_LCD_ShowPicture(0,0,68,25,as_Steps_1_ADDRESS);
// Flash_LCD_ShowPicture(0,0,68,25,as_Steps_1_ADDRESS);
 //while(1);
}


//��ʾ��ʼ���� x,y            �ַ��� ������ɫ  ����ɫ   �ֺ�
void Show_Chinese(u16 x,u16 y,u8 *s, u16 fc,   u16 bc,u8 size)
{
	uint8_t  flag=0;//�жϵ�ǰ�Ƿ�ƥ��ɹ���־
	 uint16  words_num=0;
   uint32_t index=0;	
	 uint32_t count=0;
	 uint8_t reg=0;
	 uint8_t  read_buf[32]={0};
	 uint8_t  read_16_buf[32]={0};
	 uint8_t  read_24_buf[72]={0};
	 uint8_t  read_32_buf[128]={0};
	 uint32_t  addr=0;     //�ӵ�ַ0��ȡ
	 uint32_t  font_addr=0;//�ӵ�ַ0��ȡ
	 uint8_t   addr_temp=0;
   count=	0x000034D5 -0x00000000; //���㺺�ָ���
   u8 *word; 
	 
	 u16 x0=x;
   
    word=s;
 while(*s!='\0')//�ж��Ƿ�Ϊ�ַ���ĩβ
 {
	    words_num++; 
	 		s++;
 }
 words_num=words_num/2;//ͳ�����ָ���
 printf("words_num=%d\r\n",words_num);

 for(int k=0;k<words_num;k++) //����ѭ��
 
 {
				//printf("for(int k=0;k<words_num;k++)\r\n"); 
							for(int i=0;i<(count+1)/32;i++)
							{
								
								//printf("for(int i=0;i<(count+1)/32;i++)\r\n");
								flag=0;//��־	
								 Flash_Enable
								reg=0x03;
								//���Ͷ�����
								SPI0_MasterDMATrans(&reg,1);
								
								//��������һ����Ҫ��ȡ��24λ��ַ   0xyy123456
								addr_temp=(addr>>16)&0xFF;
								SPI0_MasterDMATrans(&addr_temp,1);//0x12   ����[23:16]
								addr_temp=(addr>>8)&0xFF;
								SPI0_MasterDMATrans(&addr_temp,1);//0x34    ����[15:8]
								addr_temp=(addr>>0)&0xFF;
								SPI0_MasterDMATrans(&addr_temp,1);//0x56    ����[7:0]
								SPI0_MasterDMARecv(read_buf, 32);
								Flash_Disble
								
								for(int j=0;j<16;j++)
							{		
							     							
									if( (read_buf[j*2]==*(word)) && (read_buf[j*2+1]==*(word+1)) ) //����ƥ��ɹ�
									{
										printf("%x,%x",*(word),*(word+1));
											//ƥ��ɹ�
											index=(i*32+j*2)/2;//��ȡ��������
										printf("index=%d,i=%d,j=%d\r\n",index,i,j);
										flag=1;//��־
										addr=0;//��ַ���㷽���¸�����������ַ
										
										//LCD��ʾ�����߼����
										
	              
									 
					
									  if(size==16)
										{
											 LCD_Address_Set(x,y,x+size-1,y+size-1);//��������
											
                      font_addr=Chinese_Font_16_Address+index*32;//��ȡ���ֵ�ַ
											
											
	                  	 Flash_Enable
											reg=0x03;
											//���Ͷ�����
											SPI0_MasterDMATrans(&reg,1);
											
											//��������һ����Ҫ��ȡ��24λ��ַ   0xyy123456
											addr_temp=(font_addr>>16)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x12   ����[23:16]
											addr_temp=(font_addr>>8)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x34    ����[15:8]
											addr_temp=(font_addr>>0)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x56    ����[7:0]
											SPI0_MasterDMARecv(read_16_buf, 32);
											Flash_Disble
											
											
											
									    for(int i=0;i<32;i++)
															for(j=0;j<8;j++)
																{						
																								/*if(!mode)//�ǵ��ӷ�ʽ
																								{
																									if(tfont16[k].Msk[i]&(0x01<<j))LCD_WR_DATA(fc);
																									else LCD_WR_DATA(bc);
																								}
																								else//���ӷ�ʽ*/
																								{
																									if(read_16_buf[i]&(0x01<<j))	LCD_DrawPoint(x,y,fc);//��һ����
																									x++;
																									if((x-x0)==size)
																									{
																										x=x0;
																										y++;
																										break;
																									}
																								}																
									
															  }

										}
										
										else if(size==24)
										{
											 LCD_Address_Set(x,y,x+size-1,y+size-1);//��������
											
											font_addr=Chinese_Font_24_Address+index*72;//��ȡ���ֵ�ַ
											
											
		                   Flash_Enable
											reg=0x03;
											//���Ͷ�����
											SPI0_MasterDMATrans(&reg,1);
											
											//��������һ����Ҫ��ȡ��24λ��ַ   0xyy123456
											addr_temp=(font_addr>>16)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x12   ����[23:16]
											addr_temp=(font_addr>>8)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x34    ����[15:8]
											addr_temp=(font_addr>>0)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x56    ����[7:0]
											SPI0_MasterDMARecv(read_24_buf, 72);
											Flash_Disble
											
											
											
									    for(int i=0;i<72;i++)
															for(j=0;j<8;j++)
																{						
																								/*if(!mode)//�ǵ��ӷ�ʽ
																								{
																									if(tfont16[k].Msk[i]&(0x01<<j))LCD_WR_DATA(fc);
																									else LCD_WR_DATA(bc);
																								}
																								else//���ӷ�ʽ*/
																								{
																									if(read_24_buf[i]&(0x01<<j))	LCD_DrawPoint(x,y,fc);//��һ����
																									x++;
																									if((x-x0)==size)
																									{
																										x=x0;
																										y++;
																										break;
																									}
																								}																
									
															  }
											
											
											
											
											
											
											
											
											
											
											
											
											
											
											
										}else if(size==32)
		                {
											
										  LCD_Address_Set(x,y,x+size-1,y+size-1);//��������
											
											font_addr=Chinese_Font_32_Address+index*128;//��ȡ���ֵ�ַ
											
											
		                   Flash_Enable
											reg=0x03;
											//���Ͷ�����
											SPI0_MasterDMATrans(&reg,1);
											
											//��������һ����Ҫ��ȡ��24λ��ַ   0xyy123456
											addr_temp=(font_addr>>16)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x12   ����[23:16]
											addr_temp=(font_addr>>8)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x34    ����[15:8]
											addr_temp=(font_addr>>0)&0xFF;
											SPI0_MasterDMATrans(&addr_temp,1);//0x56    ����[7:0]
											SPI0_MasterDMARecv(read_32_buf, 128);
											Flash_Disble
											
											
											
									    for(int i=0;i<128;i++)
															for(j=0;j<8;j++)
																{						
																			
																									if(read_32_buf[i]&(0x01<<j))	LCD_DrawPoint(x,y,fc);//��һ����
																									x++;
																									if((x-x0)==size)
																	                // if(x==240)
																									{
																										x=x0;
																										y++;
																										break;
																									}
																																	
									
															  }
											

											
										
										}
																			
										break;
									}
							}						
				//				for(int j=0;j<32;j++)
				//				printf("%x,",read_buf[j]);
										if(flag!=1)
										{
										 addr+=32;
										}else{
										
										break;
										}
							}
//			printf("%x%x",*s,*(s+1));
							
		  //word+=2; 	
     word+=2; 								
		}		

 }

 
 
 
 
 
 
 
 
 
 
 
 /******************************************************************************
      ����˵������ʾͼƬ
      ������ݣ�x,y�������
                height ͼƬ�߶�
                width  ͼƬ����
                addr   ͼƬ��ַ    
      ����ֵ��  ��
******************************************************************************/


void Flash_LCD_ShowPicture(u16 x,u16 y,u16 width,u16 height, u32 addr)
{
	u16 num,i;
	u8 reg=0;
	u8 addr_temp=0;
	u8  read_buf[240*2]={0};
	
	
	for(int i=0;i<height;i++)
	{
	              Flash_Enable
								reg=0x03;
								//���Ͷ�����
								SPI0_MasterDMATrans(&reg,1);
								
								//��������һ����Ҫ��ȡ��24λ��ַ   0xyy123456
								addr_temp=(addr>>16)&0xFF;
								SPI0_MasterDMATrans(&addr_temp,1);//0x12   ����[23:16]
								addr_temp=(addr>>8)&0xFF;
								SPI0_MasterDMATrans(&addr_temp,1);//0x34    ����[15:8]
								addr_temp=(addr>>0)&0xFF;
								SPI0_MasterDMATrans(&addr_temp,1);//0x56    ����[7:0]
								SPI0_MasterDMARecv(read_buf,width*2);
								Flash_Disble


								LCD_Address_Set(x,y,x+width-1,y+1);
								LCD_CS_Clr();
								
								#if 1
								SPI0_MasterDMATrans(((u8*)read_buf),width*2);
								#else
									for(i=0;i<=num;i++)
									LCD_WR_DATA(pic[i]);
								#endif
								
								LCD_CS_Set();
								
								addr+=width*2;
								y++;
								
 }								
								
}


 
 
 
 
 
 