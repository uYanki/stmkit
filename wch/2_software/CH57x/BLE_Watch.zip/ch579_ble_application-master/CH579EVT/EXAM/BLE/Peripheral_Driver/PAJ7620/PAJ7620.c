#include "PAJ7620.h"
//��ʼ������
unsigned char init_register_array[][2] = {	// Initial Gesture

	{0xEF,0x00},
	{0x41,0xFF},//R_Int_1_En[7:0]
	{0x42,0x01},//R_Int_2_En[7:0]
	{0x46,0x2D},//R_AELedOff_UB[7:0]
	{0x47,0x0F},//R_AELedOff_LB[7:0]
	{0x48,0x70},//R_AE_Exposure_UB[7:0]
	{0x49,0x00},//R_AE_Exposure_UB[15:8]
	{0x4A,0x38},//R_AE_Exposure_LB[7:0]
	{0x4B,0x00},//R_AE_Exposure_LB[15:8]
	{0x4C,0x20},//R_AE_Gain_UB[7:0]
	{0x4D,0x00},//R_AE_Gain_LB[7:0]
	{0x51,0x10},//R_AE_EnH = 1
	{0x5C,0x02},//R_SenClkPrd[5:0]
	{0x5E,0x10},//R_SRAM_CLK_manual
	{0x80,0x42},//GPIO setting
	{0x81,0x44},//GPIO setting
	{0x82,0x0C},//Interrupt IO setting
	{0x83,0x20},//R_LightThd[7:0]
	{0x84,0x20},//R_ObjectSizeStartTh[7:0]
	{0x85,0x00},//R_ObjectSizeStartTh[9:8]
	{0x86,0x10},//R_ObjectSizeEndTh[7:0]
	{0x87,0x00},//R_ObjectSizeEndTh[9:8]
	{0x8B,0x01},//R_Cursor_ObjectSizeTh[7:0]
	{0x8D,0x00},//R_TimeDelayNum[7:0]
	{0x90,0x06},//R_NoMotionCountThd[6:0]
	{0x91,0x06},//R_NoObjectCountThd[6:0]
	{0x93,0x0D},//R_XDirectionThd[4:0]
	{0x94,0x0A},//R_YDirectionThd[4:0]
	{0x95,0x0A},//R_ZDirectionThd[4:0]
	{0x96,0x0C},//R_ZDirectionXYThd[4:0]
	{0x97,0x05},//R_ZDirectionAngleThd[3:0]
	{0x9A,0x14},//R_RotateXYThd[4:0]
	{0x9C,0x3F},//Filter setting
	{0x9F,0xF9},//R_UseBGModel is enable
	{0xA0,0x48},//R_BGUpdateMaxIntensity[7:0]
	{0xA5,0x19},//R_FilterAverage_Mode
	{0xCC,0x19},//R_YtoZSum[5:0]
	{0xCD,0x0B},//R_YtoZFactor[5:0]
	{0xCE,0x13},//bit[2:0] = R_PositionFilterLength[2:0]
	{0xCF,0x62},//bit[3:0] = R_WaveCountThd[3:0]
	{0xD0,0x21},//R_AbortXYRatio[4:0] & R_AbortLength[6:0]
	{0xEF,0x01},
	{0x00,0x1E},//Cmd_HSize[5:0]
	{0x01,0x1E},//Cmd_VSize[5:0]
	{0x02,0x0F},//Cmd_HStart[5:0]
	{0x03,0x0F},//Cmd_VStart[5:0]
	{0x04,0x02},//Sensor skip & flip
	{0x25,0x01},//R_LensShadingComp_EnH
	{0x26,0x00},//R_OffsetX[6:0]
	{0x27,0x39},//R_OffsetY[6:0]
	{0x28,0x7F},//R_LSC[6:0]
	{0x29,0x08},//R_LSFT[3:0]
	{0x30,0x03},//R_LED_SoftStart_time[7:0]
	{0x32,0x1A},//R_LED1_DAC_UB[4:0]
	{0x33,0x1A},//R_LED2_DAC_UB[4:0]
	{0x3E,0xFF},//Cmd_DebugPattern[7:0]
	{0x5E,0x3D},//analog voltage setting
	{0x65,0xAC},//R_IDLE_TIME[7:0] - 120fps
	{0x66,0x00},//R_IDLE_TIME[15:8]
	{0x67,0x97},//R_IDLE_TIME_SLEEP_1[7:0]
	{0x68,0x01},//R_IDLE_TIME_SLEEP_1[15:8]
	{0x69,0xCD},//R_IDLE_TIME_SLEEP_2[7:0]
	{0x6A,0x01},//R_IDLE_TIME_SLEEP_2[15:8]
	{0x6B,0xB0},//R_Obj_TIME_1[7:0]
	{0x6C,0x04},//R_Obj_TIME_1[15:8]
	{0x6D,0x2C},//R_Obj_TIME_2[7:0]
	{0x6E,0x01},//R_Obj_TIME_2[15:8]
	{0x72,0x01},//R_TG_EnH
	{0x73,0x35},//Auto Sleep & Wakeup mode
	{0x74,0x00},//R_Control_Mode[2:0]
	{0x77,0x01},//R_SRAM_Read_EnH
	{0xEF,0x00},

};
#define INIT_REG_ARRAY_SIZE (sizeof(init_register_array)/sizeof(init_register_array[0]))




/****************************************************************
 * Function Name: PAJ7620WriteReg
 * Description:  PAJ7620 Write reg cmd
 * Parameters: addr:reg address; cmd:function data
 * Return: error code; success: return 0
****************************************************************/
uint8_t PAJ7620WriteReg(uint8_t addr, uint8_t  cmd)
{
	
	IIC_Start();
  IIC_Send_Byte(PAJ7620_ID<<1);

	IIC_Wait_Ack();
	IIC_Send_Byte(addr);//д��Ҫ���ļĴ���

	IIC_Wait_Ack();
	IIC_Send_Byte(cmd);
	IIC_Wait_Ack();
	IIC_Stop();

}

/****************************************************************
 * Function Name: PAJ7620ReadReg
 * Description:  PAJ7620 read reg data
 * Parameters: addr:reg address;
 *			   qty:number of data to read, addr continuously increase;
 *			   data[]:storage memory start address
 * Return: error code; success: return 0
****************************************************************/
uint8_t PAJ7620ReadReg(uint8_t addr, uint8_t qty, uint8_t *data)
{

	IIC_Start();
  IIC_Send_Byte(PAJ7620_ID<<1);

	IIC_Wait_Ack();
	IIC_Send_Byte(addr);//д��Ҫ���ļĴ���

	IIC_Wait_Ack();
	IIC_Start();//��ʼ�ź�  ������ӻ�
	IIC_Send_Byte((PAJ7620_ID<<1)|1);
	IIC_Wait_Ack();
	*data=IIC_Read_Byte(0);
	IIC_Stop();
	
}

/****************************************************************
 * Function Name: PAJ7620SelectBank
 * Description:  PAJ7620 select register bank
 * Parameters: BANK0, BANK1
 * Return: none
****************************************************************/
void PAJ7620SelectBank(bank_e bank)
{
    switch(bank){
		case BANK0:
			PAJ7620WriteReg(PAJ7620_REGITER_BANK_SEL, PAJ7620_BANK0);
			break;
		case BANK1:
			PAJ7620WriteReg(PAJ7620_REGITER_BANK_SEL, PAJ7620_BANK1);
			break;
		default:
			break;
	}
}

/****************************************************************
 * Function Name: PAJ7620Init
 * Description:  PAJ7620 REG INIT
 * Parameters: none
 * Return: error code; success: return 0
****************************************************************/
uint8_t PAJ7620_Init(void)
{
	//Near_normal_mode_V5_6.15mm_121017 for 940nm
	int i = 0;
	uint8_t error;
	uint8_t data0 = 0, data1 = 0;
	//wakeup the sensor
	DelayMs(10);	//Wait  for PAJ7620U2 to stabilize
    printf("Init PAJ7620\r\n");
//	PAJ7620SelectBank(BANK0);
//	PAJ7620SelectBank(BANK0);

	PAJ7620ReadReg(0, 1, &data0);

	error = PAJ7620ReadReg(1, 1, &data1);

	if ( (data0 != 0x20 ) || (data1 != 0x76) )
	{
		printf("Init PAJ7620 fail\r\n");
	}
	for (i = 0; i < INIT_REG_ARRAY_SIZE; i++)
	{
		PAJ7620WriteReg(init_register_array[i][0], init_register_array[i][1]);
	}

	PAJ7620SelectBank(BANK0);  //gesture flage reg in Bank0
	printf("init PAJ7620 succcess\r\n");
	//Serial.println("PAJ7620 initialize register finished.");
	return 0;
}


//����ȫ�ֵı���
//uint16_t AngleAcc_Last=0;
//uint16_t AngleAcc_End=0;

signed int AngleAcc_Last=0;
signed int AngleAcc_End=0;


uint8_t  PAJ7620_Get_Result()
{
	uint8_t GES_data[2]={0};
	uint8_t AngleAcc1=0,AngleAcc2=0;
	uint8_t GES_Return=0;
	//��ʼ����ʶ���ж�
	//IIC_WriteReg(PAJ7620_I2C_ADDR,PAJ_SET_INT_FLAG1,0xff);
	//IIC_WriteReg(PAJ7620_I2C_ADDR,PAJ_SET_INT_FLAG2,0xff);
	//PAJ7620_intrrupt=1;
	//���Ƽ���ж�״̬
   //IIC_ReadData(PAJ7620_I2C_ADDR, 0x43, &data_[1]);
  //Zayn ���ӵĴ���
	//�ر�����ʶ���ж�
	//IIC_WriteReg(PAJ7620_I2C_ADDR,PAJ_SET_INT_FLAG1,0x00);
	//IIC_WriteReg(PAJ7620_I2C_ADDR,PAJ_SET_INT_FLAG1,0x00);
	PAJ7620ReadReg(0x43,1,&GES_data[0]);
	PAJ7620ReadReg(0x44,1,&GES_data[1]);
	
	//AngleAcc_Last=0;
	AngleAcc_End=0;
	PAJ7620ReadReg(0xC7,1,&AngleAcc1);
	PAJ7620ReadReg(0xC8,1,&AngleAcc2);
	AngleAcc_End=(AngleAcc1|(AngleAcc2<<8));
	//printf("AngleAcc_End=%d,AngleAcc_Last=%d\r\n",AngleAcc_End,AngleAcc_Last);

	if((GES_data[0]==0) &&(GES_data[1]==0)&&(AngleAcc_End==0))
	{
		
		     printf("GES_NONE_STATUS  \r\n");
	       GES_Return=GES_NONE_STATUS;
					return GES_Return;

	}
	
	if(AngleAcc_End)
	{
			printf("AngleAcc_End=%d,AngleAcc_Last=%d\r\n",AngleAcc_End,AngleAcc_Last);
		
		if(AngleAcc_End!=AngleAcc_Last)
			{
				if(AngleAcc_End-AngleAcc_Last<-16)
				{
					AngleAcc_Last=AngleAcc_End;
					//AngleAcc_End=0;
					//printf("AngleAcc_End=%d,AngleAcc_Last=%d\r\n",AngleAcc_End,AngleAcc_Last);
					printf("clockwise +\r\n");
					GES_Return=GES_CLOCKWISE_STATUS;
					return GES_Return;
				}

				if(AngleAcc_End-AngleAcc_Last>16)
				{
					AngleAcc_Last=AngleAcc_End;
					//AngleAcc_End=0;
					//printf("AngleAcc_End=%d,AngleAcc_Last=%d\r\n",AngleAcc_End,AngleAcc_Last);
					printf("clockwise  -\r\n");
					GES_Return=GES_COUNT_CLOCKWISE_STATUS;
					return GES_Return;
				}

			}
	}
	//AngleAcc_Last=0;
	AngleAcc_End=0;

	//printf("data[0]=%d,data[1]=%d",GES_data[0],GES_data[1]);
		switch(GES_data[0])
		{
		case GES_UP_FLAG :
			GES_Return=GES_UP_STATUS;
			printf("up\r\n");
		break;
		case GES_DOWN_FLAG:
			GES_Return=GES_DOWN_STATUS;
			printf("down\r\n");
		break;
		case GES_LEFT_FLAG:
			printf("left\r\n");
			GES_Return=GES_LEFT_STATUS;
			break;
		case GES_RIGHT_FLAG:
			printf("right\r\n");
			GES_Return=GES_RIGHT_STATUS;
			break;
		case GES_FORWARD_FLAG:
			GES_Return=GES_FORWARD_STATUS;
			printf("forward\r\n");break;
		case GES_BACKWARD_FLAG:
			GES_Return=GES_BACKWARD_STATUS;
			printf("backward\r\n");break;
		case GES_CLOCKWISE_FLAG:
			AngleAcc_End=0;
			AngleAcc_Last=0;
			printf("clockwise\r\n");break;
		case GES_COUNT_CLOCKWISE_FLAG:
			AngleAcc_End=0;
			AngleAcc_Last=0;
			printf("count clockwise\r\n");break;
		//case GES_WAVE_FLAG:break;
		default:break;
		//case :break;
		}

		switch(GES_data[1])
		{
		case GES_WAVE_FLAG:	printf("wave\r\n");break;
		default:break;
		}
		GES_data[0]=0;
		GES_data[1]=0;

		return GES_Return;
}

