#ifndef __BAT_H__
#define __BAT_H__
#include "ch57x_adc.h"
#include "My_appcation.h"

void Bat_Init();
uint8 Get_Bat_Voltage();

#endif