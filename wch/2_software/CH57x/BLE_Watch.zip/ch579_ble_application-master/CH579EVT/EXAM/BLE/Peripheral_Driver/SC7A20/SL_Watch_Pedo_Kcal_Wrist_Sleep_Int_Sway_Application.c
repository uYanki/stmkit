
#include "SL_Watch_Pedo_Kcal_Wrist_Sleep_Int_Sway_Algorithm.h"



#if SL_Sensor_Algo_Release_Enable==0x00
#include "usart.h"
extern signed short          SL_DEBUG_DATA[10][128];
extern unsigned char         SL_DEBUG_DATA_LEN;
#endif

#if SL_Sensor_Algo_Release_Enable==0x00
extern signed short          SL_ACCEL_DATA_Buf[3][16];
extern unsigned char         SL_FIFO_ACCEL_PEDO_NUM;
signed short                 hp_buf[16];
#endif


#define SL_SC7A20_SPI_IIC_MODE  1
/***SL_SC7A20_SPI_IIC_MODE==0  :SPI*******/
/***SL_SC7A20_SPI_IIC_MODE==1  :IIC*******/

/**Please modify the following parameters according to the actual situation**/
signed char SL_SC7A20_PEDO_KCAL_WRIST_SLEEP_INT_SWAY_INIT(void)
{
	unsigned char  status            =0;
	unsigned char  fifo_status       =0;
	unsigned char  sl_person_para[4] ={178,60,26,1};
	unsigned char  Turn_Wrist_Para[2]={3,5};//refer pdf
	unsigned char  sl_int_para[4]    ={1,0,4,2};//refer pdf
/*****if use spi mode please config first******/    
#if SL_SC7A20_SPI_IIC_MODE == 0//spi
    status=SL_SC7A20_Driver_Init(1,0x04);//iic mode pull up config 
	//init sensor
	status=SL_SC7A20_Driver_Init(0,0x04);//spi or iic select
#else
 	status=SL_SC7A20_Driver_Init(1,0x00);//spi or iic select   
	//0x08-->close sdo pull up
#endif
    /**********sc7a20 fifo test***************/
	//fifo_status=SL_SC7A20_FIFO_TEST();
	
    /**********set pedo sensitivity***********/
//    SL_PEDO_TH_SET(26,10,0);
	    SL_PEDO_TH_SET(16,5,4);
	/*which axis used to pedo depend on algo**/
	SL_PEDO_SET_AXIS(3);
    /**********set int para*******************/
    SL_Sc7a20_Int_Config(&sl_int_para[0]);
	/**********set motion para****************/ 
	SL_Pedo_Person_Inf_Init(&sl_person_para[0]);//personal para init
    /**********set turn wrist para************/  
    SL_Turn_Wrist_Init(&Turn_Wrist_Para[0]);
    /**********set sleep sensitivity**********/
    SL_Sleep_Para(120,8,1);
	
	return status;
}

static unsigned int   SL_STEP                  = 0;
static unsigned int   SL_STEP_TEMP             = 0;
static unsigned char  SL_STEP_MOTION           = 0;
static unsigned int	  SL_DISTANCE              = 0;
static unsigned int	  SL_KCAL                  = 0;    
static unsigned char  SL_CADENCE_STEP          = 0;//step per minutes
static unsigned short SL_CADENCE_AMP           = 0;//Equal scale scaling 
static unsigned char  SL_CADENCE_DEGREE        = 0;//degree
static signed char    SL_WRIST                 = 0;
static unsigned char  SL_INT_CNT               = 0;//counter
static unsigned char  SL_ACTION                = 0;
static unsigned char  SL_SLEEP_ACTIVE          = 0;
static unsigned char  SL_SLEEP_STATUS          = 0;
static unsigned char  SL_SLEEP_ADOM            = 0;
static unsigned char  SL_CLOCK_STATUS          = 0;
static unsigned char  SL_SWAY_STATUS           = 0;
static unsigned char  SL_SWAY_ENABLE           = 0;

unsigned int  SL_SC7A20_PEDO_KCAL_WRIST_SLEEP_INT_SWAY_ALGO(void)
{
#if SL_Sensor_Algo_Release_Enable==0x00
	unsigned char         sl_i;
#endif
	signed short          SC7A20_XYZ_Buf[3][16];
	unsigned char         SC7A20_FIFO_NUM;
	
    /*******get sc7a20 FIFO data******/
	SC7A20_FIFO_NUM= SL_SC7A20_Read_FIFO();	

    /*******get pedo value************/
    SL_STEP= SL_Watch_Pedo_Kcal_Algo();
	/*********get sleep active degree value*********/
	SL_SLEEP_ACTIVE=SL_Sleep_Active_Degree(0);
	/*******get accel orginal data and length*******/
	SC7A20_FIFO_NUM=SL_SC7A20_GET_FIFO_Buf(&SC7A20_XYZ_Buf[0][0],&SC7A20_XYZ_Buf[1][0],&SC7A20_XYZ_Buf[2][0]);

	/* SL_Pedo_GetMotion_Status */
	SL_STEP_MOTION       = SL_Pedo_GetMotion_Status();
	/* SL_Pedo_Step_Get_Distance */
	SL_DISTANCE          = SL_Pedo_Step_Get_Distance();
	/* SL_Pedo_Step_Get_KCal */
	SL_KCAL              = SL_Pedo_Step_Get_KCal();
	/*****average step per minutes****/
	SL_CADENCE_STEP      = SL_Pedo_Step_Get_Step_Per_Min();
	/*****average amp per step****/
	SL_CADENCE_AMP       = SL_Pedo_Step_Get_Avg_Amp();
	/*****motion degree****/
	SL_CADENCE_DEGREE    = SL_Pedo_Step_Get_Motion_Degree();
	
//	    if(SL_STEP>200)
//	    {
	        /**reset pedo value**/
//	        SL_Pedo_Kcal_ResetStepCount();
//	    }
    /*******get wrist value******/
    SL_WRIST = SL_Watch_Wrist_Algo();
    SL_ACTION= SL_SC7A20_Action_Degree();
    /*******get int config******/
    if((SL_STEP_TEMP==SL_STEP)&&(SL_ACTION==0))//step no change
    {
        SL_INT_CNT++;
        if(SL_INT_CNT>10)//1-->0.5s  10--5s
        {
            SL_INT_CNT  =0;
            //if 5s no step, open sensor int function
            SL_MCU_SLEEP_OPEN_SC7A20_INT();
            //close timer of  0.5s
//            SL_Close_Sc7a20_Timer();
            //open mcu int function-->
            //mcu in to sleep status
			SL_Turn_Wrist_Reset();
        }
    }
    else//step changed
    {
        SL_STEP_TEMP=SL_STEP;
        SL_INT_CNT  =0;
    }   

    /*******get overturn value******/
    SL_CLOCK_STATUS=SL_Get_Clock_Status(1);//open overturn monitor
    if(SL_CLOCK_STATUS==1)//overturn success
    { 
        SL_Get_Clock_Status(0);//close overturn monitor
    }

    /*******get sway value******/
    if(SL_SWAY_ENABLE==1)
    {
        /**this function will disable pedo function**/        
        SL_SWAY_STATUS=SL_Get_Phone_Answer_Status(4,5);//get sway value
    }
    
#if SL_Sensor_Algo_Release_Enable==0x00
	SL_DEBUG_DATA_LEN=SC7A20_FIFO_NUM;
	for(sl_i=0;sl_i<SL_DEBUG_DATA_LEN;sl_i++)
	{       
		SL_DEBUG_DATA[0][sl_i]=SC7A20_XYZ_Buf[0][sl_i];
		SL_DEBUG_DATA[1][sl_i]=SC7A20_XYZ_Buf[1][sl_i];
		SL_DEBUG_DATA[2][sl_i]=SC7A20_XYZ_Buf[2][sl_i];
		SL_DEBUG_DATA[3][sl_i]=SL_STEP;
//        SL_DEBUG_DATA[4][sl_i]=SL_STEP_MOTION;
//        SL_DEBUG_DATA[4][sl_i]=SL_ACTION;
//        SL_DEBUG_DATA[4][sl_i]=SL_CLOCK_STATUS;
        SL_DEBUG_DATA[4][sl_i]=SL_WRIST;
		SL_DEBUG_DATA[5][sl_i]=SL_SLEEP_STATUS;
//        SL_DEBUG_DATA[5][sl_i]=SL_DISTANCE;

//        SL_DEBUG_DATA[5][sl_i]=SL_SWAY_STATUS;
        SL_DEBUG_DATA[6][sl_i]=SL_KCAL;
//        SL_DEBUG_DATA[7][sl_i]=SL_CADENCE_STEP;
		SL_DEBUG_DATA[7][sl_i]=hp_buf[sl_i];
//        SL_DEBUG_DATA[8][sl_i]=SL_CADENCE_AMP;
//        SL_DEBUG_DATA[9][sl_i]=SL_CADENCE_DEGREE;

    }
    SL_DEBUG_DATA_LEN=SC7A20_FIFO_NUM;
#endif
    return SL_STEP;
}

/***���߻���ʱ���жϷ������У���Ҫ�رմ������жϹ���***/
void  SL_MCU_WAKEUP_IN_INT_SERVICE_FUNCTION(void)
{
    SL_MCU_WAKE_CLOSE_SC7A20_INT();//close sensor int function








//	SL_Open_Sc7a20_Timer();        //open sensor timer function
}
#if SL_Sensor_Algo_Release_Enable==0x00
unsigned short sl_sleep_counter=0;
#endif
#define SL_SLEEP_DEEP_TH   6
#define SL_SLEEP_LIGHT_TH  3
extern unsigned char sl_sleep_sys_hour;
/***Call this function regularly for 1 minute***/
unsigned char SL_MCU_SLEEP_ALGO_FUNCTION(void)
{

	/*******get sleep status value******/
	SL_SLEEP_STATUS= SL_Sleep_GetStatus(sl_sleep_sys_hour);
	SL_SLEEP_ACTIVE= SL_Sleep_Get_Active_Degree();
	SL_SLEEP_ADOM  = SL_Adom_GetStatus();
	
#if SL_Sensor_Algo_Release_Enable==0x00
	sl_sleep_counter++;
	USART_printf( USART1, "step=%d! sys_time=%d!\r\n",SL_STEP,sl_sleep_sys_hour);
	USART_printf( USART1, "T=%d,sleep_status:%d,sleep_adom:%d!\r\n",sl_sleep_counter,SL_SLEEP_STATUS,SL_SLEEP_ADOM);
	USART_printf( USART1, "SL_SLEEP_ACTIVE:%d!\r\n",SL_SLEEP_ACTIVE);
#endif
	
	if(SL_SLEEP_STATUS<SL_SLEEP_LIGHT_TH)
	{
		return 0;//0 1 2 3
	}
	else if(SL_SLEEP_STATUS<SL_SLEEP_DEEP_TH)
	{
		return 1;//4 5 6
	}
	else
	{
		return 2;//7
	}
}


signed char  SL_WRIST_Result(){


return SL_WRIST;
}
