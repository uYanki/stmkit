/********************************** (C) COPYRIGHT *******************************
* File Name          : RTC.c
* Author             : WCH
* Version            : V1.1
* Date               : 2019/11/05
* Description        : RTC���ü����ʼ��
*******************************************************************************/

/******************************************************************************/
/* ͷ�ļ����� */
#include "CH57x_common.h"
#include "HAL.h"

/*********************************************************************
 * CONSTANTS
 */
#define RTC_INIT_TIME_HOUR              0
#define RTC_INIT_TIME_MINUTE            0
#define RTC_INIT_TIME_SECEND            0

/***************************************************
 * Global variables
 */
u32V RTCTigFlag;

/*******************************************************************************
* Function Name  : RTC_SetTignTime
* Description    : ����RTC����ʱ��
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
void RTC_SetTignTime( u32 time )
{
	if( time&0xffff ) time += (1<<16); 
	R8_SAFE_ACCESS_SIG = SAFE_ACCESS_SIG1;		
	R8_SAFE_ACCESS_SIG = SAFE_ACCESS_SIG2;
	R32_RTC_TRIG       = time;
	RTCTigFlag = 0;
}

/*******************************************************************************
 * @fn          RTC_IRQHandler
 *
 * @brief       RTC�жϴ���
 *
 * input parameters
 *
 * @param       None.
 *
 * output parameters
 *
 * @param       None.
 *
 * @return      None.
 */
void RTC_IRQHandler( void )
{
	R8_RTC_FLAG_CTRL =(RB_RTC_TMR_CLR|RB_RTC_TRIG_CLR);
	RTCTigFlag = 1;
	printf("%s\r\n",__FUNCTION__);
}

/*******************************************************************************
 * @fn          HAL_Time0Init
 *
 * @brief       ϵͳ��ʱ����ʼ��
 *
 * input parameters
 *
 * @param       None.
 *
 * output parameters
 *
 * @param       None.
 *
 * @return      None.
 */
#include "my_appcation.h"

extern time_t My_Time;
void HAL_TimeInit( void )
{
#if( CLK_OSC32K )
  Calibration_LSI();
#else
  R8_SAFE_ACCESS_SIG = 0x57; 
  R8_SAFE_ACCESS_SIG = 0xa8;
  R8_CK32K_CONFIG    |= RB_CLK_OSC32K_XT | RB_CLK_INT32K_PON | RB_CLK_XT32K_PON;
  R8_SAFE_ACCESS_SIG = 0;
#endif
	
	My_Time.hour=8;
	My_Time.minute=58;
	My_Time.second=50;
	
	//RTC_TMRCycTypeDef 
	
	 //RTC_TMRFunCfg( Period_1_S);//����1S��ʱģʽ
	
	
	
	
	
	
  //RTC_InitTime( RTC_INIT_TIME_HOUR, RTC_INIT_TIME_MINUTE, RTC_INIT_TIME_SECEND ); //RTCʱ�ӳ�ʼ����ǰʱ��
	RTC_InitTime( My_Time.hour, 	My_Time.minute, My_Time.second ); //RTCʱ�ӳ�ʼ����ǰʱ��

	//RTC_SetTignTime(1);
  TMOS_TimerInit( 0 );
}

/******************************** endfile @ time ******************************/
