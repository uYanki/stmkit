#ifndef  __MY_SERVICE_H_
#define  __MY_SERVICE_H_

#include "CONFIG.h"

typedef struct
{
  uint16 connHandle;           // Connection handle of current connection
  uint16 connInterval;
  uint16 connSlaveLatency;
  uint16 connTimeout;
} peripheralConnItem_t;








// Position of simpleProfilechar4 value in attribute array
#define SIMPLEPROFILE_CHAR4_VALUE_POS            11


// Profile Parameters
#define SIMPLEPROFILE_CHAR1                   0  // RW uint8 - Profile Characteristic 1 value 
#define SIMPLEPROFILE_CHAR2                   1  // RW uint8 - Profile Characteristic 2 value
#define SIMPLEPROFILE_CHAR3                   2  // RW uint8 - Profile Characteristic 3 value
#define SIMPLEPROFILE_CHAR4                   3  // RW uint8 - Profile Characteristic 4 value
#define SIMPLEPROFILE_CHAR5                   4  // RW uint8 - Profile Characteristic 4 value




// Simple Keys Profile Services bit fields
#define SIMPLEPROFILE_SERVICE                 0x00000001


//�Զ������������UUID  
// Simple Profile Service UUID
#define SIMPLEPROFILE_SERV_UUID               0xFFE0


// Key Pressed UUID
#define SIMPLEPROFILE_CHAR1_UUID              0xFFE1
#define SIMPLEPROFILE_CHAR2_UUID              0xFFE2
#define SIMPLEPROFILE_CHAR3_UUID              0xFFE3
#define SIMPLEPROFILE_CHAR4_UUID              0xFFE4
#define SIMPLEPROFILE_CHAR5_UUID              0xFFE5

//����ʱ������
//head   //year   //month //day	 //hour //min  //sec
//0xab    0x20 0x21 0x04    0x11   0x16   0x52  0x21

// Length of characteristic in bytes ( Default MTU is 23 )
#define SIMPLEPROFILE_CHAR1_LEN               1  
#define SIMPLEPROFILE_CHAR2_LEN               1  
#define SIMPLEPROFILE_CHAR3_LEN               8   //�������� 
#define SIMPLEPROFILE_CHAR4_LEN               1  
#define SIMPLEPROFILE_CHAR5_LEN               5  



//������ֵ�ı�ʱ�Ļص�����
// Callback when a characteristic value has changed
typedef void (*simpleProfileChange_t)( uint8 paramID );

typedef struct
{
  simpleProfileChange_t        pfnSimpleProfileChange;  // Called when characteristic value changes
} simpleProfileCBs_t;

    






/*********************************************************************
 * API FUNCTIONS 
 */


/*
 * SimpleProfile_AddService- Initializes the Simple GATT Profile service by registering
 *          GATT attributes with the GATT server.
 *
 * @param   services - services to add. This is a bit map and can
 *                     contain more than one service.
 */
extern bStatus_t My_Profile_AddService(uint32 services);


/*
 * SimpleProfile_RegisterAppCBs - Registers the application callback function.
 *                    Only call this function once.
 *
 *    appCallbacks - pointer to application callbacks.
 */
extern bStatus_t SimpleProfile_RegisterAppCBs( simpleProfileCBs_t *appCallbacks );

/*
 * SimpleProfile_SetParameter - Set a Simple GATT Profile parameter.
 *
 *    param - Profile parameter ID
 *    len - length of data to right
 *    value - pointer to data to write.  This is dependent on
 *          the parameter ID and WILL be cast to the appropriate 
 *          data type (example: data type of uint16 will be cast to 
 *          uint16 pointer).
 */
extern bStatus_t SimpleProfile_SetParameter( uint8 param, uint8 len, void *value );
  
/*
 * SimpleProfile_GetParameter - Get a Simple GATT Profile parameter.
 *
 *    param - Profile parameter ID
 *    value - pointer to data to write.  This is dependent on
 *          the parameter ID and WILL be cast to the appropriate 
 *          data type (example: data type of uint16 will be cast to 
 *          uint16 pointer).
 */
extern bStatus_t SimpleProfile_GetParameter( uint8 param, void *value );

/*
 * simpleProfile_Notify - Send notification.
 *
 *    connHandle - connect handle
 *    pNoti - pointer to structure to notify.  
 */
extern bStatus_t simpleProfile_Notify( uint16 connHandle, attHandleValueNoti_t *pNoti );


//��ʼ����������ѡ��
void peripheralInitConnItem( peripheralConnItem_t* peripheralConnList );
void peripheralRssiCB( uint16 connHandle, int8  rssi );
void peripheralChar4Notify( uint8 *pValue, uint16 len );







#endif