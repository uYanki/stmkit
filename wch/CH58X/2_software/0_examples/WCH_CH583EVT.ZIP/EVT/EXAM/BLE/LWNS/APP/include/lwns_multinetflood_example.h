/********************************** (C) COPYRIGHT *******************************
 * File Name          : lwns_multinetflood_example.h
 * Author             : WCH
 * Version            : V1.0
 * Date               : 2021/11/10
 * Description        : multinetflood���鲥���緺�鴫������
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/
#ifndef _LWNS_MULTINETFLOOD_EXAMPLE_H_
#define _LWNS_MULTINETFLOOD_EXAMPLE_H_

#include "lwns_config.h"

#define MULTINETFLOOD_EXAMPLE_TX_PERIOD_EVT    1 << (0)

void lwns_multinetflood_process_init(void);

#endif /* _LWNS_MULTINETFLOOD_EXAMPLE_H_ */
