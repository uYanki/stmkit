/********************************** (C) COPYRIGHT *******************************
 * File Name          : lwns_rucft_example.h
 * Author             : WCH
 * Version            : V1.0
 * Date               : 2021/06/30
 * Description        : reliable unicast file transfer���ɿ������ļ���������
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/
#ifndef _LWNS_RUCFT_EXAMPLE_H_
#define _LWNS_RUCFT_EXAMPLE_H_

#include "lwns_config.h"

#define RUCFT_EXAMPLE_TX_PERIOD_EVT    1 << (0)

void lwns_rucft_process_init(void);

#endif /* _LWNS_RUCFT_EXAMPLE_H_ */
