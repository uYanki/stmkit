#ifndef __SYSC_H
#define __SYSC_H

void SystemClock_Config_HSE(void);

#endif	
