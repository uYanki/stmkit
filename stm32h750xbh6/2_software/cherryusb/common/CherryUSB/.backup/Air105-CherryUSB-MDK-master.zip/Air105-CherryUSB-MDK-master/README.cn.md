# 关于

编译下载可以参照版主IOsetting写的帖子 https://blog.csdn.net/michaelchain/article/details/122759889

# 特性

1、在原有的air105 mdk工程上加入USB，并且移植CherryUSB协议栈
2、添加RTT Viewer
