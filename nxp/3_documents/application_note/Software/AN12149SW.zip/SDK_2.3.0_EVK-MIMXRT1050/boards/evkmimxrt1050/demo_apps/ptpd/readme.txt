Overview
========

The lwip_httpsrv demo application demonstrates an HTTPServer on the lwIP TCP/IP stack with bare metal SDK or FreeRTOS.
The user uses an Internet browser to send a request for connection. The board acts as an HTTP server and sends a Web
page back to the PC.


Toolchain supported
===================
- IAR embedded Workbench 8.20 or later

Hardware requirements
=====================
- Mini/micro USB cable
- Network cable RJ45 standard
- Two EVK-MIMXRT1050 boards

Build software
==============
- set "#define PTP_TEST_APP_MASTER 1" in lwip_ptpd_freertos.c file to building image for Master device
- set "#define PTP_TEST_APP_MASTER 0" in lwip_ptpd_freertos.c file to building image for Slave device

Board settings
==============
No special settings are required.

Prepare the Demo
================
1.  Connect a USB cable between the PC host and the OpenSDA(or USB to Serial) USB port on the target board.
2.  Open a serial terminal on PC for OpenSDA serial(or USB to Serial) device with these settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  Insert the Ethernet Cable into the target board's RJ45 port and connect it to Another EVK board.
4.  Download the program to the target board and run it.



