1)	Data_collection.py: 
This script reads the vibration data from serial console and saves it in xls form

2)	kmeans_development_training.py: 
This script takes the data as input and performs the K means clustering algorithm to provide the trained data in form of centroids as output.

3)	Export_trained_data_model.py: 
This script takes the trained data (centroids of all 3 axis) as input and saves the model in saved model format (.pb) 

4)	Conversion.py: 
This script takes Tensorflow saved model (.pb file) as input and converts it to TensorFlow Lite (.tflite) format.

5)	Check_tflite.py:
This script is used to test the converted .tflite file. This script takes the “.tflite” file as input and runs the model with the test data provided in the script to provide the output as distance of each point from centroids.

6)	Display.py:
This script is used to read the state of machine from serial and display it on GUI. It displays “healthy” or “Anomaly” run time as per the condition of machine
