Overview
========
The DCP key management project is show how to use different keys.

Toolchain supported
===================
- Keil MDK  5.29


Hardware requirements
=====================
- Mini/micro USB cable
- EVK-MIMXRT1060 board
- Personal Computer

Board settings
==============
No special settings are required.

Prepare the Demo
================
1.  Connect a USB cable between the host PC and the OpenSDA USB port on the target board. 
2.  Open a serial terminal with the following settings:
    - 115200 baud rate
    - 8 data bits
    - No parity
    - One stop bit
    - No flow control
3.  select "dcp_flexspi_nor_debug" mode to compile.And download the program to the target board.
4.  Either press the reset button on your board or launch the debugger in your IDE to begin running the demo.

Running the demo
================
Example output on terminal:

DCP key management.
Key Slot0:
  AES ECB Test pass.
  AES CBC Test pass.
Key Slot1:
  AES ECB Test pass.
  AES CBC Test pass.
Key Slot2:
  AES ECB Test pass.
  AES CBC Test pass.
Key Slot3:
  AES ECB Test pass.
  AES CBC Test pass.
OCOTP Key(SNVS Master key Low):
  AES ECB Test pass.
  AES CBC Test pass.
OCOTP Key(SNVS Master key Hight):
  AES ECB Test pass.
  AES CBC Test pass.
OCOTP Key(SW_GP2 key):
  AES ECB Test pass.
  AES CBC Test pass.
Unique key:
  AES ECB Test pass.
  AES CBC Test pass.
Payload key:
  AES ECB Test pass.
  AES CBC Test pass.

=====================

