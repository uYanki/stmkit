var searchData=
[
  ['bee_5fregion_5fconfig_5ft',['bee_region_config_t',['../structbee__region__config__t.html',1,'']]]
];
