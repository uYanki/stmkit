var searchData=
[
  ['gain',['gain',['../group__spdif.html#af2eeb1f3e4a229d81b00a2e293bd5b8f',1,'spdif_config_t']]],
  ['gatherresidualwrites',['gatherResidualWrites',['../group__dcp__driver.html#a9bf6c28d293292f7ab36414ac55d8e6b',1,'dcp_config_t']]]
];
