var group__lpi2c__freertos__driver =
[
    [ "LPI2C_RTOS_Init", "group__lpi2c__freertos__driver.html#ga537a8859c9c83c8a8ccf6e0188cc8b5c", null ],
    [ "LPI2C_RTOS_Deinit", "group__lpi2c__freertos__driver.html#gacacb0612bfdcd7913be1cef8ad19fb9c", null ],
    [ "LPI2C_RTOS_Transfer", "group__lpi2c__freertos__driver.html#gab5359e4f864d7f21eebcab8d3229e963", null ]
];