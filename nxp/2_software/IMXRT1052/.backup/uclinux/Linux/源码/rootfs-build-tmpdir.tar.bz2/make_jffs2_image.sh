#!/bin/bash

fakeroot mkfs.jffs2 -X lzo -x zlib -q -r rootfs-build-tmpdir -o rootfs_flash.jffs2
