/*
* A test application that helloworld
*/
#include <stdio.h>

int main(int argc, char **argv)
{
    printf("uclinux helloworld \n");
    return 0;  
}
