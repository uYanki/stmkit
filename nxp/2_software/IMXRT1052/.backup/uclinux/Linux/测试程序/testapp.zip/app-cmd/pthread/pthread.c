/*forlinx serial port test*/
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#include <signal.h>

#define msleep(n) usleep(n*1000)

pthread_mutex_t mut;

volatile	pthread_t thread[2]; 
volatile	const int READ_THREAD_ID = 0;  
volatile	const int SEND_THREAD_ID = 1;  
volatile	int COM_READ_STATU = 1;  
volatile	int COM_SEND_STATU = 1;



void* com_read(void* pstatu)  
{
	while(COM_READ_STATU)
	{
		pthread_mutex_lock(&mut);
                printf("read pthread\n");
    		pthread_mutex_unlock(&mut);
                msleep(800);
	}
    pthread_exit(NULL);
}

void* com_send(void* p)  
{
	int ii;
	while(COM_SEND_STATU)
	{	
		printf("send pthread\n");
		msleep(800);
			
	}
	pthread_exit(NULL);	
}
  
int start_thread_func(void*(*func)(void*), pthread_t* pthread, void* par, int* COM_STATU)  
{  
        *COM_STATU = 1;  
        memset(pthread, 0, sizeof(pthread_t));  
        int temp;  
            /*creat thread*/  
	if((temp = pthread_create(pthread, NULL, func, par)) != 0)  
	{
		printf("creat thread failer!\n");
	}  
	else  
        {  
            int id = pthread_self();  
            printf("create thread %lu sucess\n", *pthread);  
        }  
        return temp;  
} 

void SignHandler(int iSignNo)
{
	COM_SEND_STATU = 0; 
	sleep(1);
	COM_READ_STATU = 0;  
	sleep(1);
	exit(1);
}

int main(int argc, char **argv)
{
 
	signal(SIGINT,SignHandler);

	printf("\nWelcome to pthread helloworld! Press Ctrl + 'c' to stop.\n\n");

    	pthread_mutex_init(&mut,NULL);  
 
	 if(start_thread_func(com_read, (pthread_t*)&thread[READ_THREAD_ID],  (int *)&COM_READ_STATU, (int *)&COM_READ_STATU) != 0)  
        {  
            printf("error to leave\n");  
            return -1;  
        }  
  
	 if(start_thread_func(com_send, (pthread_t*)&thread[SEND_THREAD_ID], (int *)&COM_SEND_STATU, (int *)&COM_SEND_STATU) != 0)
        {  
            printf("error to leave\n");  
            return -1;  
        }  

  	while(1)
  	{ 
            printf("main pthread\n");
            sleep(1);
	}

}






