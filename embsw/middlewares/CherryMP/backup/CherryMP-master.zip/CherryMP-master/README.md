# CherryMempool

CherryMempool is a tiny block memory pool based on CherryRB, support nonos or os(but we suggest you use in os), and only transfer data address not data content.
