#!/usr/bin/env bash

cd .. && \
cloc *.* \
.github \
App \
modules/log/*.* \
modules/ScopeCore/*.* \
modules/ScopeCore/modules/PacketProcessor/*.* \
modules/SmartSerial/*.* \
