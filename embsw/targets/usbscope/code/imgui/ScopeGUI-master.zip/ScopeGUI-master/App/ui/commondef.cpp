#include "commondef.h"

float UI_WaveWidth = UI_ITEM_WIDTH;
float UI_WaveHeight = 256;
