#pragma once

const float UI_WAVE_L_SLIDER_WIDTH = 14;

const float UI_ITEM_WIDTH = 1240;
const float UI_WAVE_WIDTH_SCALE_MAX = UI_ITEM_WIDTH * 10;

extern float UI_WaveWidth;
extern float UI_WaveHeight;
