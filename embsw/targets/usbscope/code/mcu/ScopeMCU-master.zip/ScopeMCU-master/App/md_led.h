#pragma once

void led_setValue(bool enable);

void led_toggle();
