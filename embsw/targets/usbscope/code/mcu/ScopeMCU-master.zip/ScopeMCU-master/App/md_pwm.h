#pragma once

#include <cstdint>

void pwm_init();
