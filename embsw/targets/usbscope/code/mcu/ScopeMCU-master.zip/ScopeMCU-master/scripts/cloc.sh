#!/usr/bin/env bash

cd .. && \
cloc *.* \
App/*.* \
App/modules/log/*.* \
App/modules/ScopeCore/*.* \
App/modules/ScopeCore/modules/PacketProcessor/*.* \
