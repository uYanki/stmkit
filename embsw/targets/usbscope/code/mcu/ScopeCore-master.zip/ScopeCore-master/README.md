# ScopeCore

[![Build Status](https://github.com/shuai132/ScopeCore/workflows/build/badge.svg)](https://github.com/shuai132/ScopeCore/actions?workflow=build)

Portable oscilloscope core

## Usage

See
[ScopeMCU](https://github.com/shuai132/ScopeMCU)
and
[ScopeGUI](https://github.com/shuai132/ScopeGUI)
