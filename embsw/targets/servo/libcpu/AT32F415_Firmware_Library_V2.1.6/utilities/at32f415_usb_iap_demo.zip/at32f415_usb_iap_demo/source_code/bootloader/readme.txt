/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to build
  a iap device use hid class protocol. the pc can detect hid device when iap
  bootloader is running. for more detailed information. please refer to the 
  application note document AN0007.
