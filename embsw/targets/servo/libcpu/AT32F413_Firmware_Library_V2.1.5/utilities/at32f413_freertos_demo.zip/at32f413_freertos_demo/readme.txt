/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

   this project describes how to use freertos on artery ic.

   hardware environment:at-start board

   how to use it ? 
   compiling and download code to at start board,push the reset button will see led2 and led3 blinking.

   for more detailed information. please refer to the application note document AN0025.
