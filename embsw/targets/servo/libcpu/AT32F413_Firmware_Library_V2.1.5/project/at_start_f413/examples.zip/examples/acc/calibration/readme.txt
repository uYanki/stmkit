/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, acc will calibration
  hick when usb is connecting.
  for more detailed information. please refer to the application note document AN0107.