/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to write/read
  data to/from battery powered data registers and demonstrates the temper pin(pc13)
  detection feature.
