/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, there are two 
  project targets: fpu_enable and fpu_disable. they test comparison fpu 
  efficiency by led4 blink cost time.for more detailed information. please
  refer to the application note document AN0037. 
