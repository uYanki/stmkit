/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, pa8 output 47 khz
  waveforms, pa8 toggled each pa3, pa6, pa7 edge.
  pin connection:
  - pa0    <--->    pa3
  - pa1    <--->    pa6
  - pa2    <--->    pa7 

  for more detailed information. please refer to the application note document AN0085.
