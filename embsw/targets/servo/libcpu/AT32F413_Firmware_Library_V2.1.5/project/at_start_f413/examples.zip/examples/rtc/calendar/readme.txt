/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to use 
  rtc peripherals to implement calendar and alarm clock functions. use usart1
  to view calendar information. led3 flashes once when the seconds are updated,
  and led4 turns on when the alarm is generated.
  for more detailed information. please refer to the application note document AN0111.