/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, demonstrates the use the maximum,
  minimum, mean, standard deviation, variance and matrix functions to calculate
  statistical values of marks obtained in a class.  for more detailed information. 
  please refer to the application note document AN0036.