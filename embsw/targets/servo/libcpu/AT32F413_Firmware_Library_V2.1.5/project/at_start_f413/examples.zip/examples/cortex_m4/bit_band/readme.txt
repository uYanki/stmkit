/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, modify the variables
  by its bitband address and then read from bitband address. if the variables is
  not the expected, led4 blink every 1s, else using bitband make the led2 toggle.
  for more detailed information. please refer to the application note document AN0083.