/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to store
  user data in the battery powered register. as the bpr domain still powered by
  vbat when vdd is switched off, its contents are not lost if a battery is 
  connected to vbat pin.
