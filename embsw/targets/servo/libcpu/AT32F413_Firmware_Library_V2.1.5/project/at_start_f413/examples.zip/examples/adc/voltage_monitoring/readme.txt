/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to
  monitoring adc channel's voltage.
  the convert data as follow:
  - adc1_ordinary_valuetab[0] ---> adc1_channel_4
  - adc1_ordinary_valuetab[1] ---> adc1_channel_5
  - adc1_ordinary_valuetab[2] ---> adc1_channel_6
  the voltage monitoring channel is: adc1_channel_5
  for more detailed information. please refer to the application note document AN0113.