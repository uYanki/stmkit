var group__dhcp6 =
[
    [ "dhcp6_cleanup", "group__dhcp6.html#gacb7042000509fb21e8d2758e235d6dde", null ],
    [ "dhcp6_disable", "group__dhcp6.html#gadd0c783a85a410f75b37a3d922ad60d2", null ],
    [ "dhcp6_enable_stateful", "group__dhcp6.html#gaa9e972fcd1d648ca5f02334b1591b619", null ],
    [ "dhcp6_enable_stateless", "group__dhcp6.html#gaf3349463541e673fec33843eb019b18c", null ],
    [ "dhcp6_set_struct", "group__dhcp6.html#ga5cdf4082c8a4ee6bf0cb874c0eaa8453", null ]
];