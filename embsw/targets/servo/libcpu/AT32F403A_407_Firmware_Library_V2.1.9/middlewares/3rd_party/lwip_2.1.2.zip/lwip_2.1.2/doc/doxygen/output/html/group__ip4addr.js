var group__ip4addr =
[
    [ "IP4_ADDR_ANY", "group__ip4addr.html#gae920b6e81610a38cf9ada52118807eff", null ],
    [ "IP4_ADDR_ANY4", "group__ip4addr.html#gaa3f65a42b68149e96e618600b2ca2e42", null ],
    [ "IP4_ADDR_BROADCAST", "group__ip4addr.html#ga5efdf55ba72c2b1b5755b1fc6f559a1a", null ],
    [ "ip_2_ip4", "group__ip4addr.html#gad7268a496b7e3f872efecd859eba6f03", null ],
    [ "IP_ADDR4", "group__ip4addr.html#gadd2203c6cbfb6de8c2d9ce5bbfb2bd2a", null ],
    [ "IP_ADDR_ANY", "group__ip4addr.html#ga3e5e67b7292b156034560fef2202776c", null ],
    [ "IP_ADDR_BROADCAST", "group__ip4addr.html#gad546955e48dada78b552375b873f6986", null ],
    [ "ip_addr_copy_from_ip4", "group__ip4addr.html#gaef063b2e975dae7ecf398770b04b14af", null ],
    [ "ip_addr_get_ip4_u32", "group__ip4addr.html#ga09c62e8a3bf599aa7f335e0ad0820e85", null ],
    [ "ip_addr_set_ip4_u32", "group__ip4addr.html#ga971516589980428bf51f37cefa4ddf66", null ],
    [ "ip_addr_set_ip4_u32_val", "group__ip4addr.html#ga624b5010ccc04cc3d0de2acce44f1c9e", null ],
    [ "IP_IS_V4", "group__ip4addr.html#gabee5dab2191bb0f3355d7f30d1496f24", null ],
    [ "IP_IS_V4_VAL", "group__ip4addr.html#gab1a059f07bd9c50aa58447d963b823a1", null ],
    [ "IPADDR4_INIT", "group__ip4addr.html#ga1eaffd17b4b3c56cc91a6d516e18118f", null ],
    [ "IPADDR4_INIT_BYTES", "group__ip4addr.html#ga55cc3896c46564bd2941ee5806fe1e11", null ]
];