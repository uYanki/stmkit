var dir_1e445e767c368c70d58af8a0b7552719 =
[
    [ "posix", "dir_fe219fca207b878205c0dd92278d118b.html", "dir_fe219fca207b878205c0dd92278d118b" ],
    [ "stdc", "dir_b42baff89a1adc9a57da7decb1835b6b.html", "dir_b42baff89a1adc9a57da7decb1835b6b" ]
];