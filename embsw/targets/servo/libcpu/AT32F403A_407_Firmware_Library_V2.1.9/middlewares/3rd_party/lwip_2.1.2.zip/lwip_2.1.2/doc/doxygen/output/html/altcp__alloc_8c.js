var altcp__alloc_8c =
[
    [ "altcp_tls_alloc", "group__altcp__tls.html#ga09e6ca8f144ee94ef21d7e5760aa4391", null ],
    [ "altcp_tls_new", "group__altcp__tls.html#ga028316a8257cf8dcace9cd063de79c0a", null ]
];