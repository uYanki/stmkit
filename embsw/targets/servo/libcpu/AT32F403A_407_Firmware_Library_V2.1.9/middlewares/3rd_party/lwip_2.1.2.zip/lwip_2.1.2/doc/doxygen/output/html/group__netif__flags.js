var group__netif__flags =
[
    [ "NETIF_FLAG_BROADCAST", "group__netif__flags.html#gaef64fe15c82bc7b235366923e517104e", null ],
    [ "NETIF_FLAG_ETHARP", "group__netif__flags.html#ga92448dc510bc8d700c09e5c971ef0676", null ],
    [ "NETIF_FLAG_ETHERNET", "group__netif__flags.html#ga76ad9d0cf9f029df0ab2a998c64040dc", null ],
    [ "NETIF_FLAG_IGMP", "group__netif__flags.html#gac9493b923d733c73f6006d9714826558", null ],
    [ "NETIF_FLAG_LINK_UP", "group__netif__flags.html#ga75f5a2b9276c93e3bd18a568459fd2d8", null ],
    [ "NETIF_FLAG_MLD6", "group__netif__flags.html#gab14fbe1447d2fdbdf5abc87f51eb6508", null ],
    [ "NETIF_FLAG_UP", "group__netif__flags.html#gab47d7d130693dc155f480a5bf447725e", null ]
];