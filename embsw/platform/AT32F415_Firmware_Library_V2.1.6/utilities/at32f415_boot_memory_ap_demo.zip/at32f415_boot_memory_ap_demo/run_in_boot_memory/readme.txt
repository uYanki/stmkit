/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, executing this project��step1/step2
  should be follow.
  step1 : enbale ap mode by icp tool. user should set boot memory to ap mode
          with icp tool.
  step2 : add the algorithm file of bootmem_ap in the project.
  step3 : executing this demo, in this project, codes in main block run usart
          for printing messages, while codes in boot memory run led toggle.
  for more detailed information. please refer to the application note document AN0066.


