/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board  and at32-comm-ev, in this demo, 
  shows how to use the can loopback mode. every 1s transmit one message 
  and the led4 blink, if the message can be received, led2 blink.
   set-up
  - can tx      --->   pb9
  - can rx      --->   pb8

  for more detailed information. please refer to the application note document AN0095.


