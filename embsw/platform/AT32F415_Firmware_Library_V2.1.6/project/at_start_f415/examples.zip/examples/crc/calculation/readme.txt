/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to use 
  crc calculation unit to get a crc code of a given buffer of data word(32-bit),
  if get a correct crc value led3 will be turn on, else led4 will be turn on.  
  for more detailed information. please refer to the application note document AN0109.