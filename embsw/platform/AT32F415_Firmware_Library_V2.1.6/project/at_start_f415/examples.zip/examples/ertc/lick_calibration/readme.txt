/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to use
  timer to calibrate the lick clock. use usart1 to view calibrate information.
  for more detailed information. please refer to the application note document AN0047.