/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to use the 
  tamper detection, the rising edge of the pc13 pin triggers an tamper event.
  for more detailed information. please refer to the application note document AN0047.