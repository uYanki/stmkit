/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to configure
  the power voltage monitoring using external interrupt line.

  for more detailed information. please refer to the application note document AN0100.