/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, pb0 output pwm waves.
  connection :
  - pa0    <--->    pa7
  - pb0 output 100 hz pwm waveform   

  for more detailed information. please refer to the application note document AN0085.