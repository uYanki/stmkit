/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, provides a description
  of how to use dma with tmr1 update request to transfer data from memory to
  tmr1 channel data register3.

  set-up
  connect the following pins to an oscilloscope to monitor the different
  waveforms:
  - tmr1 ch3  --->  pa10
  - tmr1 ch3c --->  pb15
  for more detailed information. please refer to the application note document AN0085.