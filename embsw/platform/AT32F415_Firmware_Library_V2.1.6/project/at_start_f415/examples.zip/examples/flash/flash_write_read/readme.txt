/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, test buffer will
  be wiriten to flash and read from same address, then compare them. if the 
  test is passed, the three leds will turn on.
