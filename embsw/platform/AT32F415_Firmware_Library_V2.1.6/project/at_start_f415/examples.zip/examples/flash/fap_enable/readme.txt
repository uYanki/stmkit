/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, show how to enable
  fap function by executing code. when fap enabled, the three leds will turn
  on.
 
  note: 
  if fap is still in debug mode when it is set, the debug mode must be
  cleared with poweron reset instead of system reset, to restore flash
  program access to flash memory data.
