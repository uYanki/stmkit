/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to configure
  external interrupt lines. exint line (exint line0 pa0) are configured to generate
  an interrupt on each rising edge. in the interrupt routine a led2/3/4 is toggled.
  for more detailed information. please refer to the application note document AN0104.