/**
  **************************************************************************
  * @file     readme.txt 
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, this demo toggle pa.01 forever,
  to describes how to use scr and clr register for max io toggling.