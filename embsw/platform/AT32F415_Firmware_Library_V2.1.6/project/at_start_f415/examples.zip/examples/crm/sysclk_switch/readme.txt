/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, swith sclk by pressed
  button. led4 toggle, pa8 output crm_clkout_pll_div_4. led2 fresh per 100 ms.
  for more detailed information. please refer to the application note document AN0117.