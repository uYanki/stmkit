/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, provides a description
  of how to use a dma channel to transfer a word data buffer from flash memory
  to embedded sram memory. dma1 channel1 is configured to transfer the contents
  of a 32-word data buffer stored in flash memory to the reception buffer in ram.
  if received data right, the three leds will turn on. 
