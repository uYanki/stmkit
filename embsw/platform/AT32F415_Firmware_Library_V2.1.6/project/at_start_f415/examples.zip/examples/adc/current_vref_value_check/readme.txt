/**
  **************************************************************************
  * @file     readme.txt
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board, in this demo, shows how to use
  the adc1 internal channel17 to check vref value.
  the convert data as follow:
  - adc1_ordinary_value ---> adc1_channel_17
  for more detailed information. please refer to the application note document AN0115.