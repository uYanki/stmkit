#ifndef __LUA_USR_API_H__
#define __LUA_USR_API_H__

#include "main.h"

#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"

extern luaL_Reg luaLib[];

#endif
