
1. TIM2's four input capture channel used to capture PPM CH1~CH4
	TIM4's four input capture channel used to capture PPM CH5~CH8
2. Pin map
	RCI ~ PA0
	RC2 ~ PA1
	RC3 ~ PA2
	RC4 ~ PA3
	RC5 ~ PB6
	RC6 ~ PB7
	RC7 ~ PB8
	RC8 ~ PB9
	
3. PPM Output Pin is PB1. PC13 LED can be used to probe RC1's input SIGNAL.