#ifndef _SYSTEM_CLOCK_H_
#define _SYSTEM_CLOCK_H_

void RCC_Configuration(void);

#endif
