#ifndef _NVIC_H_
#define _NVIC_H_

void NVIC_Configuration(void);

#endif
