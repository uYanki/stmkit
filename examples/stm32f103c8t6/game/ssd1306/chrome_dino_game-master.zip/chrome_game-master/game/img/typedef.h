#pragma once

#ifndef PROGMEM
#define PROGMEM
#endif
