#pragma once

#include "chrome_game_port.h"

void* chrome_game_init(ScreenConfig* screen);
