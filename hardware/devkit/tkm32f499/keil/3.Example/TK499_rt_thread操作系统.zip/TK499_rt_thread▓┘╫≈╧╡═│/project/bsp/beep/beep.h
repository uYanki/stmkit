#ifndef _BEEP_H_
#define _BEEP_H_

#include "HAL_conf.h"
#include "bitband.h"
void BEEP_Config(void);






#endif
