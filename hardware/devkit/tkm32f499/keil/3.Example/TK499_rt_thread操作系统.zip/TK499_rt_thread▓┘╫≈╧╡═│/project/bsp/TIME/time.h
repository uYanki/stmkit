#ifndef _TIME_H_
#define _TIME_H_

#include "HAL_conf.h"
#include "led.h"
void TIM3_Config(u16 arr,u16 psc);
void TIM8_Config(u32 psc,u32 arr);
void TIM2_Config(u16 psc,u16 arr,u16 ccr);
extern vu32 timr; 
extern vu32 LED_timr[2];
void delay_nus(u16 time); //nus
void delay_nms(u16 time); //nms



#endif

