#ifndef _BITBAND_H_
#define _BITBAND_H_

//����λ������ַ+λ -- ��Ӧ�������ĵ�ַ
#define BITBAND(addr,bitnum) ((addr & 0xf0000000)+0x2000000+(((addr & 0xfffff)*32)+(bitnum*4)))
//����������
#define MEM_ADDR(addr) *((volatile unsigned long *) (addr))

//#define PAOut(addr,bit) MEM_ADDR(BITBAND(addr,bit))

#define PAOut(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOA->ODR,bit))
#define PBOut(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOB->ODR,bit))
#define PCOut(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOC->ODR,bit))
#define PDOut(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOD->ODR,bit))
#define PEOut(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOE->ODR,bit))
#define PFOut(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOF->ODR,bit))
#define PGOut(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOG->ODR,bit))

#define PAIn(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOA->IDR,bit))
#define PBIn(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOB->IDR,bit))
#define PCIn(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOC->IDR,bit))
#define PDIn(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOD->IDR,bit))
#define PEIn(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOE->IDR,bit))
#define PFIn(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOF->IDR,bit))
#define PGIn(bit) MEM_ADDR(BITBAND((unsigned int)&GPIOG->IDR,bit))
#endif
