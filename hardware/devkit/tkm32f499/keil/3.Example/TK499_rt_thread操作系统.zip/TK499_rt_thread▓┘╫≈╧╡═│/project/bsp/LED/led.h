#ifndef _LED_H_
#define _LED_H_

#include "HAL_conf.h"
#include "bitband.h"
void LED_Config(void);

#define LED(x) x?(PDOut(8) = 0):(PDOut(8) = 1)
#define LED_TOGGLE() (PDOut(8) ^= 1)



#endif


