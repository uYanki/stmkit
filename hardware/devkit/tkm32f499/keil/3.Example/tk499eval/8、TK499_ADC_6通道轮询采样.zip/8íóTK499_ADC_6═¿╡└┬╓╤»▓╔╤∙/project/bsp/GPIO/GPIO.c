#include "GPIO.h"

void LED_Init(void)
{
	//First initialize the LED, that is, set the mode of the GPIO
	GPIO_InitTypeDef GPIO_InitStructure;//Define the GPIO initialization structure variable
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA | RCC_AHBPeriph_GPIOB, ENABLE);
	//Configure the GPIO connected to the LED as push-pull 
	GPIO_InitStructure.GPIO_Pin    =  GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed  = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode   = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);	
}
