#ifndef __DMA_TEST_H
#define __DMA_TEST_H

void	DMA_m8tom8_test(void);
void 	DMA_m8tom16_test(void);
void 	DMA_m8tom32_test(void);
void  DMA_m16tom8_test(void);
void  DMA_m16tom16_test(void);
void 	DMA_m16tom32_test(void);
void	DMA_m32tom8_test(void);
void  DMA_m32tom16_test(void);
void  DMA_m32tom32_test(void);

#endif
