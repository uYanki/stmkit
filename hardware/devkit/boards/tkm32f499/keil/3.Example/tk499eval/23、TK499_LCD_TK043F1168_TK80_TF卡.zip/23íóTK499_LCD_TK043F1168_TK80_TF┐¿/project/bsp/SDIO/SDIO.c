#include "SDIO.h"
#include "uart.h"
#include "sdio_sdcard.h"
#include "stdio.h"
#include <string.h>
#include "diskio.h"	
#include "ff.h"	
#include "LCD.h"
char printBuf[100];
//����TK499����
void SDIO1_GPIOInitRemap(void)
{
	#if (0)
    GPIOC->CRL  = 0x0;   
    GPIOC->AFRL = 0x0;
    GPIOC->AFRL = 0xCCCCCCCC;
    GPIOC->CRL  = 0xAAAAAAAA;   //GPIOC_Pin_6 clear
	#else
    GPIOD->AFRL &= 0xFF000000;
		GPIOD->AFRL |= 0x00CCCCCC;
		GPIOD->CRL  &= 0xFF000000;   
		GPIOD->CRL  |= 0x00aaaaaa;   
	#endif
}
void show_sdcard_info(void)
{
	switch(SDCardInfo.CardType)
	{
		case SDIO_STD_CAPACITY_SD_CARD_V1_1:printf((char *)("Card Type:SDSC V1.1\r\n"));break;
		case SDIO_STD_CAPACITY_SD_CARD_V2_0:printf((char *)("Card Type:SDSC V2.0\r\n"));break;
		case SDIO_HIGH_CAPACITY_SD_CARD:printf((char *)("Card Type:SDHC V2.0\r\n"));break;
		case SDIO_MULTIMEDIA_CARD:printf((char *)("Card Type:MMC Card\r\n"));break;
	}	
//  printf((char *)"Card ManufacturerID:%d\r\n",SDCardInfo.SD_cid.ManufacturerID);	//������ID
// 	printf((char *)"Card RCA:%d\r\n",SDCardInfo.RCA);								//����Ե�ַ
//	printf((char *)"Card Capacity:%d MB\r\n",(u32)(SDCardInfo.CardCapacity>>20));	//��ʾ����
// 	printf((char *)"Card BlockSize:%d\r\n\r\n",SDCardInfo.CardBlockSize);			//��ʾ���С
	UartSendGroup((u8*)printBuf, sprintf(printBuf,"Card ManufacturerID:%d\r\n",SDCardInfo.SD_cid.ManufacturerID));	//������ID
 	UartSendGroup((u8*)printBuf, sprintf(printBuf,"Card RCA:%d\r\n",SDCardInfo.RCA));								//����Ե�ַ
	UartSendGroup((u8*)printBuf, sprintf(printBuf,"Card Capacity:%d MB\r\n",(u32)(SDCardInfo.CardCapacity>>20)));	//��ʾ����
 	UartSendGroup((u8*)printBuf, sprintf(printBuf,"Card BlockSize:%d\r\n\r\n",SDCardInfo.CardBlockSize));			//��ʾ���С
}
void Test_SDcard_read_TXT()
{
		u8   fs_temp_buf[512];
		FIL  file;
		FATFS ufs;
		u32 fs_cnt;
		FIL *filescr1 = &file;
		FRESULT f_res;
		f_res = f_mount (&ufs, "0:", 1);//�����ļ�ϵͳ
		f_res = f_open(filescr1, "0:123.TXT",  FA_READ );
		fs_cnt = 512;
		do
  {
    f_res = f_read(filescr1, fs_temp_buf, 512, &fs_cnt);
//		printf("%s",fs_temp_buf);//��printf��ӡ�����
		UartSendGroup(fs_temp_buf,fs_cnt);
  }
	while(fs_cnt > 0);
}
void SDIO_GPIO_Test(void) //������תʹ�õ�IO
{
  u32 i,j;
  GPIOD->CRL  &= 0xFF000000;   
  GPIOD->CRL  |= 0x00333333;  
  
  GPIOD->BRR = 0x3F;
  
  for(i = 0;i < 6;i ++)
  {
    GPIOD->BSRR = 1 << i;
  }
  for(i = 0;i < 6;i ++)
  {
    GPIOD->BRR = 1 << i;
  }
  GPIOD->BSRR = 0x3F;
  j = 100;
  while(j--)
  {
    GPIOD->ODR ^= 1<<4;
  }
  GPIOD->BSRR = 0x3F;
}

//����TK499����
void SDIO_Init(void) 
{
	SDIO_GPIO_Test();
  SDIO1_GPIOInitRemap();
	
//	RCC->APB2ENR |= 0x1<<11; //open sdio1 clkgate
	RCC->APB2ENR |= 0x1<<12; //open sdio2 clkgate
	
	TEST_SDIOx->MMC_CARDSEL = 0xC0;   //enable module, enable mmcclk
	TEST_SDIOx->MMC_CTRL    = 0x03|((0x7)<<3)|(1<<8);//4bit,low speed,1/16 divider,��ʼ��ʱ�����õ���		
//	TEST_SDIOx->MMC_INT_MASK = 0x01;  //unmask interrupt
	TEST_SDIOx->MMC_CRCCTL   = 0xC0; 

	
//	TEST_SDIOx->MMC_IO_MBCTL |= 0x8;//2019
	SD_Init();
//	show_sdcard_info();
}
typedef __packed struct
{
	u8  pic_head[2];				//1
	u32 pic_size;			      //2-3
	u16 pic_nc1;				    //4
	u16 pic_nc2;				    //5
	u32 BMP_head_size;	    //6-7
	u16 pic_message_head_len_l;	//8
	u16 pic_message_head_len_h;	//9
	u16 pic_w_l;					      //10
	u16 pic_w_h;				    //11
	u16 pic_h_l;				    //12
	u16 pic_h_h;				    //13	
	u16 pic_bit;				    //14
	u16 pic_dip;				    //15
	u16 pic_zip_l;			    //16
	u16 pic_zip_h;			    //17
	u16 pic_data_size_l;		    //18
	u16 pic_data_size_h;		    //19
	u16 pic_dipx_l;			    //20
	u16 pic_dipx_h;			    //21	
	u16 pic_dipy_l;			    //22
	u16 pic_dipy_h;			    //23
	u16 pic_color_index_l;	    //24
	u16 pic_color_index_h;	    //25
	u16 pic_other_l;			    //26
	u16 pic_other_h;			    //27
//	u16 pic_color_p01;		    //28
//	u16 pic_color_p02;		    //29
//	u16 pic_color_p03;		    //30
//	u16 pic_color_p04;		    //31
//	u16 pic_color_p05;		    //32
//	u16 pic_color_p06;		    //33
//	u16 pic_color_p07;		    //34
//	u16 pic_color_p08;			//35			
}BMP_HEAD;

BMP_HEAD bmp;
//��������С��Χ����ʾͼƬ
char display_picture(char *filename)
{
	FATFS fs;            // Work area (file system object) for logical drive
	FIL fsrc;      			// file objects
	#if XSIZE_PHYS>YSIZE_PHYS
	u8 buffer[XSIZE_PHYS*4]; 		// file copy buffer
	#else
	u8 buffer[YSIZE_PHYS*4]; 		// file copy buffer
	#endif
	FRESULT res;         // FatFs function common result code
	UINT br;         		// File R/W count
	u32	 tx,ty,temp;
	u8 xOfset,r,g,b; //�������� 4������ȫ
	
	f_mount (&fs, "0:", 1);//�����ļ�ϵͳ
  res = f_open(&fsrc, filename, FA_OPEN_EXISTING | FA_READ);	 //����ͼƬ�ļ���
  if(res==FR_NO_FILE||res==FR_INVALID_NAME){
		f_mount (NULL, "0:", 1);//ע���ļ�ϵͳ
	 return 0;
  }

  if(res!=FR_OK){
   f_mount (NULL, "0:", 1);//ע���ļ�ϵͳ
	 SD_Init();//���³�ʼ��SD�� 
	 return 0;
  }

  res = f_read(&fsrc, &bmp, sizeof(bmp), &br);

//  if(br!=sizeof(bmp))
//	{
//		f_close(&fsrc);
//		f_mount (NULL, "0:", 1);//ע���ļ�ϵͳ
//		return 0;
//  }
	
  if((bmp.pic_head[0]=='B')&&(bmp.pic_head[1]=='M'))
  {
	res = f_lseek(&fsrc,bmp.BMP_head_size);
	if(res!=FR_OK){
     f_close(&fsrc);
     f_mount (NULL, "0:", 1);//ע���ļ�ϵͳ
	 return 0;
    }
//	printf("\r\n %s = %d",filename,bmp.pic_size);

	#if XSIZE_PHYS>=YSIZE_PHYS
	if ((bmp.pic_w_l>XSIZE_PHYS)||(bmp.pic_h_l>XSIZE_PHYS))//�������ֱ������˳�
	#else
	if ((bmp.pic_w_l>YSIZE_PHYS)||(bmp.pic_h_l>YSIZE_PHYS))//�������ֱ������˳�
	#endif
		{
			f_close(&fsrc);
			f_mount (NULL, "0:", 1);//ע���ļ�ϵͳ
			return 0;
		}
	if((bmp.pic_w_l>=bmp.pic_h_l)||(bmp.pic_h_l<=YSIZE_PHYS))//���ͼƬ���ȴ��ڵ��ڸ߶ȣ���ͼƬ�߶�С�ڵ��������߶ȣ���Ϊ�Ǻ�ͼ
	{
 	WriteComm(0x36); //Set_address_mode
 	WriteData(0x20); //�����������½ǿ�ʼ�������ң����µ���  XSIZE_PHYS,YSIZE_PHYS
	if(bmp.pic_w_l<XSIZE_PHYS||bmp.pic_h_l<YSIZE_PHYS)
		{
 			Lcd_ColorBox(0,0,XSIZE_PHYS,YSIZE_PHYS,BLACK);
 			BlockWrite((XSIZE_PHYS-bmp.pic_w_l)/2,(XSIZE_PHYS-bmp.pic_w_l)/2+bmp.pic_w_l-1,(YSIZE_PHYS-bmp.pic_h_l)/2,(YSIZE_PHYS-bmp.pic_h_l)/2+bmp.pic_h_l-1);
		}
		else 	BlockWrite(0,XSIZE_PHYS-1,0,YSIZE_PHYS-1);
	}
	else
	{
		WriteComm(0x36); //Set_address_mode
		WriteData(0x80); //�����������½ǿ�ʼ�������ң����µ���
		if(bmp.pic_w_l<YSIZE_PHYS||bmp.pic_h_l<XSIZE_PHYS)
			{
				Lcd_ColorBox(0,0,YSIZE_PHYS,XSIZE_PHYS,BLACK);
				BlockWrite((YSIZE_PHYS-bmp.pic_w_l)/2,(YSIZE_PHYS-bmp.pic_w_l)/2+bmp.pic_w_l-1,(XSIZE_PHYS-bmp.pic_h_l)/2,(XSIZE_PHYS-bmp.pic_h_l)/2+bmp.pic_h_l-1);
			}
			else BlockWrite(0,YSIZE_PHYS-1,0,XSIZE_PHYS-1);	
	}
	//===================================================================================================//
	if(bmp.pic_dip==16) 
	{
//		WriteComm(0x3A); //Set_address_mode
//		WriteData(0x55);
//		WriteComm(0x2c);
//		TK80->CMDIR =0x2c;
		temp=bmp.pic_w_l*2;  //�����16λ��λͼ��һ����pic_w_l*2���ֽ� bmp.pic_zip_l
		xOfset = temp%4;
		if(xOfset !=0 ) xOfset = 4- xOfset;
		if(bmp.pic_zip_l==3)//windows
		{
			for (tx = 0; tx < bmp.pic_h_l; tx++)
				{
					f_read(&fsrc, buffer, (bmp.pic_w_l)*2+xOfset, &br);
					for(ty=0;ty<temp;ty+=2)
						{		
//							r=(*(ty +1+buffer))&0xf8;
//							g=((*(ty +1+buffer)<<5)|((*(ty +0+buffer))>>3))&0xfc;
//							b=(*(ty +0+buffer))<<3;
//							TK80->DINR = (b<<16)+(g<<8)+r;
////							TK80->DINR = (*(ty +1+buffer)<<8)|(*(ty +0+buffer));
							TK80->DINR = ((*(ty +1+buffer)<<16))|((*(ty +1+buffer)&0x07)<<13)|((*(ty +0+buffer)&0xE0)<<5)|((*(ty +0+buffer)&0x1f)<<3)|0x040004;
						}
				}
			}
		else//apple 
		{
			for (tx = 0; tx < bmp.pic_h_l; tx++)
				{
					f_read(&fsrc, buffer, (bmp.pic_w_l)*2+xOfset, &br);
					for(ty=0;ty<temp;ty+=2)
						{		
//							r=(*(ty +1+buffer)<<1);
//							g=((*(ty +1+buffer))<<6)|((*(ty +0+buffer)&0xE0)>>2);
//							b=((*(ty +0+buffer))<<3);
//							TK80->DINR = (b<<16)+(g<<8)+r;
							TK80->DINR = ((*(ty +1+buffer)<<17))|((*(ty +1+buffer)&0x03)<<14)|((*(ty +0+buffer)&0xE0)<<6)|((*(ty +0+buffer)&0x1f)<<3);
						}
				}
		}
			WriteComm(0x3A); //Set_address_mode
			WriteData(0x77);
	}
	else if(bmp.pic_dip==24)	
		{
			temp=bmp.pic_w_l*3;								 //�����24λ��λͼ��һ����pic_w_l*3���ֽ�
			xOfset = temp%4;
			if(xOfset !=0 ) xOfset = 4- xOfset;
			for (tx = 0; tx < bmp.pic_h_l; tx++)
				{
					f_read(&fsrc, buffer, (bmp.pic_w_l)*3+xOfset, &br);
					for(ty=0;ty<temp;ty+=3)
						{
							TK80->DINR = ((*(ty +2+buffer)<<16))|(*(ty +1+buffer)<<8)|(*(ty +0+buffer));
						}
				}
		}
		else if(bmp.pic_dip==32)	
		{
			temp=bmp.pic_w_l*4;								 //�����32λ��λͼ��һ����pic_w_l*4���ֽ�
			for (tx = 0; tx < bmp.pic_h_l; tx++)
				{
					f_read(&fsrc, buffer, (bmp.pic_w_l)*4, &br);
					for(ty=0;ty<temp;ty+=4)
						{
							TK80->DINR = ((*(ty +2+buffer)<<16))|(*(ty +1+buffer)<<8)|(*(ty +0+buffer));
						}
				}
		}
	else 
		{
			f_mount (NULL, "0:", 1);//ע���ļ�ϵͳ
			WriteComm(0x36); WriteData(0x60);
			return 0; //��ʱ��֧��������ʽ������0
		}
   }
	f_close(&fsrc);
  f_mount (NULL, "0:", 1);//ע���ļ�ϵͳ
	WriteComm(0x36); WriteData(0x60);
  return 1;
}
int bmpCnt=0;
u8 tfBmpName[200][50];
void ReadTF(void)
{
 u16 cnt = 0;
	FRESULT result;
	FATFS fs;
	DIR dirInf;
	FILINFO fileInf;
	bmpCnt=0;	
	result = f_mount (&fs, "0:", 1);//�����ļ�ϵͳ
	if (result != FR_OK) goto MountFalse;//����ʧ��,ע���ļ�ϵͳ

	/* �򿪸��ļ��� */
	result = f_opendir(&dirInf, "/"); /* ���������������ӵ�ǰĿ¼��ʼ */
	
	if(result != FR_OK) goto MountFalse;//�����ʧ�ܣ���ע���ļ�ϵͳ
	

	/* ��ȡ��ǰ�ļ����µ��ļ���Ŀ¼ */
	for (cnt = 0; ;cnt++)
	{
		result = f_readdir(&dirInf,&fileInf);   /* ��ȡĿ¼��������Զ����� */
		if (result != FR_OK || fileInf.fname[0] == 0)
		{
			goto MountFalse;
		}

		if (fileInf.fname[0] == '.')
		{
			continue;
		}
		
		if(strstr(fileInf.fname,"BMP")!=NULL)//ʶ��bmpͼƬ�ļ�
		{
			bmpCnt++;		
			memcpy(tfBmpName[bmpCnt-1],fileInf.fname,sizeof(fileInf.fname));
//			printf("\r\n %s",tfBmpName[bmpCnt-1]);
			if(bmpCnt >200)  //ͼƬ��������������
				break;
		}
	}
MountFalse:
	f_mount (NULL, "0:", 1);//ע���ļ�ϵͳ
}	
void scan_TFCard_auto(void)
{
	int m,j;
	ReadTF();
	if(bmpCnt==0)return;
	GPIOA->CRL = (GPIOA->CRL&0xffffff0f)|0x00000080;//�� PA1���ó����룬��Ϊ����
	while(1)//�Զ�ѭ�������������ġ����˳�ѭ��
	{
			if(m<bmpCnt)
			{
				if(display_picture((char *)&tfBmpName[m]))
				{
//					j = 1000000;while(j--);
				}
			}
			else 
				{
					m=0;
					if(display_picture((char *)&tfBmpName[m]))
					{
//					j = 1000000;while(j--);
					}
				}
			if(GPIOA->IDR & GPIO_Pin_1)break;
			m++;	
	 }
}
//======================================================
// set up
// Test:  Init sequence, With response check  
// CMD 0. Reset Card
// CMD 8. Get voltage (Only 2.0 Card response to this)            ////
// CMD55. Indicate Next Command are Application specific
// ACMD44. Get Voltage windows
// CMD2. CID reg
// CMD3. Get RCA.
//======================================================

