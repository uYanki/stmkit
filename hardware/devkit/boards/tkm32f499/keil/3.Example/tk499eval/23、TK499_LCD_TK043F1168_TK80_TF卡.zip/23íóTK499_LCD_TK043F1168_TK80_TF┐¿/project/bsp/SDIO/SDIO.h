#ifndef __SDIO_H
#define __SDIO_H

#include "HAL_conf.h"


void CMD_Send(unsigned int cmd,unsigned int arg);
void SDIO1_GPIOInitRemap(void);
void SDIO1_GPIOInitInput(void);
void SDIO_Init(void) ;
char display_picture(char *filename);
void scan_TFCard_auto(void);
void show_sdcard_info(void);

#endif 

