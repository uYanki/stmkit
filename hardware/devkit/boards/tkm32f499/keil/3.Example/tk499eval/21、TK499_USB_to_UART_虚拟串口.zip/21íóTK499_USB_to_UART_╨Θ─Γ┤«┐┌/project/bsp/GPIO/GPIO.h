#ifndef __GPIO_H
#define	__GPIO_H

#include "HAL_conf.h"

void LED_Init(void);


#endif /* __LED_H */

