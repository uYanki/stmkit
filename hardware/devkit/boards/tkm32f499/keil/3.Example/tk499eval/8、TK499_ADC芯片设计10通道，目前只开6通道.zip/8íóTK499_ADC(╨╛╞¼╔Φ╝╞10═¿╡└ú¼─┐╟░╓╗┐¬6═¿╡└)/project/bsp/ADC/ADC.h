#ifndef _ADC_H
#define _ADC_H

void ADC_Config(void);

#endif
