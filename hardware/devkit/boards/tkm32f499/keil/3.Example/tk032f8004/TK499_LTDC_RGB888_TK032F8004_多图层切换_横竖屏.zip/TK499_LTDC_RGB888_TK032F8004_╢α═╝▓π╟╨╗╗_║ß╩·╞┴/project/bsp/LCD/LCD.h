#include "HAL_conf.h"


#define LCD_RGB_ORIENTATION      1  //ORIENTATION=1��ת90��   Ϊ1�Ǻ�����Ϊ0������

#if LCD_RGB_ORIENTATION //�Ƿ���ת90��
	#define XSIZE_PHYS 800
	#define YSIZE_PHYS 480
#else
	#define XSIZE_PHYS 480
	#define YSIZE_PHYS 800
#endif


extern __align(256) u32 LTDC_Buf[XSIZE_PHYS*YSIZE_PHYS*3];
//====================== comm ====================//
#define LCD_SPI_CS(a)	\
						if (a)	\
						GPIOE->BSRR = GPIO_Pin_9;	\
						else		\
						GPIOE->BRR  = GPIO_Pin_9;					
#define SPI_DCLK(a)	\
						if (a)	\
						GPIO_SetBits(GPIOE, GPIO_Pin_23);	\
						else		\
						GPIO_ResetBits(GPIOE, GPIO_Pin_23);	
#define SPI_SDA(a)	\
						if (a)	\
						GPIO_SetBits(GPIOE, GPIO_Pin_22);	\
						else		\
						GPIO_ResetBits(GPIOE, GPIO_Pin_22);	

#define LCD_RST(a)	\
						if (a)	\
						GPIO_SetBits(GPIOE, GPIO_Pin_17);	\
						else		\
						GPIO_ResetBits(GPIOE, GPIO_Pin_17);

#define Lcd_Light_ON   GPIO_SetBits(GPIOE, GPIO_Pin_16) //PE16Ϊ�ߵ�ƽ �����
#define Lcd_Light_OFF  GPIO_ResetBits(GPIOE, GPIO_Pin_16)  //PE16Ϊ�͵�ƽ ����ر�
						

#define KEY_Up     GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)
#define KEY_Down   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)
#define KEYL_Left   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_13)
#define KEY_Right   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)
#define KEY_Center  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)
						
//*************  24λɫ��1600��ɫ������ *************//
#define WHITE          0xFFFFFF
#define BLACK          0x000000
#define BLUE           0x0000FF
#define BLUE2          0x3F3FFF
#define RED            0xFF0000
#define MAGENTA        0xFF00FF
#define GREEN          0x00FF00
#define CYAN           0x00FFFF
#define YELLOW         0xFFFF00					

//*************  16λɫ���� *************//
//#define White          0xFFFF
//#define Black          0x0000
//#define Blue           0x001F
//#define Blue2          0x051F
//#define Red            0xF800
//#define Magenta        0xF81F
//#define Green          0x07E0
//#define Cyan           0x7FFF
//#define Yellow         0xFFE0
						
						

void LCD_Initial(void); //LCD��ʼ������ʱ��
void Lcd_Initialize(void); //LCD��ʼ������
volatile void LCD_delay(volatile int time);
void WriteComm(unsigned char CMD);
void WriteData(u32 dat);
void LCD_WR_REG(u16 Index,u16 CongfigTemp);
void Lcd_ColorBox(u16 xStart,u16 yStart,u16 xLong,u16 yLong,u32 Color);
//void SPILCD_DrawLine(unsigned short x1,unsigned short y1,unsigned short x2,unsigned short y2,unsigned short color);
//void SPILCD_ShowChar(unsigned short x,unsigned short y,unsigned char num, unsigned int fColor, unsigned int bColor,unsigned char flag) ;
void LCD_PutString(unsigned short x, unsigned short y, char *s, unsigned int fColor, unsigned int bColor,unsigned char flag);
void LCD_Fill_Pic(u16 x, u16 y,u16 pic_H, u16 pic_V, u32* pic);
void LCD_PutString_GB_n(unsigned short x, unsigned short y, char *s, unsigned int fColor, unsigned int bColor,unsigned char flag,unsigned int n);

void Lcd_ColorBox_Layer(u16 xStart,u16 yStart,u16 xLong,u16 yLong,u32 Color,char layer_n);
void LCD_Fill_Pic_Layer(u16 x, u16 y,u16 pic_H, u16 pic_V, u32* pic,char Layer_n);
void LCD_PutString_Layer(u32 x, u32 y, char *s, unsigned int fColor, unsigned int bColor,unsigned char flag,char Layer_n);
