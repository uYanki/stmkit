#ifndef __MAIN_H
#define	__MAIN_H

#include "HAL_conf.h"
#include "led.h"
#include "sys.h"
#include "spi.h"
#include "TK499_Timer.h"
extern u32 LTDC_add;

void delay_ms(u16 time);

#endif


