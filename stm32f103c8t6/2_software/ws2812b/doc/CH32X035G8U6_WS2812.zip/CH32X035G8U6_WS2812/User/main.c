/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2023/12/26
 * Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/

/*
 *@Note
 *GPIO routine:
 *PA0 push-pull output.
 *
 ***Only PA0--PA15 and PC16--PC17 support input pull-down.

    IO_Drive_Mode    ---  PA0
    PWM_Drive_Mode   ---  PB9  (T1C1)
    SPI_Drive_Mode   ---  PA7  (SPI1_MOSI)
    PIOC_Drive_Mode  ---  PC18 (PIOC_IO0)
*/

#include "debug.h"
#include "RGB1W.h"

/* Global define */
#define IO_Drive_Mode       0x01  // IO��ת��ʽ����
#define PWM_Drive_Mode      0x02  // TIM_PWM��ʽ����
#define SPI_Drive_Mode      0x03  // SPI��ʽ����
#define PIOC_Drive_Mode     0x04  // PIOC��ʽ����

#define Mode     IO_Drive_Mode  // ѡ��������ʽ

/* Global Variable */
#if Mode == IO_Drive_Mode
void GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_WriteBit(GPIOA, GPIO_Pin_0, Bit_RESET);
}

void WS2812_0(void)
{
    /* T0H - 300ns , T0L - 600ns */
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);  // �ߵ�ƽʱ�� 45ns
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BCR = GPIO_Pin_0;                            // �͵�ƽʱ�� 40ns
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
}

void WS2812_1(void)
{
    /* T1H - 600ns , T1L - 600ns */
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);  // �ߵ�ƽʱ�� 45ns
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BSHR = (GPIO_Pin_0 & (uint32_t)0x0000FFFF);
    GPIOA->BCR = GPIO_Pin_0;                            // �͵�ƽʱ�� 40ns
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
    GPIOA->BCR = GPIO_Pin_0;
}

void WS2812_Reset(void)
{
    /* RES �͵�ƽ280us���� */
    GPIOA->BCR = GPIO_Pin_0;
    Delay_Us(300);
}

#elif Mode == PWM_Drive_Mode
#define TIM1_CH1CVR_ADDRESS    0x40012C34

uint8_t WS2812_RGB_Buffer[] = {
    0x01, 0x00, 0x00,  // G-R-B
    0x00, 0x01, 0x00,
    0x00, 0x00, 0x01,
};

uint16_t TIM1_CH1VR_Buffer[(3*3*8)+3] = {0};  // 3�ŵ�*ÿ�ŵ�������ɫ����*ÿ����ɫ8λ����+3��0���ݣ�Ϊ������͵�ƽ����280us��Reset�źţ�

void TIM1_PWMOut_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure={0};
    TIM_OCInitTypeDef TIM_OCInitStructure={0};
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure={0};

    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure );

    TIM_TimeBaseInitStructure.TIM_Period = 10-1;
    TIM_TimeBaseInitStructure.TIM_Prescaler = (SystemCoreClock/8000000)-1;  // 800K Hz
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit( TIM1, &TIM_TimeBaseInitStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init( TIM1, &TIM_OCInitStructure );

    TIM_OC1PreloadConfig( TIM1, TIM_OCPreload_Enable );   ///ͨ��1

    TIM_ARRPreloadConfig( TIM1, ENABLE );
    TIM_Cmd( TIM1, ENABLE );
}

void TIM1_DMA_Init(DMA_Channel_TypeDef *DMA_CHx, u32 ppadr, u32 memadr, u16 bufsize)
{
    DMA_InitTypeDef DMA_InitStructure = {0};

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA_CHx);
    DMA_InitStructure.DMA_PeripheralBaseAddr = ppadr;  // DMA�������ַ
    DMA_InitStructure.DMA_MemoryBaseAddr = memadr;  // DMA�ڴ����ַ
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;  // ���ݴ��䷽�򣬴��ڴ��ȡ���͵�����
    DMA_InitStructure.DMA_BufferSize = bufsize;  // DMAͨ����DMA����Ĵ�С
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA_CHx, &DMA_InitStructure);

    DMA_Cmd(DMA_CHx, ENABLE);
}

void WS2812_Display(uint8_t pdata[], uint8_t len)
{
    uint8_t n = 0;
    uint8_t x = 0,y = 0,z = 0;

    for(x=0;x<len;x++)
    {
        n = pdata[x];
        for(y=0;y<8;y++)
        {
            z = ((n<<y)&0x80);
            if(z) TIM1_CH1VR_Buffer[x*8+y] = 5;  // �ж�Ϊ1��
            else  TIM1_CH1VR_Buffer[x*8+y] = 3;  // �ж�Ϊ0��
        }
    }
    TIM1_DMA_Init(DMA1_Channel5, (u32)TIM1_CH1CVR_ADDRESS, (u32)TIM1_CH1VR_Buffer, 75);
}

#elif Mode == SPI_Drive_Mode
uint8_t SPI_Tx_Buffer[] = {
    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x0F,  // G - 0x01
    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,  // R - 0x00
    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,  // B - 0x00

    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,  // G - 0x00
    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x0F,  // R - 0x01
    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,  // B - 0x00

    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,  // G - 0x00
    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,  // R - 0x00
    0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x0F,  // B - 0x01
};

void SPI1_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    SPI_InitTypeDef SPI_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;  //NSS
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_SET);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;  //SCLK
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;  //MISO
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;  //MOSI
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    SPI_SSOutputCmd(SPI1, ENABLE);
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;  // 6M Hz
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_LSB;
    SPI_InitStructure.SPI_CRCPolynomial = 0;
    SPI_Init(SPI1, &SPI_InitStructure);

    SPI_Cmd(SPI1, ENABLE);
    GPIO_WriteBit(GPIOA, GPIO_Pin_4, Bit_RESET);
}
#elif Mode == PIOC_Drive_Mode
u8 RGBpbuf[] = {
    0x01, 0x00, 0x00,  // G-R-B
    0x00, 0x01, 0x00,
    0x00, 0x00, 0x01,
};

#define     rgb_source_addr         ((uint8_t *)RGBpbuf)
#define     rgb_data_bytes          sizeof(RGBpbuf)    // 3 RGB LEDs, 9 bytes data

#endif

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();
    Delay_Init();
    USART_Printf_Init(115200);
    printf("SystemClk:%d\r\n", SystemCoreClock);
    printf( "ChipID:%08x\r\n", DBGMCU_GetCHIPID() );
    printf("WS2812 TEST\r\n");
#if Mode == IO_Drive_Mode
    GPIO_Config();
#elif Mode == PWM_Drive_Mode
    TIM1_PWMOut_Init();
    TIM_DMACmd(TIM1, TIM_DMA_Update, ENABLE);
    TIM_CtrlPWMOutputs(TIM1, ENABLE);
#elif Mode == SPI_Drive_Mode
    SPI1_Init();
#elif Mode == PIOC_Drive_Mode
    uint16_t total_bytes;
    u8* RGB_RAM;
    RGB1W_Init( );
    stat = 0x80;
#endif

    while(1)
    {
#if Mode == IO_Drive_Mode
        /* ��λ�ȷ������� GRB ��˳��������  */
        // 16����
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_1(); // G1 - 0x08
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0(); // R1 - 0x00
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0(); // B1 - 0x00
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0(); // G2 - 0x00
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_1(); // R2 - 0x01
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0(); // B2 - 0x00
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0(); // G3 - 0x00
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0(); // R3 - 0x00
        WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_0();WS2812_1(); // B3 - 0x01
        WS2812_Reset();
#elif Mode == PWM_Drive_Mode
        WS2812_Display(WS2812_RGB_Buffer, 9);
        Delay_Us(300);  // Reset
#elif Mode == SPI_Drive_Mode
        for(uint8_t i=0;i<(24*3);i++)  // ÿ24�ֽڿ���һ�ŵ��飬��3��
        {
            SPI_I2S_SendData(SPI1, SPI_Tx_Buffer[i]);
            while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) != SET);
        }
        Delay_Us(300);  // Reset
#elif Mode == PIOC_Drive_Mode
        total_bytes = rgb_data_bytes;
        Delay_Ms(200);
        stat = 0x80;
        if ( stat != 0xFF )
        {
            if ( stat < 0x80 )
            {
                if ( stat == RGB1W_ERR_OK ) printf("1-wire finished\r\n");
                else printf("1-wire error %02x\r\n", stat);
                stat = 0x80;  // free
            }
            if ( stat == 0x80 && total_bytes )
            {  //RAM mode for 1~3072 bytes data
                stat = 0xFF;  // wait
                RGB_RAM = RGBpbuf;
                RGB1W_SendRAM( total_bytes, RGB_RAM ,0);
                total_bytes = 0;
            }
        }
        if ( PIOC->D8_SYS_CFG & RB_INT_REQ ) {  // query if disable interrupt
            stat = PIOC->D8_CTRL_RD;  // auto remove interrupt request after reading
        }
#endif
    }
}


