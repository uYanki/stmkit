/**
 * @file usbh_cp210x.h
 * @author 262666882@qq.com
 * @brief 从linux驱动移植过来的,支持cp210x芯片。目前只做了简单测试，基本功能可用。
 * @version 0.1
 * @date 2023-07-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#ifndef USBH_CP210X_H
#define USBH_CP210X_H

#include "rtthread.h"
#include "usbh_core.h"
#include "cp210x.h"

#include "ipc/ringbuffer.h"

struct usbh_cp210x
{

    struct usbh_hubport *hport;

    uint8_t intf;
    usbh_pipe_t bulkin;
    usbh_pipe_t bulkout;
    struct usbh_urb bulkin_urb;
    struct usbh_urb bulkout_urb;

    struct tty_struct drv_data;
    int index;
};

struct usbh_cp210x_static_device
{
    struct rt_device parent;

    struct usbh_cp210x *p_device;
    struct rt_mutex lock;
};


#endif
