
#ifndef CP210X_H
#define CP210X_H

#include <stdint.h>

#include "termbits.h"

#ifdef RUN_PC_TEST
#define dev_dbg(port, fmt, ...)  printf("[Debug]   " fmt, ##__VA_ARGS__)
#define dev_err(port, fmt, ...)  printf("[ERROR]   " fmt, ##__VA_ARGS__)
#define dev_warn(port, fmt, ...) printf("[Warning] " fmt, ##__VA_ARGS__)
#else

#include <stdio.h>
#include "rtthread.h"
#define dev_dbg(port, fmt, ...)  printf("[Debug]   " fmt, ##__VA_ARGS__)
#define dev_err(port, fmt, ...)  printf("[ERROR]   " fmt, ##__VA_ARGS__)
#define dev_warn(port, fmt, ...) printf("[Warning] " fmt, ##__VA_ARGS__)
#endif

#define le32_to_cpu(le32_val) (le32_val)

#define USB_CTRL_SET_TIMEOUT 1
#define USB_CTRL_GET_TIMEOUT 1
#define EIO  -23

#define TIOCSTI		0x5412
#define TIOCMGET	0x5415
#define TIOCMBIS	0x5416
#define TIOCMBIC	0x5417
#define TIOCMSET	0x5418
# define TIOCM_LE	0x001
# define TIOCM_DTR	0x002
# define TIOCM_RTS	0x004
# define TIOCM_ST	0x008
# define TIOCM_SR	0x010
# define TIOCM_CTS	0x020
# define TIOCM_CAR	0x040
# define TIOCM_RNG	0x080
# define TIOCM_DSR	0x100
# define TIOCM_CD	TIOCM_CAR
# define TIOCM_RI	TIOCM_RNG
# define TIOCM_OUT1	0x2000
# define TIOCM_OUT2	0x4000
# define TIOCM_LOOP	0x8000
#define u8 unsigned char
#define __u8 unsigned char
#define u16 uint16_t
#define u32 uint32_t
typedef int speed_t;
typedef int bool;


typedef int32_t tcflag_t;

#define DRIVER_DESC "Silicon Labs CP210x RS232 serial adaptor driver"

struct usb_serial_port{
	u8			partnum;
	u8			ctrlpipe_rx;
	u8			ctrlpipe_tx;
	speed_t		max_speed;
	bool		use_actual_rate;
	__u8		bInterfaceNumber;
	bool		has_swapped_line_ctl;
};

int usb_control_msg( struct usb_serial_port *port, int pipe, int u1, u8 type, u16 val, u8 interface_num, void *dmabuf, int bufsize, int flags);

typedef unsigned char cc_t;

#define NCCS 19
struct termios {
	tcflag_t c_iflag;		/* input mode flags */
	tcflag_t c_oflag;		/* output mode flags */
	tcflag_t c_cflag;		/* control mode flags */
	tcflag_t c_lflag;		/* local mode flags */
	cc_t c_cc[NCCS];		/* control characters */
	cc_t c_line;			/* line discipline (== c_cc[19]) */
	speed_t c_ispeed;		/* input speed */
	speed_t c_ospeed;		/* output speed */
};

/* Alpha has identical termios and termios2 */

struct termios2 {
	tcflag_t c_iflag;		/* input mode flags */
	tcflag_t c_oflag;		/* output mode flags */
	tcflag_t c_cflag;		/* control mode flags */
	tcflag_t c_lflag;		/* local mode flags */
	cc_t c_cc[NCCS];		/* control characters */
	cc_t c_line;			/* line discipline (== c_cc[19]) */
	speed_t c_ispeed;		/* input speed */
	speed_t c_ospeed;		/* output speed */
};

/* Alpha has matching termios and ktermios */

struct ktermios {
	tcflag_t c_iflag;		/* input mode flags */
	tcflag_t c_oflag;		/* output mode flags */
	tcflag_t c_cflag;		/* control mode flags */
	tcflag_t c_lflag;		/* local mode flags */
	cc_t c_cc[NCCS];		/* control characters */
	cc_t c_line;			/* line discipline (== c_cc[19]) */
	speed_t c_ispeed;		/* input speed */
	speed_t c_ospeed;		/* output speed */
};


struct tty_struct{
    struct usb_serial_port driver_data;
    struct termios termios;
};

int cp210x_attach(struct usb_serial_port *port);
int cp210x_port_probe(struct usb_serial_port *port);
void cp210x_break_ctl(struct tty_struct *tty, int break_state);
int cp210x_open(struct tty_struct *tty);
int cp210x_tiocmget(struct tty_struct *tty);
void cp210x_set_termios(struct tty_struct *tty);
void cp210x_change_speed(struct tty_struct *tty);
void cp210x_dtr_rts(struct usb_serial_port *port, int on);

#endif
