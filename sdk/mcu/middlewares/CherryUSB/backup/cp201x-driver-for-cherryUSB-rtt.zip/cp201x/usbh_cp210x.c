/**
 * @file usbh_cp210x.c
 * @author 262666882@qq.com
 * @brief 从linux驱动移植过来的,支持cp210x芯片。目前只做了简单测试，基本功能可用。
 * @version 0.1
 * @date 2023-07-05
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>

#include "cp210x.h"
#include "rtthread.h"
#include "usbh_cp210x.h"

#include <rtdevice.h>

#ifndef container_of
#define container_of(p,t,m)                     \
    ((t*)((char*)p-(char*)(&(((t*)0)->m))))
#endif
#define DEV_COUNT 4
static struct usbh_cp210x_static_device g_devices[DEV_COUNT];

static int __cp210x_set( struct usbh_cp210x *p_dev, int brate, int bits, int stopb, int parity, int hwctrl)
{

	memset(&p_dev->drv_data.termios, 0, sizeof(p_dev->drv_data.termios));
	p_dev->drv_data.termios.c_iflag = 0;
	p_dev->drv_data.termios.c_oflag = 0;
	if (bits == 8)
		p_dev->drv_data.termios.c_cflag = CS8;
	else if (bits == 7)
		p_dev->drv_data.termios.c_cflag = CS7;
	else if (bits == 6)
		p_dev->drv_data.termios.c_cflag = CS6;
	else if (bits == 5)
		p_dev->drv_data.termios.c_cflag = CS5;
	else 
		p_dev->drv_data.termios.c_cflag = CS8;
	
	int c_cflag_p = 0;
	switch (parity){
		case PARITY_NONE:break;
		case PARITY_EVEN: c_cflag_p=PARENB; break;
		case PARITY_ODD: c_cflag_p=PARENB|PARODD; break;
		case PARITY_SPACE: c_cflag_p=PARENB|CMSPAR; break;
		case PARITY_MARK: c_cflag_p=PARENB|CMSPAR|PARODD; break;
	}
	int stopbits = 0; /* 1 stopbit default */
	if ( stopb == 2){
		stopbits = CSTOPB;
	} 
	p_dev->drv_data.termios.c_cflag |= c_cflag_p | stopbits;

	p_dev->drv_data.termios.c_lflag = 0;
	p_dev->drv_data.termios.c_cc[0] = 0;
	p_dev->drv_data.termios.c_ospeed = 9600;
	cp210x_set_termios(&p_dev->drv_data);
    cp210x_break_ctl( &p_dev->drv_data, hwctrl );
}

static int __usbh_cp210x_connect(struct usbh_hubport *hport, uint8_t intf)
{
    struct usb_endpoint_descriptor *ep_desc;
	int index = hport->port-1;
	struct usbh_cp210x *p_cp210x= usb_malloc(sizeof(struct usbh_cp210x));
	if (0 == p_cp210x){
		return -ENOSYS;
	}
	memset( p_cp210x, 0x00, sizeof(*p_cp210x));
	p_cp210x->hport = hport;
	p_cp210x->intf = intf;
	hport->config.intf[intf].priv = p_cp210x;

	p_cp210x->drv_data.driver_data.bInterfaceNumber = 1;
	p_cp210x->drv_data.driver_data.ctrlpipe_rx      = 0x80;
	p_cp210x->drv_data.driver_data.ctrlpipe_tx      = 0x00;
	p_cp210x->drv_data.driver_data.max_speed        = 9600;
	p_cp210x->drv_data.driver_data.use_actual_rate  = 1;
	p_cp210x->drv_data.driver_data.bInterfaceNumber = 1;
	p_cp210x->drv_data.driver_data.has_swapped_line_ctl = 0;

    USB_LOG_INFO("%s hub %d port %d\n", "---- attach ----", hport->parent->index, hport->port );
    if ( 0 != cp210x_attach( &p_cp210x->drv_data.driver_data ) ){
        USB_LOG_INFO("%s\n", "Device NOT supported!" );
		return -EIO;
    }
    cp210x_port_probe( &p_cp210x->drv_data.driver_data );
    cp210x_open(&p_cp210x->drv_data);
    cp210x_break_ctl( &p_cp210x->drv_data, 0 );

	{
		memset(&p_cp210x->drv_data.termios, 0, sizeof(p_cp210x->drv_data.termios));
		p_cp210x->drv_data.termios.c_iflag = 0;
		p_cp210x->drv_data.termios.c_oflag = 0;
		p_cp210x->drv_data.termios.c_cflag = CS8;
		p_cp210x->drv_data.termios.c_lflag = 0;
		p_cp210x->drv_data.termios.c_cc[0] = 0;
		p_cp210x->drv_data.termios.c_ospeed = 9600;
		cp210x_set_termios(&p_cp210x->drv_data);
	}

    int r = cp210x_tiocmget( &p_cp210x->drv_data);

    for (uint8_t i = 0; i < hport->config.intf[intf].altsetting[0].intf_desc.bNumEndpoints; i++) {
        ep_desc = &hport->config.intf[intf].altsetting[0].ep[i].ep_desc;
        if (ep_desc->bEndpointAddress & 0x80) {
            usbh_hport_activate_epx(&p_cp210x->bulkin, hport, ep_desc);
        } else {
            usbh_hport_activate_epx(&p_cp210x->bulkout, hport, ep_desc);
        }
    }
	struct usbh_cp210x_static_device *p_dev_static = g_devices+index;
	rt_mutex_take( &p_dev_static->lock, RT_WAITING_FOREVER );
	{
		p_dev_static->p_device = p_cp210x;
	}
	rt_mutex_release( &p_dev_static->lock );
	return 0;
}

int usb_control_msg( struct usb_serial_port *port, int pipe, int req, u8 type, u16 val, u8 interface_num, void *dmabuf, int bufsize, int flags)
{
	struct usbh_cp210x *p_device = container_of(port, struct usbh_cp210x, drv_data.driver_data);
    struct usb_setup_packet *setup = p_device->hport->setup;

	setup->bmRequestType = type;
	setup->bRequest = req;
	setup->wValue = val;
	setup->wIndex = interface_num;
	setup->wLength = bufsize;
	int len = usbh_control_transfer( p_device->hport->ep0, setup, dmabuf );
	if ( len > 0 ){
		return len - 8;
	}
	return len;
}

static int __usbh_cp210x_disconnect(struct usbh_hubport *hport, uint8_t intf)
{
    struct usbh_cp210x *p_device = (struct usbh_cp210x*)hport->config.intf[intf].priv;
	if (p_device){
		int index = p_device->index;
		rt_mutex_take( &g_devices[index].lock, RT_WAITING_FOREVER);
		g_devices[index].p_device = 0;
		if (p_device->bulkin){
			usbh_pipe_free(p_device->bulkin);
		}
		if (p_device->bulkout){
			usbh_pipe_free(p_device->bulkout);
		}
		memset(p_device, 0, sizeof(*p_device));
		usb_free(p_device);
		rt_mutex_release( &g_devices[index].lock );
	}
}


static const struct usbh_class_driver cp210x_class_driver = {
    .driver_name = "cp210x",
    .connect = __usbh_cp210x_connect,
    .disconnect =__usbh_cp210x_disconnect 
};

CLASS_INFO_DEFINE const struct usbh_class_info cp210x_class_info = {
    .match_flags = USB_CLASS_MATCH_INTF_CLASS | USB_CLASS_MATCH_INTF_SUBCLASS | USB_CLASS_MATCH_INTF_PROTOCOL,
    .class = 0xff,    // usbh_cp210x_static_device_CLASS_MASS_STORAGE,
    .subclass = 0x00, //MSC_SUBCLASS_SCSI,
    .protocol = 0x00, //MSC_PROTOCOL_BULK_ONLY,
    .vid = 0x00,
    .pid = 0x00,
    .class_driver = &cp210x_class_driver
};



static rt_err_t __init(struct rt_device *dev)
{
    rt_err_t result = RT_EOK;
    struct usbh_cp210x_static_device *p_this;

    RT_ASSERT(dev != RT_NULL);
    p_this = (struct usbh_cp210x_static_device *)dev;
    return result;
}

static rt_err_t __open(struct rt_device *dev, rt_uint16_t oflag)
{
    rt_uint16_t stream_flag = 0;

    RT_ASSERT(dev != RT_NULL);

    /* keep steam flag */
    if ((oflag & RT_DEVICE_FLAG_STREAM) || (dev->open_flag & RT_DEVICE_FLAG_STREAM))
        stream_flag = RT_DEVICE_FLAG_STREAM;

    /* get open flags */
    dev->open_flag = oflag & 0xff;
    /* set stream flag */
    dev->open_flag |= stream_flag;
    //dev->flag |= RT_DEVICE_FLAG_ACTIVATED;

    return RT_EOK;
}

static rt_err_t __close(struct rt_device *dev)
{
    struct usbh_cp210x_static_device *p_this;

    RT_ASSERT(dev != RT_NULL);
    p_this = (struct usbh_cp210x_static_device *)dev;
    (void)p_this;

    /* this device has more reference count */
    if (dev->ref_count > 1) return RT_EOK;

    dev->flag &= ~RT_DEVICE_FLAG_ACTIVATED;

    return RT_EOK;
}

static rt_size_t __read(struct rt_device *dev,
                                rt_off_t          pos,
                                void             *buffer,
                                rt_size_t         size)
{
    struct usbh_cp210x_static_device *p_this;

    RT_ASSERT(dev != RT_NULL);
    if (size == 0) return 0;

    p_this = (struct usbh_cp210x_static_device *)dev;

	rt_mutex_take( &p_this->lock, RT_WAITING_FOREVER);
	struct usbh_cp210x *p_device = p_this->p_device;
	if (!p_device){
		rt_mutex_release( &p_this->lock );
		return 0;
	}
    int ret;
    struct usbh_urb *urb = &p_device->bulkout_urb;
    memset(urb, 0, sizeof(struct usbh_urb));

    usbh_bulk_urb_fill(urb, p_device->bulkin, buffer, size, 500, NULL, NULL);
    ret = usbh_submit_urb(urb);
	rt_mutex_release( &p_this->lock );
    return ret>0?ret:0;
}

static rt_size_t __write(struct rt_device *dev,
                                 rt_off_t          pos,
                                 const void       *buffer,
                                 rt_size_t         size)
{
    struct usbh_cp210x_static_device *p_this;

    RT_ASSERT(dev != RT_NULL);
    if (size == 0) return 0;

    p_this = (struct usbh_cp210x_static_device *)dev;
 
	rt_mutex_take( &p_this->lock, RT_WAITING_FOREVER);
	struct usbh_cp210x *p_device = p_this->p_device;
	if (!p_device){
		rt_mutex_release( &p_this->lock );
		return 0;
	}
    int ret;
    struct usbh_urb *urb = &p_device->bulkout_urb;
    memset(urb, 0, sizeof(struct usbh_urb));

    usbh_bulk_urb_fill(urb, p_device->bulkout, (uint8_t*)buffer, size, 500, NULL, NULL);
    ret = usbh_submit_urb(urb);
	rt_mutex_release( &p_this->lock );
    
    return ret>0?ret:0;
}

static rt_err_t __control(struct rt_device *dev,
                                  int              cmd,
                                  void             *args)
{
    rt_err_t ret = RT_EOK;
    struct usbh_cp210x_static_device *p_this;

    RT_ASSERT(dev != RT_NULL);
    p_this = (struct usbh_cp210x_static_device *)dev;

    (void)p_this;

	rt_mutex_take( &p_this->lock, RT_WAITING_FOREVER);
	struct usbh_cp210x *p_device = p_this->p_device;
	if (!p_device){
		rt_mutex_release( &p_this->lock );
		return 0;
	}

    switch (cmd)
    {
        case RT_DEVICE_CTRL_SUSPEND:
            /* suspend device */
            dev->flag |= RT_DEVICE_FLAG_SUSPENDED;
            break;

        case RT_DEVICE_CTRL_RESUME:
            /* resume device */
            dev->flag &= ~RT_DEVICE_FLAG_SUSPENDED;
            break;

        case RT_DEVICE_CTRL_CONFIG:
			if (args) {
                struct serial_configure *pconfig = (struct serial_configure *) args;
            }
            break;
        default :
            break;
    }

	rt_mutex_release( &p_this->lock );
    return ret;
}

#ifdef RT_USING_DEVICE_OPS
const static struct rt_device_ops p_this_ops =
{
    __init,
    __open,
    __close,
    __read,
    __write,
    __control
};
#endif

static void __device_register( const char *name, int index )
{
    rt_err_t ret;
    rt_uint32_t flag = 0;
    struct rt_device *device;

	struct usbh_cp210x_static_device *p_dev = g_devices+index;

	memset(p_dev, 0, sizeof(*p_dev));


    device = &(p_dev->parent);

    device->type        = RT_Device_Class_Char;
    device->rx_indicate = RT_NULL;
    device->tx_complete = RT_NULL;

#ifdef RT_USING_DEVICE_OPS
    device->ops         = &p_this_ops;
#else
    device->init        = __init;
    device->open        = __open;
    device->close       = __close;
    device->read        = __read;
    device->write       = __write;
    device->control     = __control;
#endif
    device->user_data   = 0;
	rt_mutex_init( &p_dev->lock, "USBx", 0);

    /* register a character device */
    ret = rt_device_register(device, name, flag);
}

void register_all_ttyusb_devices(void)
{
	__device_register( "ttyU0", 0);
	__device_register( "ttyU1", 1);
	__device_register( "ttyU2", 2);
	__device_register( "ttyU3", 3);
}

