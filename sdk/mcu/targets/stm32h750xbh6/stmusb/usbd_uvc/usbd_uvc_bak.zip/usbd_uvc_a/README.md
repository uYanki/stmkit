[TOC]

# 虚拟串口 

## CubeMx

### 设备模式

![usb_mode](.assets/README/usb_mode.png)

![usbd_class](.assets/README/usbd_class.png)

### 时钟源

![usb_clock_sel](.assets/README/usb_clock_sel.png)

## keil

### printf

![usbd_printf](.assets/README/usbd_printf.png)