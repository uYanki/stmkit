[TOC]

# 虚拟摄像头

## 移植过程

参考 `usbd_cdc_acm`

## 测试效果

在 PotPlayer 界面中按下 `Ctrl+J`，或者在菜单中选择 `摄像头/其他设备`

![image-20250208221323752](.assets/README/image-20250208221323752.png)

![image-20250208221233430](.assets/README/image-20250208221233430.png)