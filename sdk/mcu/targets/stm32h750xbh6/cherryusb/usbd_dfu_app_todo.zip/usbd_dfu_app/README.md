[TOC]

# DFU

Device Firmware update

## 升级工具

使用 STM32CubeProgrammer 进行升级

![image-20250209034910915](.assets/README/image-20250209034910915.png)