/***
	*************************************************************************************************
	*	@file  	main.c
	*	@version V1.0
	*  @date    2022-9-23
	*	@author  ���ͿƼ�	
	*	@brief   FreeRTOS + CherryUSB + DAP ����
   *************************************************************************************************
   *  @description
	*
	*	ʵ��ƽ̨������STM32H750VBT6���İ� ���ͺţ�FK750M1-VBT6��
	*	�Ա���ַ��https://shop212360197.taobao.com
	*	QQ����Ⱥ��536665479
	*	
>>>>> ����˵����
	*
	*	1.WinUSB�豸
	*	2.DAP�豸������cache���Դﵽ�������
	*
	************************************************************************************************
***/
#include "main.h"
#include "led.h"
#include "usart.h"
#include "cmsis_os2.h"			// RTOSͷ�ļ�

#include "usbd_core.h"
#include "DAP_config.h"
#include "DAP.h"
#include "osObjects.h"

PCD_HandleTypeDef hpcd_USB_OTG_FS;

extern void daplink_winusb_init(void);

	  
void usb_dc_low_level_init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = { 0 };
    RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = { 0 };

    /* USER CODE BEGIN USB_OTG_FS_MspInit 0 */

    /* USER CODE END USB_OTG_FS_MspInit 0 */
    /** Initializes the peripherals clock
  */
    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_USB;
    PeriphClkInitStruct.UsbClockSelection = RCC_USBCLKSOURCE_HSI48;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK) {
        Error_Handler();
    }
    /** Enable USB Voltage detector
  */
    HAL_PWREx_EnableUSBVoltageDetector();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USB_OTG_FS GPIO Configuration
    PA11     ------> USB_OTG_FS_DM
    PA12     ------> USB_OTG_FS_DP
    */
    GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF10_OTG1_FS;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* Peripheral clock enable */
    __HAL_RCC_USB_OTG_FS_CLK_ENABLE();
    /* USB_OTG_FS interrupt Init */
    HAL_NVIC_SetPriority(OTG_FS_IRQn, 6, 0);
    HAL_NVIC_EnableIRQ(OTG_FS_IRQn);
    /* USER CODE BEGIN USB_OTG_FS_MspInit 1 */

    /* USER CODE END USB_OTG_FS_MspInit 1 */
}

/*************************************** RTOS�������� ***************************************************/

const osThreadAttr_t Main_Task_Attr = 	// ���������ȼ����
{
	.priority = osPriorityHigh5,
	.stack_size = 4096,
};

const osThreadAttr_t Msg_Task_Attr = 	// ��Ϣ��������
{
	.priority = osPriorityLow2,
	.stack_size = 4096,
};

const osThreadAttr_t LED_Task_Attr = 	// �������
{
	.priority = osPriorityLow1,
	.stack_size = 512,
};

osThreadId_t Main_Task_Id 	= NULL;	// ������ID
osThreadId_t Msg_Task_Id 	= NULL;	// ��Ϣ��������ID
osThreadId_t LED_Task_Id 	= NULL;	// �������ID


/********************************************** �������� *******************************************/
void SystemClock_Config(void);		// ʱ�ӳ�ʼ��
void MPU_Config(void);					// MPU����

void RTOS_Main_Task(void *argument);	// ������
void RTOS_Msg_Task(void *argument);		// ��Ϣ��������
void RTOS_LED_Task(void *argument);		// �������

#define  DWT_CR      *(__IO uint32_t *)0xE0001000
#define  DWT_CYCCNT  *(__IO uint32_t *)0xE0001004
#define  DEM_CR      *(__IO uint32_t *)0xE000EDFC
	
#define  DEM_CR_TRCENA                   (1 << 24)
#define  DWT_CR_CYCCNTENA                (1 <<  0)

/***************************************************************************************************
*	�� �� ��: main
*
*	��������: ������
*	
****************************************************************************************************/

int main(void)
{
	MPU_Config();				// MPU����
//	SCB_EnableICache();		// ʹ��ICache
//	SCB_EnableDCache();		// ʹ��DCache
	HAL_Init();					// ��ʼ��HAL��	
	SystemClock_Config();	// ����ϵͳʱ�ӣ���Ƶ480MHz
	LED_Init();					// ��ʼ��LED����
	USART1_Init();				// USART1��ʼ��	

	 
	DEM_CR |= (uint32_t)DEM_CR_TRCENA;     // ʹ��DWT����   	 
	DWT_CYCCNT = (uint32_t)0u; 				// ʹ�ܼ�����֮ǰ��DWT CYCCNT�Ĵ�����0 
	DWT_CR |= (uint32_t)DWT_CR_CYCCNTENA;	// ʹ�ܼ�����		
		
	osKernelInitialize();	// ��ʼ��RTOS

	Main_Task_Id = osThreadNew(RTOS_Main_Task, 	NULL, &Main_Task_Attr);  	// ����������
	Msg_Task_Id  = osThreadNew(RTOS_Msg_Task, 	NULL, &Msg_Task_Attr);  	//	��Ϣ��������	
	LED_Task_Id  = osThreadNew(RTOS_LED_Task, 	NULL, &LED_Task_Attr);  	//	LED����

	osKernelStart();	// ����ϵͳ
	
	while(1);	
}



/***************************************************************************************************
*	�� �� ��: RTOS_Main_Task
*
*	��������: ���������ȼ����
*
*	˵    ��: ��
****************************************************************************************************/

void RTOS_Main_Task(void *argument)
{
	(void)argument;
	
 	DAP_Setup();          	// DAP Setup

	daplink_winusb_init();
	
    while (!usb_device_is_configured()) {

    }	 
	 
	
	DAP_ThreadId = osThreadNew(DAP_Thread, NULL, NULL);	// ����DAP�̣߳����ڴ���DAP�����¼�

	osDelay(osWaitForever);	// ���ٻص��������
	for (;;) {}
}

/***************************************************************************************************
*	�� �� ��: RTOS_Msg_Task
*
*	��������: ��Ϣ��������
*
*	˵    ��: ��
****************************************************************************************************/

void RTOS_Msg_Task(void *argument)
{
	(void)argument;

	printf("RTOS �������\r\n");

	while(1)
	{
		osDelay(50);
	}
}

/***************************************************************************************************
*	�� �� ��: RTOS_LED_Task
*
*	��������: ��������������ȼ����
*
*	˵    ��: ��
****************************************************************************************************/

void RTOS_LED_Task(void *argument)
{
	(void)argument;
	
	while(1)
	{
		LED1_Toggle;	// LED1 ״̬��ת
		osDelay(100);	// ��ʱ
	}
}



/****************************************************************************************************/
/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (HSE)
  *            SYSCLK(Hz)                     = 480000000 (CPU Clock)
  *            HCLK(Hz)                       = 240000000 (AXI and AHBs Clock)
  *            AHB Prescaler                  = 2
  *            D1 APB3 Prescaler              = 2 (APB3 Clock  120MHz)
  *            D2 APB1 Prescaler              = 2 (APB1 Clock  120MHz)
  *            D2 APB2 Prescaler              = 2 (APB2 Clock  120MHz)
  *            D3 APB4 Prescaler              = 2 (APB4 Clock  120MHz)
  *            HSE Frequency(Hz)              = 25000000
  *            PLL_M                          = 5
  *            PLL_N                          = 192
  *            PLL_P                          = 2
  *            PLL_Q                          = 4
  *            PLL_R                          = 2
  *            VDD(V)                         = 3.3
  *            Flash Latency(WS)              = 4
  * @param  None
  * @retval None
  */
  
  
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Supply configuration update enable 
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);
  /** Configure the main internal regulator output voltage 
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI48|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSI48State = RCC_HSI48_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 5;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_2;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInitStruct.UsbClockSelection = RCC_USBCLKSOURCE_HSI48;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Enable USB Voltage detector 
  */
  HAL_PWREx_EnableUSBVoltageDetector();
}

//	����MPU
//
void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct;
  
  HAL_MPU_Disable(); // ����֮ǰ�Ƚ�ֹMPU

  MPU_InitStruct.Enable 				= MPU_REGION_ENABLE;
  MPU_InitStruct.BaseAddress 			= 0x24070000;
  MPU_InitStruct.Size 					= MPU_REGION_SIZE_64KB;
  MPU_InitStruct.AccessPermission 	= MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.IsBufferable 		= MPU_ACCESS_NOT_BUFFERABLE;
  MPU_InitStruct.IsCacheable 			= MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsShareable 			= MPU_ACCESS_NOT_SHAREABLE;
  MPU_InitStruct.Number 				= MPU_REGION_NUMBER0;
  MPU_InitStruct.TypeExtField 		= MPU_TEX_LEVEL1;
  MPU_InitStruct.SubRegionDisable 	= 0x00;
  MPU_InitStruct.DisableExec 			= MPU_INSTRUCTION_ACCESS_DISABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);	// ʹ��MCU
}



/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/


