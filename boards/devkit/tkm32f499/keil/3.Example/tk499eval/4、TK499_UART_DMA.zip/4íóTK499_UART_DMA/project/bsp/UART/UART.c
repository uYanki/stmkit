#include "UART.h"

//����DMA���յ����ݺ�ı�ǣ���DMA���ж��︳ֵ��Ȼ�����Ϳ��Ը�����������жϴ���
unsigned char dma3Flag=0;
unsigned char dma8Flag=0;

//����һ�����飬������DMA����������������
unsigned char uart_tx_buf[32]={'H','a','p','p','y',' ','n','e','w',' ','y','e','a','r','!'};
unsigned char uart_rx_buf[32];

void DMA2_Channel3_IRQHandler() //rx
{
	if(DMA_GetITStatus(DMA2_IT_TC3))
  {
    DMA_ClearITPendingBit(DMA2_IT_TC3);
    dma3Flag = 0x1;
  }
}

void DMA2_Channel8_IRQHandler() //tx
{
	if(DMA_GetITStatus(DMA2_IT_TC8))
		{
			DMA_ClearITPendingBit(DMA2_IT_TC8);
			
			DMA_Cmd(DMA2_Channel8, DISABLE);//����꣬��DMA
			UART_DMACmd(UART1, UART_DMAReq_EN, DISABLE);   //disable DMA 
			dma8Flag = 0x1;
		}
}
void outbyte(void)
{
	DMA_InitTypeDef DMA_InitStructure;
//	*((volatile unsigned char*)0x70600000) = c;
	
  UART_DMACmd(UART1, UART_DMAReq_EN, ENABLE);   //DMA ʹ��
	
	DMA_DeInit(DMA2_Channel8);
	
	DMA_InitStructure.DMA_PeripheralBaseAddr = UART1_BASE;//����������ȥ�Ļ�ַ
  DMA_InitStructure.DMA_MemoryBaseAddr = (u32)&uart_tx_buf;//Ҫ�������ݵ������ַ
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
  DMA_InitStructure.DMA_BufferSize = 15;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte; //DMA_PeripheralDataSize_Byte;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	
	DMA_Init(DMA2_Channel8, &DMA_InitStructure);
	DMA_Cmd(DMA2_Channel8, ENABLE);
}


void  inbyte()
{
	DMA_InitTypeDef DMA_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	DMA_DeInit(DMA2_Channel1);
	
	NVIC_InitStructure.NVIC_IRQChannel = DMA2_Channel3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	DMA_ITConfig(DMA2_Channel3, DMA_IT_TC, ENABLE);				
	dma3Flag = 0x0;
		
	UART_DMACmd(UART1, UART_DMAReq_EN, ENABLE);   //DMA ʹ��

	
	DMA_InitStructure.DMA_PeripheralBaseAddr = (UART1_BASE + 0x04);
  DMA_InitStructure.DMA_MemoryBaseAddr =  (u32)&uart_rx_buf;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
  DMA_InitStructure.DMA_BufferSize = 10;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte; 
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_Low;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_Init(DMA2_Channel3, &DMA_InitStructure);
	
	DMA_Init(DMA2_Channel3, &DMA_InitStructure);
	DMA_Cmd(DMA2_Channel3, ENABLE);
	
	//DMAcheckStatus(DMA1_FLAG_TC6);
	while(1)
	{
		if(dma3Flag)
		{
			dma3Flag = 0x0;
			break;
		}
	}
	DMA_Cmd(DMA2_Channel3, DISABLE);
	UART_DMACmd(UART1, UART_DMAReq_EN, DISABLE);   //disable DMA 
}


void Uart1DMARxTest(void)
{
	inbyte();
	uart_rx_buf[10]=0;//�ض����飬��ֹδ��ʼ���������Ա����ӡ
	printf("\r\n");
	printf("%s",uart_rx_buf);				
}

void UartInit(UART_TypeDef* UARTx,int BaudRate)
{
	UART_InitTypeDef       UART_InitStructure;  
	GPIO_InitTypeDef  GPIO_InitStructure;   
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
	
	GPIO_PinAFConfig(GPIOA, GPIO_Pin_9 | GPIO_Pin_10, GPIO_AF_UART_1); //PA9��PA10����Ϊ����1	
	UART_DMACmd(UARTx, UART_DMAReq_EN, ENABLE);  //UART1_GCR = UART1_GCR | 0x0002;//dma mode

	UART_InitStructure.UART_BaudRate = BaudRate; //������
  UART_InitStructure.UART_WordLength = UART_WordLength_8b;//����λ
  UART_InitStructure.UART_StopBits = UART_StopBits_1;//ֹͣλ
  UART_InitStructure.UART_Parity = UART_Parity_No ;
  UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;//�������ģʽ
  UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None; 	
	UART_Init(UARTx, &UART_InitStructure);
	UART_Cmd(UARTx, ENABLE);  //UART ģ��ʹ��

  UART_ClearITPendingBit(UARTx, 0xff); 
	
	//ע���ʼ��˳���������򿪣��������ַ���ӡ����
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9;   //uart1_tx  pa9
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // ���⸴�����
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10;  //uart1_rx  pa10
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //��������   
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}
u8 Uart1_Receive(void)
{
	//�ж������Ƿ���
  while((UART1->CSR & (1<<1)) ==0);
	return UART1->RDR;

}

void send_data(u8 data)
{
	while((UART1->CSR &0x1) == 0);
	UART1->TDR = data; 
}
void send_group(u8*data,u16 len)
{
	while(len--)
	send_data(*data++);
}
void send_str(char *p)
{
		while(*p != '\0')
		{
			send_data(*p);
			p++;
		}
}

//�������д��룬���ù�ѡUSE microlib,ʹ��printf

#pragma import(__use_no_semihosting)                          
struct __FILE 
{ 
int handle; 
}; 
FILE __stdout;       
void _sys_exit(int x) 
{ 
x = x; 
} 
int fputc(int ch, FILE *f)
{      
while((UART1->CSR &0x1) == 0){}
	UART1->TDR = (u8) ch;      
return ch;
}


