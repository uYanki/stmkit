#ifndef __EXIT_H
#define __EXIT_H

#include "HAL_conf.h"

void EXIT_KEY_Init(void);

#endif
