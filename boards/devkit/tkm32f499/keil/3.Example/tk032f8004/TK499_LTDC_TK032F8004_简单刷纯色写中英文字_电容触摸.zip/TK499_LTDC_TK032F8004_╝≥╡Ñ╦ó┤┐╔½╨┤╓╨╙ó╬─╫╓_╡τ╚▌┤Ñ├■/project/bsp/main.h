#ifndef __MAIN_H
#define	__MAIN_H

#include "HAL_conf.h"
#include "led.h"
#include "sys.h"
#include "spi.h"
#include "timer.h"


void delay_ms(u16 time);

#endif


