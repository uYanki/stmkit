#ifndef _TK499_TIME_H_
#define _TK499_TIME_H_

#include "tk499.h"
#include "HAL_conf.h"
#include "main.h"
void TIM8_Config(u16 arr,u16 psc);
void delay_nms(u16 time);

#endif


