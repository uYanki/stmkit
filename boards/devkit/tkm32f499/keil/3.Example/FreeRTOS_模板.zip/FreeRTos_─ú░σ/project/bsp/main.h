#ifndef _MAIN_H_
#define _MAIN_H_

#include "tk499.h"
#include "GPIO.h"
#include "sys.h"
#include "TK499_timer.h"
#include "UART.h"

#include "stdio.h"
#include "stdarg.h"
#include "stdlib.h"
#include "math.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "croutine.h"
#endif


