
#ifndef   MP3PLAYER_H
#define   MP3PLAYER_H

#include "stm32f10x.h"

u8 Mp3Player_Init(void);

void SetBands(void);


#endif


