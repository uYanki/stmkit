
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'LKS08x_FOC_Open_HallSense' 
 * Target:  'LKS08x_FOC_Open_HallSense' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "lks32mc08x.h"



#endif /* RTE_COMPONENTS_H */
