#ifndef __GLOBAL_VARIABLE__
#define __GLOBAL_VARIABLE__

#include "mc_type.h"
#include "config.h"
#include "smo.h"
extern stru_FOC_CtrProcDef struFOC_CtrProc; /* FOC�����ڻ��ṹ�� */

void Hardware_init(void);
void sys_init(void);
void Task_Scheduler(void);
void DSP_Init(void);
void ADC_init(void);
void MCPWM_init(void);
void UTimer_init(void);
void GPIO_init(void);
void PGA_init(void);
void ADC_NormalModeCFG(void);
void FOC_Model(stru_FOC_CtrProcDef *pCtrProc);
void StopMotorImmdly(stru_FOC_CtrProcDef *this);
void SetTime_TimeOut_Counter(u16 hTimeout);
void Sys_State_Run(stru_FOC_CtrProcDef *this);
void MCPWM0_RegUpdate(stru_VoltPhaseUVW VoltPhaseUVW);
void MCL_Init(stru_FOC_CtrProcDef *pCtrProc);
void Curr_rc_fir(Stru_Curr_RC *this);
void currentOffsetRead(void);
void FOC_InitstruParama(stru_FOC_CtrProcDef *this);
void Sys_State_Machine(stru_FOC_CtrProcDef *this);
void Key_in(stru_FOC_CtrProcDef *this);
s16 CORDIC_atan2(s16 x, s16 y);

stru_VoltVoctorDQ RevPark_Circle_Limitation(stru_VoltVoctorDQ VoltVoctorDQ);
stru_VoltPhaseUVW SVPWM(stru_VoltAlphBeta, u16 hPWM_PERIOD);
stru_CurrAlphBeta Clarke(stru_CurrPhaseUVW uvw);
stru_CurrVoctorDQ Park(stru_CurrAlphBeta ab, stru_TrigComponents TrigComponents);
stru_VoltAlphBeta Rev_Park(stru_VoltVoctorDQ dq, stru_TrigComponents TrigComponents);
stru_TrigComponents Trig_Functions(s16 hAngle);
#endif

/* ********************** (C) COPYRIGHT LINKO SEMICONDUCTOR ******************** */
/* ------------------------------END OF FILE------------------------------------ */
