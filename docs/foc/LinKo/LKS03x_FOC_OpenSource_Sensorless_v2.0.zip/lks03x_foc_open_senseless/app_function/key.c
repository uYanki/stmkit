#include "global_variable.h"
void Key_in(stru_FOC_CtrProcDef *this)
{
    if (GPIO_ReadInputDataBit(GPIO_STOP) == 0)
    {
        this->bMC_RunFlg = 0;
    }
    else if (GPIO_ReadInputDataBit(GPIO_START) == 0)
    {
        this->bMC_RunFlg = 1;
    }
}
