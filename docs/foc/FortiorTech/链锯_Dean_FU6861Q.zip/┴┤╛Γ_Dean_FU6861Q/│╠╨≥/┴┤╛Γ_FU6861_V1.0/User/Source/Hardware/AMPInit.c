/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AMPInit.c
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 01/04/2017
* Description        : This file contains AMP initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>

/*-------------------------------------------------------------------------------------------------
	Function Name :	void AMP_Init(void)
	Description   :	AMP初始化配置,使能运放电压VHALF，配置运放的电流采样正向输入，反向输入和输出，包括I_BUS,I_U,I_V
	                并使能对应的运放
	Input         :	无
  Output				:	无
-------------------------------------------------------------------------------------------------*/
void AMP_Init(void)
{
	/**使能VHALF电压**/
	SetBit(VREF_VHALF_CR, VHALFEN);												// 使能VHALF

  SetBit(P3_AN, P32);                           // AMP0--I_BUS   

	
  /*AMP管脚配置*/
 	SetBit(P2_AN, P27);            
	SetBit(P3_AN, P30|P31);                           // AMP0--I_BUS   
  SetBit(AMP_CR, AMP0EN);
	
}