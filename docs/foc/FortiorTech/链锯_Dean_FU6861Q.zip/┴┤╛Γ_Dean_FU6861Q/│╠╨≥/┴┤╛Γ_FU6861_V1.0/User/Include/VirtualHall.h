/******************** (C) COPYRIGHT 2018 Fortiortech shenzhen******************
* File Name          : VirtualHall.c
* Author             : Fortiortech  Appliction Team Alex.He
* Version            : V1.0
* Date               : 2018-6-13
* Description        : This file contains rotor position detection used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __VIRTUALHALL_H_
#define __VIRTUALHALL_H_

typedef struct
{
  int16 VirtlHall_KF_Data;                             
  int16 VirtlHall_KR_Data;                

  uint16 VirtlHallSignal_ChangeCount_Data;       
  int16 VirtlHallSignal_ForwardValue_Data;    

  uint16 MOTOR_BLDC2FOC_COUNT_Data;          
  uint16 MOTOR_FOC2BLDC_COUNT_Data;          

  uint16 MOTOR_SPEED_BLDC2FOC_RPM_Data;     
  uint16 MOTOR_SPEED_FOC2BLDC_RPM_Data;   
  
	uint16 MOTOR_MIN_Duty;
	
  uint16 PhaseLossDetect_Data;  

  uint16 OVER_PROTECT_Data;	
	uint16 UNDER_PROTECT_Data;	  
	
}VirlHallTypeDef;

extern VirlHallTypeDef xdata VirlHal;
extern uint8  xdata  Motor_Bldc2Foc_Sector;
extern int16  xdata  VirtlHall_Signal;

extern uint16 xdata  TIM1_BLDCCountAll_Flag,TIM1_CW_BLDCCount;
extern uint8  xdata  PhaseLossDetect_Flag;


extern void Motor_BLDC_Init(VirlHallTypeDef *VIRHAL);
extern void VirtlHall_Drv(VirlHallTypeDef *VIRHAL);


#endif