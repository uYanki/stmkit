/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Interrupt.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the interrupt function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <Interrupt.h>
#include <FU68xx_2.h>
#include <Myproject.h>

uint16 xdata  MAX_BLDC_VH_Duty_Load;
uint16 xdata  Speedperiod1,Speedperiod2;
uint16 xdata  Power_Currt1,Power_Currt2,Power_Currt_temp1,Power_Currt3;
uint8  xdata  I_Limt_Flag;
uint8  xdata   BLDCStallCount;
uint8  xdata   BLDCStallFlag ;
uint16 xdata   Speedperiodx[16] = {0};
uint8  xdata  heihei = 0;

extern uint8  xdata Motor_Direction;
uint16 Pdelay_time = 0;

/*-------------------------------------------------------------------------------------------------
    Function Name : void CMP_ISR(void)
    Description   : CMP3：硬件比较器过流保护，关断输出，中断优先级最高
										CMP0/1/2：顺逆风判断
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void CMP_ISR(void) interrupt 7
{
    if(ReadBit(CMP_SR, CMP3IF))
    {
				FaultProcess();                                                       // 关闭输出
				mcFaultSource = FaultHardOVCurrent;                                   // 硬件过流保护
        
			  if(McStaSet.SetFlag.BLDCSetFlag == 1)		
				{
				  ClrBit(DRV_SR, DCIM1); 
					ClrBit(DRV_SR, DCIM0);
					SetBit(DRV_SR, SYSTIE);		                     // Ê¹ÄÜ1ms¶¨Ê±ÖÐ¶Ï

          McStaSet.SetFlag.BLDCSetFlag = 2;
				}	
				
				ONOFFTest.PowerOFF_Count = 8000;			
				mcState = mcFault;                                                    // 状态为mcFault                                                     

        ClrBit(CMP_SR, CMP3IF);
    }

}


/*---------------------------------------------------------------------------*/
/* Name     :   void Drv_INT(void) interrupt 3
/* Input    :   NO
/* Output   :   NO
/* Description: Drv中断,每两个载波周期执行一次，用于处理响应较高的程序，中断优先级第二。DCEN开了就会产生中断。
/*---------------------------------------------------------------------------*/
void Drv_INT(void) interrupt 3
{
    if(ReadBit(DRV_SR, DCIF))                                 // 比较中断
    {
		  	
      VirtlHall_Drv(&VirlHal);
		  SetBit(ADC_CR, ADCBSY);          //使能ADC的DCBUS采样  会于BLDC采样冲突
      
			if((McStaSet.SetFlag.BLDCSetFlag == 3)||(McStaSet.SetFlag.BLDCSetFlag == 4))
			{
				 mcSpeedRamp.DelayPeriod++;
         mcSpeedRamp.DelayCurrtlimit++;
				
         
					Power_Currt2   = (TIM1__ITRIP > mcCurOffset.Iw_busOffset)?(TIM1__ITRIP - mcCurOffset.Iw_busOffset):(0);
          
 			    if(Power_Currt2 > I_Limt_Max)
					{
						I_Limt_Flag = 1;
            if(DRV_DR > MIN_BLDC_Duty)
						{
							DRV_DR -= 2;
//              if (DRV_DR < HIGH_BLDC_Duty)
//              {
//                DRV_DR  = HIGH_BLDC_Duty;
//              }
						}					
            
					}
         if ((mcSpeedRamp.DelayCurrtlimit >= 5) && (McStaSet.SetFlag.BLDCSetFlag == 4))
         {
            mcSpeedRamp.DelayCurrtlimit = 0;
            Power_Currt_temp1 = (ADC3_DR<<3);
			
					  Power_Currt1   = (Power_Currt_temp1 > mcCurOffset.Iw_busOffset)?(Power_Currt_temp1 - mcCurOffset.Iw_busOffset):(0);

					
            if(Power_Currt2 <= I_Limt_Max)	
            {													
               if(Power_Currt1 > I_LimtValue_Up)
               {
                  I_Limt_Flag = 1;		
                 GP01 = 0;
               }
               else if(Power_Currt1 < I_LimtValue_Dw) 
               {
                 I_Limt_Flag = 0;
                 GP01 = 1;
               }
               
               if(I_Limt_Flag == 1)
               {
                  if(Power_Currt1 < I_LimtValue_Out)
                  {
                    if(DRV_DR < (mcSpeedRamp.BLDC_Value-2))
                    {
                      DRV_DR   = DRV_DR + 2;
                    }
                    else
                    {
                      DRV_DR   = mcSpeedRamp.BLDC_Value;
                    }
                  }
                  else if(Power_Currt1 > I_LimtValue_Out)
                  {
                    if(DRV_DR > (375 + 3))
                    {
                      DRV_DR   = DRV_DR - 3;
                    }
                    else
                    {
                      DRV_DR   = 375;
                    }
                  }	
               }
               
             }
         }
				
			   if(mcSpeedRamp.DelayPeriod >= Motor_Duty_Count)
				 {
					 mcSpeedRamp.DelayPeriod = 0;
	
					 if(TIM1_BLDCCountAll_Flag == 0 ) {MAX_BLDC_VH_Duty_Load = MAX_BLDC_VH_Duty_0;}
					 if(TIM1_BLDCCountAll_Flag == 1 ) {MAX_BLDC_VH_Duty_Load = MAX_BLDC_VH_Duty_1;}
					 if(TIM1_BLDCCountAll_Flag == 2 ) {MAX_BLDC_VH_Duty_Load = MAX_BLDC_VH_Duty_2;}
								
					 
		     if(I_Limt_Flag == 0)
				 {
					 if(McStaSet.SetFlag.BLDCSetFlag == 4)
					 {
							 if(mcSpeedRamp.BLDC_Value > DRV_DR )
							 {
								 DRV_DR = DRV_DR + 1;
							 }
							 else if(mcSpeedRamp.BLDC_Value  < DRV_DR )
							 {
								 DRV_DR = DRV_DR - 1;
							 }
							 else
							 {
								 DRV_DR = mcSpeedRamp.BLDC_Value;
							 }						 
						}
					 else if(McStaSet.SetFlag.BLDCSetFlag == 3)
					 {
						 if(DRV_DR < MAX_BLDC_VH_Duty_Load)
						 {
							 if(mcSpeedRamp.BLDC_Value > (DRV_DR - 1 ))
							 {
								 DRV_DR = DRV_DR + 1;
							 }
							 else if(mcSpeedRamp.BLDC_Value  < (DRV_DR+1))
							 {
								 DRV_DR = DRV_DR - 1;
							 }
							 else
							 {
								 DRV_DR = mcSpeedRamp.BLDC_Value;
							 }							 
						 }
						 else	
						 {				 				 
							 if(MAX_BLDC_VH_Duty_Load < DRV_DR)
							 {
								 DRV_DR = DRV_DR - 1;
							 }
							 else
							 {
								 DRV_DR = MAX_BLDC_VH_Duty_Load;
							 }
						 }	
					  }			
			    }
					
			   }
			 }
			 
			   if(McStaSet.SetFlag.BLDCSetFlag == 3)
				 {
						if(TIM1_CR4 ==5 ) spidebug[0] = AL_THT(90);
						if(TIM1_CR4 ==6 ) spidebug[0] = AL_THT(150);
						if(TIM1_CR4 ==1 ) spidebug[0] = AL_THT(210);
						if(TIM1_CR4 ==2 ) spidebug[0] = AL_THT(270);
						if(TIM1_CR4 ==3 ) spidebug[0] = AL_THT(330);
						if(TIM1_CR4 ==4 ) spidebug[0] = AL_THT(30);
					 				 
				}		

		 GP01 = 0;
			
			}
      ClrBit(DRV_SR, DCIF);
}
		

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM4_1ms_INT(void) interrupt 10
/* Input    :   NO
/* Output   :   NO
/* Description: 1ms定时器中断（SYS TICK中断），用于处理附加功能，如控制环路响应、各种保护等。中断优先级低于FO中断和FOC中断。
/*---------------------------------------------------------------------------*/
void TIM4_1ms_INT(void) interrupt 10
{
    if(ReadBit(DRV_SR, SYSTIF))          // SYS TICK中断
    {
			  SetBit(ADC_CR, ADCBSY);          //使能ADC的DCBUS采样  会于BLDC采样冲突
        Speedperiod1 = TIM1_BCOR;
        Speedperiod2 = TIM1__BCCR;
        if ((Speedperiod1 < 600) && (Power_Currt1 > 900) && (Speedperiod2 < 600) && (McStaSet.SetFlag.BLDCSetFlag == 4))
        {
          BLDCStallFlag = 0;				    
          mcFaultSource = FaultStall;
          FaultProcess();	
        }
        
				Power_Currt_temp1 = (ADC3_DR<<3);
			
			  Power_Currt1   = (Power_Currt_temp1 > mcCurOffset.Iw_busOffset)?(Power_Currt_temp1 - mcCurOffset.Iw_busOffset):(0);
        
        if ((Speedperiod1 > 4000) && (McStaSet.SetFlag.BLDCSetFlag == 4) && (Speedperiod2 > 4000) && (Power_Currt1 > 1000))
        {
          BLDCStallFlag = 0;				    
          mcFaultSource = FaultStall;
          FaultProcess();	
        }
						 
			  VSP= ADC7_DR<<3;//低通滤波
					 
			  VSPSample();			 	 				

        /*****DCbus的采样获取值并滤波******/
        mcFocCtrl.mcDcbusFlt = LPFFunction(ADC2_DR<<3,mcFocCtrl.mcDcbusFlt,10);
					 
				/*****温度的采样获取值并滤波******/
				mcFocCtrl.mctemperature = LPFFunction(ADC6_DR<<3,mcFocCtrl.mctemperature,10);
        /*****故障保护函数功能，如过欠压保护、启动保护、缺相、堵转等********/
        Fault_Detection();
				
        LED_Display();//LED灯显示

        /*****电机状态机的时序处理*****/
        if(mcFocCtrl.State_Count > 0)      mcFocCtrl.State_Count--;
				
				if(mcSpeedRamp.FlagONOFF  == 1)
				 {
						Pdelay_time = 0;
				 }
				else if(mcSpeedRamp.FlagONOFF  == 0)
				 { 
					 Pdelay_time++;			            //断电延时时间自加
				if(Pdelay_time >= PDELAY_Vaule)
					{						
						Pdelay_time = PDELAY_Vaule;
						Pdelay_OFF;	                //Pdelay延时掉电
					}	
				else
					{
						Pdelay_ON;	                //Pdelay延时掉电
					}
				 }	
				 
				if(ONOFFTest.PowerOFF_Count > 0)
				{
					ONOFFTest.PowerOFF_Count--;
				}
				else if((mcState == mcStop)||(mcState == mcFault))
				{
					mcFaultDect.OverCurrentCnt =0;              //一级过流计数时间清零
					mcFaultDect.OverCurrentCnt1 =0;             //二级过流计数时间清零
					mcFaultDect.OverCurrentCnt2 =0;             //三级过流计数时间清零
				}
			
				#if (StallProtect == Enable)         
        {				
					if(TIM1_CW_BLDCCount > Motor_Stall_Count)
					{
						if(BLDCStallCount < 20)
						{
						 BLDCStallCount++;
						}
						else
						{
							BLDCStallFlag = 1;
						}
					}
					else
					{
						BLDCStallFlag = 0;
						BLDCStallCount = 0;
					}
			  }
		    #endif
        /*****电机启动爬坡函数处理*****/
        StarRampDealwith();
				
//        #if (StartONOFF == Enable)
//				{
//          ONOFF_StartTest(&ONOFFTest);
//				}
//        #endif

        ClrBit(DRV_SR, SYSTIF);                                    // 清零标志位
    }
}








/* Private variables ----------------------------------------------------------------------------*/
void INT0(void) interrupt 0
{
}

/*-------------------------------------------------------------------------------------------------
    Function Name : void FO_INT(void)
    Description   : FO_INT interrupt，硬件FO过流保护，关断输出，中断优先级最高
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void FO_INT(void) interrupt 1                                                   // 硬件FO过流中断，关闭输出
{
//    FaultProcess();                                                             // 关闭输出
//    mcFaultSource = FaultHardOVCurrent;                                         // 硬件过流保护
//    mcState       = mcFault;                                                    // 状态为mcFault
//    IF0           = 0;                                                          // clear P00 interrupt flag
}
/*---------------------------------------------------------------------------*/
/* Name     :   void EXTERN_INT(void) interrupt 2
/* Input    :   NO
/* Output   :   NO
/* Description: 睡眠唤醒
/*---------------------------------------------------------------------------*/
void EXTERN_INT(void) interrupt 2
{
    if(SleepSet.SleepFlag)
    {
        SleepSet.SleepFlag = 0;
        SleepSet.SleepEn   = 1;
    }

    ClrBit(P1_IF, P11);                    // 清零P10标志位
}
/*---------------------------------------------------------------------------*/
/* Name     :   void TIM2_INT(void) interrupt 4
/* Input    :   NO
/* Output   :   NO
/* Description:	正反转检测(RSD)
/*---------------------------------------------------------------------------*/
void TIM2_INT(void) interrupt 4
{
//    if(ReadBit(TIM2_CR1, T2IR))
//    {
//			ClrBit(TIM2_CR1, T2IR);
//    }
//    if(ReadBit(TIM2_CR1, T2IP))
//    {
//			#if (TailWind_Mode == TailWind_RSD_Method)
//			{
//				RSDFRDetect();//RSD正反转检测
//			}
//			#endif

//			ClrBit(TIM2_CR1, T2IP);
//    }
//    if(ReadBit(TIM2_CR1, T2IF))//溢出中断,用于判断静止,时间为349ms。
//    {
//        #if (TailWind_Mode == TailWind_RSD_Method)
//			  {
//					RSDDetect.RSDState=Static;
//					RSDDetect.RSDFlag=1;
//				}
//        #endif

//        ClrBit(TIM2_CR1, T2IF);
//    }
}

void TIM1_INT(void) interrupt 5
{
//  if(ReadBit(TIM1_SR,T1PDIF))     //CMP/HALL Î»ÖÃ¼ì²â ÖÐ¶Ï    
//  {
//    ClrBit(TIM1_SR,T1PDIF);       //CLRFlag_PDIF;

//    Speedperiod1 = TIM1_BCOR;
//    
//    Speedperiodx[heihei] = Speedperiod1;
//    
//    heihei = heihei + 1;
//    
//    if (heihei >= 16)
//    {
//      heihei = 0;
//    }
//    
//  }
}
void INT6(void) interrupt 6
{
}
void INT8(void) interrupt 8
{
}

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM23_INT(void) interrupt 9
/* Input    :   NO
/* Output   :   NO
/* Description: Capture PWM ，中断优先级第二，高于FOC中断，用于PWM调速
/*---------------------------------------------------------------------------*/
void TIM3_INT(void) interrupt 9
{
//    if(ReadBit(TIM3_CR1, T3IR))
//    {
//			ClrBit(TIM3_CR1, T3IR);
//    }
//    if(ReadBit(TIM3_CR1, T3IP))//周期中断
//    {
//        if(mcPwmInput.PWMFlag != 1)//若正在计算占空比则不更新
//        {
//					mcPwmInput.PWMCompare    = TIM3__DR;
//					mcPwmInput.PWMARR        = TIM3__ARR;
//					mcPwmInput.PWMUpdateFlag = 1;
//        }

//        ClrBit(TIM3_CR1, T3IP);
//    }
//    if(ReadBit(TIM3_CR1, T3IF))
//    {
//        if(GP11 == 1)//PWM 100%输出
//        {
//					mcPwmInput.PWMCompare = 8000;
//					mcPwmInput.PWMARR     = 8000;
//        }
//        else//PWM 为0%
//        {
//					mcPwmInput.PWMCompare = 0;
//					mcPwmInput.PWMARR     = 8000;
//        }
//        mcPwmInput.PWMUpdateFlag =1;

//        ClrBit(TIM3_CR1, T3IF);
//    }
}

void INT11(void) interrupt 11
{
}

/*---------------------------------------------------------------------------*/
/* Name     :   void USART_INT(void) interrupt 12
/* Input    :   NO
/* Output   :   NO
/* Description: 串口中断，中断优先级最低，用于接收调速信号,无中断插入时8us
/*---------------------------------------------------------------------------*/
void USART_INT(void)  interrupt 12
{
    if(RI == 1)
    {
        RI = 0;
//        Uart.Uredata= UT_DR;            //读接收数据
    }
}


void INT13(void) interrupt 13
{
}
void INT14(void) interrupt 14
{
}
void INT15(void) interrupt 15
{
}


