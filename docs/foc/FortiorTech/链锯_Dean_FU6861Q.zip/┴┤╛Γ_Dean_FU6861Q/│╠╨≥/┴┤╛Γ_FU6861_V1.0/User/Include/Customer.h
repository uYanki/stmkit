/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Customer.h
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-21
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __CUSTOMER_H_
#define __CUSTOMER_H_

/*芯片参数值-------------------------------------------------------------------*/
 /*CPU and PWM Parameter*/
 #define MCU_CLOCK                      (24.0)                                  // (MHz) 主频
 #define PWM_FREQUENCY_BLDC             (14.0)                                  // (kHz) 载波频率

 /*deadtime Parameter*/
 #define PWM_DEADTIME                   (0.0)                                   // (us) 死区时间

 /*single resistor sample Parameter*/
 #define MIN_WIND_TIME                  (PWM_DEADTIME + 0.8)                                   // (us) 单电阻最小采样窗口，建议值死区时间+0.9us

/*电机参数值-------------------------------------------------------------------*/// 未知名电机
 #define Pole_Pairs                     (5.0)                                     // 极对数
 
/*硬件板子参数设置值------------------------------------------------------------*/
/*PWM high or low level Mode*/
/*根据驱动芯片的类型选择*/
#define All_High_Level                 (0)                                     // 驱动高电平有效
#define All_Low_Level                  (1)                                     // 驱动低电平有效
#define UP_H_DOWN_L                    (2)                                     // 上桥臂高电平有效，下桥臂低电平有效
#define UP_L_DOWN_H                    (3)                                     // 上桥臂低电平有效，下桥臂高电平有效
#define PWM_Level_Mode                 (UP_H_DOWN_L)

/*hardware current sample Parameter*/
/*电流基准的电路参数*/

#define HW_RSHUNT                      (0.001)                                 // (Ω)  采样电阻
#define HW_AMPGAIN                     (7.5)                                    // 运放放大倍数
#define HW_ADC_REF                     (4.5)                                   // (V)  ADC参考电压

/*hardware voltage sample Parameter*/
/*母线电压采样分压电路参数*/
#define RV1                            (0.0)                                  // (kΩ) 母线电压分压电阻1
#define RV2                            (30.0)                                   // (kΩ) 母线电压分压电阻2
#define RV3                            (5.1)                                   // (kΩ) 母线电压分压电阻3
#define RV                             ((RV1 + RV2 + RV3) / RV3)               // 分压比

/***************VirtlHall*******************************/
#define VirtlHall_KF                   _Q15(0.40)      //虚拟霍尔信号正转下降阈值                    
#define VirtlHall_KR                   _Q15(0.71)     //虚拟霍尔信号正转上升阈值    上升沿/下降沿对称度
#define VirtlHallSignal_ForwardValue   (int16)(1)   //虚拟霍尔信号正转切换阈值  8.0V 2000 12.0V 4000 

#define VirtlHallSignal_ChangeCount    (uint16)(75)    //反转检测脉冲注入的间隔数
 
#define MOTOR_BLDC2FOC_COUNT           (uint16)(6)     //低速切高速维持拍数
#define MOTOR_FOC2BLDC_COUNT           (uint16)(6)     //高速切低速维持拍数

#define MOTOR_SPEED_BLDC2FOC_RPM       (500.0)        //低速无感方波大力矩切高速无感BLDC的速度，单位RPM
#define MOTOR_SPEED_FOC2BLDC_RPM       (300.0)        //高速无感BLDC切低速无感方波大力矩的速度，单位RPM

#define Motor_Duty_Count               (uint16)(20)      //Duty增减响应的载波间隔个数

#define Min_BLDC_Duty                  (0.15)            //VSP起  始最小Duty
#define Max_BLDC_VH_Duty_0             (0.350)            //速度在0到(MOTOR_SPEED_BLDC2FOC_RPM/3)区间的最大Duty
#define Max_BLDC_VH_Duty_1             (0.375)            //速度在(MOTOR_SPEED_BLDC2FOC_RPM/3)到(2*MOTOR_SPEED_BLDC2FOC_RPM/3)区间的最大Duty
#define Max_BLDC_VH_Duty_2             (0.400)            //速度在(2*MOTOR_SPEED_BLDC2FOC_RPM/3)到MOTOR_SPEED_BLDC2FOC_RPM区间的最大Duty
#define Max_BLDC_Duty                  (1.00)            //VSP终点最大Duty

#define Max_BLDC_High_Duty             (0.50)           //超前角和屏蔽续流角高速区间生效Duty阈值
#define Max_BLDC_Low_Duty              (0.45)           //超前角和屏蔽续流角低速区间生效Duty阈值

#define I_Limt_Max		                 I_Limt_MaxValue(80.0)	//母线电流峰值限制值												

#define LimtCurt_K                     (float)(54.0)    //硬件母线电流RC滤波系数，R=10K C=1.0uF    RS = 0.001Ω  
#define I_LimtValue_Up							   I_LimtValue1(52.0) //母线电流限流区间触发值 60												  
#define I_LimtValue_Out							   I_LimtValue1(50.0) //母线电流限流区间稳定值 59														 
#define I_LimtValue_Dw							   I_LimtValue1(48.0) //母线电流限流区间退出值 50
 

 /*堵转保护*/
 #define StallProtect                   (Enable)         // 堵转保护：Enable--使能  Disable--禁止  
 #define MOTOR_STALL_COUNT              (100.0)         // 堵转检测时间, 单位毫秒：ms  最大65535/PWM_FREQUENCY_BLDC  

 /*缺相保护*/
 #define PhaseLossProtect               (Enable)        // 缺相保护：Enable--使能  Disable--禁止  
 #define PhaseLossDetectValue           (uint16)(5000)   // ADCX_DR<<3 缺相电压检测判断阈值

 
/*启动参数参数值----------------------------------------------------------------*/
 #define Charge_Time                    (6)                                     // (ms) 预充电时间，单位：ms
 #define Charge_Duty                    (0.5)                                    // 预充电下桥Duty

/******* 初始位置检查参数 **********/
 #define PosCheckMode                   (Disable)                               // Enable-禁止初始位置检测，Disable-禁止初始位置检测    

/*脉冲注入时间长于2ms 或 低于2ms*/
 #define Long_Inject                    (0)                                     // 脉冲注入时间长于2ms,若时间长于4ms，则要修改定时器分频
 #define Short_Inject                   (1)                                     // 脉冲注入时间低于2ms
 #define InjectTime                     (Short_Inject)

 #define RPD_Time                       (20)                                     // (ms) 每次RPD的间隔时间
 #define RPD_CurValue                   (10.0)                                   // (A)  RPD过流值
 #define DAC_RPDCurValue                _Q7(I_ValueX(RPD_CurValue*2.0))


/*转速参数值-------------------------------------------------------------------*/
 #define MOTOR_SPEED_BASE               (30000.0)                                // (RPM) 速度基准

 /* motor run speed value */
 //电机运行时最大最小转速、堵转保护转速
 #define MOTOR_SPEED_SMOMIN_RPM         (1000.0)                                 // (RPM) SMO运行最小转速
 #define MOTOR_SPEED_MIN_RPM            (1050.0)                                 // (RPM) 运行最小转速
 #define MOTOR_SPEED_MAX_RPM            (10000.0)                                // (RPM) 运行最大转速
  
 
 #define MOTOR_SPEED_BLDC2FOC_LOW       (1500.0)
 #define MOTOR_SPEED_FOC2BLDC_LOW       (1000.0)
 
 #define MOTOR_SPEED_BLDC2FOC_HIG       (2250.0)
 #define MOTOR_SPEED_FOC2BLDC_HIG       (2400.0)

 
 #define MOTOR_SPEED_MID_RPM1            (9000.0)                                 // (RPM) 运行最小转速
 #define MOTOR_SPEED_MID_RPM2            (14000.0)                                 // (RPM) 运行最小转速


 #define MOTOR_SPEED_STAL_MAX_RPM       (5500.0)                                // (RPM) 堵转保护转速
 #define MOTOR_SPEED_STAL_MIN_RPM       (200.0)

 #define MOTOR_SPEED_STOP_RPM           (12000.0)                                 // (RPM) 运行最小转速

 /*VSP给定模式*/
 #define PWMMODE                        (0)                                     // PWM调速
 #define SREFMODE                       (1)                                     // 模拟调速
 #define NONEMODE                       (2)                                     // 直接给定值，不调速
 #define SPEED_MODE                     (SREFMODE)

/*电机开机、关机的设置----------------------------------------------------------*/
 /* motor ON/0FF value */
 #define OFF_Duty                     _Q15(0.60/HW_ADC_REF)                              // 关机PWM占空比，小于该占空比关机                                                                                //关机PWM占空比，小于该占空比时关机
 #define ON_Duty                      _Q15(0.60/HW_ADC_REF)                              // 开机PWM占空比，大于该占空比时开机
 #define MIN_Duty                     _Q15(0.60/HW_ADC_REF)                              // 速度曲线上最小PWM占空比
 #define MAX_Duty                     _Q15(2.50/HW_ADC_REF)                               // 速度曲线上最大PWM占空比

/*******运行时的参数*****************/
/*电流环参数设置值--------------------------------------------------------------*/
 #define DQKPStart                      _Q12(0.3)                               // DQ轴KP
 #define DQKIStart                      _Q15(0.0025)                              // DQ轴KI

 #define DQKP1                           _Q12(0.5)                               // DQ轴KP
 #define DQKI1                           _Q15(0.0075)                              // DQ轴KI
 
 #define DQKP2                           _Q12(0.3)                               // DQ轴KP
 #define DQKI2                           _Q15(0.005)                              // DQ轴KI

 /* D轴参数设置 */
 #define DOUTMAX                        _Q15(0.50)                              // D轴最大限幅值，单位：输出占空比
 #define DOUTMIN                        _Q15(-0.50)                             // D轴最小限幅值，单位：输出占空比
 /* Q轴参数设置，默认0.99即可 */
 #define QOUTMAX                        _Q15(0.999)                              // Q轴最大限幅值，单位：输出占空比
 #define QOUTMIN                        _Q15(-0.999)                             // Q轴最小限幅值，单位：输出占空比
 
 #define QOUT_INC                        (35)                                    // Q轴电流增大步进值,开环控制时有效
 #define QOUT_DEC                        (35)                                    // Q轴电流减小步进值,开环控制时有效
	

 /*速度环调节参数*/
 #define SKP                            _Q12(0.5)                               // 外环KP
 #define SKI                            _Q12(0.005)                              // 外环KI

 #define SOUTMAX                        I_Value(5.0)                           // (A) 外环最大限幅值
 #define SOUTMIN                        I_Value(0.02)                           // (A) 外环最小限幅值

 #define SPEED_INC                      (100.0)                                  // 速度环增量
 #define SPEED_DEC                      (100.0)                                  // 速度环减量

 /*功率环调节参数*/
 #define Motor_Max_Power                (4000)
 #define Motor_Min_Power                (400)

 /*UQ环调节参数*/
 #define UQ_KP                           _Q12(1.0)                               // 外环KP
 #define UQ_KI                           _Q12(0.01)                              // 外环KI

 #define UQ_OUTMAX                       I_Value(60.0)                           // (A) 外环最大限幅值
 #define UQ_OUTMIN                       I_Value(0.005)                           // (A) 外环最小限幅值

 #define UQ_INC                        (500.0)                                  // 速度环增量
 #define UQ_DEC                        (500.0)                                  // 速度环减量


 #define UQ_Min                         _Q15(0.20)  
 #define UQ_Max                         _Q15(0.99)  


/*模式选择设置值----------------------------------------------------------------*/
 /*IPM测试模式*/
 #define IPMtest                        (0)                                     // IPM测试或者MOS测试，MCU输出固定占空比
 #define NormalRun                      (1)                                     // 正常按电机状态机运行
 #define IPMState                       (NormalRun)

/*Motor  Direction: CW or CCW*/
#define  CW										          (0)														                                  // CW ,正转
#define  CCW									          (1)														                                 // CCW,反转
//#define  MotorDirection                 (CW)


/*保护参数值-------------------------------------------------------------------*/
 /*硬件过流保护*/
 #define Hardware_FO_Protect            (1)                                     // 硬件FO过流保护使能，适用于IPM有FO保护的场合
 #define Hardware_CMP_Protect           (2)                                     // 硬件CMP比较过流保护使能，适用于MOS管应用场合
 #define Hardware_FO_CMP_Protect        (3)                                     // 硬件CMP比较和FO过流保护都使能
 #define Hardware_Protect_Disable       (4)                                     // 硬件过流保护禁止，用于测试
 #define HardwareCurrent_Protect        (Hardware_CMP_Protect)                  // 硬件过流保护实现方式

 /*硬件过流保护比较值来源*/
 #define Compare_DAC                    (0)                                     // DAC设置硬件过流值
 #define Compare_Hardware               (1)                                     // 硬件设置硬件过流值
 #define Compare_Mode                   (Compare_DAC)                           // 硬件过流值的来源
 
 /*硬件过流保护*/
 #define OverHardcurrentValue           (180.0)          
 // (A) DAC模式下的硬件过流值


 /*软件过流保护*/
 #define  OverSoftCurrentProtect        (1)                                     // 一级软件过流保护：1--使能 0--禁止  						
 #define 	OverSoftCurrent							  I_LimtValue1(60.0)                           // (A) 一级软件过流值
 #define 	OverSoftCurrentTime           (500)                                  // (ms)一级软件过流检测时间
 
 #define  OverSoftCurrentProtect1       (1)                                     // 二级软件过流保护：1--使能 0--禁止  						
 #define 	OverSoftCurrent1							I_LimtValue1(65.0)                           // (A) 二级软件过流值
 #define 	OverSoftCurrentTime1          (100)                                   // (ms)二级软件过流检测时间
 
 #define  OverSoftCurrentProtect2       (0)                                     // 三级软件过流保护：1--使能 0--禁止  						
 #define 	OverSoftCurrent2							I_LimtValue1(45.0)                           // (A) 三级软件过流值
 #define 	OverSoftCurrentTime2          (25)                                    // (ms)三级软件过流检测时间
 

 /*过欠压保护*/
 #define VoltageProtect                 (Enable)                               // 电压保护：Enable--使能  Disable--禁止  
 #define Over_Protect_Voltage           (21.5)                                    // 不需改动
 #define Over_Recover_Vlotage           (21.0)                                    // (V) 直流电压过压保护恢复值
 #define Under_Protect_Voltage          (12.5)                                  // (V) 不需改动
 #define Under_Recover_Vlotage          (13.0)                                  // (V) 直流电压欠压保护恢复值
 #define Start_Protect_Voltage          (13.0)                                  //启动电压值
 
 /*温度保护*/
 #define TemperatureProtect             (Enable)                               // 温度保护：Enable--使能  Disable--禁止  
 #define Overtemperature_Value          (3000)                                    //  过温保护值
 #define Overtemperature_time           (500)                                    //  过温保护时间
 #define Recovertemperature             (Disable)                               // 温度保护：Enable--使能  Disable--禁止  
 #define Retemperature_Value            (6000)                                   //  过温保护恢复值
 #define Recovertemperature_time        (500)                                    //  过温保护恢复时间


 /******启停测试参数******/
 #define StartONOFF                     (Disable)                               //程序自动启停测试：Enable--使能  Disable--禁止  
 #define StartON_Time                   (700)                                  // (ms) 启动运行时间
 #define StartOFF_Time                  (700)                                  // (ms) 停止时间

 #define StopBrakeFlag                  (0)
 #define StopWaitTime                   (2000)                                  // (ms) 刹车等待时间

  /*延时断电*/
 #define PDELAY                         (GP22)
 #define PDELAY_Vaule                   (10000)              //延时断电时间 单位：ms
 #define Pdelay_ON                      (GP22 = 1)
 #define Pdelay_OFF                     (GP22 = 0)
#endif
