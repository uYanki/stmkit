/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : FocControl.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the foc control framework used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <FocControl.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ----------------------------------------------------------------------------*/
MotStaType mcState;
//MotStaTim  MotorStateTime;
MotStaM    McStaSet;
//TailWindSet xdata  mcTailwind;
uint8  xdata Motor_Direction;

/*---------------------------------------------------------------------------*/
/* Name     :   void MC_Control(void)
/* Input    :   NO
/* Output   :   NO
/* Description: 电机状态机函数，包括初始化、预充电、顺风逆风判断、预定位、启动、运行、故障等
/*---------------------------------------------------------------------------*/
void MC_Control(void)
{
    switch(mcState)
    {
        case mcReady:    // 关闭输出,上电会对电流进行采集校准,当采样校准结束标志置1且启动指令置1后，才跳转到mcInit
				{
					Motor_Ready();
					if(mcSpeedRamp.FlagONOFF == 1)
					{
						mcState = mcInit;
            ADC_Init();
					}
				}
        break;

        case mcInit:                          // 初始化状态，进入mcCharge状态
				{
					Motor_Init();	
					mcState                   =  mcCharge;               // 跳入mcCharge状态
					mcFocCtrl.State_Count     = Charge_Time;				
				}
        break;

        case mcCharge:                        // 预充电状态，MCU输出固定频率占空比，预充电结束后，跳入mcTailWind
				{
					Motor_Charge();
					#if (IPMState == NormalRun)           // 正常按电机状态机运行
					{
						if( mcFocCtrl.State_Count == 0)
						{
							MOE     = 0;                      // 关闭输出
							DRV_CMR &= 0xFFC0;
							BLDCStallCount = 0;
							BLDCStallFlag = 0;

							mcState = mcBLDC;
							if(GP23 == 1)
							{
								Motor_Direction = CW; 
							}
							else 		
							{
								Motor_Direction = CCW; 
							}						
						}
					}
					#endif
				 }
        break;

				case mcBLDC:                          // 初始化状态，进入mcCharge状态
				{
					 Motor_BLDC();
					if((mcSpeedRamp.FlagONOFF == 0)&&(McStaSet.SetFlag.BLDCSetFlag == 3))
					{	
						mcState    = mcStop;														
					}
				if(mcSpeedRamp.FlagONOFF == 1)         
        {
					if(((StallProtect == Enable)&&(TIM1_CW_BLDCCount > Motor_Stall_Count)&&(BLDCStallFlag == 1)))
					  {
							BLDCStallFlag = 0;				    
							mcFaultSource = FaultStall;
			        FaultProcess();							
					  }
					 if((PhaseLossProtect == Enable)&&(PhaseLossDetect_Flag == 1))
					   {
							 PhaseLossDetect_Flag = 0;
							 mcFaultSource = FaultLossPhase;
			         FaultProcess();			
             }
			   }
				}
        break;
				
        case mcRun:                             // 运行状态，若运行状态的给定变为0，进入mcStop状态。
				{
				 if(mcSpeedRamp.FlagONOFF == 0)
					{
					  mcState  = mcStop;
				  }			
				}
        break;

        case mcStop:
				{

					McStaSet.SetFlag.BLDCSetFlag = 0;	
					MOE        = 0;
					TIM1_CR0 = 0;
					TIM1_CR1 = 0;
					TIM1_CR2 = 0;
					TIM1_CR3 = 0x04;
					TIM1_CR4 = 0;
					TIM1_IER = 0;
					FOC_CR1    = 0x00;
					/*关闭FOC*/
					ClrBit(DRV_CR, FOCEN);
					
//					Driver_Init();	
//					ClrBit(DRV_CR, OCS);		
//					DRV_DR     = DRV_ARR;
//					DRV_CMR	  |= 0x0015;	
					MOE        = 0;	
					ONOFFTest.PowerOFF_Count = 8000;			
				  mcState  = mcBrake;		
				}
        break;

        case mcBrake:
				{
         if((mcSpeedRamp.FlagONOFF == 1)&&(ONOFFTest.PowerOFF_Count <=7850))
					{
						mcState = mcReady;		
            McStaSet.SetFlag.CalibFlag = 0;						
					}							
				}
        break;

        case mcFault:
				{
					if(mcSpeedRamp.FlagONOFF == 0)
					  {
							mcState  = mcStop;
            }
        }
        break;
    }
}


