/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Parameter.h
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-20
* Description        : This file contains all FOC debug parameter.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/

#ifndef __Parameter_H_
#define __Parameter_H_

/* Define to prevent recursive inclusion -------------------------------------*/
/* Q format define ---------------------------------------------------------------------------------*/
#define _Q7(A)                          (int8)(A * 128)
#define _Q10(A)                         (int16)(A * 1024)                                             // Q15 format
#define _Q11(A)                         (int16)(A * 2048)                                                 // Q12 format
#define _Q12(A)                         (int16)(A * 4096)                                                 // Q12 format
#define _Q13(A)                         (int16)(A * 8192)                                                 // Q12 format
#define _Q15(A)                         (int16)(A * 32767)                                                // Q15 format
#define _2PI                            (3.1415926 * 2)                                                 // 2 PI value
#define _Q16                            (65535.0)                                                        // Q16 format value
/* Private define ------------------------------------------------------------*/
#define SystemPowerUpTime               (10000)                                                    // 上电等待时间，cpu计数时钟

/*芯片参数值------------------------------------------------------------------*/
/*CPU and PWM Parameter*/
#define PWM_CYCLE                       (1000.0 / PWM_FREQUENCY)                    // 周期us
#define SAMP_FREQ                       (PWM_FREQUENCY * 1000)                        // 采样频率(HZ)
#define SAMP_FREQ_BLDC                  (PWM_FREQUENCY_BLDC * 1000)                        // 采样频率(HZ)

#define TPWM_VALUE                      (1.0 / SAMP_FREQ)                             // 载波周期(S)
#define PWM_VALUE_LOAD                  (uint16)(MCU_CLOCK * 500 / PWM_FREQUENCY)   // PWM 定时器重载值
#define PWM_VALUE_LOAD_BLDC             (uint16)(MCU_CLOCK * 500 / PWM_FREQUENCY_BLDC)   // PWM 定时器重载值


/*double resistor sample Parameter*/
#define DLL_TIME                        (PWM_DEADTIME+0.2)                       // 双电阻最小脉宽设置(us),建议值为死区时间值+0.2us以上
/*three resistor overmodule Parameter*/
#define OVERMOD_TIME                    (4.0)                                    // 过调制时间(us)，建议值2.0
/*deadtime compensation*/
#define DT_TIME                         (0.4)                                   // 死区补偿时间(us)，适用于双电阻和三电阻，建议值是1/2死区时间
/*min pulse*/
#define GLI_TIME                        (0.5)                                     // 桥臂窄脉宽消除(us),建议值0.5

/*deadtime Parameter*/
#define PWM_LOAD_DEADTIME               (PWM_DEADTIME * MCU_CLOCK)                          // 死区设置值
#define PWM_OVERMODULE_TIME             (OVERMOD_TIME * MCU_CLOCK / 2)                        // 过调制时间
#define PWM_DLOWL_TIME                  (DLL_TIME * MCU_CLOCK / 2)                    //下桥臂最小时间
/*single resistor sample Parameter*/
#define PWM_TS_LOAD                     (uint16)(_Q16 / PWM_CYCLE * MIN_WIND_TIME / 16)            // 单电阻采样设置值
#define PWM_DT_LOAD                     (uint16)(_Q16 / PWM_CYCLE * DT_TIME / 16)                  // 死区补偿值
#define PWM_TGLI_LOAD                   (uint16)(_Q16 / PWM_CYCLE * (GLI_TIME + PWM_DEADTIME) / 16)  // 最小脉冲

 /* current set value */
#define I_ValueX(Curr_Value)            (Curr_Value * HW_RSHUNT * HW_AMPGAIN / (HW_ADC_REF))
#define I_Value(Curr_Value)             _Q15(I_ValueX(Curr_Value))

/*硬件板子参数设置值------------------------------------------------------------------*/
/*hardware current sample Parameter*/
/*电流基准的电路参数*/
#define HW_BOARD_CURR_MAX               (HW_ADC_REF / 2 / HW_AMPGAIN / HW_RSHUNT)         // 最大采样电流,2.702A
#define HW_BOARD_CURR_MIN               (-HW_BOARD_CURR_MAX)                                        // 最小采样电流,-2.702A
#define HW_BOARD_CURR_BASE              (HW_BOARD_CURR_MAX * 2)                                       // 电流基准//5.4A

/*hardware voltage sample Parameter*/
/*母线电压采样分压电路参数*/
#define HW_BOARD_VOLT_MAX               (HW_ADC_REF * RV)                       // (V)  ADC可测得的最大母线电压
#define HW_BOARD_VOLTAGE_BASE           (HW_BOARD_VOLT_MAX / 1.732)                              // 电压基准
#define HW_BOARD_VOLTAGE_VC             ((RV1 + RV2 + RV3 * VOLT_COMP) / (RV3 * VOLT_COMP))
#define HW_BOARD_VOLTAGE_BASE_Start     (HW_ADC_REF * HW_BOARD_VOLTAGE_VC / 1.732)               // 电压基准


/*硬件过流保护DAC值*/
#define DAC_OvercurrentValue            _Q7(I_ValueX(OverHardcurrentValue*2.0))+0x7F

#define Align_Theta                     (uint16)((float)(Align_Angle*182.038)) 

#define AL_THT(ALIGN_Temp)              (uint16)((float)(ALIGN_Temp*182.038))

#define BASE_FREQ                       ((MOTOR_SPEED_BASE / 60) * Pole_Pairs)  // 基准频率

/*保护参数值------------------------------------------------------------------*/
/* protect value */
#define OVER_PROTECT_VALUE              _Q15(Over_Protect_Voltage  / HW_BOARD_VOLT_MAX)
#define UNDER_PROTECT_VALUE             _Q15(Under_Protect_Voltage / HW_BOARD_VOLT_MAX)
#define OVER_RECOVER_VALUE              _Q15(Over_Recover_Vlotage  / HW_BOARD_VOLT_MAX)
#define UNDER_RECOVER_VALUE             _Q15(Under_Recover_Vlotage / HW_BOARD_VOLT_MAX)
#define Start_PROTECT_VALUE             _Q15(Start_Protect_Voltage  / HW_BOARD_VOLT_MAX)



#define DC_HIG_VALUE                    _Q15(19.5 / HW_BOARD_VOLT_MAX)
#define DC_LOW_VALUE                    _Q15(15.5 / HW_BOARD_VOLT_MAX)


/* motor speed set value */
#define Motor_Open_Ramp_ACC             _Q15(MOTOR_OPEN_ACC     / MOTOR_SPEED_BASE)
#define Motor_Open_Ramp_Min             _Q15(MOTOR_OPEN_ACC_MIN / MOTOR_SPEED_BASE)

#define Motor_Omega_Ramp_Min            _Q15(MOTOR_SPEED_BLDC2FOC_RPM / MOTOR_SPEED_BASE)
#define Motor_Omega_Ramp_End            _Q15((MOTOR_SPEED_BLDC2FOC_RPM + 1000.0) / MOTOR_SPEED_BASE)
#define Motor_Omega_Ramp_Min_Hig        _Q15(MOTOR_SPEED_SMOMIN_RPM / MOTOR_SPEED_BASE)

#define Motor_Loop_Speed                _Q15(MOTOR_LOOP_RPM / MOTOR_SPEED_BASE)

//#define Motor_Speed                     _Q15(0.02*MOTOR_SPEED_BASE)
#define Motor_Speed_Run                 _Q15(0.005*MOTOR_SPEED_BASE)
#define Motor_Speed_Run1                _Q15(0.02*MOTOR_SPEED_BASE)
#define Motor_Speed_Run2                _Q15(0.05*MOTOR_SPEED_BASE)
#define Motor_Speed_Run3                _Q15(0.15*MOTOR_SPEED_BASE)
#define Motor_Speed_Run4                _Q15(0.25*MOTOR_SPEED_BASE)


#define Motor_Max_Speed                 _Q15(MOTOR_SPEED_MAX_RPM   / MOTOR_SPEED_BASE)
#define Motor_Min_Speed                 _Q15(MOTOR_SPEED_MIN_RPM   / MOTOR_SPEED_BASE)
#define Motor_Stop_Speed                _Q15(MOTOR_SPEED_STOP_RPM  / MOTOR_SPEED_BASE)

#define Motor_Mid_Speed1                 _Q15(MOTOR_SPEED_MID_RPM1  / MOTOR_SPEED_BASE)
#define Motor_Mid_Speed2                 _Q15(MOTOR_SPEED_MID_RPM2  / MOTOR_SPEED_BASE)

 
#define Motor_Stall_Min_Speed           _Q15(MOTOR_SPEED_STAL_MIN_RPM / MOTOR_SPEED_BASE)
#define Motor_Stall_Max_Speed           _Q15(MOTOR_SPEED_STAL_MAX_RPM / MOTOR_SPEED_BASE)

/*外环增量*/


#define Motor_Bldc2Foc_Speed_Hig        (uint16)(SAMP_FREQ_BLDC/(MOTOR_SPEED_BLDC2FOC_HIG/(10.0/Pole_Pairs)))
#define Motor_Bldc2Foc_Speed_Low        (uint16)(SAMP_FREQ_BLDC/(MOTOR_SPEED_BLDC2FOC_LOW/(10.0/Pole_Pairs)))

#define Motor_Bldc2Foc_Speed             _Q15((MOTOR_SPEED_BLDC2FOC_RPM )/ MOTOR_SPEED_BASE)
#define Motor_Bldc2Foc_SpeedH            _Q15((MOTOR_SPEED_BLDC2FOC_HIG )/ MOTOR_SPEED_BASE)
#define Motor_Bldc2Foc_SpeedL            _Q15((MOTOR_SPEED_BLDC2FOC_LOW )/ MOTOR_SPEED_BASE)


//#define Motor_Foc2Bldc_Tht_Up            AL_THT(195.0)
//#define Motor_Foc2Bldc_Tht_Dn            AL_THT(165.0)

//#define Motor_Foc2Bldc_Speed            _Q15(MOTOR_SPEED_FOC2BLDC_RPM / MOTOR_SPEED_BASE)
//#define Motor_Foc2Bldc_SpeedH           _Q15(MOTOR_SPEED_FOC2BLDC_HIG / MOTOR_SPEED_BASE)
//#define Motor_Foc2Bldc_SpeedL           _Q15(MOTOR_SPEED_FOC2BLDC_LOW / MOTOR_SPEED_BASE)


#define SPEED_K                         ((float)(Motor_Max_Speed-Motor_Min_Speed)/(float)(MAX_Duty-MIN_Duty))
#define POWER_K                         ((float)(Motor_Max_Power-Motor_Min_Power)/(float)(MAX_Duty-MIN_Duty))
#define UQ_K                            ((float)(UQ_Max-UQ_Min)/(float)(MAX_Duty-MIN_Duty))

#define MIN_BLDC_Duty                   (uint16)(Min_BLDC_Duty*PWM_VALUE_LOAD_BLDC)  
#define MAX_BLDC_Duty                   (uint16)(Max_BLDC_Duty*PWM_VALUE_LOAD_BLDC)   
#define MAX_BLDC_VH_Duty_0              (uint16)(Max_BLDC_VH_Duty_0*PWM_VALUE_LOAD_BLDC)   
#define MAX_BLDC_VH_Duty_1              (uint16)(Max_BLDC_VH_Duty_1*PWM_VALUE_LOAD_BLDC)   
#define MAX_BLDC_VH_Duty_2              (uint16)(Max_BLDC_VH_Duty_2*PWM_VALUE_LOAD_BLDC)   

#define HIGH_BLDC_Duty                  (uint16)(Max_BLDC_High_Duty*PWM_VALUE_LOAD_BLDC)  
#define LOW_BLDC_Duty                   (uint16)(Max_BLDC_Low_Duty*PWM_VALUE_LOAD_BLDC)   

#define I_LimtValue1(Curr_limt1)			  (uint16)(LimtCurt_K*Curr_limt1)													
#define I_Limt_MaxValue(Curr_limt2)			(uint16)(32767.0*((HW_RSHUNT*Curr_limt2*HW_AMPGAIN)/(HW_ADC_REF)))													

#define BLDC_K                         ((float)(MAX_BLDC_Duty-MIN_BLDC_Duty)/(float)(MAX_Duty-MIN_Duty))

/* obsever parameter set value */
#define Ke                              (Pole_Pairs * KeVpp * KeT / 207.84)     // (V/KRPM) 反电动势常数
#define MAX_BEMF_VOLTAGE                ((MOTOR_SPEED_BASE*Ke)/(1000.0))
#define MAX_OMEG_RAD_SEC                ((float)(_2PI*BASE_FREQ))
#define OBS_K1T                         _Q15(LD/(LD+RS*TPWM_VALUE))
#define OBS_K2T                         _Q13((TPWM_VALUE/(LD+RS*TPWM_VALUE))*(HW_BOARD_VOLTAGE_BASE_Start/HW_BOARD_CURR_BASE))
//#define OBS_K2T_SMO                     _Q13((TPWM_VALUE/(LD+RS*TPWM_VALUE))*1.4*(HW_BOARD_VOLTAGE_BASE_Start/HW_BOARD_CURR_BASE))
#define OBS_K2T_Actual                  _Q13((TPWM_VALUE/(LD+RS*TPWM_VALUE))*(HW_BOARD_VOLTAGE_BASE/HW_BOARD_CURR_BASE))
#define OBS_K3T                         _Q15((TPWM_VALUE/(LD+RS*TPWM_VALUE))*(MAX_BEMF_VOLTAGE/HW_BOARD_CURR_BASE))
#define OBS_K4T                         _Q15(((LD-LQ)*TPWM_VALUE*MAX_OMEG_RAD_SEC)/(LD+RS*TPWM_VALUE))

#define OBSW_KP_GAIN                    _Q12(2*_2PI*ATT_COEF*ATO_BW/BASE_FREQ)
#define OBSW_KI_GAIN                    _Q15(_2PI*ATO_BW*ATO_BW*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN                _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN/BASE_FREQ)
#define OBSW_KI_GAIN_RUN                _Q15(_2PI*ATO_BW_RUN*ATO_BW_RUN*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN1               _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN1/BASE_FREQ)
#define OBSW_KI_GAIN_RUN1               _Q15(_2PI*ATO_BW_RUN1*ATO_BW_RUN1*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN2               _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN2/BASE_FREQ)
#define OBSW_KI_GAIN_RUN2               _Q15(_2PI*ATO_BW_RUN2*ATO_BW_RUN2*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN3               _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN3/BASE_FREQ)
#define OBSW_KI_GAIN_RUN3               _Q15(_2PI*ATO_BW_RUN3*ATO_BW_RUN3*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN4               _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN4/BASE_FREQ)
#define OBSW_KI_GAIN_RUN4               _Q15(_2PI*ATO_BW_RUN4*ATO_BW_RUN4*TPWM_VALUE/BASE_FREQ)

#define OBS_FBASE                       BASE_FREQ*TPWM_VALUE*32768                          // Fbase*Tpwm*32768
#define OBS_KLPF                        _Q15(_2PI*BASE_FREQ*TPWM_VALUE)                 // 2PI*Fbase*Tpwm
#define SPEED_KLPF                      _Q15(_2PI*SPD_BW*TPWM_VALUE)                        // 2PI*SPD_BW*Tpwm
#define OBS_EA_KS                       _Q15((2*MOTOR_SPEED_SMOMIN_RPM*_2PI*BASE_FREQ*TPWM_VALUE)/MOTOR_SPEED_BASE)     // SMO的最小速度

#define OBSE_PLLKP_GAIN                 _Q11(((2*ATT_COEF*_2PI*E_BW*LD - RS)*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)
#define OBSE_PLLKI_GAIN                 _Q11((_2PI*E_BW*_2PI*E_BW*LD*TPWM_VALUE*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)

#define OBSE_PLLKP_GAIN_RUN             _Q11(((2*ATT_COEF*_2PI*E_BW_RUN*LD - RS)*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)
#define OBSE_PLLKI_GAIN_RUN             _Q11((_2PI*E_BW_RUN*_2PI*E_BW_RUN*LD*TPWM_VALUE*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)

#define OBSE_PLLKP_GAIN_RUN1            _Q11(((2*ATT_COEF*_2PI*E_BW_RUN1*LD - RS)*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)
#define OBSE_PLLKI_GAIN_RUN1            _Q11((_2PI*E_BW_RUN1*_2PI*E_BW_RUN1*LD*TPWM_VALUE*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)

#define OBSE_PLLKP_GAIN_RUN2            _Q11(((2*ATT_COEF*_2PI*E_BW_RUN2*LD - RS)*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)
#define OBSE_PLLKI_GAIN_RUN2            _Q11((_2PI*E_BW_RUN2*_2PI*E_BW_RUN2*LD*TPWM_VALUE*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)

#define OBSE_PLLKP_GAIN_RUN3            _Q11(((2*ATT_COEF*_2PI*E_BW_RUN3*LD - RS)*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)
#define OBSE_PLLKI_GAIN_RUN3            _Q11((_2PI*E_BW_RUN3*_2PI*E_BW_RUN3*LD*TPWM_VALUE*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)

#define OBSE_PLLKP_GAIN_RUN4            _Q11(((2*ATT_COEF*_2PI*E_BW_RUN4*LD - RS)*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)
#define OBSE_PLLKI_GAIN_RUN4            _Q11((_2PI*E_BW_RUN4*_2PI*E_BW_RUN4*LD*TPWM_VALUE*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)

/*逆风判断时的估算算法设置值------------------------------------------------------------*/
#define SPEED_KLPF_WIND                 _Q15(_2PI*SPD_BW_Wind*TPWM_VALUE)           // 2PI*SPD_BW_Wind*Tpwm
#define OBSW_KP_GAIN_WIND               _Q12(2*_2PI*ATT_COEF*ATO_BW_Wind/BASE_FREQ)
#define OBSW_KI_GAIN_WIND               _Q15(_2PI*ATO_BW_Wind*ATO_BW_Wind*TPWM_VALUE/BASE_FREQ)//---PLL

/*Current Calib:enable or disable*/
#define CalibENDIS                      (Enable)                                   //Enable-禁止电流基准校正，Disable-使能电流基准校正	
#define Calib_Time                     (1000)                                  // 校正次数，固定1000次，单位:次

/*double resistor sample mode*/
#define DouRes_1_Cycle                  (0)                                        // 1 周期采样完 ia, ib
#define DouRes_2_Cycle                  (1)                                        // 交替采用ia, ib, 2周期采样完成
#define DouRes_Sample_Mode              (DouRes_1_Cycle)



#define ANGLE_MASK(ANGLE_M)                  {TIM1_CR1  =(TIM1_CR1 &(0x80)) | (ANGLE_M*127/60);}  
#define ANGLE_DELAY(ANGLE_D)                 {TIM1_CR2  =(TIM1_CR2 &(0x80)) | (ANGLE_D*127/60);}  

#define ANGLE_MASK_R(ANGLE_M_R)        (uint8)(ANGLE_M_R*127/60)
#define ANGLE_DELAY_R(ANGLE_D_R)       (uint8)(ANGLE_D_R*127/60) 

#define ActiveLowEnable                 (0x0540)                                //低电平有效
#define ActiveHighEnable                (0)                                     //高电平有效

#define H_MOSActive                     (ActiveHighEnable)                     //上桥预驱电平
#define L_MOSActive                     (ActiveLowEnable)                     //小桥预驱电平

#define PWM_BITCON                      (L_MOSActive+H_MOSActive*2)            //000高有效 AAA低有效  222上桥低  888下桥低

#define TUVW_OFF     0x0000
#define TULVLWL_ON   0x0540

/*****HPWM+LPWM*********/
#define TUH_VL0       0x0006
#define TUH_WL0       0x0012
#define TVH_WL0       0x0018
#define TVH_UL0       0x0009
#define TWH_UL0       0x0021
#define TWH_VL0       0x0024

/*****HPWM+LON*********/
#define TUH_VL1                         0x0102
#define TUH_WL1                         0x0402
#define TVH_WL1                         0x0408
#define TVH_UL1                         0x0048
#define TWH_UL1                         0x0060
#define TWH_VL1                         0x0120

/*****HON_PWM+LPWM*********/
#define TUH_VL2                         0x0084
#define TUH_WL2                         0x0402
#define TVH_WL2                         0x0210
#define TVH_UL2                         0x0048
#define TWH_UL2                         0x0801
#define TWH_VL2                         0x0120

#define TUH_VL3                         0x0102
#define TUH_WL3                         0x0090
#define TVH_WL3                         0x0408
#define TVH_UL3                         0x0201
#define TWH_UL3                         0x0060
#define TWH_VL3                         0x0804

#define UVW_OFF                         (TUVW_OFF^PWM_BITCON) 
#define ULVLWL_ON                       (TULVLWL_ON^PWM_BITCON)

#define CMP_UVW_UPDO                   (0x0000+UVW_OFF)  
#define CMP_W_DO                       0x2000  
#define CMP_V_UP                       0x3000 
#define CMP_U_DO                       0x4000
#define CMP_W_UP                       0x5000 
#define CMP_V_DO                       0x6000 
#define CMP_U_UP                       0x1000 
#define CMP_UVW_NO                     0x0000  


/*****HPWM+LPWM*********/
#define UH_VLA0            (TUH_VL0^PWM_BITCON)
#define UH_WLA0            (TUH_WL0^PWM_BITCON)
#define VH_WLA0            (TVH_WL0^PWM_BITCON)
#define VH_ULA0            (TVH_UL0^PWM_BITCON)
#define WH_ULA0            (TWH_UL0^PWM_BITCON)
#define WH_VLA0            (TWH_VL0^PWM_BITCON)

/*****HPWM+LON*********/
#define UH_VLA1            (TUH_VL1^PWM_BITCON)
#define UH_WLA1            (TUH_WL1^PWM_BITCON)
#define VH_WLA1            (TVH_WL1^PWM_BITCON)
#define VH_ULA1            (TVH_UL1^PWM_BITCON)
#define WH_ULA1            (TWH_UL1^PWM_BITCON)
#define WH_VLA1            (TWH_VL1^PWM_BITCON)

#define UH_VLA2            (TUH_VL2^PWM_BITCON)
#define UH_WLA2            (TUH_WL2^PWM_BITCON)
#define VH_WLA2            (TVH_WL2^PWM_BITCON)
#define VH_ULA2            (TVH_UL2^PWM_BITCON)
#define WH_ULA2            (TWH_UL2^PWM_BITCON)
#define WH_VLA2            (TWH_VL2^PWM_BITCON)

#define UH_VLA3            (TUH_VL3^PWM_BITCON)
#define UH_WLA3            (TUH_WL3^PWM_BITCON)
#define VH_WLA3            (TVH_WL3^PWM_BITCON)
#define VH_ULA3            (TVH_UL3^PWM_BITCON)
#define WH_ULA3            (TWH_UL3^PWM_BITCON)
#define WH_VLA3            (TWH_VL3^PWM_BITCON)

#define  Tim1_Ures_Down		              (0)														                                 
#define  Tim1_Ures_Up									  (1)														                                 

//#define Motor_Bldc2Foc_Speed_BLDC       (uint16)(SAMP_FREQ_BLDC/(MOTOR_SPEED_BLDC2FOC_RPM/(10.0/Pole_Pairs)))

#define Motor_Bldc2Foc_Speed_BLDC       (uint16)((MCU_CLOCK*5.0*500000.0)/(Pole_Pairs*MOTOR_SPEED_BLDC2FOC_RPM)) 

//#define Motor_Foc2Bldc_TIM1_BCOR        (uint16)((MCU_CLOCK*5.0*1000000.0)/(Pole_Pairs*MOTOR_SPEED_BLDC2FOC_RPM)) 

/*注意溢出 预分频12M时，此时MOTOR_SPEED_FOC2BLDC_RPM最小为 = 12M/65535 =  183RPM */
#define Motor_Foc2Bldc_Speed_BLDC       (uint16)((MCU_CLOCK*5.0*500000.0)/(Pole_Pairs*MOTOR_SPEED_FOC2BLDC_RPM)) 

#define Motor_Stall_Count              (uint16)(MOTOR_STALL_COUNT*PWM_FREQUENCY_BLDC)    
 
#endif