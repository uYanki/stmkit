
/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : PIInit.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains PI initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>

void PI_Init(void)
{
	PI_KP = UQ_KP;
	PI_KI = UQ_KI;
	PI_EK = 0;
	PI_LPF_CR |= 0x02;									// Start PI
	PI_UKMAX = UQ_OUTMAX;
	PI_UKMIN = UQ_OUTMIN;
	_nop_(); _nop_(); _nop_(); _nop_();
	PI_UK =   0;
	PI_LPF_CR &= 0xFD;									// stop PI
}