/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : FocControl.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains all the foc control function used for motor control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>
#include <FU68xx_2_DMA.h>
#endif
CurrentOffset xdata mcCurOffset;

extern uint8  xdata Motor_Direction;

/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Charge(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	预充电，当一直处于预充电状态下，不接电机，可用于验证IPM或者Mos。
预充电分三步，第一步是对U相进行预充电，第二步是对U,V两相进行预充电;第三步是对U、V、W三相进行预充电。
/*---------------------------------------------------------------------------*/
void Motor_Charge(void)
{
     if(McStaSet.SetFlag.ChargeSetFlag==0)
		 {
				McStaSet.SetFlag.ChargeSetFlag = 1;
       	#if (PWM_Level_Mode == All_Low_Level)	 //用于測試6536
				{
         SetBit(P1_OE, P10);
//         GP10=1;
        }
        #endif
				
			 	#if (IPMState == IPMtest)
				 {
				   DRV_DR = 0.5*DRV_ARR;						    // IPM 70% duty
				 }
				 #elif (IPMState == NormalRun)		      // 正常按电机状态机运行
				 {
           DRV_DR = Charge_Duty*DRV_ARR;				        //下桥臂10% duty
				 }
				#endif
			 	/*-------------------------------------------------------------------------------------------------
				DRV_CTL：PWM来源选择
				OCS = 0, DRV_COMR
				OCS = 1, FOC/SVPWM/SPWM
				-------------------------------------------------------------------------------------------------*/
				ClrBit(DRV_CR, OCS);
				mcFocCtrl.ChargeStep = 0;
		 }
		 if((mcFocCtrl.State_Count < Charge_Time)&&(mcFocCtrl.ChargeStep == 0))
		 {
			 mcFocCtrl.ChargeStep = 1;
			 #if (IPMState == IPMtest)
			 {
			   DRV_CMR |= 0x0003;                         // U相输出
			 }
			 #elif (IPMState == NormalRun)		          // 正常按电机状态机运行
			 {
			   DRV_CMR |= 0x003F;                         // U相下桥臂通
			 }
			 #endif
			 MOE = 1;
		 }
//		 if(( mcFocCtrl.State_Count <= (Charge_Time<<1)/3)&&(mcFocCtrl.ChargeStep== 1))
//		 {
//			 mcFocCtrl.ChargeStep = 2;
//			 #if (IPMState == IPMtest)
//			 {
//         DRV_CMR |= 0x000F;                         // U、V相输出
//			 }
//			 #elif (IPMState == NormalRun)		          // 正常按电机状态机运行
//			 {
//         DRV_CMR |= 0x000F;                         // V相下桥臂导通
//			 }
//       #endif
//		 }
//		 if((mcFocCtrl.State_Count <= Charge_Time/3)&&(mcFocCtrl.ChargeStep== 2))
//		 {
//			  mcFocCtrl.ChargeStep = 3;
//			 #if (IPMState == IPMtest)
//			 {
//         DRV_CMR |= 0x003F;                         // U、V、W相输出
//	     }
//			 #elif (IPMState == NormalRun)		          // 正常按电机状态机运行
//			 {
//			   DRV_CMR |= 0x003F;                         // W相下桥臂导通
//			 }
//       #endif
//		 }
}

/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_BLDC(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	BLDC
/*---------------------------------------------------------------------------*/
void Motor_BLDC(void)
{ 
   Motor_BLDC_Init(&VirlHal);
	
	if(McStaSet.SetFlag.BLDCSetFlag == 3)
	{	
		if(TIM1_BLDCCountAll_Flag == 3)
		{	
			McStaSet.SetFlag.BLDCSetFlag = 4;
			mcState = mcRun;
			TIM1_BLDCCountAll_Flag = 0;			
			TIM1_BLDC();
		}
	}
}



/*---------------------------------------------------------------------------*/
/* Name		:	void MC_Stop(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	inital motor control parameter
/*---------------------------------------------------------------------------*/
void MC_Stop(void)
{
	MOE     = 0;
	ClrBit(DRV_CR, FOCEN, 0);	//关闭FOC																											// disable FOC output and initial register
	mcState = mcInit;
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void MotorControlInit(void)
	Description   :	控制变量初始化清零,包括保护参数的初始化、电机状态初始化
	Input         :	输入说明（详细）
  Output				:	输出说明（详细）
-------------------------------------------------------------------------------------------------*/
void MotorcontrolInit(void)
{
  /***********保护******************/
	memset(&mcFaultDect,0, sizeof(FaultVarible));																// FaultVarible变量清零
  /******堵转保护*********/
//	mcFaultDect.StallRecover          = 1000;//5s

  /******保护次数*********/
	memset(&mcProtectTime,0, sizeof(ProtectVarible));														// ProtectVarible保护次数清零 
  /*******过流保护*****************/
	memset(&mcCurVarible,0, sizeof(CurrentVarible));														// 电流保护的变量清零

  /*****顺逆风判断，FOCMethod不需要在此赋初值*******/
//	#if (TailWind_Mode == TailWind_RSD_Method)
//	{
//   memset(&RSDDetect,0, sizeof(MotorRSDTypeDef));	//	RSDDetect所有变量清零
//	}
//	#elif (TailWind_Mode == TailWind_BEMF_Method)
//	{
//   memset(&BEMFDetect,0, sizeof(BEMFDetect_TypeDef));		//	BEMFDetect所有变量清零
//	} 
//  #endif

	/*******启停测试的参数***************/
	memset(&ONOFFTest,0, sizeof(ONVarible));

  /*****电机状态机时序变量***********/
	McStaSet.SetMode                   = 0;

  /*****电机目标方向**********/
	mcFRState.TargetFR                 = 0;

  /*****外部控制环*******/
	memset(&mcFocCtrl,0, sizeof(FOCCTRL));																// mcFocCtrl变量清零

  /******电流偏置校准变量*****/
	memset(&mcCurOffset,0, sizeof(CurrentOffset));												// mcCurOffset变量清零
	mcCurOffset.IuOffsetSum            = 16383;
	mcCurOffset.IvOffsetSum            = 16383;
	mcCurOffset.Iw_busOffsetSum        = 16383;
  mcCurOffset.OffsetFlag             = 0;                               // 等待电流采集
	/*****LED灯响应***/
	memset(&mcLedDisplay,0, sizeof(MCLedDisplay));												// mcLedDisplay变量清零
	mcLedDisplay.Counttime            = 4999;

	/*****速度环的响应***/
	memset(&mcSpeedRamp,0, sizeof(MCRAMP));												        // mcSpeedRamp变量清零
//	mcSpeedRamp.IncValue              = Motor_Speed_Inc;
//	mcSpeedRamp.DecValue              = Motor_Speed_Dec;
	mcSpeedRamp.DelayPeriod           = 0;
  mcSpeedRamp.DelayCurrtlimit       = 0;
	/*PWM调速变量*/
	memset(&mcPwmInput,0, sizeof(PWMINPUTCAL));												    // mcPwmInput变量清零

	/*串口变量*/
//	memset(&Uart,0, sizeof(MCUART));												              // MCUART变量清零

	/*睡眠模式*/  
	memset(&SleepSet,0, sizeof(SLEEPMODE));		                                  // 睡眠模式清零

	BLDCStallFlag = 0;
	
  BLDCStallCount = 0;
	
}

/*---------------------------------------------------------------------------*/
/* Name		:	void VariablesPreInit(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	初始化电机参数
/*---------------------------------------------------------------------------*/
void VariablesPreInit(void)
{
	/***********保护******************/
	mcFaultSource = FaultNoSource;
	memset(&mcFaultDect,0, sizeof(FaultVarible));																// FaultVarible变量清零

  /*****外部控制环*******/
	memset(&mcFocCtrl,0, sizeof(FOCCTRL));																// mcFocCtrl变量清零

//  /*****顺逆风判断*******/
//	#if (TailWind_Mode == TailWind_RSD_Method)
//	{
//	  RSDDetect.RSDCCWTimes    = 0;                             //  CCW刹车次数清零
//	}
//	#elif (TailWind_Mode == TailWind_BEMF_Method)
//	{
//	}
//	#elif (TailWind_Mode == TailWind_FOC_Method)
//	{
//	 memset(&TailWindDetect,0, sizeof(MotorTailWindTypeDef));		//	TailWindDetect所有变量清零
//	}
//  #endif
  /*****电机状态机时序变量***********/
  McStaSet.SetMode                   = 0;

	/*****LED灯响应***/
//	memset(&mcLedDisplay,0, sizeof(MCLedDisplay));												// mcLedDisplay变量清零
//	mcLedDisplay.Counttime            = 4999;


}
/*---------------------------------------------------------------------------*/
/* Name		:	void GetCurrentOffset(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	上电时，先对硬件电路的电流进行采集，写入对应的校准寄存器中。
								调试时，需观察mcCurOffset结构体中对应变量是否在范围内。采集结束后，OffsetFlag置1。
/*---------------------------------------------------------------------------*/
void GetCurrentOffset(void)
{     
	  SetBit(ADC_CR, ADCBSY);		                           // 使能ADC
		while(ReadBit(ADC_CR, ADCBSY));

		mcCurOffset.Iw_busOffsetSum+=((ADC4_DR& 0x0fff) << 3);
		mcCurOffset.Iw_busOffset = mcCurOffset.Iw_busOffsetSum >> 4;
		mcCurOffset.Iw_busOffsetSum -= mcCurOffset.Iw_busOffset;


		  mcCurOffset.OffsetCount++;
		if(mcCurOffset.OffsetCount>Calib_Time)
		{
			mcCurOffset.OffsetFlag = 1;
    }
}
/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Ready(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	上电时，关闭输出，先对硬件电路的电流进行采集，在FOC_Init中写入对应的校准寄存器中。
                调试时，需观察mcCurOffset结构体中对应变量是否在范围内。
/*---------------------------------------------------------------------------*/
void Motor_Ready(void)
{
   if(McStaSet.SetFlag.CalibFlag==0)
   {	 
			 VirlHal.VirtlHall_KF_Data = VirtlHall_KF;                             
			 VirlHal.VirtlHall_KR_Data = VirtlHall_KR;  

			VirlHal.VirtlHallSignal_ChangeCount_Data = VirtlHallSignal_ChangeCount;       
			VirlHal.VirtlHallSignal_ForwardValue_Data = VirtlHallSignal_ForwardValue;    

			VirlHal.MOTOR_BLDC2FOC_COUNT_Data = MOTOR_BLDC2FOC_COUNT;          
			VirlHal.MOTOR_FOC2BLDC_COUNT_Data = MOTOR_FOC2BLDC_COUNT;          

			VirlHal.MOTOR_SPEED_BLDC2FOC_RPM_Data = Motor_Bldc2Foc_Speed_BLDC;     
			VirlHal.MOTOR_SPEED_FOC2BLDC_RPM_Data = Motor_Foc2Bldc_Speed_BLDC; 
		 
		  VirlHal.MOTOR_MIN_Duty = MIN_BLDC_Duty;
		 
		  VirlHal.PhaseLossDetect_Data  = PhaseLossDetectValue;
		 
		 	VirlHal.OVER_PROTECT_Data  = OVER_PROTECT_VALUE;     
			VirlHal.UNDER_PROTECT_Data = UNDER_PROTECT_VALUE; 
		 
			MOE        = 0;
			TIM1_CR0 = 0;
			TIM1_CR1 = 0;
			TIM1_CR2 = 0;
			TIM1_CR3 = 0;
			TIM1_CR4 = 0;
			TIM1_IER = 0;
			FOC_CR1    = 0x00;
			/*关闭FOC*/
			ClrBit(DRV_CR, FOCEN);
		
     McStaSet.SetFlag.CalibFlag = 1;
   }
}
/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Init(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	对电机相关变量、PI进行初始化设置
/*---------------------------------------------------------------------------*/
void Motor_Init(void)
{
	 VariablesPreInit();                           // 电机相关变量初始化
	 PI_Init();			                               // PI初始化
}
#endif