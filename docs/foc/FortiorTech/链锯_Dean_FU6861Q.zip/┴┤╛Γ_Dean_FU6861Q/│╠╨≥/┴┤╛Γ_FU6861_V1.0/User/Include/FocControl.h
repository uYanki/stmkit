/**
  ******************************************************************************
  * @file    FocControl.h
  * @author  Fortior Application Team
  * @version V1.0.0
  * @date    10-Apr-2017
  * @brief   define motor contorl parameter
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __FocControl_H_
#define __FocControl_H_


/* Exported types -------------------------------------------------------------------------------*/
typedef enum
{
    mcReady     = 0,
    mcInit      = 1,
    mcCharge    = 2,
    mcTailWind  = 3,
    mcPosiCheck = 4,
    mcBLDC      = 5,
	  mcAlign     = 6,
    mcStart     = 7,
    mcRun       = 8,
    mcStop      = 9,
    mcFault     = 10,
    mcPllTect   = 11,
    mcBrake     = 12
}MotStaType;

typedef union
{
    uint16 SetMode;                      // 整个配置模式使能位
    struct
    {
        uint16 CalibFlag        :1;      // 电流校准的标志位
        uint16 ChargeSetFlag    :1;      // 预充电配置标志位
			  uint16 BLDCSetFlag      :4;      // BLDC配置标志位
        uint16 AlignSetFlag     :1;      // 预定位配置标志位
        uint16 TailWindSetFlag  :1;      // 顺逆风配置标志位
        uint16 StartSetFlag     :1;      // 启动配置标志位
        uint16 PosiCheckSetFlag :1;      // 位置检测配置标志位
    } SetFlag;
}MotStaM;



/* Exported variables ---------------------------------------------------------------------------*/
extern MotStaType mcState;
//extern MotStaTim  MotorStateTime;
extern MotStaM McStaSet;
//extern TailWindSet   xdata mcTailwind;

/* Exported functions ---------------------------------------------------------------------------*/
extern void MC_Control(void);
extern void MotorcontrolInit(void);
extern void McTailWindDealwith(void);

extern void TailWindDealwith(void);
//extern void Motor_PllStart(void);

extern uint8 BLDCStallCount;
extern uint8 BLDCStallFlag;
#endif
