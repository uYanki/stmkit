/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the add function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <AddFunction.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ---------------------------------------------------------*/
FaultStateType			       mcFaultSource;
PWMINPUTCAL        xdata   mcPwmInput;
FaultVarible       xdata   mcFaultDect;
//MotorRSDTypeDef    xdata   RSDDetect;
CurrentVarible     xdata   mcCurVarible;
ProtectVarible     xdata   mcProtectTime;

FOCCTRL            xdata   mcFocCtrl;
ONVarible          xdata   ONOFFTest;
MCLedDisplay       xdata   mcLedDisplay;
MCRAMP             xdata   mcSpeedRamp;
SLEEPMODE          xdata   SleepSet;
MotorFRTypeDef		 xdata   mcFRState;
uint16 						 xdata   VSP;

int16              xdata   temp_FOC_UQ,Motor_Loop_Speed_Temp;
extern      uint16 xdata  Power_Currt1;
/*---------------------------------------------------------------------------*/
/* Name		:	int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
/* Input	:	INVlaue，OutLastValue
/* Output	:	int16的变量
/* Description:	滤波函数,用乘法器做的
/*---------------------------------------------------------------------------*/
int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
{
	int16 Result = 0;
	MDU_MA = (INVlaue-OutLastValue);
	MDU_MB = (int16)480;		           			/*写被乘数和乘数*/

	Result = MDU_MB;
	Result += OutLastValue;
	return(Result);
}

/*---------------------------------------------------------------------------*/
/* Name		:	void FaultProcess(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护处理函数，关闭FOC输出，同时将状态变为mcFault
/*---------------------------------------------------------------------------*/
void FaultProcess(void)
{
	MOE     = 0;

	TIM1_CR0 = 0;
	TIM1_CR1 = 0;
	TIM1_CR2 = 0;
	TIM1_CR3 = 0;
	TIM1_CR4 = 0;
	TIM1_IER = 0;	
	
	FOC_CR1    = 0x00;
	ClrBit(DRV_CR, FOCEN);	
	
	Driver_Init();	
	ONOFFTest.PowerOFF_Count = 8000;			
	mcState = mcFault;
	

}

/*---------------------------------------------------------------------------*/
/* Name		:	int16 Abs_F16(int16 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint16 Abs_F16(int16 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	int32 Abs_F32(int32 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint32 Abs_F32(int32 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	void APP_DIV(void)
/* Input	:	void
/* Output	:	void
/* Description:	将所有用到除法的地方，放在同一个中断，以避免中断串扰
/*---------------------------------------------------------------------------*/
void APP_DIV(void)
{
    if( mcPwmInput.PWMDivFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcPwmInput.PWMDuty = MDU_DIV_IDATA_U32(&mcPwmInput.pwm.PWMCompareAMP, &mcPwmInput.PWMARRUpdate);
       mcPwmInput.PWMDivFlag=0;
    }
    if( mcFocCtrl.ESDIVFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcFocCtrl.SQUSpeedDIVEs = MDU_DIV_XDATA_U32(&mcFocCtrl.SQUSysSpeed,&mcFocCtrl.EsValue);
       mcFocCtrl.ESDIVFlag=0;
    }
}

/*****************************************************************************
 * Function:		 void Fault_Overcurrent(CurrentVarible *h_Cur)
 * Description:	 一级软件过流保护
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Overcurrent(FaultVarible *h_Fault)
{
	if(Power_Currt1 >= OverSoftCurrent)
	{
		h_Fault->OverCurrentCnt++;
		if(h_Fault->OverCurrentCnt >= OverSoftCurrentTime)
		{
			h_Fault->OverCurrentCnt = 0;
//			h_Fault->OverCurrentCnt1 = 0;
//			h_Fault->OverCurrentCnt2 = 0;
			mcFaultSource = FaultSoftOVCurrent;
			FaultProcess();
     }
  }
	else
	{
					h_Fault->OverCurrentCnt = 0;

//	  if(h_Fault->OverCurrentCnt > 0)
//		{
//			//h_Fault->OverCurrentCnt--;
//				h_Fault->OverCurrentCnt = 0;
//		}
//		if(h_Fault->OverCurrentCnt1 > 0)
//		{
////			h_Fault->OverCurrentCnt1--;
//				h_Fault->OverCurrentCnt = 0;
//		}
//		if(h_Fault->OverCurrentCnt2 > 0)
//		{
////			h_Fault->OverCurrentCnt2--;
//				h_Fault->OverCurrentCnt = 0;
//		}	
  }
}

/*****************************************************************************
 * Function:		 void Fault_Overcurrent(CurrentVarible *h_Cur)
 * Description:	 二级软件过流保护
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Overcurrent1(FaultVarible *h_Fault)
{
	if(Power_Currt1 >= OverSoftCurrent1)
	{
		h_Fault->OverCurrentCnt1++;
		if(h_Fault->OverCurrentCnt1 >= OverSoftCurrentTime1)
		{
//			h_Fault->OverCurrentCnt = 0;
			h_Fault->OverCurrentCnt1 = 0;
//			h_Fault->OverCurrentCnt2 = 0;
			mcFaultSource = FaultSoftOVCurrent1;
			FaultProcess();
     }
  }
	else
	{
//					h_Fault->OverCurrentCnt1 = 0;

	  if(h_Fault->OverCurrentCnt1 > 0)
		{
			h_Fault->OverCurrentCnt1--;
//				h_Fault->OverCurrentCnt1 = 0;
		}
//		if(h_Fault->OverCurrentCnt2 > 0)
//		{
////			h_Fault->OverCurrentCnt2--;
//				h_Fault->OverCurrentCnt1 = 0;
//		}
			
  }
}

/*****************************************************************************
 * Function:		 void Fault_Overcurrent(CurrentVarible *h_Cur)
 * Description:	 三级软件过流保护
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Overcurrent2(FaultVarible *h_Fault)
{
	if(Power_Currt1 >= OverSoftCurrent2)
	{
		h_Fault->OverCurrentCnt2++;
		if(h_Fault->OverCurrentCnt2 >= OverSoftCurrentTime2)
		{
//			h_Fault->OverCurrentCnt = 0;
//			h_Fault->OverCurrentCnt1 = 0;
			h_Fault->OverCurrentCnt2 = 0;
			mcFaultSource = FaultSoftOVCurrent2;
			FaultProcess();
     }
  }
	else
	{
	  if(h_Fault->OverCurrentCnt2 > 0)
		{
			h_Fault->OverCurrentCnt2--;
//				h_Fault->OverCurrentCnt2 = 0;
		}
//			h_Fault->OverCurrentCnt2 = 0;

  }
}
/*****************************************************************************
 * Function:		 void	Fault_OverVoltage(mcFaultVarible *h_Fault)
 * Description:	 过压欠压保护函数：程序每5ms判断一次，母线电压大于过压保护值时，计数器加一，计数器值超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
                 同理，欠压保护。
	               电机过欠压保护状态下，母线电压恢复到欠压恢复值以上，过压恢复值以下时，计数器加一，超过200次后，恢复。根据档位信息来决定恢复到哪个状态。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_OverUnderVoltage(FaultVarible *h_Fault)
{
	//过压保护
		if(mcFaultSource == FaultNoSource)//程序无其他保护下
		{
				if(mcFocCtrl.mcDcbusFlt > OVER_PROTECT_VALUE)	 //母线电压大于过压保护值时，计数，超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
				{
					h_Fault->OverVoltDetecCnt++;
					if(h_Fault->OverVoltDetecCnt > 500)//检测20ms
					{
						h_Fault->OverVoltDetecCnt = 0;
						mcFaultSource=FaultOverVoltage;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->OverVoltDetecCnt>0)
					{
						h_Fault->OverVoltDetecCnt--;
					}
				}

			//欠压保护

				if(mcFocCtrl.mcDcbusFlt< UNDER_PROTECT_VALUE)
				{
					h_Fault->UnderVoltDetecCnt++;

					if(h_Fault->UnderVoltDetecCnt > 500)//检测20ms
					{
						h_Fault->UnderVoltDetecCnt = 0;
						mcFaultSource=FaultUnderVoltage;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->UnderVoltDetecCnt>0)
					{
						h_Fault->UnderVoltDetecCnt--;
					}
				}
		}

		/*******过压欠压保护恢复*********/
//		if((mcState == mcFault) &&((mcFaultSource==FaultUnderVoltage)||(mcFaultSource==FaultOverVoltage)))
//		{
//			if((mcFocCtrl.mcDcbusFlt< OVER_RECOVER_VALUE)&&(mcFocCtrl.mcDcbusFlt> UNDER_RECOVER_VALUE))
//			{
//				h_Fault->VoltRecoverCnt++;
//				if(h_Fault->VoltRecoverCnt>100)//连续检测1s，若正常则恢复
//				{
//          mcState = mcReady;
//					mcFaultSource=FaultNoSource;
//					h_Fault->VoltRecoverCnt = 0;
//				}
//			}
//			else
//			{
//				h_Fault->VoltRecoverCnt = 0;
//			}
//	 }
}

/*温度保护函数*/
void Fault_Overtemperature(FaultVarible *h_Fault)
  {
		if(mcFocCtrl.mctemperature <= Overtemperature_Value)
		  {
			  h_Fault->OvertemperatureCnt++;
				if(h_Fault->OvertemperatureCnt >= Overtemperature_time)
			 	 {
					  h_Fault->OvertemperatureCnt = 0;
					  mcFaultSource = FaultMotorOverTemperature;
					  FaultProcess();
         }
      }
		else if(mcFocCtrl.mctemperature >= Retemperature_Value)	
		 {
			 h_Fault->OvertemperatureCnt--;
			 if(h_Fault->OvertemperatureCnt <= 0)
			  {
					h_Fault->OvertemperatureCnt = 0;
        }
			 if(Recovertemperature == Enable)
			  {
				 if((mcFaultSource == FaultMotorOverTemperature)&&(mcState == mcFault))
					 {
						 h_Fault->temperatureRecoverCnt++;
						 if(h_Fault->temperatureRecoverCnt >= Recovertemperature_time)
							 {
								 mcState = mcReady;
								 mcFaultSource=FaultNoSource;
								 h_Fault->temperatureRecoverCnt = 0;
							 }
					 } 
				 }					 
     }
		
  }
/*---------------------------------------------------------------------------*/
/* Name		:	void Fault_Detection(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护函数，因保护的时间响应不会很高，采用分段处理，每5个定时器中断执行一次对应的保护
	              常见保护有过欠压、过温、堵转、启动、缺相等保护，调试时，可根据需求，一个个的调试加入。
/*---------------------------------------------------------------------------*/
void Fault_Detection(void)
{
		if(OverSoftCurrentProtect ==Enable)     
		{
		 Fault_Overcurrent(&mcFaultDect);											// 一级软件过流保护
		}
		if(OverSoftCurrentProtect1 ==Enable)     
		{
		 Fault_Overcurrent1(&mcFaultDect);										// 二级软件过流保护
		}
		if(OverSoftCurrentProtect2 ==Enable)     
		{
		 Fault_Overcurrent2(&mcFaultDect);										// 三级软件过流保护
		}	

		if(VoltageProtect==Enable)                            //过欠压保护使能
		{
			Fault_OverUnderVoltage(&mcFaultDect);
		}

	  if(TemperatureProtect==Enable)                       //过温保护使能
		 {
			 Fault_Overtemperature(&mcFaultDect);
		 }
}

/*---------------------------------------------------------------------------*/
/* Name		:	void ONOFF_StartTest(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	启动测试
/*---------------------------------------------------------------------------*/
void ONOFF_StartTest(ONVarible  *h_test)
{
		if((mcSpeedRamp.FlagONOFF==1)&&(mcState!=mcFault))
	{
		 h_test->ON_Count++;
		if(h_test->ON_Count>StartON_Time)
		{
			h_test->ON_Count=0;
			h_test->ONOFF_Times++;
			h_test->ONOFF_Flag=0;
		  mcSpeedRamp.FlagONOFF = 0;
			mcSpeedRamp.BLDC_Value = 0;

		}
  }
	else
	{
		if(mcState!=mcFault)
		{
		  h_test->OFF_Count++;
			if(h_test->OFF_Count>StartOFF_Time)
			{
				h_test->OFF_Count=0;
				h_test->ONOFF_Flag=1;
				 mcSpeedRamp.FlagONOFF = 1;
				 mcSpeedRamp.BLDC_Value  = MAX_BLDC_Duty;

			}
	  }

  }
}

/*---------------------------------------------------------------------------*/
/* Name		:	 uint16 SoftLPF(uint16 Xn1, uint16 Xn0, uint16 K)
/* Input	:	uint16 Xn1, uint16 Xn0, uint16 K
/* Output	:	uint16
/* Description:	软件低通滤波
/*---------------------------------------------------------------------------*/
 int16 SoftLPF(int16 Xn1, int16 Xn0, int16 K)
 {
 	int16 temp16 = 0;
 	int32 Temp32 = 0;

 	Temp32 = (((int32)Xn1 - (int32)Xn0) * (int32)K) >> 15;
 	temp16 = Xn0 + (int16)Temp32;
 	return temp16;
 }


/*---------------------------------------------------------------------------*/
/* Name		:	void LED_Display(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	LED灯显示
/*---------------------------------------------------------------------------*/
void LED_Display(void)
{
	switch(mcFaultSource)
	{
    		case FaultNoSource:
    		    ResetLEDPin;	    	//低电平点亮，高电平灭
    		  break;
    	  case FaultSoftOVCurrent:
				    Led_OnOff(&mcLedDisplay,1);
				  break;
				case FaultSoftOVCurrent1:
					  Led_OnOff(&mcLedDisplay,2);
					break;
    		case FaultSoftOVCurrent2:
            Led_OnOff(&mcLedDisplay,3);
    			break;
    		case FaultHardOVCurrent:
            Led_OnOff(&mcLedDisplay,4);
    			break;
    		case FaultUnderVoltage:
					  Led_OnOff(&mcLedDisplay,5);
					break;
				case FaultOverVoltage:
					  Led_OnOff(&mcLedDisplay,6);
				  break;
    		case  FaultMotorOverTemperature:
            Led_OnOff(&mcLedDisplay,7);
    			break;
				case  FaultLossPhase:
					  Led_OnOff(&mcLedDisplay,8);
					break;
				case  FaultStall:
					  Led_OnOff(&mcLedDisplay,9);
					break;
				case  FaultCommunication:
					  Led_OnOff(&mcLedDisplay,10);
					break;
    		default:
    			break;
  }

}

  //LED灯的闪烁
  void Led_OnOff(MCLedDisplay *hLedDisplay,uint8 htime)
  {
		hLedDisplay->LedCount++;
	  if(hLedDisplay->LedCount<hLedDisplay->Counttime)
	   {
		    if(hLedDisplay->Count<200)
	      {
				 hLedDisplay->Count++;

	      }
				else if((hLedDisplay->Count>=200)&&(hLedDisplay->Count<201))
				{
					hLedDisplay->Count=0;
				  LEDPinONOFF;
					hLedDisplay->LedTimCot++;
				}
				else
					;
				if(hLedDisplay->LedTimCot>=2*htime)
		  	{
					hLedDisplay->Count=202;
				  SetLEDPin;
				}
      }
	    else if(hLedDisplay->LedCount>=hLedDisplay->Counttime)
	    {
	     hLedDisplay->LedCount=0;
	     hLedDisplay->LedTimCot=0;
	     hLedDisplay->Count=0;
	    }
 }

/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_Genal_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	U(K) = U(k-1) + Kp*(E(k)-E(k-1)) + Ki*E(k) ----- (Uk_min < U(k) < Uk_max)b
	Description   :	PI控制
	Input         :	Xn1--E(K-1)
	                Yn0--U(K-1)
					Xn2--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间为3.8us
-------------------------------------------------------------------------------------------------*/
int16 HW_Genal_PI(int16 Xn1, int16 Yn0, int16 Xn2)
{
		PI_KP = SKP;
		PI_KI = SKI;
		PI_UKMAX = SOUTMAX;
		PI_UKMIN = SOUTMIN;
		PI_EK =  Xn1;     	  //初始化E(K-1)
		PI_LPF_CR |= 0x02;	  // Start PI
		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
		PI_UK =  Yn0;           //初始化U(K-1)
		PI_EK =  Xn2;	      //填入EK
		PI_LPF_CR |= 0x02;	  // Start PI
		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
		PI_UK+=(SKP/4096 +1);
		return PI_UK;
}
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_One_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	Description   :	PI控制
	Input         :	Xn1--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间us
-------------------------------------------------------------------------------------------------*/
int16 HW_One_PI(int16 Xn1)
{
	  PI_EK =  Xn1;	      //填入EK
	  PI_LPF_CR |= 0x02;	  // Start PI
	  _nop_();  _nop_();  _nop_();  _nop_();  _nop_();
	  PI_UK+=(SKP/4096 +1);
	  return PI_UK;
}
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 LPF(int16 Xn1, int16 Xn0, int8 K)
	Description   :	LFP控制
	Input         :	Xn1--当前输入值
	                Xn0--上一次滤波输出值
									K--LPF滤波系数
  Output				:	LPF_Y--当前滤波输出值，执行时间为4us。
-------------------------------------------------------------------------------------------------*/
int16 LPFFunction(int16 Xn1, int16 Xn0, int8 K)
{
	LPF_K = K;
	LPF_X = Xn1;
	LPF_Y = Xn0;
	SetBit(PI_LPF_CR, LPFSTA);
	_nop_();_nop_();_nop_();_nop_();_nop_();
	return LPF_Y;
}

/*---------------------------------------------------------------------------*/
/* Name		:	void VSPSample(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	VSP采样
/*---------------------------------------------------------------------------*/
void VSPSample(void)
{
	/*****VREF的采样获取值并滤波******/
	
	  if((VSP > ON_Duty)&&(mcFocCtrl.mcDcbusFlt > Start_PROTECT_VALUE))
		{		
			mcSpeedRamp.FlagONOFF  = 1;	
		}
	  else if(VSP < OFF_Duty)//电机停机
		{	
			mcSpeedRamp.FlagONOFF  = 0;			
		}
	  if(mcSpeedRamp.FlagONOFF  == 1)
		{			
		   if(VSP > MAX_Duty)    //最小转速运行
				{
					mcSpeedRamp.BLDC_Value  = MAX_BLDC_Duty;
				}
				else if(VSP > MIN_Duty)//调速
				{
					mcSpeedRamp.BLDC_Value  = MIN_BLDC_Duty + BLDC_K*(VSP-MIN_Duty);						
				}
				else		     //最大转速运行
				{
					mcSpeedRamp.BLDC_Value  = MIN_BLDC_Duty;
				}
		}
	  else if(mcSpeedRamp.FlagONOFF  == 0)
		{
			mcSpeedRamp.BLDC_Value = 0;
    }

}

/*---------------------------------------------------------------------------*/
/* Name		:	void StarRampDealwith(void)
/* Input	:	NO
/* Output	:	NO
/* Description:
/*---------------------------------------------------------------------------*/
void StarRampDealwith(void)
{
	uint8 ANGLE_MTemp,ANGLE_DTemp;
	
		if((McStaSet.SetFlag.BLDCSetFlag == 4)&&(mcState == mcRun))
		{		
			if(DRV_DR > HIGH_BLDC_Duty)
			{
				/*-------------------------------------------------------------------------------------------------
				屏蔽续流时间（角度）设置
				-------------------------------------------------------------------------------------------------*/
				ANGLE_MTemp = (uint8)(TIM1_CR1&0x7F);
				
			      if(ANGLE_MASK_R(20) > ANGLE_MTemp)  { TIM1_CR1 = (TIM1_CR1 &(0x80))|(ANGLE_MTemp+1);}      //续流屏蔽+超前角度<60，最好不要大于30度 
			 else if(ANGLE_MASK_R(20) < ANGLE_MTemp)  { TIM1_CR1 = (TIM1_CR1 &(0x80))|(ANGLE_MTemp-1);}					
 

				/*-------------------------------------------------------------------------------------------------
				检测到过零点后的延迟换相时间（角度）设置
				-------------------------------------------------------------------------------------------------*/
				ANGLE_DTemp = (uint8)(TIM1_CR2&0x7F);
				
			      if(ANGLE_DELAY_R(25) > ANGLE_DTemp)  { TIM1_CR2 = (TIM1_CR2 &(0x80))|(ANGLE_DTemp+1);}     //超前角度（0-30度）30度为不超前不滞后
			 else if(ANGLE_DELAY_R(25) < ANGLE_DTemp)  { TIM1_CR2 = (TIM1_CR2 &(0x80))|(ANGLE_DTemp-1);}							 
			 
			}
			else if(DRV_DR < LOW_BLDC_Duty)
			{

				/*-------------------------------------------------------------------------------------------------
				屏蔽续流时间（角度）设置
				-------------------------------------------------------------------------------------------------*/
				ANGLE_MTemp = (uint8)(TIM1_CR1&0x7F);
				
			      if(ANGLE_MASK_R(20) > ANGLE_MTemp)  { TIM1_CR1 = (TIM1_CR1 &(0x80))|(ANGLE_MTemp+1);}
			 else if(ANGLE_MASK_R(20) < ANGLE_MTemp)  { TIM1_CR1 = (TIM1_CR1 &(0x80))|(ANGLE_MTemp-1);}					


				/*-------------------------------------------------------------------------------------------------
				检测到过零点后的延迟换相时间（角度）设置
				-------------------------------------------------------------------------------------------------*/
				ANGLE_DTemp = (uint8)(TIM1_CR2&0x7F);
				
			      if(ANGLE_DELAY_R(25) > ANGLE_DTemp)  { TIM1_CR2 = (TIM1_CR2 &(0x80))|(ANGLE_DTemp+1);}
			 else if(ANGLE_DELAY_R(25) < ANGLE_DTemp)  { TIM1_CR2 = (TIM1_CR2 &(0x80))|(ANGLE_DTemp-1);}							 

			}
		}
}
