/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Customer.h
* Author             : Vina Peng, Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-21
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __CUSTOMER_H_
#define __CUSTOMER_H_

/*程序参数------------------------------------------------------------------*/
#define   PROGRAM_CODE_NUME      (20237)
#define   PROGRAM_CODE_VERSION   (01)

#define I_ValueX(Curr_Value)            (Curr_Value * HW_RSHUNT * HW_AMPGAIN / HW_ADC_REF)
#define I_ValueX_BUS(Curr_Value)        (Curr_Value * HW_RSHUNT_BUS * HW_AMPGAIN_BUS / HW_ADC_REF)
#define I_Value(Curr_Value)             _Q15(I_ValueX(Curr_Value))
/*芯片参数值-------------------------------------------------------------------*/
 /*CPU and PWM Parameter*/
 #define MCU_CLOCK                      (24.0)                                  // (MHz) 主频
 #define PWM_FREQUENCY                  (16.0)                                  // (kHz) 载波频率

 /*deadtime Parameter*/
 #define PWM_DEADTIME                   (1.0)                                   // (us) 死区时间

 /*single resistor sample Parameter*/
 #define MIN_WIND_TIME                  (1.7)                                   // (us) 单电阻最小采样窗口，建议值死区时间+0.9us
/*电机参数值------------------------------------------------------------------*/
/*motor Parameter*/
 #define		Pole_Pairs              (4.0)					     			// 极对数
 #define 	RS                          (21.2)				    				// 相电阻 , ohm
 #define 	LD                          (0.080)									// D轴相电感 , H
 #define 	LQ                          (0.080)									// Q轴相电感 , H
 #define		Ke                      (69.1)								    // 反电动势常数, V/KRPM 

 #define MOTOR_SPEED_BASE               (4000.0)                                // (RPM) 速度基准
/*硬件板子参数设置值------------------------------------------------------------*/
 /*PWM high or low level Mode*/
 /*根据驱动芯片的类型选择，大部分芯片为High_Level*/
 #define High_Level                     (0)                                     // 驱动高电平有效
 #define Low_Level                      (1)                                     // 驱动低电平有效
 #define UP_H_DOWN_L                    (2)                                     // 上桥臂高电平有效，下桥臂低电平有效
 #define UP_L_DOWN_H                    (3)                                     // 上桥臂低电平有效，下桥臂高电平有效
 #define PWM_Level_Mode                 (High_Level)

 /*hardware current sample Parameter*/
 /*电流基准的电路参数*/
 /*weizhen*/
 #define HW_RSHUNT                      (0.22)                                 	// (Ω)  采样电阻
 #define HW_ADC_REF                     (4.5)                                   // (V)  ADC参考电压
 #define HW_AMPGAIN                     (5.0)                                   // 运放放大倍数
 
 /*母线采样电阻及放大倍数*/
 #define HW_RSHUNT_BUS                  (0.22)                                 	// (Ω)  采样电阻
 #define HW_AMPGAIN_BUS                 (5.0)                                   // 运放放大倍数

 /* current set value */
 /*hardware voltage sample Parameter*/
 /*母线电压采样分压电路参数*/
 #define RV1                            (520.0)                                 // (kΩ) 母线电压分压电阻1
 #define RV2                            (470.0)                                 // (kΩ) 母线电压分压电阻2
 #define RV3                            (6.8)                                   // (kΩ) 母线电压分压电阻3
 #define VC1                            (1.0)                                   // 电压补偿系数
 #define RV                             ((RV1 + RV2 + RV3) / RV3)               // 分压比
 #define HW_BOARD_VOLT_MAX              (HW_ADC_REF * RV)                       // (V)  ADC可测得的最大母线电压
/*时间设置值-------------------------------------------------------------------*/
 #define Calib_Time                     (1000)                                  // 校正次数，固定1000次，单位:次
 #define Charge_Time                    (30)                                     // (ms) 预充电时间，单位：ms
 #define Align_Time                     (1) //400                                    // (ms) 预定位时间，单位：ms
/*正常运行时估算算法的参数设置值-------------------------------------------------*/
 #define OBS_KSLIDE                     _Q15(0.85)                              // SMO算法里的滑膜增益值
 #define E_BW_Wind                      (800.0)//600(BASE_FREQ*2)                  // PLL算法里的反电动势滤波值
 #define E_BW_Start						(70.0)
 #define E_BW                           (400.0)//(BASE_FREQ*2)                  // PLL算法里的反电动势滤波值
/*逆风判断时的估算算法设置值-----------------------------------------------------*/
 #define TailWind_Time                  (300)                                   // (ms) 顺逆风检测时间
 #define ATO_BW_Wind                    (40.0)//120.0-PLL 120.0-smo             // 逆风判断观测器带宽的滤波值，经典值为8.0-100.0
 #define SPD_BW_Wind                    (15.0)//10.0-PLL  ,10.0-smo             // 逆风判断速度带宽的滤波值，经典值为5.0-40.0

 /**逆风顺风状态下的KP、KI****/
 #define DQKP_TailWind                  _Q12(0.8)                               //_Q12(1.0)-PLL ,   _Q12(1.5)   -smo
 #define DQKI_TailWind                  _Q15(0.05)                              //_Q15(0.08)-PLL  ,_Q15(0.2)-smo
/*启动参数参数值----------------------------------------------------------------*/
 /*********** RPD parameter ***********/
 /******* 初始位置检查参数 **********/
 #define PosCheckEnable                 (0)                                     // 初始位置使能
 #define AlignTestMode                  (0)                                     // 预定位测试模式
 /*脉冲注入时间长于2ms 或 低于2ms*/
 #define Long_Inject                    (0)                                     // 脉冲注入时间长于2ms,若时间长于4ms，则要修改定时器分频
 #define Short_Inject                   (1)                                     // 脉冲注入时间低于2ms
 #define InjectTime                     (Short_Inject)

 #define RPD_Time                       (3)                                     // (ms) 每次RPD的时间
 #define RPD_CurValue                   (1.0)                                   // (A)  RPD过流值
 #define DAC_RPDCurValue                _Q7(I_ValueX(RPD_CurValue * 2))

 /***预定位的Kp、Ki****/
 #define DQKP_Alignment                 _Q12(1.5)                               // 预定位的KP
 #define DQKI_Alignment                 _Q12(0.05)                              // 预定位的KI
 #define ID_Align_CURRENT               I_Value(0.0)                            // (A) D轴定位电流
 #define IQ_Align_CURRENT               I_Value(0.01)                           // (A) Q轴定位电流
 #define IQ_Align_CURRENT_CCW			I_Value(0.6)
 #define Align_Angle                    (30.0)                                  // (°) 预定位角度

 /***启动电流****/
 #define ID_Start_CURRENT               I_Value(0.0)                            // (A) D轴启动电流
 #define IQ_Start_CURRENT               I_Value(0.50)                            // (A) Q轴启动电流

 /***运行电流****/
 #define ID_RUN_CURRENT                 I_Value(0.0)                            // (A) D轴运行电流
 #define IQ_RUN_CURRENT                 I_Value(0.30)                            // (A) Q轴运行电流

 /***限制电流****/
 #define LIMIT_MIN_CURRENT              I_Value(0.10)                           // (A) Q轴限制电流

 ///********Omega启动的参数**********/
 #define ATO_BW                         (10.0)                                  // 观测器带宽的滤波值，经典值为1.0-200.0
 #define ATO_BW_CCW						(18.0)
 #define ATO_BW_RUN                     (20.0)
 #define ATO_BW_RUN1                    (30.0)
 #define ATO_BW_RUN2                    (40.0)
 #define ATO_BW_RUN3                    (40.0)//(50.0)
 #define ATO_BW_RUN4                    (40.0)//(66.0)//调整FOC_EKP/EKI，解决堵风口时电流异常问题

 #define SPD_BW                         (15.0)                                  // 速度带宽的滤波值，经典值为5.0-40.0
 #define ATT_COEF                       (0.85)                                  // 无需改动
/*转速参数值-------------------------------------------------------------------*/
 /* motor start speed value */
 //open 算法启动参数
 #define MOTOR_OPEN_ACC                 (8.0)                                  // 强拖启动的增量(每载波周期加一次)8.0
 #define MOTOR_OPEN_ACC_MIN             (0.2)                                   // 强拖启动的初始速度
 #define MOTOR_OPEN_ACC_INC             (2.0)
 #define MOTOR_OPEN_ACC_CNT             (1.0)                                 // 强拖启动的执行次数(MOTOR_OPEN_ACC_CNT*256)
 #define MOTOR_OPEN_ACC_CYCLE           (5)                                     // 强拖启动循环拖动的次数

 //OMEGA启动参数
 #define Motor_Omega_Ramp_ACC_Antiwind  (12.0)                                   // omega启动的增量   12
 #define Motor_Omega_Ramp_ACC           (3.0) //3                                  // omega启动的增量   3
 #define MOTOR_OMEGA_ACC_MIN            (20.0)                                  // (RPM) omega启动的最小切换转速
 #define MOTOR_OMEGA_ACC_END            (60.0)                                  // (RPM) omega启动的限制转速

 /* motor loop control speed value */
 #define MOTOR_LOOP_RPM                 (120.0)                                 // (RPM) 由mode 0到mode1切换转速，即闭环切换转速

 /* motor run speed value */
 //电机运行时最大最小转速、堵转保护转速
 #define MOTOR_SPEED_SMOMIN_RPM         (200.0)                                 // (RPM) SMO运行最小转速
 #define MOTOR_SPEED_MIN_RPM            (200.0)                                // (RPM) 运行最小转速
 #define MOTOR_SPEED_MAX_RPM            (2000.0)                                // (RPM) 运行最大转速
 #define MOTOR_SPEED_LIMIT_RPM          (2100.0)
 #define MOTOR_SPEED_STAL_MAX_RPM       (2500.0)                                // (RPM) 堵转保护转速
 #define MOTOR_SPEED_STAL_MIN_RPM       (80.0)

 #define MOTOR_SPEED_STOP_RPM           (250.0)                                 // (RPM) 运行最小转速

 #define Motor_Max_Power                (2685)                                  //正常运行时的最大功率175W
 #define Motor_Min_Power                (200)									//正常运行时的最小功率11.6W
 #define Motor_Erupt_Power              (3300)									//爆发状态下的功率220W
 
/*电机开机、关机的设置----------------------------------------------------------*/
 /* motor ON/0FF value */
 #define OFFPWMDuty                     _Q15(0.04)                              // 关机PWM占空比，小于该占空比关机                                                                                //关机PWM占空比，小于该占空比时关机
 #define OFFPWMDutyHigh                 _Q15(1.0)                               // 关机PWM占空比，大于该占空比关机
 #define ONPWMDuty                      _Q15(0.07)                              // 开机PWM占空比，大于该占空比时开机
 #define MINPWMDuty                     _Q15(0.07)                              // 速度曲线上最小PWM占空比
 #define MAXPWMDuty                     _Q15(1.0)                               // 速度曲线上最大PWM占空比

 /*******运行时的参数*****************/
/*电流环参数设置值--------------------------------------------------------------*/
 #define DQKPStart                      _Q12(0.5)                               // DQ轴KP
 #define DQKIStart                      _Q15(0.01)                              // DQ轴KI

 #define DQKP                           _Q12(0.5)                               // DQ轴KP
 #define DQKI                           _Q15(0.01)                              // DQ轴KI
 /* D轴参数设置 */
 #define DOUTMAX                        _Q15(0.30)                              // D轴最大限幅值，单位：输出占空比
 #define DOUTMIN                        _Q15(-0.30)                             // D轴最小限幅值，单位：输出占空比
 /* Q轴参数设置，默认0.99即可 */
 #define QOUTMAX                        _Q15(0.99)                              // Q轴最大限幅值，单位：输出占空比
 #define QOUTMIN                        _Q15(-0.99)                             // Q轴最小限幅值，单位：输出占空比
 #define QOUTINC                        (4)                                     // Q轴电流增大步进值,开环控制时有效4
 #define QOUTCURRENT                    (0.8)                                   // (A) Q轴输出电流,开环控制时有效
 #define QOUTVALUE                      I_Value(QOUTCURRENT)
/*外环参数设置值----------------------------------------------------------------*/
 #define SPEED_LOOP_TIME                (10)                                    // (ms) 速度环调节周期 风扇速度环50，功率环5

 #define SKP                            _Q12(0.08)                              // 外环KP
 #define SKI                            _Q12(0.005)                             // 外环KI

 #define SOUTMAX                        I_Value(2.2)                            // (A) 外环最大限幅值
 #define SOUTMIN                        I_Value(0.005)                          // (A) 外环最小限幅值
 
 #define SPEED_INC                      (15.0)                                  // 速度环增量
 #define SPEED_DEC                      (60.0)                                  // 速度环减量
  
 #define		Motor_EmptyLoad_Check	    (1)                                 //运行时空载带载检测使能
 #define		Motor_Load_Speed			_Q15(400/MOTOR_SPEED_BASE)          //切闭环时带载转速
 #define        Motor_EmptyLoad_Speed       _Q15(1600.0/MOTOR_SPEED_BASE)       //切闭环时空载转速

 #define SKP1                           _Q12(0.3)                               // 空载时外环KP
 #define SKI1                           _Q12(0.003)                             // 空载时外环KI
 #define SOUTMAX1                       I_Value(0.8)                            // 空载时外环最大限幅值


 /*外环使能*/
 #define OUTLoop_Disable                (0)                                     // 关闭外环
 #define OUTLoop_Enable                 (1)                                     // 使能外环
 #define OUTLoop_Mode                   (OUTLoop_Enable)

 /*外环选择功率环或速度环*/
 #define POWER_LOOP_CONTROL             (0)                                     //恒功率
 #define SPEED_LOOP_CONTROL             (1)                                     //恒转速
 #define CURRE_LOOP_CONTROL             (2)                                     //恒扭矩
 #define Motor_Speed_Control_Mode       (POWER_LOOP_CONTROL)

 //调速模式
 #define PWMMODE                        (0)                                     // PWM调速
 #define SREFMODE                       (1)                                     // 模拟调速
 #define NONEMODE                       (2)                                     // 直接给定值，不调速
 #define UARTMODE                       (3)
 #define SPEED_MODE                     (NONEMODE)

 
/*模式选择设置值----------------------------------------------------------------*/
 /*IPM测试模式*/
 #define IPMtest                        (0)                                     // IPM测试或者MOS测试，MCU输出固定占空比
 #define NormalRun                      (1)                                     // 正常按电机状态机运行
 #define IPMState                       (NormalRun)

 /*估算器模式选择*/
 #define SMO                            (0)                                     // SMO ,滑膜估算
 #define PLL                            (1)                                     // PLL ,锁相环
 #define EstimateAlgorithm              (PLL)

 /*顺逆风判断设置*/
 #define NoTailWind                     (0)                                     // 无逆风顺风判断
 #define TailWind                       (1)                                     // 逆风顺风判断
 #define TailWind_Mode                  (TailWind)

 /*顺逆风判断方法*/
 #define RSDMethod                      (0)                                     // RSD比较器方法
 #define BEMFMethod                     (1)                                     // BEMF方法
 #define FOCMethod                      (2)                                     // FOC计算方法
 #define FRDetectMethod                 (FOCMethod)

 /*开环启动模式选择*/
 #define Open_Start                     (0)                                     // 开环强拖启动
 #define Omega_Start                    (1)                                     // Omega启动
 #define Open_Omega_Start               (2)                                     // 先开环启，后Omega启动
 #define Open_Start_Mode                (Omega_Start)

 /*电流采样模式*/
 #define Single_Resistor                (0)                                     // 单电阻电流采样模式
 #define Double_Resistor                (1)                                     // 双电阻电流采样模式
 #define Three_Resistor                 (2)                                     // 三电阻电流采样模式
 #define Shunt_Resistor_Mode            (Double_Resistor)

 #define OverModulation                 (0)                                     // 0-禁止过调制，1-使能过调制
 
 /*正反转模式*/
 #define IRMODE                         (1)                                     // 正反转模式，正转为0，反转为1
 
/*保护参数值-------------------------------------------------------------------*/
 /*硬件过流保护*/
 #define Hardware_FO_Protect            (1)                                     // 硬件FO过流保护使能，适用于IPM有FO保护的场合
 #define Hardware_CMP_Protect           (2)                                     // 硬件CMP比较过流保护使能，适用于MOS管应用场合
 #define Hardware_FO_CMP_Protect        (3)                                     // 硬件CMP比较和FO过流保护都使能
 #define Hardware_Protect_Disable       (4)                                     // 硬件过流保护禁止，用于测试
 #define HardwareCurrent_Protect        (Hardware_CMP_Protect)                  // 硬件过流保护实现方式

 /*硬件过流保护比较值来源*/
 #define Compare_DAC                    (0)                                     // DAC设置硬件过流值
 #define Compare_Hardware               (1)                                     // 硬件设置硬件过流值
 #define Compare_Mode                   (Compare_DAC)                           // 硬件过流值的来源

 #define OverHardcurrentValue           (5.0)//(7.0)                                   // (A) DAC模式下的硬件过流值

 /*软件过流保护*/
 #define OverSoftCurrentValue           I_Value(6.0)//(7.0)                            // (A) 软件过流值

 /*过流恢复*/
 #define CurrentRecoverEnable           (1)                                     // 过流保护使能位, 0，不使能；1，使能
 #define OverCurrentRecoverTime         (1000)                                  // (ms) 过流保护恢复时间

 #define VoltageProtectEnable           (1)                                     // 电压保护，0,不使能；1，使能
 #define StartProtectEnable             (1)                                     // 启动保护，0,不使能；1，使能
 #define StallProtectEnable             (1)                                     // 堵转保护，0,不使能；1，使能
 #define PhaseLossProtectEnable         (1)                                     // 缺相保护，0,不使能；1，使能
 #define VTHProtectEnable			    (0)                                     // 测温保护，0,不使能；1，使能

 /*过欠压保护*/
 #define Over_Protect_Voltage           (260*1.414)                                   // (V) 直流电压过压保护值
 #define Over_Recover_Vlotage           (245*1.414)                                   // (V) 直流电压过压保护恢复值
 #define Under_Protect_Voltage          (180*1.414)                                   // (V) 直流电压欠压保护值
 #define Under_Recover_Vlotage          (200*1.414)                                   // (V) 直流电压欠压保护恢复值

 /*缺相保护*/
 #define    PhaseLossCurrentValue          I_Value(0.2)                            // (A)  缺相电流值
 #define    PhaseLossRecoverTime           (600)                                   // (ms) 缺相保护时间

 /*堵转保护*/
 #define    StallCurrentValue1             I_Value(3.4)                            // (A)  堵转过流值
 #define    StallRecoverTime               (200)                                  // (ms) 启动运行时间

 /*启动保护*/
 #define    StartProtectRestartTimes       (5)                                     // 启动保护重启次数，单位：次
 #define    StallProtectRestartTimes       (5)                                     // 堵转保护重启次数，单位：次
 #define    PhaseLossProtectRestartTimes   (5)                                     // 缺相保护重启次数，单位：次

 /******启停测试参数******/
 #define    StartONOFF_Enable              (0)
 #define    StartON_Time                   (4000)                                  // (ms) 启动运行时间
 #define    StartOFF_Time                  (12000)                                  // (ms) 停止时间

 #define    StopBrakeFlag                  (0)
 #define    StopWaitTime                   (2000)                                  // (ms) 刹车等待时间

 #define    ENABLE					        (1)
 #define    NO_ABLE						    (0)

 #define    SLEEPMODE_EN                    (NO_ABLE)       //睡眠模式使能
 
 #define    SPEED_LIMIT_ENABLE              (1)         //
 #define    PI_RUN_MIN_CURRENT			    I_Value(0.2)
																			
 #define 	POWER_LIMIT_ENABLE				         (NO_ABLE)//1-限功率 0-不限功率
 #define 	LIMIT_POWER								 (POWER_220W)   

 #define 	POWER_270W								 (4500)
 #define 	POWER_260W								 (4350)
 #define 	POWER_250W								 (4150)
 #define 	POWER_240W								 (4000)
 #define    POWER_230W								 (3800)
 #define    POWER_220W								 (3650)
 #define    POWER_180W								 (3000)
 #define    POWER_92W								 (1500)  //
 #define    POWER_62W								 (1000)
 #define    POWER_TEST								 (1000)

 #endif
