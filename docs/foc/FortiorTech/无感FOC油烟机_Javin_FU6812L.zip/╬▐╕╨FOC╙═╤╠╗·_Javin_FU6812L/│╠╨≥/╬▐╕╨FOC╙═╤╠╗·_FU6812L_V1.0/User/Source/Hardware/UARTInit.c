/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : UARTInit.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains UART initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/
#include <FU68xx_2.h>
#include <Myproject.h>
/* Private variables ----------------------------------------------------------------------------*/
MCUART Uart;

const uint16  SpeedGiven[10] ={0,250,500,750,1000,1250,1500,1750,2000,2250};

#define UartRxMinPow    3
#define UartRxMaxPow    85
#define UartRxPowK      ((float)(Motor_Max_Power-Motor_Min_Power)/(float)(UartRxMaxPow-UartRxMinPow))
#define UartRxPowKErupt ((float)(Motor_Erupt_Power-Motor_Min_Power)/(float)(UartRxMaxPow-UartRxMinPow))
void UART_Init(void)
{
    SetBit(PH_SEL, UARTEN);     //p0[6]as UART_RXD; p0[5]as UART_TXD
    UT_MOD1 = 0;
    UT_MOD0 = 1;                //8bit波特率可变UART模式
    SM2 = 0;                    //禁止Mode2和Mode3多机通讯
    REN = 1;                    //使能接收
    ES0 = 0;                    //先关中断

    PUART1=0;                   //中断优先级时最低
    PUART0=0;

//  UT_BAUD =0x9b;              //default baudrate:9600-0x9b,1200-0x4E1
	UT_BAUD = 0x270&0x3FF;      //baudrate 2400; 624=24000000/16/2400-1
    ES0 = 1;                    //发送/接受中断使能
}
void UartTxdate(uint16* sndBuf, int32 len)
{
    uint16 i=0;
  for(i=0;i<len;i++)
    {
      UART_SendData(*sndBuf++);
    }
}
void UART_SendData(unsigned char T_Data)
{
    UT_DR = T_Data;
//    while(!(TI==1));        //等待发送完成
//    TI = 0;                 //发送完成中断标志位清零
}
/***************处理串口接收到的数据************/
void UartDealResponse(void)
{
    static uint8 UartTxNumCnt = 0;
    uint16 UartTxBit3 = 0;
    if(++UartTxNumCnt>=4)   UartTxNumCnt = 0;
    Uart.T_DATA[0] = 0xAA;
    Uart.T_DATA[1] = 0xAF;
    Uart.T_DATA[2] = UartTxNumCnt;
    if(UartTxNumCnt==0)         
        UartTxBit3 = mcFaultSource;                                 //反馈故障码
    else if(UartTxNumCnt == 1)                                      //建议反馈转速数据为实际转速的十六分之一
    {
        UartTxBit3 = mcFocCtrl.SpeedFlt*MOTOR_SPEED_BASE/32767;
        UartTxBit3 = UartTxBit3/15;
    }
    else if(UartTxNumCnt == 2)                                      //mcFocCtrl.Powerlpf为电机功率参数，由于电机参数区别，每款电机实际功率与mcFocCtrl.Powerlpf间比例系数需实际测量。建议反馈数据为电机实际功率的二分之一
    {
        UartTxBit3 = mcFocCtrl.Powerlpf/120;
    }
    else if(UartTxNumCnt == 3)
    {
        UartTxBit3 = mcState;
    }
    Uart.T_DATA[3] = (uint8)UartTxBit3;
    Uart.T_DATA[4] = 0x00;
    Uart.T_DATA[5] = Uart.T_DATA[0]+Uart.T_DATA[1]+Uart.T_DATA[2]+Uart.T_DATA[3]+Uart.T_DATA[4];
    Uart.UsaTxlen =6;
    Uart.SendCnt=0;
    UART_SendData(Uart.T_DATA[0]);
}
//void UartDealComm(void)
//{
//     uint16 j=0;
//     uint16 checkdate=0x00;
//     if(Uart.ResponceFlag==1)//10ms
//     {
//         UartDealResponse();
//         Uart.T_DATA[0]     = 0xaa;
//         Uart.T_DATA[1]     = mcState;
//         Uart.T_DATA[2]     = (uint16)(((int32)mcFocCtrl.SpeedFlt*2400)>>19);// actual speed/16 ,if actual speed=1000rpm/min,then TxBuf[2]=63
//         Uart.T_DATA[3]     = (uint16)(((int32)mcFocCtrl.mcDcbusFlt*626)>>16);// DC bus feedback, 1 stand for 2V
//         Uart.T_DATA[4]     = mcFaultSource;//Fault state
//         Uart.T_DATA[5]     = 0x00;
//         Uart.T_DATA[6]     = 0x00;
//         Uart.T_DATA[7]     = 0x00;
//         for( j = 0; j < 7; j++ )
//         {
//          checkdate += Uart.T_DATA[j];
//         }
//         Uart.T_DATA[8]     = checkdate;
//         Uart.T_DATA[9]     = 0x55;
//         UartTxdate(Uart.T_DATA,10);
//         Uart.ResponceFlag=0;
//     }
//}

void UartDealComm(void)
{
    uint8   Cal_Rs = 0;
    uint8   UartTargetPow = 0;
    if(Uart.ResponceFlag==1)
    {
        if(Time.PowerUpTimeCount>300)
        {
            Cal_Rs = Uart.R_DATA[0]+Uart.R_DATA[1]+Uart.R_DATA[2]+Uart.R_DATA[3]+Uart.R_DATA[4];
            if(Cal_Rs == Uart.R_DATA[5])
            {
                UartTargetPow = Uart.R_DATA[2];
                if(UartTargetPow>UartRxMaxPow)    UartTargetPow = 85;
                if(UartTargetPow>1)
                {
                    mcSpeedRamp.FlagONOFF = 1;
                    #if ((Motor_Speed_Control_Mode==POWER_LOOP_CONTROL)) // 调速方式 --恒功率
                    {
                        if(UartTargetPow<UartRxMinPow)  mcSpeedRamp.TargetValue = Motor_Min_Power;
                        else                            
                        {
                            if(EruptSpeedCtr.EruptStatus)
                                mcSpeedRamp.TargetValue = Motor_Min_Power+UartRxPowKErupt*(UartTargetPow-UartRxMinPow);
                            else
                                mcSpeedRamp.TargetValue = Motor_Min_Power+UartRxPowK*(UartTargetPow-UartRxMinPow);
                        }
                    }
                    #elif ((Motor_Speed_Control_Mode==SPEED_LOOP_CONTROL)) // 调速方式 --恒转速				
                    {
                        mcSpeedRamp.TargetValue=_Q15(SpeedGiven[UartTargetPow]/MOTOR_SPEED_BASE);
                    }
                    #elif ((Motor_Speed_Control_Mode==CURRE_LOOP_CONTROL)) // 调速方式 --恒电流（恒扭矩）
                    {
                        UartTargetPow = I_Value(0.215)*UartTargetPow+I_Value(1.315);
                        
                        mcSpeedRamp.TargetValue = _Q15(2000/MOTOR_SPEED_BASE);
                        if(UartTargetPow<I_Value(0.2)) 
                        {                      
                          UartTargetPow = I_Value(0.2);
                        }
                        else if(UartTargetPow > SOUTMAX)
                        {
                          UartTargetPow = SOUTMAX;
                          mcSpeedRamp.TargetValue = _Q15(2100/MOTOR_SPEED_BASE);// 限制转速
                        }
                        PI_UKMAX = UartTargetPow;											
                    }
                    #endif
                }
                else
                {
                    mcSpeedRamp.FlagONOFF = 0;
                    mcSpeedRamp.TargetValue = 0;
                    if((mcFaultSource!=FaultUnderVoltage)&&(mcFaultSource!=FaultOverVoltage))
                    {
                        mcFaultDect.AOpencnt=0;
                        mcFaultDect.BOpencnt=0;
                        mcFaultDect.COpencnt=0;
                        memset(&mcProtectTime,0, sizeof(ProtectVarible));
                        mcFaultSource = FaultNoSource;
                        if(mcState==mcFault)    mcState = mcReady;
                    }
                }
            }
        }
        Uart.ResponceFlag = 0;
        Uart.R_DATA[0] = 0;
        Uart.R_DATA[1] = 0;
    }
    if(Time.UartTxTime==100)
    {
        Time.UartTxTime = 0;
        UartDealResponse();
    }
#endif
}


