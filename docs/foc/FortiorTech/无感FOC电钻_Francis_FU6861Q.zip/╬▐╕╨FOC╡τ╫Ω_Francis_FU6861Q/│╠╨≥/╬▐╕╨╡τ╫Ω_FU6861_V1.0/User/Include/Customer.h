/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Customer.h
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-21
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __CUSTOMER_H_
#define __CUSTOMER_H_

/*芯片参数值-------------------------------------------------------------------*/
 /*CPU and PWM Parameter*/
 #define MCU_CLOCK                      (24.0)                                  // (MHz) 主频
 #define PWM_FREQUENCY                  (30.0)                                  // (kHz) 载波频率
 #define PWM_FREQUENCY_BLDC             (16.0)                                  // (kHz) 载波频率

 /*deadtime Parameter*/
 #define PWM_DEADTIME                   (0.0)                                   // (us) 死区时间

 /*single resistor sample Parameter*/
 #define MIN_WIND_TIME                  (PWM_DEADTIME + 0.8)                                   // (us) 单电阻最小采样窗口，建议值死区时间+0.9us

/*电机参数值-------------------------------------------------------------------*/// 未知名电机
 #define Pole_Pairs                     (2.0)                                     // 极对数
 #define RS                             (0.015)                                // (Ω) 相电阻
 #define LD                             (0.000003)                               // (H) D轴电感
 #define LQ                             (0.000003)                               // (H) Q轴电感
 #define KeVpp                          (2.62)                                   // (V)      反电动势测量的峰峰值
 #define KeT                            (7.72)                                  // (ms)     反电动势测量的周期

/*硬件板子参数设置值------------------------------------------------------------*/
/*PWM high or low level Mode*/
/*根据驱动芯片的类型选择*/
#define All_High_Level                 (0)                                     // 驱动高电平有效
#define All_Low_Level                  (1)                                     // 驱动低电平有效
#define UP_H_DOWN_L                    (2)                                     // 上桥臂高电平有效，下桥臂低电平有效
#define UP_L_DOWN_H                    (3)                                     // 上桥臂低电平有效，下桥臂高电平有效
#define PWM_Level_Mode                 (UP_H_DOWN_L)

/*hardware current sample Parameter*/
/*电流基准的电路参数*/

#define HW_RSHUNT                      (0.001)                                 // (Ω)  采样电阻
#define HW_AMPGAIN                     (10.0)                                    // 运放放大倍数
#define HW_ADC_REF                     (4.5)                                   // (V)  ADC参考电压

/*hardware voltage sample Parameter*/
/*母线电压采样分压电路参数*/
#define RV1                            (0.0)                                  // (kΩ) 母线电压分压电阻1
#define RV2                            (30.0)                                   // (kΩ) 母线电压分压电阻2
#define RV3                            (5.1)                                   // (kΩ) 母线电压分压电阻3
#define RV                             ((RV1 + RV2 + RV3) / RV3)               // 分压比


/*电压补偿系数*/
#define VOLT_COMP                       (1.00)                                   // 电压补偿系数

/***************VirtlHall*******************************/
#define VirtlHall_KF                   _Q15(0.235)      //虚拟霍尔信号正转下降阈值     0.24                 
#define VirtlHall_KR                   _Q15(0.690)      //虚拟霍尔信号正转上升阈值     0.68

#define VirtlHallSignal_ChangeCount    (uint16)(40)    //反转检测脉冲注入的间隔数
#define VirtlHallSignal_ForwardValue   (int16)(3000)   //虚拟霍尔信号正转切换阈值  8.0V 2000 12.0V 4000  

#define MOTOR_BLDC2FOC_COUNT           (uint16)(12)     //低速切高速维持拍数
#define MOTOR_FOC2BLDC_COUNT           (uint16)(6)     //高速切低速维持拍数

#define MOTOR_SPEED_BLDC2FOC_RPM       (2000.0)        //低速无感方波大力矩切高速无感BLDC的速度，单位RPM
#define MOTOR_SPEED_FOC2BLDC_RPM       (1500.0)        //高速无感BLDC切低速无感方波大力矩的速度，单位RPM

#define Motor_Duty_Count               (uint16)(5)      //Duty增减响应的载波间隔个数 3

#define Min_BLDC_Duty                  (0.18)           //0.28 //VSP起始最小Duty 0.25
#define Max_BLDC_VH_Duty_0             (0.35)           //0.35 //速度在0到(MOTOR_SPEED_BLDC2FOC_RPM/3)区间的最大Duty
#define Max_BLDC_VH_Duty_1             (0.30)           //0.40 //速度在(MOTOR_SPEED_BLDC2FOC_RPM/3)到(2*MOTOR_SPEED_BLDC2FOC_RPM/3)区间的最大Duty
#define Max_BLDC_VH_Duty_2             (0.40)           //0.55 //速度在(2*MOTOR_SPEED_BLDC2FOC_RPM/3)到MOTOR_SPEED_BLDC2FOC_RPM区间的最大Duty
#define Max_BLDC_Duty                  (1.00)            //VSP终点最大Duty

#define Max_BLDC_High_Duty             (0.50)           //超前角和屏蔽续流角高速区间生效Duty阈值
#define Max_BLDC_Low_Duty              (0.45)           //超前角和屏蔽续流角低速区间生效Duty阈值

#define I_Limt_Max		                 I_Limt_MaxValue(100.0)	//母线电流峰值限制值												

#define LimtCurt_K                     (float)(70.0)    //硬件母线电流RC滤波系数，R=10K C=1.0uF    
#define I_LimtValue_Up							   I_LimtValue1(89.0) //母线电流限流区间触发值 60												  
#define I_LimtValue_Out							   I_LimtValue1(88.0) //母线电流限流区间稳定值 59														 
#define I_LimtValue_Dw							   I_LimtValue1(80.0) //母线电流限流区间退出值 50
 

 /*堵转保护*/
 #define StallProtect                   (Enable)         // 堵转保护：Enable--使能  Disable--禁止  
 #define MOTOR_STALL_COUNT              (500.0)         // 堵转检测时间, 单位毫秒：ms  最大65535/PWM_FREQUENCY_BLDC  

 /*缺相保护*/
 #define PhaseLossProtect               (Disable)        // 缺相保护：Enable--使能  Disable--禁止  
 #define PhaseLossDetectValue           (uint16)(5000)   // ADCX_DR<<3 缺相电压检测判断阈值


/*顺逆风判断设置*/
 #define NoTailWind                     (0)                                     // 无逆风顺风判断
 #define TailWind_RSD_Method            (1)                                     // RSD比较器方法
 #define TailWind_BEMF_Method           (2)                                     // BEMF方法
 #define TailWind_FOC_Method            (3)                                     // FOC计算方法
 #define TailWind_Mode                  (NoTailWind)

/*逆风判断时的估算算法设置值-----------------------------------------------------*/
 #define TailWind_Time                  (250)                                   // (ms) 顺逆风检测时间
 #define ATO_BW_Wind                    (150.0)//120.0-PLL 120.0-smo            // 逆风判断观测器带宽的滤波值，经典值为8.0-100.0
 #define SPD_BW_Wind                    (10.0)//10.0-PLL  ,10.0-smo             // 逆风判断速度带宽的滤波值，经典值为5.0-40.0

 /**逆风顺风状态下的KP、KI****/
 #define DQKP_TailWind                  _Q12(1.5)                               //_Q12(1.0)-PLL ,   _Q12(1.5)   -smo
 #define DQKI_TailWind                  _Q15(0.01)                              //_Q15(0.08)-PLL  ,_Q15(0.2)-smo
 
/*启动参数参数值----------------------------------------------------------------*/
 #define Charge_Time                    (6)                                     // (ms) 预充电时间，单位：ms
 #define Charge_Duty                    (0.5)                                    // 预充电下桥Duty

/******* 初始位置检查参数 **********/
 #define PosCheckMode                   (Disable)                               // Enable-禁止初始位置检测，Disable-禁止初始位置检测    

/*脉冲注入时间长于2ms 或 低于2ms*/
 #define Long_Inject                    (0)                                     // 脉冲注入时间长于2ms,若时间长于4ms，则要修改定时器分频
 #define Short_Inject                   (1)                                     // 脉冲注入时间低于2ms
 #define InjectTime                     (Short_Inject)

 #define RPD_Time                       (20)                                     // (ms) 每次RPD的间隔时间
 #define RPD_CurValue                   (10.0)                                   // (A)  RPD过流值
 #define DAC_RPDCurValue                _Q7(I_ValueX(RPD_CurValue*2.0))

/******* 预定位测试模式*/
 #define AlignTestMode                  (Disable)                               // Enable-使能预定位测试模式，Disable-禁止预定位测试模式     
 #define Align_Time                     (4000)                                     // (ms) 预定位时间，单位：ms
 
 #define Align_Angle                    (30.0)                                   // (°) 预定位角度
 
 #define ID_Align_CURRENT               I_Value(0.0)                            // (A) D轴定位电流
 #define IQ_Align_CURRENT               I_Value(10.0)                            // (A) Q轴定位电流

 /***预定位的Kp、Ki****/
 #define DQKP_Alignment                 _Q12(0.5)                               // 预定位的KP
 #define DQKI_Alignment                 _Q12(0.01)                              // 预定位的KI

 /***启动电流****/
 #define ID_Start_CURRENT               I_Value(0.00)                            // (A) D轴启动电流
 #define IQ_Start_CURRENT               I_Value(15.0)                            // (A) Q轴启动电流

 /***运行电流****/
 #define ID_RUN_CURRENT                 I_Value(0.0)                            // (A) D轴运行电流
 #define IQ_RUN_CURRENT                 I_Value(5.0)                            // (A) Q轴运行电流

 /***限制电流****/
 #define LIMIT_MIN_CURRENT              I_Value(5.0)                           // (A) Q轴限制电流

 ///********SMO启动的参数**********/
 #define ATO_BW                         (50.0)                                  // 观测器带宽的滤波值，经典值为1.0-200.0
 #define ATO_BW_RUN                     (65.0)
 #define ATO_BW_RUN1                    (75.0)
 #define ATO_BW_RUN2                    (85.0)
 #define ATO_BW_RUN3                    (90.0)
 #define ATO_BW_RUN4                    (100.0)

 #define SPD_BW                         (20.0)                                  // 速度带宽的滤波值，经典值为5.0-40.0
 #define ATT_COEF                       (0.85)                                  // 无需改动

 ///********PLL启动的参数**********/
 #define OBS_KSLIDE                     _Q15(0.85)                              // SMO算法里的滑膜增益值
 #define E_BW                           (1.50*BASE_FREQ)                         // PLL算法里的反电动势滤波值
 
 #define E_BW_RUN                       (0.50*BASE_FREQ)                         // PLL算法里的反电动势滤波值
 #define E_BW_RUN1                      (1.00*BASE_FREQ)                         // PLL算法里的反电动势滤波值
 #define E_BW_RUN2                      (1.40*BASE_FREQ)                         // PLL算法里的反电动势滤波值
 #define E_BW_RUN3                      (1.50*BASE_FREQ)                         // PLL算法里的反电动势滤波值
 #define E_BW_RUN4                      (1.50*BASE_FREQ)                         // PLL算法里的反电动势滤波值


/*转速参数值-------------------------------------------------------------------*/
 #define MOTOR_SPEED_BASE               (30000.0)                                // (RPM) 速度基准

 /* motor start speed value */
 //open 算法启动参数
 #define MOTOR_OPEN_ACC                 (1000.0)                                  // 强拖启动的增量(每载波周期加一次)
 #define MOTOR_OPEN_ACC_MIN             (500.0)                                   // 强拖启动的初始速度
 #define MOTOR_OPEN_ACC_CNT             (5.0)                                 // 强拖启动的执行次数(MOTOR_OPEN_ACC_CNT*256)
 #define MOTOR_OPEN_ACC_CYCLE           (1)                                     // 强拖启动循环拖动的次数

 //OMEGA启动参数
 #define Motor_Omega_Ramp_ACC           (100.0)                                   // omega启动的增量   12
// #define MOTOR_OMEGA_ACC_MIN            (100.0)                                   // (RPM) omega启动的最小切换转速
// #define MOTOR_OMEGA_ACC_END            (5000.0)                                 // (RPM) omega启动的限制转速

 /* motor loop control speed value */
 #define MOTOR_LOOP_RPM                 (1500.0)                                 // (RPM) 由mode 0到mode1切换转速，即闭环切换转速

 /* motor run speed value */
 //电机运行时最大最小转速、堵转保护转速
 #define MOTOR_SPEED_SMOMIN_RPM         (1000.0)                                 // (RPM) SMO运行最小转速
 #define MOTOR_SPEED_MIN_RPM            (1050.0)                                 // (RPM) 运行最小转速
 #define MOTOR_SPEED_MAX_RPM            (10000.0)                                // (RPM) 运行最大转速
  
 
 #define MOTOR_SPEED_BLDC2FOC_LOW       (1500.0)
 #define MOTOR_SPEED_FOC2BLDC_LOW       (1000.0)
 
 #define MOTOR_SPEED_BLDC2FOC_HIG       (2250.0)
 #define MOTOR_SPEED_FOC2BLDC_HIG       (2400.0)

 
 #define MOTOR_SPEED_MID_RPM1            (9000.0)                                 // (RPM) 运行最小转速
 #define MOTOR_SPEED_MID_RPM2            (14000.0)                                 // (RPM) 运行最小转速


 #define MOTOR_SPEED_STAL_MAX_RPM       (5500.0)                                // (RPM) 堵转保护转速
 #define MOTOR_SPEED_STAL_MIN_RPM       (200.0)

 #define MOTOR_SPEED_STOP_RPM           (12000.0)                                 // (RPM) 运行最小转速

 /*VSP给定模式*/
 #define PWMMODE                        (0)                                     // PWM调速
 #define SREFMODE                       (1)                                     // 模拟调速
 #define NONEMODE                       (2)                                     // 直接给定值，不调速
 #define SPEED_MODE                     (SREFMODE)

/*电机开机、关机的设置----------------------------------------------------------*/
 /* motor ON/0FF value */
 #define OFF_Duty                     _Q15(0.60/HW_ADC_REF)                              // 关机PWM占空比，小于该占空比关机                                                                                //关机PWM占空比，小于该占空比时关机
 #define ON_Duty                      _Q15(0.90/HW_ADC_REF)                              // 开机PWM占空比，大于该占空比时开机
 #define MIN_Duty                     _Q15(0.90/HW_ADC_REF)                              // 速度曲线上最小PWM占空比
 #define MAX_Duty                     _Q15(4.20/HW_ADC_REF)                               // 速度曲线上最大PWM占空比

/*******运行时的参数*****************/
/*电流环参数设置值--------------------------------------------------------------*/
 #define DQKPStart                      _Q12(0.3)                               // DQ轴KP
 #define DQKIStart                      _Q15(0.0025)                              // DQ轴KI

 #define DQKP1                           _Q12(0.5)                               // DQ轴KP
 #define DQKI1                           _Q15(0.0075)                              // DQ轴KI
 
 #define DQKP2                           _Q12(0.3)                               // DQ轴KP
 #define DQKI2                           _Q15(0.005)                              // DQ轴KI

 /* D轴参数设置 */
 #define DOUTMAX                        _Q15(0.50)                              // D轴最大限幅值，单位：输出占空比
 #define DOUTMIN                        _Q15(-0.50)                             // D轴最小限幅值，单位：输出占空比
 /* Q轴参数设置，默认0.99即可 */
 #define QOUTMAX                        _Q15(0.999)                              // Q轴最大限幅值，单位：输出占空比
 #define QOUTMIN                        _Q15(-0.999)                             // Q轴最小限幅值，单位：输出占空比
 
 #define QOUT_INC                        (35)                                    // Q轴电流增大步进值,开环控制时有效
 #define QOUT_DEC                        (35)                                    // Q轴电流减小步进值,开环控制时有效
	
/*外环参数设置值----------------------------------------------------------------*/

 /*外环使能*/
 #define OutLoop_Disable                (0)                                     // 关闭外环
 #define OutLoop_Enable                 (1)                                     // 使能外环
 #define OutLoop_Mode                   (OutLoop_Enable)

/*外环不使能时的Q轴运行电流*/	
 #define OutLoop_IQ_Current             (4.0)                                   // (A) Q轴输出电流,开环控制时有效
 #define OutLoop_IQ_VALUE               I_Value(OutLoop_IQ_Current)

 /*外环选择功率环或速度环*/
 #define Power_Loop_Control             (0)                                     //恒功率
 #define Speed_Loop_Control             (1)                                     //恒转速
 #define UQ_Loop_Control                (2)                                     //恒转速
 #define Motor_Speed_Control_Mode       (UQ_Loop_Control)

 /*环路调节参数*/
 #define SPEED_LOOP_TIME                (1.0)                                    // (ms) 速度环调节周期 风扇速度环50，功率环5

 /*速度环调节参数*/
 #define SKP                            _Q12(0.5)                               // 外环KP
 #define SKI                            _Q12(0.005)                              // 外环KI

 #define SOUTMAX                        I_Value(5.0)                           // (A) 外环最大限幅值
 #define SOUTMIN                        I_Value(0.02)                           // (A) 外环最小限幅值

 #define SPEED_INC                      (100.0)                                  // 速度环增量
 #define SPEED_DEC                      (100.0)                                  // 速度环减量

 /*功率环调节参数*/
 #define Motor_Max_Power                (4000)
 #define Motor_Min_Power                (400)

 /*UQ环调节参数*/
 #define UQ_KP                           _Q12(1.0)                               // 外环KP
 #define UQ_KI                           _Q12(0.01)                              // 外环KI

 #define UQ_OUTMAX                       I_Value(60.0)                           // (A) 外环最大限幅值
 #define UQ_OUTMIN                       I_Value(0.005)                           // (A) 外环最小限幅值

 #define UQ_INC                        (500.0)                                  // 速度环增量
 #define UQ_DEC                        (500.0)                                  // 速度环减量


 #define UQ_Min                         _Q15(0.20)  
 #define UQ_Max                         _Q15(0.99)  


/*模式选择设置值----------------------------------------------------------------*/
 /*IPM测试模式*/
 #define IPMtest                        (0)                                     // IPM测试或者MOS测试，MCU输出固定占空比
 #define NormalRun                      (1)                                     // 正常按电机状态机运行
 #define IPMState                       (NormalRun)

/*Motor  Direction: CW or CCW*/
#define  CW										          (0)														                                  // CW ,正转
#define  CCW									          (1)														                                 // CCW,反转
//#define  MotorDirection                 (CW)

 /*估算器模式选择*/
 #define SMO                            (0)                                     // SMO ,滑膜估算
 #define PLL                            (1)                                     // PLL ,锁相环
 #define EstimateAlgorithm              (SMO)

 /*开环启动模式选择*/
 #define Open_Start                     (0)                                     // 开环强拖启动
 #define Omega_Start                    (1)                                     // Omega启动
 #define Open_Omega_Start               (2)                                     // 先开环启，后Omega启动
 #define Open_Start_Mode                (Omega_Start)

 /*电流采样模式*/
 #define Single_Resistor                (0)                                     // 单电阻电流采样模式
 #define Double_Resistor                (1)                                     // 双电阻电流采样模式
 #define Three_Resistor                 (2)                                     // 三电阻电流采样模式
 #define Shunt_Resistor_Mode            (Single_Resistor)

/*SVPWM mode*/
#define SVPWM_5_Segment                 (0)                                     // 五段式SVPWM
#define SVPWM_7_Segment                 (1)                                     // 七段式SVPWM
#define SVPMW_Mode                      (SVPWM_5_Segment)

/*OverModulation mode:enable or disable*/
#define OverModulation                  (Enable)                               // Enable-禁止过调制，Disable-使能过调制


/*保护参数值-------------------------------------------------------------------*/
 /*硬件过流保护*/
 #define Hardware_FO_Protect            (1)                                     // 硬件FO过流保护使能，适用于IPM有FO保护的场合
 #define Hardware_CMP_Protect           (2)                                     // 硬件CMP比较过流保护使能，适用于MOS管应用场合
 #define Hardware_FO_CMP_Protect        (3)                                     // 硬件CMP比较和FO过流保护都使能
 #define Hardware_Protect_Disable       (4)                                     // 硬件过流保护禁止，用于测试
 #define HardwareCurrent_Protect        (Hardware_CMP_Protect)                  // 硬件过流保护实现方式

 /*硬件过流保护比较值来源*/
 #define Compare_DAC                    (0)                                     // DAC设置硬件过流值
 #define Compare_Hardware               (1)                                     // 硬件设置硬件过流值
 #define Compare_Mode                   (Compare_DAC)                           // 硬件过流值的来源
 
 /*硬件过流保护*/
 #define OverHardcurrentValue           (100.0)                                 // (A) DAC模式下的硬件过流值
 
 /*软件过流保护*/
 #define  OverSoftCurrentProtect        (1)                                     // 一级软件过流保护：1--使能 0--禁止  						
 #define 	OverSoftCurrent							  I_LimtValue1(57.0)                      // (A) 一级软件过流值
 #define 	OverSoftCurrentTime           (1200)                                  // (ms)一级软件过流检测时间
 
 #define  OverSoftCurrentProtect1       (1)                                     // 二级软件过流保护：1--使能 0--禁止  						
 #define 	OverSoftCurrent1							I_LimtValue1(70.0)                      // (A) 二级软件过流值
 #define 	OverSoftCurrentTime1          (300)                                   // (ms)二级软件过流检测时间
 
 #define  OverSoftCurrentProtect2       (0)                                     // 三级软件过流保护：1--使能 0--禁止  						
 #define 	OverSoftCurrent2							I_LimtValue1(120.0)                      // (A) 三级软件过流值
 #define 	OverSoftCurrentTime2          (50)                                    // (ms)三级软件过流检测时间

 /*过欠压保护*/
 #define VoltageProtect                 (1)                                     // 电压保护：Enable--使能  Disable--禁止  
 #define Over_Protect_Voltage           (21.0)                                  // (V) 直流电压过压保护值
 #define Over_Recover_Vlotage           (20.5)                                  // (V) 直流电压过压保护恢复值
 #define Under_Protect_Voltage          (13.75)                                  // (V) 直流电压欠压保护值
 #define Under_Recover_Vlotage          (14.00)                                  // (V) 直流电压欠压保护恢复值
 #define Start_Protect_Voltage          (15.0)                                  // (V) 启动电压

 /*通讯保护*/
 #define CommunicationProtect           (0)                                     // 通讯保护：Enable--使能  Disable--禁止  
 #define Communication_Protect_Voltage  (1.2)                                   // (V) 通讯电压欠压保护值
 
 /*温度保护*/
 #define   Tempera_Value(NTC_Value) 		    _Q15((5.0*NTC_Value/(10.0+NTC_Value))/4.5)
 
 #define 	Motor_TemperatureProtectEnable    (1)														      // 温度保护使能：Enable--使能  Disable--禁止
 #define  OVER_Motor_Temperature 		        Tempera_Value(0.67)					        // 过温保护阈值，根据NTC曲线设定  0.67
 #define  UNDER_Motor_Temperature           Tempera_Value(0.91)					        // 低温恢复阈值，根据NTC曲线设定  0.91
 #define 	Over_Motor_TemperRecoverTime	    1000				                        // 过温恢复时间
 
 /*延时断电*/
 #define PDELAY                         (GP22)
 #define PDELAY_Vaule                   (15000)                                 //延时断电时间 单位：ms
 #define Pdelay_ON                      (GP22 = 1)
 #define Pdelay_OFF                     (GP22 = 0)

 /******启停测试参数******/
 #define StartONOFF                     (Disable)                               //程序自动启停测试：Enable--使能  Disable--禁止  
 #define StartON_Time                   (3500)                                  // (ms) 启动运行时间
 #define StartOFF_Time                  (2500)                                  // (ms) 停止时间

 #define StopBrakeFlag                  (0)
 #define StopWaitTime                   (2000)                                  // (ms) 刹车等待时间


#endif
