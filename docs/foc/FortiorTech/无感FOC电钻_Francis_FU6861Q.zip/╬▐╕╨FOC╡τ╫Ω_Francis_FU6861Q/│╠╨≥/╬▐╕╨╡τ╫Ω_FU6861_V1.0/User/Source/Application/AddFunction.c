/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the add function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <AddFunction.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ---------------------------------------------------------*/
FaultStateType			       mcFaultSource;
PWMINPUTCAL        xdata   mcPwmInput;
FaultVarible       xdata   mcFaultDect;
//MotorRSDTypeDef    xdata   RSDDetect;
CurrentVarible     xdata   mcCurVarible;
ProtectVarible     xdata   mcProtectTime;

FOCCTRL            xdata   mcFocCtrl;
ONVarible          xdata   ONOFFTest;
MCLedDisplay       xdata   mcLedDisplay;
MCRAMP             xdata   mcSpeedRamp;
SLEEPMODE          xdata   SleepSet;
MotorFRTypeDef		 xdata   mcFRState;
uint16 						 xdata   VSP;

int16              xdata   temp_FOC_UQ,Motor_Loop_Speed_Temp;
extern      uint16 xdata  Power_Currt1;

/*---------------------------------------------------------------------------*/
/* Name		:	int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
/* Input	:	INVlaue，OutLastValue
/* Output	:	int16的变量
/* Description:	滤波函数,用乘法器做的
/*---------------------------------------------------------------------------*/
int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
{
	int16 Result = 0;
	MDU_MA = (INVlaue-OutLastValue);
	MDU_MB = (int16)480;		           			/*写被乘数和乘数*/

	Result = MDU_MB;
	Result += OutLastValue;
	return(Result);
}

/*---------------------------------------------------------------------------*/
/* Name		:	void FaultProcess(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护处理函数，关闭FOC输出，同时将状态变为mcFault
/*---------------------------------------------------------------------------*/
void FaultProcess(void)
{
	MOE     = 0;

	TIM1_CR0 = 0;
	TIM1_CR1 = 0;
	TIM1_CR2 = 0;
	TIM1_CR3 = 0;
	TIM1_CR4 = 0;
	TIM1_IER = 0;	
	
	FOC_CR1    = 0x00;
	ClrBit(DRV_CR, FOCEN);	
	
	Driver_Init();	
	ONOFFTest.PowerOFF_Count = 0;			
	mcState = mcFault;
	

}

/*---------------------------------------------------------------------------*/
/* Name		:	int16 Abs_F16(int16 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint16 Abs_F16(int16 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	int32 Abs_F32(int32 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint32 Abs_F32(int32 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	void APP_DIV(void)
/* Input	:	void
/* Output	:	void
/* Description:	将所有用到除法的地方，放在同一个中断，以避免中断串扰
/*---------------------------------------------------------------------------*/
void APP_DIV(void)
{
    if( mcPwmInput.PWMDivFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcPwmInput.PWMDuty = MDU_DIV_IDATA_U32(&mcPwmInput.pwm.PWMCompareAMP, &mcPwmInput.PWMARRUpdate);
       mcPwmInput.PWMDivFlag=0;
    }
    if( mcFocCtrl.ESDIVFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcFocCtrl.SQUSpeedDIVEs = MDU_DIV_XDATA_U32(&mcFocCtrl.SQUSysSpeed,&mcFocCtrl.EsValue);
       mcFocCtrl.ESDIVFlag=0;
    }
}
/*---------------------------------------------------------------------------*/
/* Name		:	void PWMInputCapture(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	输入PWM处理
/*---------------------------------------------------------------------------*/
void PWMInputCapture(void)
{
  uint16 MotorControlVSP;

	 if(mcPwmInput.PWMUpdateFlag==1)  // 有新的duty更新
	 {
      if((Abs_F32(mcPwmInput.PWMCompare-mcPwmInput.PWMCompareOld)<50)// 两次比较值相近，减少读错率
        &&(Abs_F32(mcPwmInput.PWMARROld-mcPwmInput.PWMARR)<50)// 两次周期值相近，减少读错率
//        &&((100<mcPwmInput.PWMARR)&&(mcPwmInput.PWMARR<6000))// 周期值在一定范围内才认为有效，即一定频率范围
        &&(mcPwmInput.PWMDivFlag==0))
        {
          mcPwmInput.PWMFlag=1;                               // PWMFlag置1期间，不读取TIM3__DR和TIM3__ARR;，防止出错
          mcPwmInput.pwm.PWMCompareUpdate[0]=(mcPwmInput.PWMCompare>>1);// 对其乘以32768
          mcPwmInput.PWMARRUpdate=mcPwmInput.PWMARR;
          mcPwmInput.PWMDivFlag=1;                            // 启动除法
          mcPwmInput.PWMFlag=0;
        }
       if(mcPwmInput.PWMDivFlag==0)
        {
          if(mcPwmInput.PWMcnt<3)//2次求平均值
          {
            mcPwmInput.PWMcnt++;
            mcPwmInput.PWMVSum +=mcPwmInput.PWMDuty;
          }
          else
          {
            MotorControlVSP= (mcPwmInput.PWMVSum >>1);//注意其有一个右移与前面的比较值标幺化有关
            mcPwmInput.PWMVSum=0;
            mcPwmInput.PWMcnt =0;
          }
           MotorControlVSP=mcPwmInput.PWMDuty;
         if(MotorControlVSP > ON_Duty)
          {
            mcSpeedRamp.FlagONOFF = 1;
          }
         else if(MotorControlVSP < OFF_Duty)//||(MotorControlVSP >= OFFPWMDutyHigh))
          {
            mcSpeedRamp.FlagONOFF = 0;
          }

          //转速曲线计算
          if(mcSpeedRamp.FlagONOFF==1)
          {
            if(MotorControlVSP <= MIN_Duty)
            {
              mcSpeedRamp.TargetValue = Motor_Min_Speed;
            }
            else if(MotorControlVSP < MAX_Duty)
            {
              mcSpeedRamp.TargetValue = Motor_Min_Speed + SPEED_K*(MotorControlVSP-MIN_Duty);
            }
            else
            {
              mcSpeedRamp.TargetValue	=	Motor_Max_Speed;
            }
          }
          else
          {
            mcSpeedRamp.TargetValue =0;
          }
        }

      mcPwmInput.PWMUpdateFlag =0;
      mcPwmInput.PWMCompareOld=mcPwmInput.PWMCompare;//将此次比较值赋值给上次比较值
      mcPwmInput.PWMARROld=mcPwmInput.PWMARR;//将此次周期值赋值给上次周期值
	  }
}

/*****************************************************************************
 * Function:		 void Fault_Overcurrent(CurrentVarible *h_Cur)
 * Description:	 一级软件过流保护
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Overcurrent(FaultVarible *h_Fault)
{
	if(Power_Currt1 >= OverSoftCurrent)
	{
		h_Fault->OverCurrentCnt++;
		if(h_Fault->OverCurrentCnt >= OverSoftCurrentTime)
		{
			h_Fault->OverCurrentCnt = 0;
			h_Fault->OverCurrentCnt1 = 0;
			h_Fault->OverCurrentCnt2 = 0;
			mcFaultSource = FaultSoftOVCurrent;
			FaultProcess();
     }
  }
	else
	{
	  if(h_Fault->OverCurrentCnt > 0)
		{
			h_Fault->OverCurrentCnt--;
		}
		if(h_Fault->OverCurrentCnt1 > 0)
		{
			h_Fault->OverCurrentCnt1--;
		}
		if(h_Fault->OverCurrentCnt2 > 0)
		{
			h_Fault->OverCurrentCnt2--;
		}	
  }
}

/*****************************************************************************
 * Function:		 void Fault_Overcurrent(CurrentVarible *h_Cur)
 * Description:	 二级软件过流保护
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Overcurrent1(FaultVarible *h_Fault)
{
	if(Power_Currt1 >= OverSoftCurrent1)
	{
		h_Fault->OverCurrentCnt1++;
		if(h_Fault->OverCurrentCnt1 >= OverSoftCurrentTime1)
		{
			h_Fault->OverCurrentCnt = 0;
			h_Fault->OverCurrentCnt1 = 0;
			h_Fault->OverCurrentCnt2 = 0;
			mcFaultSource = FaultSoftOVCurrent1;
			FaultProcess();
     }
  }
	else
	{
	  if(h_Fault->OverCurrentCnt1 > 0)
		{
			h_Fault->OverCurrentCnt1--;
		}
		if(h_Fault->OverCurrentCnt2 > 0)
		{
			h_Fault->OverCurrentCnt2--;
		}
			
  }
}

/*****************************************************************************
 * Function:		 void Fault_Overcurrent(CurrentVarible *h_Cur)
 * Description:	 三级软件过流保护
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Overcurrent2(FaultVarible *h_Fault)
{
	if(Power_Currt1 >= OverSoftCurrent2)
	{
		h_Fault->OverCurrentCnt2++;
		if(h_Fault->OverCurrentCnt2 >= OverSoftCurrentTime2)
		{
			h_Fault->OverCurrentCnt = 0;
			h_Fault->OverCurrentCnt1 = 0;
			h_Fault->OverCurrentCnt2 = 0;
			mcFaultSource = FaultSoftOVCurrent2;
			FaultProcess();
     }
  }
	else
	{
	  if(h_Fault->OverCurrentCnt2 > 0)
		{
			h_Fault->OverCurrentCnt2--;
		}
			
  }
}
/*****************************************************************************
 * Function:		 void	Fault_OverVoltage(mcFaultVarible *h_Fault)
 * Description:	 过压欠压保护函数：程序每5ms判断一次，母线电压大于过压保护值时，计数器加一，计数器值超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
                 同理，欠压保护。
	               电机过欠压保护状态下，母线电压恢复到欠压恢复值以上，过压恢复值以下时，计数器加一，超过200次后，恢复。根据档位信息来决定恢复到哪个状态。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_OverUnderVoltage(FaultVarible *h_Fault)
{
	//过压保护
		if(mcFaultSource == FaultNoSource)//程序无其他保护下
		{
				if(mcFocCtrl.mcDcbusFlt > OVER_PROTECT_VALUE)	 //母线电压大于过压保护值时，计数，超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
				{
					h_Fault->OverVoltDetecCnt++;
					if(h_Fault->OverVoltDetecCnt > 500)//检测20ms
					{
						h_Fault->OverVoltDetecCnt = 0;
						mcFaultSource=FaultOverVoltage;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->OverVoltDetecCnt>0)
					{
						h_Fault->OverVoltDetecCnt--;
					}
				}

			//欠压保护

				if(mcFocCtrl.mcDcbusFlt< UNDER_PROTECT_VALUE)
				{
					h_Fault->UnderVoltDetecCnt++;

					if(h_Fault->UnderVoltDetecCnt > 500)//检测20ms
					{
						h_Fault->UnderVoltDetecCnt = 0;
						mcFaultSource=FaultUnderVoltage;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->UnderVoltDetecCnt>0)
					{
						h_Fault->UnderVoltDetecCnt--;
					}
				}
		}

		/*******过压欠压保护恢复*********/
//		if((mcState == mcFault) &&((mcFaultSource==FaultUnderVoltage)||(mcFaultSource==FaultOverVoltage)))
//		{
//			if((mcFocCtrl.mcDcbusFlt< OVER_RECOVER_VALUE)&&(mcFocCtrl.mcDcbusFlt> UNDER_RECOVER_VALUE))
//			{
//				h_Fault->VoltRecoverCnt++;
//				if(h_Fault->VoltRecoverCnt>100)//连续检测1s，若正常则恢复
//				{
//          mcState = mcReady;
//					mcFaultSource=FaultNoSource;
//					h_Fault->VoltRecoverCnt = 0;
//				}
//			}
//			else
//			{
//				h_Fault->VoltRecoverCnt = 0;
//			}
//	 }
}

/*****************************************************************************
 * Motor温度保护
 * Function:		 void	Fault_Temperature(mcFaultVarible *h_Fault)
 * Description:	 注意当前热敏电阻为NTC还是PTC，温度检测保护
 * Parameter:		 mcFaultVarible *h_Fault               
 * Return:			 no
 *****************************************************************************/
  void Fault_MotorTemperature(FaultVarible *h_Fault)
  {
		if(mcFocCtrl.MotorTempDecFlt < OVER_Motor_Temperature)
		{
		 h_Fault->MotorTemperCnt++; 				
	   if(h_Fault->MotorTemperCnt > 500)								
	   {	
		  h_Fault->MotorTemperCnt = 0;
			h_Fault->MotorTemperRecover = 0;	
			mcFaultSource = FaultMotorOverTemperature;
		  FaultProcess();
		 }	   
	  }
		else
		{
		  h_Fault->MotorTemperCnt = 0;	
		}
  
//		if((mcState == mcFault)&&(mcFaultSource == FaultMotorOverTemperature))
//		{							
//			 if(h_Fault->MotorTemperRecover < Over_Motor_TemperRecoverTime)								
//			 {
//				 h_Fault->MotorTemperRecover++; 
//			 }
//       else
//			 {
//				if(mcFocCtrl.MotorTempDecFlt > UNDER_Motor_Temperature)	
//				{	
//					h_Fault->MotorTemperRecover = 0;					
//					mcState = mcReady;
//					mcFaultSource=FaultNoSource;
//			  }				 
//			 }	   
//		 }
	}

/*****************************************************************************
 * 通讯保护
 * Function:		 void	Fault_Communication(mcFaultVarible *h_Fault)
 * Description:	 当通讯口检测电压小于1.2V保护
 * Parameter:		 mcFaultVarible *h_Fault               
 * Return:			 no
 *****************************************************************************/	
  void Fault_Communication(FaultVarible *h_Fault)
  {
		if(mcFocCtrl.CommunicationFlt < Communication_PROTECT_VALUE)
		{
			h_Fault->CommunicationCnt++; 				
	   if(h_Fault->CommunicationCnt > 500)								
	   {	
		  h_Fault->CommunicationCnt = 0;	
			mcFaultSource = FaultCommunication;
		  FaultProcess();
		 }	   
	  }
		else 
		{
			if(h_Fault->CommunicationCnt>0)
			{
				h_Fault->CommunicationCnt --;
      }	
		}
	}

/*---------------------------------------------------------------------------*/
/* Name		:	void Fault_Detection(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护函数，因保护的时间响应不会很高，采用分段处理，每5个定时器中断执行一次对应的保护
	              常见保护有过欠压、过温、堵转、启动、缺相等保护，调试时，可根据需求，一个个的调试加入。
/*---------------------------------------------------------------------------*/
void Fault_Detection(void)
{
	if(OverSoftCurrentProtect ==Enable)     
	{
	 Fault_Overcurrent(&mcFaultDect);											// 一级软件过流保护
	}
	if(OverSoftCurrentProtect1 ==Enable)     
	{
	 Fault_Overcurrent1(&mcFaultDect);										// 二级软件过流保护
	}
	if(OverSoftCurrentProtect2 ==Enable)     
	{
	 Fault_Overcurrent2(&mcFaultDect);										// 三级软件过流保护
	}	
  if(VoltageProtect==Enable)
	{
	 Fault_OverUnderVoltage(&mcFaultDect);                //电压保护
  }
	if(Motor_TemperatureProtectEnable==Enable)            //温度保护
	{	
	 Fault_MotorTemperature(&mcFaultDect); 
	}
	if(CommunicationProtect==Enable)                      //通讯保护
	{
	 Fault_Communication(&mcFaultDect);	
  }
}

/*---------------------------------------------------------------------------*/
/* Name		:	void ONOFF_StartTest(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	启动测试
/*---------------------------------------------------------------------------*/
void ONOFF_StartTest(ONVarible  *h_test)
{
	if(h_test->ONOFF_Flag==1)
	{
		 h_test->ON_Count++;
		if(h_test->ON_Count>StartON_Time)
		{
			h_test->ON_Count=0;
			h_test->ONOFF_Times++;
			h_test->ONOFF_Flag=0;
		  mcSpeedRamp.FlagONOFF = 0;
			mcSpeedRamp.TargetValue = 0;

		}
  }
	else
	{
		if(mcState!=mcFault)
		{
		  h_test->OFF_Count++;
			if(h_test->OFF_Count>StartOFF_Time)
			{
				h_test->OFF_Count=0;
				h_test->ONOFF_Flag=1;
				 mcSpeedRamp.FlagONOFF = 1;
				 mcSpeedRamp.TargetValue = Motor_Min_Speed;

			}
	  }

  }
}

/*---------------------------------------------------------------------------*/
/* Name		:	void Speed_response(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	速度响应函数，可根据需求加入控制环，如恒转矩控制、恒转速控制、恒功率控制
/*---------------------------------------------------------------------------*/
void Speed_response(void)
{

	if((mcState ==mcRun)&&(McStaSet.SetFlag.BLDCSetFlag == 0))
	 {
		switch(mcFocCtrl.CtrlMode)
		{
				case 0:
				{
	          if(FOC__EOME > Motor_Loop_Speed_Temp)
					 {
					    mcFocCtrl.CtrlMode= 1;
						 
						  FOC_EFREQMIN 	= Motor_Omega_Ramp_Min_Hig;

	
//								FOC_DQKP = DQKP2;
//								FOC_DQKI = DQKI2;
//							 
//								FOC_EKP       = OBSW_KP_GAIN_RUN4;	                          // 估算器里的PI的KP
//								FOC_EKI     	= OBSW_KI_GAIN_RUN4;	

						 
              FOC_DQKP = DQKPStart;
              FOC_DQKI = DQKIStart;
						 
			   	  	FOC_EKP       = OBSW_KP_GAIN_RUN4;	                          // 估算器里的PI的KP
				    	FOC_EKI     	= OBSW_KI_GAIN_RUN4;		                    // 估算器里的PI的KI

						 
							#if (Motor_Speed_Control_Mode == Speed_Loop_Control)
							{
								mcSpeedRamp.ActualValue = FOC__EOME;
							}
							#elif (Motor_Speed_Control_Mode == Power_Loop_Control)
							{
								mcSpeedRamp.ActualValue = mcFocCtrl.Powerlpf;
							}
							#elif (Motor_Speed_Control_Mode == UQ_Loop_Control)
							{
										mcSpeedRamp.ActualValue = FOC__UQ;//mcSpeedRamp.TargetValue;//
								
//								 	FOC_QMAX 			= mcSpeedRamp.TargetValue;
//	                FOC_QMIN 			= UQ_Min;//-mcSpeedRamp.TargetValue;
							}
							#endif
              mcFocCtrl.TorqueLoopTime= SPEED_LOOP_TIME;

					 }
//					 else if(FOC_IQREF < IQ_RUN_CURRENT)
//					 {
//              FOC_IQREF  += 50;
//					 }
				}
				break;
				case 1:
				{
					mcFocCtrl.TorqueLoopTime++;
					if(mcFocCtrl.TorqueLoopTime > SPEED_LOOP_TIME)
					{
						mcFocCtrl.TorqueLoopTime=0;

						mc_ramp(&mcSpeedRamp);

//						FOC__UQ = mcSpeedRamp.ActualValue;
						 temp_FOC_UQ = (int16)(FOC__UQ);
						 FOC_IQREF= HW_One_PI(mcSpeedRamp.ActualValue - temp_FOC_UQ);

//						 if(mcFocCtrl.SpeedFlt > Motor_Mid_Speed2)
//						 {
//								FOC_DQKP = DQKP2;
//								FOC_DQKI = DQKI2;
//							 
////								FOC_EKP       = OBSW_KP_GAIN_RUN4;	                          // 估算器里的PI的KP
////								FOC_EKI     	= OBSW_KI_GAIN_RUN4;	
//						 }
//						 else if(mcFocCtrl.SpeedFlt > Motor_Mid_Speed1)
//						 {
//								FOC_DQKP = DQKP1;
//								FOC_DQKI = DQKI1;
//							 
////								FOC_EKP       = OBSW_KP_GAIN_RUN3;	                          // 估算器里的PI的KP
////								FOC_EKI     	= OBSW_KI_GAIN_RUN3;	
//						 }
//						 else
//						 {
//								FOC_DQKP = DQKPStart;
//								FOC_DQKI = DQKIStart;
//							 
////								FOC_EKP       = OBSW_KP_GAIN_RUN2;	                          // 估算器里的PI的KP
////								FOC_EKI     	= OBSW_KI_GAIN_RUN2;	
//						 }
							 
				
				 
				  }
			  }
				break;
		}
	}
	
  #if ((TailWind_Mode == TailWind_RSD_Method)||(TailWind_Mode == TailWind_BEMF_Method))
  {
    if(mcState==mcRun)
    {
      if(mcFocCtrl.RunStateCnt<15000)//15s的延迟，用于清RSDCCWFlag,BEMFCCWFlag
      {
        mcFocCtrl.RunStateCnt++;
      }
      else
      {
        BEMFDetect.BEMFCCWFlag= 0;
        RSDDetect.RSDCCWFlag  = 0;
      }
    }
  }
  #endif


}

/*---------------------------------------------------------------------------*/
/* Name		:	void FGOutput(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	FG信号输出
/*---------------------------------------------------------------------------*/
void FGOutput(void)
{//FG可用中断FGIF进行判断
	if(mcState==mcRun)
	{
		if((FOC__THETA>=0)&&(FOC__THETA<32768))//0-180
		{
			ResetFGPin;
		}
		else if((FOC__THETA>=32768)&&(FOC__THETA<65536))//180-360
		{
			SetFGPin;
		}
  }
	else if(mcState == mcFault)
	{
			SetFGPin;
	}
	else
	{
			ResetFGPin;
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	 uint16 SoftLPF(uint16 Xn1, uint16 Xn0, uint16 K)
/* Input	:	uint16 Xn1, uint16 Xn0, uint16 K
/* Output	:	uint16
/* Description:	软件低通滤波
/*---------------------------------------------------------------------------*/
 int16 SoftLPF(int16 Xn1, int16 Xn0, int16 K)
 {
 	int16 temp16 = 0;
 	int32 Temp32 = 0;

 	Temp32 = (((int32)Xn1 - (int32)Xn0) * (int32)K) >> 15;
 	temp16 = Xn0 + (int16)Temp32;
 	return temp16;
 }


/*---------------------------------------------------------------------------*/
/* Name		:	void LED_Display(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	LED灯显示
/*---------------------------------------------------------------------------*/
void LED_Display(void)
{
	switch(mcFaultSource)
	{
    		case FaultNoSource:
//    		    ResetLEDPin;	    	//低电平点亮，高电平灭
    		  break;
    	  case FaultSoftOVCurrent:
				    Led_OnOff(&mcLedDisplay,1);
				  break;
				case FaultSoftOVCurrent1:
					  Led_OnOff(&mcLedDisplay,2);
					break;
    		case FaultSoftOVCurrent2:
            Led_OnOff(&mcLedDisplay,3);
    			break;
    		case FaultHardOVCurrent:
            Led_OnOff(&mcLedDisplay,4);
    			break;
    		case FaultUnderVoltage:
					  Led_OnOff(&mcLedDisplay,5);
					break;
				case FaultOverVoltage:
					  Led_OnOff(&mcLedDisplay,6);
				  break;
    		case  FaultMotorOverTemperature:
            Led_OnOff(&mcLedDisplay,7);
    			break;
				case  FaultLossPhase:
					  Led_OnOff(&mcLedDisplay,8);
					break;
				case  FaultStall:
					  Led_OnOff(&mcLedDisplay,9);
					break;
				case  FaultCommunication:
					  Led_OnOff(&mcLedDisplay,10);
					break;
    		default:
    			break;
  }

}

  //LED灯的闪烁
  void Led_OnOff(MCLedDisplay *hLedDisplay,uint8 htime)
  {
		hLedDisplay->LedCount++;
	  if(hLedDisplay->LedCount<hLedDisplay->Counttime)
	   {
		    if(hLedDisplay->Count<200)
	      {
				 hLedDisplay->Count++;

	      }
				else if((hLedDisplay->Count>=200)&&(hLedDisplay->Count<201))
				{
					hLedDisplay->Count=0;
				  LEDPinONOFF;
					hLedDisplay->LedTimCot++;
				}
				else
					;
				if(hLedDisplay->LedTimCot>=2*htime)
		  	{
					hLedDisplay->Count=202;
				  SetLEDPin;
				}
      }
	    else if(hLedDisplay->LedCount>=hLedDisplay->Counttime)
	    {
	     hLedDisplay->LedCount=0;
	     hLedDisplay->LedTimCot=0;
	     hLedDisplay->Count=0;
	    }
 }
/*---------------------------------------------------------------------------*/
/* Name		:	void mc_ramp(void)
/* Input	:	hTarget,MC_RAMP *hSpeedramp
/* Output	:	NO
/* Description:
/*---------------------------------------------------------------------------*/

void mc_ramp(MCRAMP *hSpeedramp)
{
//	  if( --hSpeedramp->DelayCount < 0)
//		{
//				hSpeedramp->DelayCount = hSpeedramp->DelayPeriod;

				if (hSpeedramp->ActualValue < hSpeedramp->TargetValue)
				{
						if((hSpeedramp->ActualValue + UQ_INC) < hSpeedramp->TargetValue)
						{
								hSpeedramp->ActualValue += UQ_INC;
						}
						else
						{
								hSpeedramp->ActualValue = hSpeedramp->TargetValue;
						}
				}
				else
				{
						if((hSpeedramp->ActualValue - UQ_DEC) > hSpeedramp->TargetValue)
						{

								hSpeedramp->ActualValue -= UQ_DEC;
						}
						else
						{
								hSpeedramp->ActualValue = hSpeedramp->TargetValue;
						}
				}
//		}
}
void HW_Speed_PI(void)
{
//		PI_EK =  mcSpeedRamp.ActualValue- mcFocCtrl.Powerlpf;	//给定转速与实际转速之差，可区分恒功率或恒转速，或恒电压
		PI_EK =  mcSpeedRamp.ActualValue- FOC__EOME;	//给定转速与实际转速之差，直接减FOC__EOME有风险
		PI_LPF_CR |= 0x02;									// Start PI
		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//	  mcFocCtrl.mcIqref= PI_UK;//可区分限功率与不限功率
//		FOC_IQREF =mcFocCtrl.mcIqref;
		PI_UK+=(SKP/4096 +1);
		FOC_IQREF= PI_UK;

}
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_Genal_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	U(K) = U(k-1) + Kp*(E(k)-E(k-1)) + Ki*E(k) ----- (Uk_min < U(k) < Uk_max)b
	Description   :	PI控制
	Input         :	Xn1--E(K-1)
	                Yn0--U(K-1)
					Xn2--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间为3.8us
-------------------------------------------------------------------------------------------------*/
int16 HW_Genal_PI(int16 Xn1, int16 Yn0, int16 Xn2)
{
		PI_KP = SKP;
		PI_KI = SKI;
		PI_UKMAX = SOUTMAX;
		PI_UKMIN = SOUTMIN;
		PI_EK =  Xn1;     	  //初始化E(K-1)
		PI_LPF_CR |= 0x02;	  // Start PI
		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
		PI_UK =  Yn0;           //初始化U(K-1)
		PI_EK =  Xn2;	      //填入EK
		PI_LPF_CR |= 0x02;	  // Start PI
		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
		PI_UK+=(SKP/4096 +1);
		return PI_UK;
}
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_One_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	Description   :	PI控制
	Input         :	Xn1--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间us
-------------------------------------------------------------------------------------------------*/
int16 HW_One_PI(int16 Xn1)
{
	  PI_EK =  Xn1;	      //填入EK
	  PI_LPF_CR |= 0x02;	  // Start PI
	  _nop_();  _nop_();  _nop_();  _nop_();  _nop_();
	  PI_UK+=(SKP/4096 +1);
	  return PI_UK;
}
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 LPF(int16 Xn1, int16 Xn0, int8 K)
	Description   :	LFP控制
	Input         :	Xn1--当前输入值
	                Xn0--上一次滤波输出值
									K--LPF滤波系数
  Output				:	LPF_Y--当前滤波输出值，执行时间为4us。
-------------------------------------------------------------------------------------------------*/
int16 LPFFunction(int16 Xn1, int16 Xn0, int8 K)
{
	LPF_K = K;
	LPF_X = Xn1;
	LPF_Y = Xn0;
	SetBit(PI_LPF_CR, LPFSTA);
	_nop_();_nop_();_nop_();_nop_();_nop_();
	return LPF_Y;
}

/*---------------------------------------------------------------------------*/
/* Name		:	void VSPSample(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	VSP采样
/*---------------------------------------------------------------------------*/
void VSPSample(void)
{
  uint16  VSP_User=VSP;
 if(StartONOFF == Disable)
	{
	  if((VSP_User > ON_Duty)&&(mcFocCtrl.mcDcbusFlt > Start_PROTECT_VALUE))  //启动电压
		{			
		  mcSpeedRamp.FlagONOFF  = 1;		
		}
	  else if(VSP_User < OFF_Duty)//电机停机
		{	
			mcSpeedRamp.FlagONOFF  = 0;	
		}
		 if(mcSpeedRamp.FlagONOFF  == 1)
		 {
				if(VSP_User > MAX_Duty)    //最大转速运行
				{
					mcSpeedRamp.BLDC_Value  = MAX_BLDC_Duty;
				}
				else if(VSP_User > MIN_Duty)//调速
				{
					mcSpeedRamp.BLDC_Value  = MIN_BLDC_Duty + BLDC_K*(VSP_User-MIN_Duty);						
				}
				else		     //最小转速运行
				{
					mcSpeedRamp.BLDC_Value  = MIN_BLDC_Duty;
				}
			}
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	void Sleepmode(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	睡眠模式测试
/*---------------------------------------------------------------------------*/
 void Sleepmode(void)
 {
	 		SleepSet.SleepDelayCout++;
		if(SleepSet.SleepDelayCout>=20000)//最大65530，若要再大，需改数据类型
		{
//				FOC_EFREQMIN 	= -Motor_Omega_Ramp_Min;
//				FOC_EFREQHOLD = -Motor_Omega_Ramp_End;
			mcSpeedRamp.TargetValue=0;
			MOE     = 0;
			ClrBit(DRV_CR, FOCEN);	//关闭FOC
			SleepSet.SleepDelayCout=0;
			SleepSet.SleepFlag=1;
			SetBit(P1_IE, P11);   // config P11 as the source of EXTI1
			SetBit(PCON, STOP);
		}

 }
/*---------------------------------------------------------------------------*/
/* Name		:	void StarRampDealwith(void)
/* Input	:	NO
/* Output	:	NO
/* Description:
/*---------------------------------------------------------------------------*/
void StarRampDealwith(void)
{
	uint8 ANGLE_MTemp,ANGLE_DTemp;
	
		if((McStaSet.SetFlag.BLDCSetFlag == 4)&&(mcState == mcRun))
		{		
			if(DRV_DR > HIGH_BLDC_Duty)
			{
				/*-------------------------------------------------------------------------------------------------
				屏蔽续流时间（角度）设置
				-------------------------------------------------------------------------------------------------*/
				ANGLE_MTemp = (uint8)(TIM1_CR1&0x7F);
				
			      if(ANGLE_MASK_R(25) > ANGLE_MTemp)  { TIM1_CR1 = (TIM1_CR1 &(0x80))|(ANGLE_MTemp+1);}
			 else if(ANGLE_MASK_R(25) < ANGLE_MTemp)  { TIM1_CR1 = (TIM1_CR1 &(0x80))|(ANGLE_MTemp-1);}					
 

				/*-------------------------------------------------------------------------------------------------
				检测到过零点后的延迟换相时间（角度）设置
				-------------------------------------------------------------------------------------------------*/
				ANGLE_DTemp = (uint8)(TIM1_CR2&0x7F);
				
			      if(ANGLE_DELAY_R(26) > ANGLE_DTemp)  { TIM1_CR2 = (TIM1_CR2 &(0x80))|(ANGLE_DTemp+1);}
			 else if(ANGLE_DELAY_R(26) < ANGLE_DTemp)  { TIM1_CR2 = (TIM1_CR2 &(0x80))|(ANGLE_DTemp-1);}							 
			 
			}
			else if(DRV_DR < LOW_BLDC_Duty)
			{
				/*-------------------------------------------------------------------------------------------------
				屏蔽续流时间（角度）设置
				-------------------------------------------------------------------------------------------------*/
				ANGLE_MTemp = (uint8)(TIM1_CR1&0x7F);
				
			      if(ANGLE_MASK_R(20) > ANGLE_MTemp)  { TIM1_CR1 = (TIM1_CR1 &(0x80))|(ANGLE_MTemp+1);}
			 else if(ANGLE_MASK_R(20) < ANGLE_MTemp)  { TIM1_CR1 = (TIM1_CR1 &(0x80))|(ANGLE_MTemp-1);}					


				/*-------------------------------------------------------------------------------------------------
				检测到过零点后的延迟换相时间（角度）设置
				-------------------------------------------------------------------------------------------------*/
				ANGLE_DTemp = (uint8)(TIM1_CR2&0x7F);
				
			      if(ANGLE_DELAY_R(26) > ANGLE_DTemp)  { TIM1_CR2 = (TIM1_CR2 &(0x80))|(ANGLE_DTemp+1);}
			 else if(ANGLE_DELAY_R(26) < ANGLE_DTemp)  { TIM1_CR2 = (TIM1_CR2 &(0x80))|(ANGLE_DTemp-1);}							 

			}
		}
}
