//////////////////////////////////////////////////////////////////////
//文件名：FU68xx_SPI.c                                              //
//说明：FU68xx系列芯片的SPI底层驱动                                 //
//Log                                                               //
//Timer         Writer      Thing                               Ver //
//2016-10-08    Any         创建文件                            V1.0//
//2016-11-03    Any         SPI一些配置使用宏条件                   //
//                          收发函数合并                        V1.1//
//2016-12-19    Any         除去宏定义操作                      V1.2//
//2016-12-22    Any         增加空闲电平初始化                  V1.3//
//2016-12-23    Any         PHSEL修改                           V1.4//
//2017-02-06    Any         增强PHSEL判断                       V1.5//
//2017-02-13    Any         把空闲电平设置归入Line_Mode         V1.6//
//2017-02-21    Any         取消Nss控制函数，改为宏定义         V1.7//
//2017-02-21    Any         取消收发函数的Nss控制权             V1.8//
//2017-02-21    Any         取消SPI忙检测函数，改为宏定义       V1.9//
//2017-02-21    Any         建立SPI所有标志位的检测和部分清除   V2.0//
//////////////////////////////////////////////////////////////////////
#include <FU6812_MCU.h>
#include <FU6812_SPI.h>

/**
 * 初始化SPI
 *
 */
void SPI_Config(void)
{
  #if defined (SPI_SET_MASTER)
      SPI_CLK = SPI_FREC / SPI_SET_SPEED - 1;  // 设置SPI时钟(主机模式设置)
  #endif

  SPI_CR0 = SPI_CLK_MODE                       // 设置SPI主从机模式和SPI时钟模式
  #if defined (SPI_SET_MASTER)
       | SPIMS
  #endif
  ;

  SPI_CR1 = SPIEN                             // 设置SPI模式和使能SPI
  #if defined (SPI_SET_MASTER)
      | SPI_SET_MODE
  #elif (SPI_SET_MODE != SPI_MODE_L3)
      | SPI_MODE_L4
  #endif
  ;

  #if (SPI_SET_MODE != SPI_MODE_L3)
      P0_PU = P04;                          // 4线模式下NSS使能上拉
  #endif

  #if defined (EN_IRQ_SPI)                     // 设置SPI中断
      SPIIE   = 1;
  #endif

  SetReg(PH_SEL, SPITMOD | UARTEN | UARTCH, 0x00); // 使能SPI复用端口
}

/**
 * SPI单字节收发
 *
 * @param   SendDat    发送的数据
 * @return             接收的数据
 */
uint8_t SendReceive_SPI(uint8_t SendDat)
{
  while (!ReadBit(SPI_CR1, TXBMT));        // 等到发送缓冲为空
  SPI_DR = SendDat;

  while (ReadBit(SPI_CR0, SPIBSY));           // 等待SPI运行结束

  return SPI_DR;
}

/**
 * 收发一串SPI数据
 *
 * @param   SendDat    发送数据流
 * @param   ReceiveDat 接收数据流
 * @param   len        数据流长度
 */
void SendReceives_SPI(uint8_t* SendDat, uint8_t* ReceiveDat, uint8_t len)
{
  while (len--)
  {
      while (!ReadBit(SPI_CR1, TXBMT));
      SPI_DR = *SendDat;
      SendDat++;

      while (ReadBit(SPI_CR0, SPIBSY));
      *ReceiveDat = SPI_DR;
      ReceiveDat++;
  }
}
