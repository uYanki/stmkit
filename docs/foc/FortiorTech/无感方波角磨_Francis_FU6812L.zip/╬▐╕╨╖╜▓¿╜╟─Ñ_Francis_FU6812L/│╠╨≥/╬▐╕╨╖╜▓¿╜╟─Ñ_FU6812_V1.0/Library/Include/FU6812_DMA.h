#ifndef __FU6812_DMA_H__
#define __FU6812_DMA_H__

#include <FU6812_MCU.h>

/*************************************************************************************///Defined CMD(Don't touch)
// DMA管道参数表
 #define UART_XDATA      0x00                            // DMA管道--UART->XDATA
 #define XDATA_UART      (DMACFG0)                       // DMA管道--UART<-XDATA
 #define I2C_XDATA       (DMACFG1)                       // DMA管道--I2C ->XDATA
 #define XDATA_I2C       (DMACFG0 | DMACFG1)             // DMA管道--I2C <-XDATA
 #define SPI_XDATA       (DMACFG2)                       // DMA管道--SPI ->XDATA
 #define XDATA_SPI       (DMACFG2 | DMACFG0)             // DMA管道--SPI <-XDATA

// DMA模块参数配置表
 #define ENIE DMAIE                                      // 使能DMA中断
 #define DISIE 0x00                                      // 禁能DMA中断
 #define FLSB 0x00                                       // DMA先发低8位
 #define FHSB ENDIAN                                     // DMA先发高8位
/*************************************************************************************///Config
/*************************************************************************************///External Function
#define Wait_DMA(a)       while (ReadBit(*(&DMA0_CR0 + a), DMABSY))
#define Switch_DMA(a)     SetBit(*(&DMA0_CR0 + a), DMAEN | DMABSY)

extern void Init_DMA(uint8_t IEMod, uint8_t FirstMod);
extern void Set_DMA(uint8_t Ch, uint8_t Pipe, uint8_t* Addr, uint8_t Len);
extern void Set_DBG_DMA(uint8_t* Addr);

#endif