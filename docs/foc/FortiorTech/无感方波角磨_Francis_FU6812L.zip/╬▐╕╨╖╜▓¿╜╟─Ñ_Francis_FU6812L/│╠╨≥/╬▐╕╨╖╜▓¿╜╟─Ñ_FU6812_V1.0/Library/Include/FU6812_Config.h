#ifndef __FU6812_CONFIG_H__
#define __FU6812_CONFIG_H__

  #define USE_ADC
  #define USE_AMP
  #define USE_CMP
  #define USE_DAC
  #define USE_DMA
  #define USE_DRV
  #define USE_FLASH
  #define USE_FOC
  #define USE_GPIO
  #define USE_I2C
  #define USE_IRQ
  #define USE_LPF
  #define USE_MDU
  #define USE_PI
  #define USE_POWER
  #define USE_RST
  #define USE_SPI
  #define USE_TIM1
  #define USE_TIM2
  #define USE_TIM3
  #define USE_TIM4
  #define USE_UART
  #define USE_WDT



  #define EN_IRQ_LVW
  #define EN_IRQ_INT0
  #define EN_IRQ_INT1
  #define EN_IRQ_DRV
  #define EN_IRQ_TIM2
  #define EN_IRQ_TIM1
  #define EN_IRQ_ADC
  #define EN_IRQ_CMP
  #define EN_IRQ_TIM3
  #define EN_IRQ_TIM45
  #define EN_IRQ_TSD
  #define EN_IRQ_UART
  #define EN_IRQ_I2C
  #define EN_IRQ_SPI
  #define EN_IRQ_DMA

#endif
