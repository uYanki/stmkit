#ifndef __FU6812_MCU_H__
#define __FU6812_MCU_H__
#include <intrins.h>
#include <FU6812_Type.h>
//--------------------------------------------------------------------------
#define SYSCLK_FREQ               (24000000)                      // -- %% CPUFre = 24MHz
#define FREC16 (SYSCLK_FREQ / 16)                                 //  
#define FREC8  (SYSCLK_FREQ / 8)                                  //  
#define FREC2  (SYSCLK_FREQ / 2)                                  // 
//--------------------------------------------------------------------------

#define SetReg(reg, val1, val2)                 (reg = reg & (~(val1)) | (val2))
#define SetBit(reg, value)                      (reg |=  (value))
#define ClrBit(reg, value)                      (reg &= ~(value))
#define XorBit(reg, value)                      (reg ^=  (value))
#define ReadBit(reg, value)                     ((reg & (value)) == (value))


// 搜索快照寄存器请在Keil搜索"[0-9A-Z]__[A-Z]"，勾选"Match Case"和"Regular Expressior"
// 快速搜索外设方法:在搜索对话框中输入"//"+外设名称.例:搜索TIMER1,则输入"//TIM1"

/*************************************************************///SFR
 sfr16   DPTR                = 0x82;                           // 8051指针
 sfr     DPL                 = 0x82;                           // 8051指针低8位
 sfr     DPH                 = 0x83;                           // 8051指针高8位

 sfr     PSW                 = 0xd0;                           // 8051状态寄存器
 sbit    CY                                     = PSW^7;
 sbit    AC                                     = PSW^6;
 sbit    F0                                     = PSW^5;
 sbit    RS1                                    = PSW^4;
 sbit    RS0                                    = PSW^3;
 sbit    OV                                     = PSW^2;
 sbit    F1                                     = PSW^1;
 sbit    P                                      = PSW^0;
/*************************************************************///RST
 sfr     RST_SRC             = 0xc9;
 #define RSTPOW                                 0x80
 #define RSTEXT                                 0x40
 #define RSTLVD                                 0x20
 #define RSTEOS                                 0x10
 #define RSTWDT                                 0x08
 #define RSTFED                                 0x04
 #define RSTDBG                                 0x02
 #define RSTCLR                                 0x01
/*************************************************************///IRQ
 sfr     TCON                = 0x88;
 sbit    TSDIF                                  = TCON^5;
 sbit    IT11                                   = TCON^4;
 sbit    IT10                                   = TCON^3;
 sbit    IF0                                    = TCON^2;
 sbit    IT01                                   = TCON^1;
 sbit    IT00                                   = TCON^0;

 sfr     IE                  = 0xa8;
 sbit    EA                                     = IE^7;
 sbit    ES0                                    = IE^4;
 sbit    SPIIE                                  = IE^3;
 sbit    EX1                                    = IE^2;
 sbit    TSDIE                                  = IE^1;
 sbit    EX0                                    = IE^0;

 sfr     IP0                 = 0xb8;
 sbit    PDRV1                                  = IP0^7;
 sbit    PDRV0                                  = IP0^6;
 sbit    PX11                                   = IP0^5;
 sbit    PX10                                   = IP0^4;
 sbit    PX01                                   = IP0^3;
 sbit    PX00                                   = IP0^2;
 sbit    PLVW1                                  = IP0^1;
 sbit    PLVW0                                  = IP0^0;

 sfr     IP1                 = 0xc0;
 sbit    PCMP1                                  = IP1^7;
 sbit    PCMP0                                  = IP1^6;
 sbit    PADC1                                  = IP1^5;
 sbit    PADC0                                  = IP1^4;
 sbit    PTIM11                                 = IP1^3;
 sbit    PTIM10                                 = IP1^2;
 sbit    PTIM21                                 = IP1^1;
 sbit    PTIM20                                 = IP1^0;

 sfr     IP2                 = 0xc8;
 sbit    PTSD1                                  = IP2^7;
 sbit    PTSD0                                  = IP2^6;
 sbit    PTIM4S1                                = IP2^5;
 sbit    PTIM4S0                                = IP2^4;
 sbit    PTIM31                                 = IP2^3;
 sbit    PTIM30                                 = IP2^2;

 sfr     IP3                 = 0xd8;
 sbit    PDMA1                                  = IP3^7;
 sbit    PDMA0                                  = IP3^6;
 sbit    PSPI1                                  = IP3^5;
 sbit    PSPI0                                  = IP3^4;
 sbit    PI2C1                                  = IP3^3;
 sbit    PI2C0                                  = IP3^2;
 sbit    PUART1                                 = IP3^1;
 sbit    PUART0                                 = IP3^0;

 // 中断编号
 // LVW             interrupt 0
 // INT0            interrupt 1
 // INT1            interrupt 2
 // DRV             interrupt 3
 // TIM2            interrupt 4
 // TIM1            interrupt 5
 // ADC             interrupt 6
 // CMP             interrupt 7
 // TIM3            interrupt 9
 // TIM4/SysTick    interrupt 10
 // TSD             interrupt 11
 // UART            interrupt 12
 // I2C             interrupt 13
 // SPI             interrupt 14
 // DMA             interrupt 15
/*************************************************************///I2C
 #define I2C_CR              *(_IO  uint8_t xdata *)0x4028     // I2C控制寄存器
 #define I2CEN                                  0x80               // rw--I2C使能
 #define I2CMS                                  0x40               // rw--主/从机模式选择
 #define I2CFMOD                                0x08               // rw--滤波宽度 (下一MCU版本删除)
 #define I2CSPD1                                0x04               // rw--速度控制位1
 #define I2CSPD0                                0x02               // rw--速度控制位0
 #define I2CIE                                  0x01               // rw--中断控制

 #define I2C_SR              *(_IO  uint8_t xdata *)0x402b     // I2C状态寄存器
 #define I2CBSY                                 0x80               // r---I2C忙标志
 #define DMOD                                   0x40               // rw--I2C读写控制
 #define I2CSTA                                 0x10               // rw--START信号控制
 #define I2CSTP                                 0x08               // rw--STOP信号控制
 #define STR                                    0x04               // rw--I2C事件完成标志
 #define NACK                                   0x02               // rw--应答信号控制
 #define I2CIF                                  0x01               // r---中断标志

 #define I2C_ID              *(_IO  uint8_t xdata *)0x4029     // 本机2C地址
 #define I2C_DR              *(_IO  uint8_t xdata *)0x402a     // I2C数据缓冲器
/*************************************************************///SPI
 #define SPI_CR0             *(_IO  uint8_t xdata *)0x4030     // SPI控制寄存器1
 #define SPIBSY                                 0x80               // r---忙标志
 #define SPIMS                                  0x40               // rw--主/从机设置
 #define CPHA                                   0x20               // rw--时钟相位
 #define CPOL                                   0x10               // rw--时钟空闲电平
 #define SLVSEL                                 0x08               // r---NSS处理后的信号
 #define NSSIN                                  0x04               // r---NSS即时信号
 #define SRMT                                   0x02               // r---移位寄存器空标志
 #define RXBMT                                  0x01               // r---接收缓冲器空标志

 #define SPI_CR1             *(_IO  uint8_t xdata *)0x4031     // SPI控制寄存器2
 #define SPIIF                                  0x80               // rw0-中断标志
 #define WCOL                                   0x40               // rw0-写冲突标志
 #define MODF                                   0x20               // rw0-模式错误标志
 #define RXOVR                                  0x10               // rw0-接收溢出标志
 #define NSSMOD1                                0x08               // rw--SPI模式配置位1
 #define NSSMOD0                                0x04               // rw--SPI模式配置位0
 #define TXBMT                                  0x02               // r---发送缓冲器空标志
 #define SPIEN                                  0x01               // rw--SPI使能

 #define SPI_CLK             *(_IO  uint8_t xdata *)0x4032     // SPI时钟配置寄存器
 #define SPI_DR              *(_IO  uint8_t xdata *)0x4033     // SPI数据缓冲器
/*************************************************************///UART
 sfr     UT_CR               = 0x98;                           // UART控制寄存器
 sbit    UT_MOD1                                = UT_CR^7;
 sbit    UT_MOD0                                = UT_CR^6;
 sbit    SM2                                    = UT_CR^5;
 sbit    REN                                    = UT_CR^4;
 sbit    TB8                                    = UT_CR^3;
 sbit    RB8                                    = UT_CR^2;
 sbit    TI                                     = UT_CR^1;
 sbit    RI                                     = UT_CR^0;

 sfr16   UT_BAUD             = 0x9a;                           // UART波特率控制器
 #define UART_2xBAUD                            0x8000

 sfr     UT_DR               = 0x99;                           // UART数据寄存器
/*************************************************************///MDU
 sfr     MDU_CR              = 0xc1;                           // MDU控制寄存器
 #define DIVDONE                                0x80
 #define DIVERR                                 0x40
 #define ALIGN1                                 0x08
 #define ALIGN0                                 0x04
 #define MDSN                                   0x02
 #define DIVSTA                                 0x01

 sfr16   MDU_MA              = 0xc2;                           // 乘法操作数A
 sfr16   MDU_DA01            = 0xc4;                           // 除法操作数A----被除数或商的[15:0]
 sfr16   MDU_DA23            = 0xc6;                           // 除法操作数A----被除数或商的[31:16]
 sfr16   MDU_MB              = 0xca;                           // 乘法操作数B
 sfr16   MDU_DB01            = 0xcc;                           // 除法操作数B----除数或余数[15:0]

 sfr     MDU_DA0             = 0xc4;                           // 除法操作数A----被除数或商的[7:0]
 sfr     MDU_DA1             = 0xc5;                           // 除法操作数A----被除数或商的[15:8]
 sfr     MDU_DA2             = 0xc6;                           // 除法操作数A----被除数或商的[23:16]
 sfr     MDU_DA3             = 0xc7;                           // 除法操作数A----被除数或商的[31:24]
 sfr     MDU_DB0             = 0xcc;                           // 除法操作数A----被除数或商的[7:0]
 sfr     MDU_DB1             = 0xcd;                           // 除法操作数A----被除数或商的[15:8]
/*************************************************************///PI
 sfr     PI_LPF_CR           = 0xf9;                           // PI和LPF以及T2部分功能的控制寄存器
 #define T2TSS                                  0x80
 #define T2IPD                                  0x40
 #define RANGR                                  0x04
 #define PISTA                                  0x02
 #define LPFSTA                                 0x01

 sfr16   PI_EK               = 0xea;                           // PI误差输入寄存器
 sfr16   PI_UK               = 0xec;                           // PI结果输出寄存器
 sfr16   PI_KP               = 0xee;                           // PI的比例值寄存器
 sfr16   PI_KI               = 0xf2;                           // PI的积分值寄存器
 sfr16   PI_UKMAX            = 0xf4;                           // PI输出结果最大值寄存器
 sfr16   PI_UKMIN            = 0xf6;                           // PI输出结果最小值寄存器
/*************************************************************///LPF
 sfr     LPF_K               = 0xdd;
 sfr16   LPF_X               = 0xde;
 sfr16   LPF_Y               = 0xe6;
/*************************************************************///FOC
 #define FOC_CR1             *(_IO  uint8_t xdata *)0x40a0
 #define OVMDL                                  0x80
 #define EFAE                                   0x40
 #define RFAE                                   0x20
 #define ANGM                                   0x10
 #define CSM1                                   0x08
 #define CSM0                                   0x04
 #define SPWMSEL                                0x02
 #define SVPWMEN                                0x01

 #define FOC_CR2             *(_IO  uint8_t xdata *)0x40a1
 #define ESEL                                   0x80
 #define F5SEG                                  0x20
 #define DSS                                    0x10
 #define CSOC1                                  0x08
 #define CSOC0                                  0x04
 #define UQD                                    0x02
 #define UDD                                    0x01

 #define FOC_EKP             *(_IO  int16_t xdata *)0x4074
 #define FOC_EKI             *(_IO  int16_t xdata *)0x4076
 #define FOC_KSLIDE          *(_IO uint16_t xdata *)0x4078
 #define FOC_EKLPFMIN        *(_IO uint16_t xdata *)0x407a
 #define FOC_EBMFK           *(_IO  int16_t xdata *)0x407c
 #define FOC_OMEKLPF         *(_IO  int16_t xdata *)0x407e
 #define FOC_FBASE           *(_IO uint16_t xdata *)0x4080
 #define FOC_EFREQACC        *(_IO uint16_t xdata *)0x4082
 #define FOC_EFREQMIN        *(_IO  int16_t xdata *)0x4084
 #define FOC_EFREQHOLD       *(_IO  int16_t xdata *)0x4086
 #define FOC_EK3             *(_IO  int16_t xdata *)0x4088
 #define FOC_EK4             *(_IO  int16_t xdata *)0x408a
 #define FOC_EK1             *(_IO  int16_t xdata *)0x408c
 #define FOC_EK2             *(_IO  int16_t xdata *)0x408e
 #define FOC_IDREF           *(_IO uint16_t xdata *)0x4090
 #define FOC_IQREF           *(_IO uint16_t xdata *)0x4092
 #define FOC_DQKP            *(_IO uint16_t xdata *)0x4094
 #define FOC_DQKI            *(_IO uint16_t xdata *)0x4096
 #define FOC__UDCFLT         *(_I  uint16_t xdata *)0x4098

 #define FOC_TSMIN           *(_IO  uint8_t xdata *)0x40a2
 #define FOC_TGLI            *(_IO  uint8_t xdata *)0x40a3
 #define FOC_TBLO            *(_IO  uint8_t xdata *)0x40a4
 #define FOC_TRGDLY          *(_IO   int8_t xdata *)0x40a5
 #define FOC_CSO             *(_IO uint16_t xdata *)0x40a6
 #define FOC__RTHESTEP       *(_IO  int16_t xdata *)0x40a8
 #define FOC_RTHEACC         *(_IO  int16_t xdata *)0x40aa
 #define FOC__RTHECNT        *(_IO  uint8_t xdata *)0x40ac
 #define FOC__THECOR         *(_IO  uint8_t xdata *)0x40ad
 #define FOC__THECOMP        *(_IO  int16_t xdata *)0x40ae
 #define FOC_DMAX            *(_IO  int16_t xdata *)0x40b0
 #define FOC_DMIN            *(_IO  int16_t xdata *)0x40b2
 #define FOC_QMAX            *(_IO  int16_t xdata *)0x40b4
 #define FOC_QMIN            *(_IO  int16_t xdata *)0x40b6
 #define FOC__UD             *(_IO  int16_t xdata *)0x40b8
 #define FOC__UQ             *(_IO  int16_t xdata *)0x40ba
 #define FOC__ID             *(_I   int16_t xdata *)0x40bc
 #define FOC__IQ             *(_I   int16_t xdata *)0x40be
 #define FOC__IBET           *(_I   int16_t xdata *)0x40c0
 #define FOC__VBET           *(_I   int16_t xdata *)0x40c2
 #define FOC__VALP           *(_I   int16_t xdata *)0x40c4
 #define FOC__IC             *(_I   int16_t xdata *)0x40c6
 #define FOC__IB             *(_I   int16_t xdata *)0x40c8
 #define FOC__IA             *(_I   int16_t xdata *)0x40ca
 #define FOC__THETA          *(_IO  int16_t xdata *)0x40cc
 #define FOC__ETHETA         *(_IO  int16_t xdata *)0x40ce
 #define FOC__EALP           *(_I   int16_t xdata *)0x40d0
 #define FOC__EBET           *(_I   int16_t xdata *)0x40d2
 #define FOC__EOME           *(_IO  int16_t xdata *)0x40d4
 #define FOC__ESQU           *(_I  uint16_t xdata *)0x40d6
 #define FOC__POW            *(_I   int16_t xdata *)0x40d8
/*************************************************************///TIM1
 #define TIM1_CR0            *(_IO  uint8_t xdata *)0x4068
 #define T1RWEN                                 0x80
 #define T1CFLT1                                0x40
 #define T1CFLT0                                0x20
 #define T1FORC                                 0x10
 #define T1OPS1                                 0x08
 #define T1OPS0                                 0x04
 #define T1BCEN                                 0x02
 #define T1RCEN                                 0x01

 #define TIM1_CR1            *(_IO  uint8_t xdata *)0x4069
 #define T1BAPE                                 0x80

 #define TIM1_CR2            *(_IO  uint8_t xdata *)0x406a
 #define T1BRS                                  0x80

 #define TIM1_CR3            *(_IO  uint8_t xdata *)0x406b
 #define T1AFL                                  0x80
 #define T1PSC2                                 0x40
 #define T1PSC1                                 0x20
 #define T1PSC0                                 0x10
 #define T1TIS1                                 0x08
 #define T1TIS0                                 0x04
 #define T1INM1                                 0x02
 #define T1INM0                                 0x01

 #define TIM1_CR4            *(_IO  uint8_t xdata *)0x406c
 #define T1CST2                                 0x04
 #define T1CST1                                 0x02
 #define T1CST0                                 0x01

 #define TIM1_IER            *(_IO  uint8_t xdata *)0x406d
 #define T1UPD                                  0x80
 #define T1ADIE                                 0x20
 #define T1BOIE                                 0x10
 #define T1ROIE                                 0x08
 #define T1WTIE                                 0x04
 #define T1PDIE                                 0x02
 #define T1BDIE                                 0x01

 #define TIM1_SR             *(_IO  uint8_t xdata *)0x406e
 #define T1ADIF                                 0x20
 #define T1BOIF                                 0x10
 #define T1ROIF                                 0x08
 #define T1WTIF                                 0x04
 #define T1PDIF                                 0x02
 #define T1BDIF                                 0x01


 #define TIM1_DBR1           *(_IO uint16_t xdata *)0x4074
 #define TIM1_DBR2           *(_IO uint16_t xdata *)0x4076
 #define TIM1_DBR3           *(_IO uint16_t xdata *)0x4078
 #define TIM1_DBR4           *(_IO uint16_t xdata *)0x407a
 #define TIM1_DBR5           *(_IO uint16_t xdata *)0x407c
 #define TIM1_DBR6           *(_IO uint16_t xdata *)0x407e
 #define TIM1_DBR7           *(_IO uint16_t xdata *)0x4080
 #define T1CPE2                                 0x4000
 #define T1CPE1                                 0x2000
 #define T1CPE0                                 0x1000
 #define T1WHP                                  0x0800
 #define T1WLP                                  0x0400
 #define T1VHP                                  0x0200
 #define T1VLP                                  0x0100
 #define T1UHP                                  0x0080
 #define T1ULP                                  0x0040
 #define T1WHE                                  0x0020
 #define T1WLE                                  0x0010
 #define T1VHE                                  0x0008
 #define T1VLE                                  0x0004
 #define T1UHE                                  0x0002
 #define T1ULE                                  0x0001

 #define TIM1_BCOR           *(_IO uint16_t xdata *)0x4070
 #define TIM1__BCNTR         *(_IO uint16_t xdata *)0x4082
 #define TIM1__BCCR          *(_IO uint16_t xdata *)0x4084
 #define TIM1__BARR          *(_IO uint16_t xdata *)0x4086
 #define TIM1__RARR          *(_IO uint16_t xdata *)0x4088
 #define TIM1__RCNTR         *(_IO uint16_t xdata *)0x408a
 #define TIM1__UCOP          *(_IO uint16_t xdata *)0x408c
 #define TIM1__UFLP          *(_IO uint16_t xdata *)0x408e
 #define TIM1__URES          *(_IO uint16_t xdata *)0x4090
 #define TIM1__UIGN          *(_IO uint16_t xdata *)0x4092
 #define TIM1_KF             *(_IO uint16_t xdata *)0x4094
 #define TIM1_KR             *(_IO uint16_t xdata *)0x4096
 #define TIM1__ITRIP         *(_I  uint16_t xdata *)0x4098
/*************************************************************///TIM2
 sfr     TIM2_CR0            = 0xa1;
 #define T2PSC2                                 0x80
 #define T2PSC1                                 0x40
 #define T2PSC0                                 0x20
 #define T2OCM                                  0x10
 #define T2IRE                                  0x08
 #define T2CES                                  0x04
 #define T2MOD1                                 0x02
 #define T2MOD0                                 0x01

 sfr     TIM2_CR1            = 0xa9;
 #define T2IR                                   0x80
 #define T2IP                                   0x40
 #define T2IF                                   0x20
 #define T2IPE                                  0x10
 #define T2IFE                                  0x08
 #define T2FE                                   0x04
 #define T2DIR                                  0x02
 #define T2EN                                   0x01

 sfr16   TIM2__CNTR          = 0xaa;
 sfr16   TIM2__DR            = 0xac;
 sfr16   TIM2__ARR           = 0xae;
 sfr     TIM2_CR2            = 0xf9;
/*************************************************************///TIM3
 sfr     TIM3_CR0            = 0x9c;
 #define T3PSC2                                 0x80
 #define T3PSC1                                 0x40
 #define T3PSC0                                 0x20
 #define T3OCM                                  0x10
 #define T3IRE                                  0x08
 #define T3OPM                                  0x02
 #define T3MOD                                  0x01

 sfr     TIM3_CR1            = 0x9d;
 #define T3IR                                   0x80
 #define T3IP                                   0x40
 #define T3IF                                   0x20
 #define T3IPE                                  0x10
 #define T3IFE                                  0x08
 #define T3FE1                                  0x04
 #define T3FE0                                  0x02
 #define T3EN                                   0x01

 sfr16   TIM3__CNTR          = 0xa2;
 sfr16   TIM3__DR            = 0xa4;
 sfr16   TIM3__ARR           = 0xa6;
/*************************************************************///TIM4
 sfr     TIM4_CR0            = 0x9e;
 #define T4PSC2                                 0x80
 #define T4PSC1                                 0x40
 #define T4PSC0                                 0x20
 #define T4OCM                                  0x10
 #define T4IRE                                  0x08
 #define T4OPM                                  0x02
 #define T4MOD                                  0x01

 sfr     TIM4_CR1            = 0x9f;
 #define T4IR                                   0x80
 #define T4IP                                   0x40
 #define T4IF                                   0x20
 #define T4IPE                                  0x10
 #define T4IFE                                  0x08
 #define T4FE1                                  0x04
 #define T4FE0                                  0x02
 #define T4EN                                   0x01

 sfr16   TIM4__CNTR          = 0x92;
 sfr16   TIM4__DR            = 0x94;
 sfr16   TIM4__ARR           = 0x96;
/*************************************************************///SYSTICK
 #define SYST_ARR            *(_IO uint16_t xdata *)0x4064
/*************************************************************///DRV
 sfr     DRV_OUT             = 0xf8;       // 驱动输出空闲状态寄存器
 sbit    MOE                                    = DRV_OUT^7;
 sbit    OISWL                                  = DRV_OUT^5;
 sbit    OISWH                                  = DRV_OUT^4;
 sbit    OISVL                                  = DRV_OUT^3;
 sbit    OISVH                                  = DRV_OUT^2;
 sbit    OISUL                                  = DRV_OUT^1;
 sbit    OISUH                                  = DRV_OUT^0;

 #define DRV_DR              *(_IO uint16_t xdata *)0x4058
 #define DRV_COMR            *(_IO uint16_t xdata *)0x405a

 #define DRV_CMR             *(_IO uint16_t xdata *)0x405c
 #define W2HP                                   0x8000
 #define W2LP                                   0x4000
 #define W2HE                                   0x2000
 #define W2LE                                   0x1000
 #define WHP                                    0x0800
 #define WLP                                    0x0400
 #define VHP                                    0x0200
 #define VLP                                    0x0100
 #define UHP                                    0x0080
 #define ULP                                    0x0040
 #define WHE                                    0x0020
 #define WLE                                    0x0010
 #define VHE                                    0x0008
 #define VLE                                    0x0004
 #define UHE                                    0x0002
 #define ULE                                    0x0001

 #define DRV_ARR             *(_IO uint16_t xdata *)0x405e
 #define DRV_DTR             *(_IO  uint8_t xdata *)0x4060

 #define DRV_SR              *(_IO  uint8_t xdata *)0x4061
 #define SYSTIF                                 0x80
 #define SYSTIE                                 0x40
 #define FGIF                                   0x20
 #define DCIF                                   0x10
 #define FGIE                                   0x08
 #define DCIP                                   0x04
 #define DCIM1                                  0x02
 #define DCIM0                                  0x01

 #define DRV_CR              *(_IO  uint8_t xdata *)0x4062
 #define DRVEN                                  0x80
 #define DDIR                                   0x40
 #define FOCEN                                  0x20
 #define DRPE                                   0x10
 #define OCS                                    0x08
 #define MESEL                                  0x04
 #define DRVOE                                  0x01
/*************************************************************///WDT
 #define WDT_CR              *(_IO  uint8_t xdata *)0x4026
 #define WDTF                                   0x02
 #define WDTRF                                  0x01

 #define WDT_REL             *(_IO  uint8_t xdata *)0x4027
/*************************************************************///GPIO
 sfr     P0                  = 0x80;
 sbit    GP00                                   = P0^0;// IO
 sbit    GP01                                   = P0^1;// IO
 sbit    GP02                                   = P0^2;// IO
 sbit    GP03                                   = P0^3;// IO
 sbit    GP04                                   = P0^4;// IO
 sbit    GP05                                   = P0^5;// IO
 sbit    GP06                                   = P0^6;// IO
 sbit    GP07                                   = P0^7;// IO

 sfr     P1                  = 0x90;
 sbit    GP10                                   = P1^0;// IO
 sbit    GP11                                   = P1^1;// IO
 sbit    GP12                                   = P1^2;// IO
 sbit    GP13                                   = P1^3;// IOA
 sbit    GP14                                   = P1^4;// IOA
 sbit    GP15                                   = P1^5;// IOA
 sbit    GP16                                   = P1^6;// IOA
 sbit    GP17                                   = P1^7;// IOA

 sfr     P2                  = 0xa0;
 sbit    GP20                                   = P2^0;// IOA
 sbit    GP21                                   = P2^1;// IOA
 sbit    GP22                                   = P2^2;// IOA
 sbit    GP23                                   = P2^3;// IOA
 sbit    GP24                                   = P2^4;// IOA
 sbit    GP25                                   = P2^5;// IOA
 sbit    GP26                                   = P2^6;// IOA
 sbit    GP27                                   = P2^7;// IOA

 sfr     P3                  = 0xb0;
 sbit    GP30                                   = P3^0;// IOA
 sbit    GP31                                   = P3^1;// IOA
 sbit    GP32                                   = P3^2;// IOA
 sbit    GP33                                   = P3^3;// IOA
 sbit    GP34                                   = P3^4;// IOA
 sbit    GP35                                   = P3^5;// IOA
 sbit    GP36                                   = P3^6;// IO
 sbit    GP37                                   = P3^7;// IO

 sfr     P4                  = 0xe8;
 sbit    GP40                                   = P4^0;// IO
 sbit    GP41                                   = P4^1;// IO
 sbit    GP42                                   = P4^2;// IO

 sfr     P0_OE               = 0xfc;            // P0输出使能寄存器
 #define P0_PU               *(_IO  uint8_t xdata *)0x4053     // P0上拉使能寄存器
 #define P07                                    0x80
 #define P06                                    0x40
 #define P05                                    0x20
 #define P04                                    0x10
 #define P03                                    0x08
 #define P02                                    0x04
 #define P01                                    0x02
 #define P00                                    0x01

 sfr     P1_IE               = 0xd1;
 sfr     P1_IF               = 0xd2;
 sfr     P1_OE               = 0xfd;            // P1输出使能寄存器
 #define P1_PU               *(_IO  uint8_t xdata *)0x4054     // P1上拉使能寄存器
 #define P17                                    0x80
 #define P16                                    0x40
 #define P15                                    0x20
 #define P14                                    0x10
 #define P13                                    0x08
 #define P12                                    0x04
 #define P11                                    0x02
 #define P10                                    0x01

 #define P1_AN               *(_IO  uint8_t xdata *)0x4050     // P1模拟使能寄存器
 #define HBMOD                                  0x08
 #define HDIO                                   0x04
 #define ODE1                                   0x02
 #define ODE0                                   0x01
 // #define P14                                 0x10
 // #define P15                                 0x20
 // #define P16                                 0x40
 // #define P17                                 0x80

 sfr     P2_IE               = 0xd3;
 sfr     P2_IF               = 0xd4;
 sfr     P2_OE               = 0xfe;            // P2输出使能寄存器
 #define P2_AN               *(_IO  uint8_t xdata *)0x4051     // P2模拟使能寄存器
 #define P2_PU               *(_IO  uint8_t xdata *)0x4055     // P2上拉使能寄存器
 #define P27                                    0x80
 #define P26                                    0x40
 #define P25                                    0x20
 #define P24                                    0x10
 #define P23                                    0x08
 #define P22                                    0x04
 #define P21                                    0x02
 #define P20                                    0x01

 sfr     P3_OE               = 0xff;            // P3输出使能寄存器
 #define P3_PU               *(_IO  uint8_t xdata *)0x4056     // P3上拉使能寄存器
 #define P3_AN               *(_IO  uint8_t xdata *)0x4052     // P3模拟使能寄存器
 #define P37                                    0x80
 #define P36                                    0x40
 #define P35                                    0x20
 #define P34                                    0x10
 #define P33                                    0x08
 #define P32                                    0x04
 #define P31                                    0x02
 #define P30                                    0x01

 sfr     P4_OE               = 0xe9;            // P4输出使能寄存器
 #define P4_PU               *(_IO  uint8_t xdata *)0x4057     // P4上拉使能寄存器
 #define P42                                    0x04
 #define P41                                    0x02
 #define P40                                    0x01

 #define PH_SEL              *(_IO  uint8_t xdata *)0x404c     //端口复用
 #define SPITMOD                                0x80
 #define UARTEN                                 0x40
 #define UARTCH                                 0x20
 #define T4SEL                                  0x10
 #define T3SEL                                  0x08
 #define T2SEL                                  0x04
 #define T2SSEL                                 0x02
 #define W2OE                                   0x01
/*************************************************************///ADC
 #define ADC_MASK_SYSC       *(_IO uint16_t xdata *)0x4036
 #define CH11EN                                 0x0800
 #define CH10EN                                 0x0400
 #define CH9EN                                  0x0200
 #define CH8EN                                  0x0100
 #define CH7EN                                  0x0080
 #define CH6EN                                  0x0040
 #define CH5EN                                  0x0020
 #define CH4EN                                  0x0010
 #define CH3EN                                  0x0008
 #define CH2EN                                  0x0004
 #define CH1EN                                  0x0002
 #define CH0EN                                  0x0001

 #define ADC_CR              *(_IO  uint8_t xdata *)0x4039
 #define ADCEN                                  0x80
 #define ADCBSY                                 0x40
 #define ADCIE                                  0x02
 #define ADCIF                                  0x01

 #define ADC_SYSC            *(_IO  uint8_t xdata *)0x4038
 #define ADC0_DR             *(_I  uint16_t xdata *)0x0300
 #define ADC1_DR             *(_I  uint16_t xdata *)0x0302
 #define ADC2_DR             *(_I  uint16_t xdata *)0x0304
 #define ADC3_DR             *(_I  uint16_t xdata *)0x0306
 #define ADC4_DR             *(_I  uint16_t xdata *)0x0308
 #define ADC5_DR             *(_I  uint16_t xdata *)0x030a
 #define ADC6_DR             *(_I  uint16_t xdata *)0x030c
 #define ADC7_DR             *(_I  uint16_t xdata *)0x030e
 #define ADC8_DR             *(_I  uint16_t xdata *)0x0310
 #define ADC9_DR             *(_I  uint16_t xdata *)0x0312
 #define ADC10_DR            *(_I  uint16_t xdata *)0x0314
 #define ADC11_DR            *(_I  uint16_t xdata *)0x0316
/*************************************************************///DAC
 #define DAC_CR              *(_IO  uint8_t xdata *)0x4035
 #define DACEN                                  0x80
 #define DACMOD                                 0x40

 #define DAC_DR              *(_IO  uint8_t xdata *)0x404b
/*************************************************************///DMA
 #define DMA0_CR0            *(_IO uint8_t  xdata *)0x403a     //DMA通道0配置 & DMA公共配置
 #define DMA1_CR0            *(_IO uint8_t  xdata *)0x403b     //DMA通道1配置 & Debug设置
 #define DMAEN                                  0x80               //rw--DMA通道0/1使能
 #define DMABSY                                 0x40               //rw1-DMA通道0/1状态/启动
 #define DMACFG2                                0x20               //rw--DMA通道0/1外设与方向选择位2
 #define DMACFG1                                0x10               //rw--DMA通道0/1外设与方向选择位1
 #define DMACFG0                                0x08               //rw--DMA通道0/1外设与方向选择位0
 #define DBGSW                                  0x04               //rw--DMA通道1DEG模式指向区域(在DMA_CR1配置)
 #define DBGEN                                  0x02               //rw--DMA通道1DEG模式使能    (在DMA_CR1配置)
 #define DMAIE                                  0x04               //rw--DMA中断使能            (在DMA_CR0配置)
 #define ENDIAN                                 0x02               //rw--DMA数据传输顺序        (在DMA_CR0配置)
 #define DMAIF                                  0x01               //rw0-DMA通道0/1中断标志位

 #define DMA0_CR1            *(_IO uint16_t xdata *)0x403c     //DMA通道0传输长度和首地址配置
 #define DMA1_CR1            *(_IO uint16_t xdata *)0x403e     //DMA通道1传输长度和首地址配置
/*************************************************************///VREF
 #define VREF_VHALF_CR       *(_IO  uint8_t xdata *)0x404f
 #define VRVSEL1                                0x80
 #define VRVSEL0                                0x40
 #define VREFEN                                 0x10
 #define VHALFEN                                0x01
/*************************************************************///AMP
 #define AMP_CR              *(_IO  uint8_t xdata *)0x404e
 #define AMP2EN                                 0x04
 #define AMP1EN                                 0x02
 #define AMP0EN                                 0x01
/*************************************************************///CMP
 sfr     CMP_CR0             = 0xd5;
 #define CMP3IM1                                0x80
 #define CMP3IM0                                0x40
 #define CMP2IM1                                0x20
 #define CMP2IM0                                0x10
 #define CMP1IM1                                0x08
 #define CMP1IM0                                0x04
 #define CMP0IM1                                0x02      // CMPx_IM[0:1]: 00:不产生中断  01:升沿中断  10:降沿中断  11:双沿中断
 #define CMP0IM0                                0x01

 sfr     CMP_CR1             = 0xd6;
 #define HALLSEL                                0x80
 #define CMP3MOD1                               0x40
 #define CMP3MOD0                               0x20
 #define CMP3EN                                 0x10
 #define CMP3HYS                                0x08
 #define CMP0HYS2                               0x04
 #define CMP0HYS1                               0x02
 #define CMP0HYS0                               0x01

 sfr     CMP_CR2             = 0xda;
 #define CMP4EN                                 0x80
 #define CMP0MOD1                               0x40
 #define CMP0MOD0                               0x20
 #define CMP0SEL1                               0x10
 #define CMP0SEL0                               0x08
 #define CMP0CSEL1                              0x04
 #define CMP0CSEL0                              0x02
 #define CMP0EN                                 0x01

 sfr     CMP_CR3             = 0xdc;
 #define CMPDTEN                                0x80
 #define DBGSEL1                                0x40
 #define DBGSEL0                                0x20
 #define SAMSEL1                                0x10
 #define SAMSEL0                                0x08
 #define CMPSEL2                                0x04
 #define CMPSEL1                                0x02
 #define CMPSEL0                                0x01

 sfr     CMP_SR              = 0xd7;
 #define CMP3IF                                 0x80
 #define CMP2IF                                 0x40
 #define CMP1IF                                 0x20
 #define CMP0IF                                 0x10
 #define CMP3OUT                                0x08
 #define CMP2OUT                                0x04
 #define CMP1OUT                                0x02
 #define CMP0OUT                                0x01

 sfr     EVT_FILT            = 0xd9;
 #define TSDEN                                  0x80
 #define TSDADJ1                                0x40
 #define TSDADJ0                                0x20
 #define MOEMD1                                 0x10
 #define MOEMD0                                 0x08
 #define EFSRC                                  0x04
 #define EFDIV1                                 0x02
 #define EFDIV0                                 0x01

 #define CMP_SAMR            *(_IO  uint8_t xdata *)0x40ad
/*************************************************************///FLASH
 sfr     FLA_KEY             = 0x84;                           //FLASH解锁寄存器
 #define FLAKSTA1                               0x02               //rw--FLASH解锁状态位1
 #define FLAKSTA0                               0x01               //rw--FLASH解锁状态位0

 sfr     FLA_CR              = 0x85;                           //FLASH控制器
 #define FLAERR                                 0x10               //r---FLASH错误标志位
 #define FLAACT                                 0x08               //rw1-FLASH操作开始
 #define FLAERS                                 0x02               //rw--FLASH清除使能
 #define FLAEN                                  0x01               //rw--FLASH编程使能
/*************************************************************///CRC
 #define CRC_DIN             *(_O   uint8_t xdata *)0x4021     //CRC数据输入寄存器

 #define CRC_CR              *(_IO  uint8_t xdata *)0x4022     //CRC控制器
 #define CRCDONE                                0x10               //r1--自动CRC完成标志
 #define CRCDINI                                0x08               //r0w1CRC初始化
 #define CRCVAL                                 0x04               //rw--CRC初始化的值
 #define AUTOINT                                0x02               //rw--CRC自动计算使能
 #define CRCPNT                                 0x01               //rw--CRC结果访问位置

 #define CRC_DR              *(_IO  uint8_t xdata *)0x4023     //CRC结果输出寄存器
 #define CRC_BEG             *(_IO  uint8_t xdata *)0x4024     //CRC自动计算的起始位置
 #define CRC_CNT             *(_IO  uint8_t xdata *)0x4025     //CRC块数计数器
/*************************************************************///POWER
 sfr     PCON                = 0x87;
 #define GF3                                    0x20
 #define GF2                                    0x10
 #define GF1                                    0x08
 #define LDOM                                   0x04
 #define STOP                                   0x02
 #define IDEL                                   0x01

 sfr     LVSR                = 0xdb;
 #define EXT0CFG2                               0x20
 #define EXT0CFG1                               0x10
 #define EXT0CFG0                               0x08
 #define TSDF                                   0x04
 #define LVWF                                   0x02
 #define LVWIF                                  0x01


 #define CCFG1               *(_IO  uint8_t xdata *)0x401E
 #define LVDENB                                 0x80
 #define LVWIE                                  0x40
 #define WDTEN                                  0x20
 #define FCKSEL1                                0x04
 #define FCKSEL0                                0x02

#endif
