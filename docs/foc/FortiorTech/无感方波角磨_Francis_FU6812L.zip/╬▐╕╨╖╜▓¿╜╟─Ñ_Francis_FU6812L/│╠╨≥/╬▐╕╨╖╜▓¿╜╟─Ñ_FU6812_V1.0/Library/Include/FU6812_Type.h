#ifndef __FU6812_TYPE_H__
#define __FU6812_TYPE_H__


/*���ú궨��-------------------------------------------------------------------------------------*/
#define Q12(n)    (uint32)(n*4095.0)
#define Q15(n)    (uint32)(n*32767.0)
#define Q16(n)    (uint32)(n*65535.0)
#define Enable    1
#define Disable   0
#define True      1
#define False     0
#define TRUE      1
#define FALSE     0
#define false     0
#define true      1


/*�Զ����������ͼ��-----------------------------------------------------------------------------*/
#define __I  volatile const    /*!< defines 'read only' permissions      */
#define __O  volatile          /*!< defines 'write only' permissions     */
#define __IO volatile          /*!< defines 'read / write' permissions   */

#define bool bit
#define _I            volatile const
#define _IO           volatile

typedef signed char    int8_t;
typedef signed short   int16_t;
typedef signed long    int32_t;
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned long  uint32_t;


typedef signed char    int8;
typedef signed int     int16;
typedef signed long    int32;
typedef unsigned char  uint8;
typedef unsigned int   uint16;
typedef unsigned long  uint32;

typedef signed char    s8;
typedef signed int     s16;
typedef signed long    s32;

typedef unsigned long  u32;
typedef unsigned int   u16;
typedef unsigned char  u8;

typedef   int32  const code  sc32;  /*!< Read Only */
typedef   int16  const code  sc16;  /*!< Read Only */
typedef   int8   const code  sc8;   /*!< Read Only */
typedef   uint32 const code  uc32;  /*!< Read Only */
typedef   uint16 const code  uc16;  /*!< Read Only */
typedef   uint8  const code  uc8;   /*!< Read Only */

#endif
