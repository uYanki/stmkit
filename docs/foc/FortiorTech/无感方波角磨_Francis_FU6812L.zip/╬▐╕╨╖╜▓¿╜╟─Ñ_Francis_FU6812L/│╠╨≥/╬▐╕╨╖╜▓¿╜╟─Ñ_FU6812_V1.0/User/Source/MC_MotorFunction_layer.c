/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : ���ܲ�
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <sys_conf.h>
#include <MC_MotorCotrol_layer.h>  
#include <MC_MotorFunction_layer.h> 
#include <MC_MotorDriver_layer.h>   

/** @addtogroup FT68xx
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
Power_TypeDef xdata Power; 
extern u16 idata giEventCounter;
/* Private function prototypes -----------------------------------------------*/
u16 Drv_PowerThermCalc(u16 VthMeas);      //�¶ȼ���
void Drv_RotorCircleNumCalc(void);      //����Ȧ������
void MCL_OverLoadInit(u16 OL0A,u16 OL1A,u16 OL2A,u16 OL3A,u32 OL0ms,u32 OL1ms,u32 OL2ms,u32 OL3ms);
u8 MCL_OverLoadCalc(u16 Ibus);              //���ؼ���
void Mcl_NoloadCale(void);                  //�����ж�

/* Private functions ---------------------------------------------------------*/


/*******************************************************************************
* Function Name  : MCL_OverLoadInit    //���� 
* Description    : �¶�200-> 20��  
* Input          : PTC�¶�
* Output         : None
* Return         : ADC�ɼ�ֵ
*******************************************************************************/

#if(OVERLOAD_EN)
void MCL_OverLoadInit(u16 OL0A,u16 OL1A,u16 OL2A,u16 OL3A,
                      u32 OL0ms,u32 OL1ms,u32 OL2ms,u32 OL3ms)
  {
    Ctl.OL.Value = 0x7F; 
    Ctl.OL.Group[0].Current = OL0A;
    Ctl.OL.Group[1].Current = OL1A;
    Ctl.OL.Group[2].Current = OL2A;
    Ctl.OL.Group[3].Current = OL3A;

    Ctl.OL.Group[0].Nms = OL0ms;
    Ctl.OL.Group[1].Nms = OL1ms;
    Ctl.OL.Group[2].Nms = OL2ms;
    Ctl.OL.Group[3].Nms = OL3ms;
      
    Ctl.OL.Group[0].msCounter = 0;
    Ctl.OL.Group[1].msCounter = 0;
    Ctl.OL.Group[2].msCounter = 0;
    Ctl.OL.Group[3].msCounter = 0;
    
    Ctl.OL.Group[0].flg = 0;
    Ctl.OL.Group[1].flg = 0;
    Ctl.OL.Group[2].flg = 0;
    Ctl.OL.Group[3].flg = 0;
  }
#endif


 /******************************************************************************* 
* Function Name  : MCL_OverLoadCalc 
* Author         : wangt  
* Description     
* Input          : None 
* Output         : None 
* Return         : 
*******************************************************************************/  
#if(OVERLOAD_EN) 
u8 MCL_OverLoadCalc(u16 Ibus)   
  { 
    u16 tIbus = 0;    //�������ֵ
    tIbus = Ibus;

    if((Ctl.OL.msFlag == 0x7F)&&(Ctl.OL.Value == 0x7F)&&(Ctl.State == MOTOR_NORMAL))
      {
        if(tIbus >= Ctl.OL.Group[0].Current)    
          {  
             Ctl.OL.Group[0].msCounter++;
             if(tIbus >= Ctl.OL.Group[1].Current)  
             {
                 Ctl.OL.Group[0].msCounter++;
                 Ctl.OL.Group[1].msCounter++;
                 if(tIbus >= Ctl.OL.Group[2].Current) 
                 {
                     Ctl.OL.Group[0].msCounter++;
                     Ctl.OL.Group[1].msCounter++;
                     Ctl.OL.Group[2].msCounter++;
                     if(tIbus>=Ctl.OL.Group[3].Current) 
                     {  
                         Ctl.OL.Group[0].msCounter++;
                         Ctl.OL.Group[1].msCounter++;
                         Ctl.OL.Group[2].msCounter++;
                         Ctl.OL.Group[3].msCounter++;
                     }
                     else
                     {
                        Ctl.OL.Group[3].msCounter--;  
                     }
                 }
                 else
                 {
                     Ctl.OL.Group[2].msCounter--;  
                     Ctl.OL.Group[3].msCounter--;  
                 }
             }
             else
             {
                 Ctl.OL.Group[1].msCounter--;  
                 Ctl.OL.Group[2].msCounter--;  
                 Ctl.OL.Group[3].msCounter--;                
             }
          }
          else
          {   
             Ctl.OL.Group[0].msCounter--; 
             Ctl.OL.Group[1].msCounter--;  
             Ctl.OL.Group[2].msCounter--;  
             Ctl.OL.Group[3].msCounter--;  
          } 
       if(Ctl.OL.Group[0].msCounter >= Ctl.OL.Group[0].Nms) 
       {
         Ctl.OL.Group[0].flg = TRUE;
         Ctl.OL.Value = 0xF0; 
       }
       if(Ctl.OL.Group[1].msCounter >= Ctl.OL.Group[1].Nms)
       {
         Ctl.OL.Group[1].flg = TRUE; 
         Ctl.OL.Value = 0xF1; 
       }
       if(Ctl.OL.Group[2].msCounter >= Ctl.OL.Group[2].Nms)
       {
         Ctl.OL.Group[2].flg = TRUE; 
         Ctl.OL.Value = 0xF2; 
       }
       if(Ctl.OL.Group[3].msCounter >= Ctl.OL.Group[3].Nms)
       {
         Ctl.OL.Group[3].flg = TRUE;  
         Ctl.OL.Value = 0xF3; 
       }
       
       if(Ctl.OL.Group[0].msCounter<-100)
       {
         Ctl.OL.Group[0].msCounter = -100; 
       }
       if(Ctl.OL.Group[1].msCounter<-100)
       {
         Ctl.OL.Group[1].msCounter = -100;  
       }
       if(Ctl.OL.Group[2].msCounter<-100)
       {
         Ctl.OL.Group[2].msCounter = -100;  
       }
       if(Ctl.OL.Group[3].msCounter<-100)
       {
         Ctl.OL.Group[3].msCounter = -100;  
       }

       Ctl.OL.msFlag = 0;
      }   
    return Ctl.OL.Value; 
  } 
#endif
  
/*******************************************************************************
* Function Name  : Drv_PowerThermCalc    
* Description    : �ο���ѹ5.0V
* Input          : PTC�¶�
* Output         : None
* Return         : ADC�ɼ�ֵ
*******************************************************************************/
u16 Drv_PowerThermCalc(u16 VthMeas)
  {
    u16 tVthMeas;
    u16 tTherm;

    tVthMeas =  VthMeas;

    if(tVthMeas > 16383)
      {
        tTherm = 250;        
      }
    else if(tVthMeas > 14863)
      {
        tTherm = 300;        
      }
    else if(tVthMeas > 12041)
      {
        tTherm = 400;        
      }
    else if(tVthMeas > 10035)
      {
        tTherm = 500;        
      }
    else if(tVthMeas > 7582)
      {
        tTherm = 600;        
      }
    else if(tVthMeas > 5959)
      {
        tTherm = 700;        
      }
    else if(tVthMeas > 4681)
      {
        tTherm = 800;        
      }
    else if(tVthMeas > 3687)
      {
        tTherm = 900;        
      }
    else if(tVthMeas > 2918)
      {
        tTherm = 1000;        
      }
    else if(tVthMeas > 2324)
      {
        tTherm = 1100;
      }
    else if(tVthMeas > 1864)
      {
        tTherm = 1200;
      }
    else
    {
      tTherm = 2000;
    }
    return tTherm;      
  }  

/*******************************************************************************
* Function Name  : Drv_RotorCircleNumCalc    
* Description    : 
* Input          : �������Ȧ������
* Output         : None
* Return         : 
*******************************************************************************/

void Drv_RotorCircleNumCalc(void)   //Ctl.Step
{         
  s8 StepERR; 
  Ctl.Spd.RotorPosition = Ctl.gStepCur;

  StepERR = Ctl.Spd.RotorPosition - Ctl.Spd.RotorPositionqPre;
  if((StepERR == 5)||(StepERR == -1))
  {
    StepERR = 2;
  }
  else if(StepERR == -5)
  {
    StepERR = 1;
  }
  if(StepERR  == 2) 
  {
    Ctl.Spd.ComNum--;
  }    
  else if(StepERR == 1)
  {
    Ctl.Spd.ComNum++;
  }  
  if(Ctl.gDirectionC != Ctl.gDirectionS)
  {
    giEventCounter = 0;
  }
  Ctl.gDirectionS = StepERR;
  Ctl.Spd.RotorPositionqPre = Ctl.Spd.RotorPosition;  
  #if(MOTORCIRCLECALEEN)       
  Ctl.Spd.MechCircleNum =  =  Ctl.Spd.ComNum/(6*POLE_PAIR);  //��еȦ��
  #endif
}


/*******************************************************************************
* Function Name  : Mcl_NoloadCale    
* Description    : ��������ж�
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void Mcl_NoloadCale(void)            
{
  #if(NOLOAD_EN)
  if(Ctl.Noload.Counter > NOLOADNUM)
  {
     if(Ctl.Noload.Counter > (NOLOADNUM))
     {
       Ctl.Noload.Counter = (NOLOADNUM);
     }
     Ctl.Noload.Flag = 0X7F;
  }
  else
  {
    Ctl.Noload.Flag = 0XFF;
  }
  #endif
}

