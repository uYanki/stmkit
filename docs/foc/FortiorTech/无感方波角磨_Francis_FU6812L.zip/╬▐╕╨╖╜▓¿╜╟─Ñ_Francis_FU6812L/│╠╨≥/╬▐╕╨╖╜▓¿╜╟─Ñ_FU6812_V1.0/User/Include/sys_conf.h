/************************ (C) COPYRIGHT 2016 FT *******************************
* File Name          : ϵͳ���ò�
* Author             : Tom wang Fortiortech  Application Dept (NO.0060 18664917879)     
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        :  ���棺��ֹ�޸�,ɾ�� �ṹ�嶨�� ����ᵼ��δ֪����
TOM 20170911
sys_conf.h -> fu68xx_IQmath.h
              user_conf.h  -> tempuserconf.h
           -> function.h
           -> tempconstant.h
           
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SYS_CONF_H
#define __SYS_CONF_H

/* Includes ------------------------------------------------------------------*/
#include <fu68xx_IQmath.h>
#include <user_conf.h>

//&& ��д  %% ֻ��  ��λ *  ����ֵ -- �޵�λ
//------------------------------------------------------------------------------
//PWM
#define PWM_BITCON        (L_MOSActive+H_MOSActive*2)          //000 ����Ч   AAA ����Ч 222���ŵ� 888 ���ŵ�

#define DRV_OE_OFF        {MOE = 0;}           //��λ -- %% 
#define DRV_OE_ON         {MOE = 1;}           //��λ -- %% 

#define TPWMOUT_OFF        0x000  //��λ -- %% 
#define TPWMOUT_ENABLE     0x000  //��λ -- %% 
#define TPWM_BREAK         0x540  //��λ -- %% 

#define TPWM_UH_ON         0x080  //��λ -- %% 
#define TPWM_VH_ON         0x200  //��λ -- %% 
#define TPWM_WH_ON         0x800  //��λ -- %%   
#define TPWM_UL_ON         0x040  //��λ -- %% 
#define TPWM_VL_ON         0x100  //��λ -- %% 
#define TPWM_WL_ON         0x400  //��λ -- %% 

#define TPWM_UHVL_ON       0x180  //��λ -- %% 
#define TPWM_UHWL_ON       0x480  //��λ -- %% 
#define TPWM_VHUL_ON       0x600  //��λ -- %% 
#define TPWM_VHWL_ON       0x240  //��λ -- %% 
#define TPWM_WHUL_ON       0x840  //��λ -- %% 
#define TPWM_WHVL_ON       0x900  //��λ -- %% 

#define TPWM_VL_ON         0x040  //��λ -- %% 
#define TPWM_ULVL_ON       0x140  //��λ -- %% 
#define TPWM_ULVLWL_ON     0x540  //��λ -- %% 

#define TPWM_UH_PWM        0x002  //��λ -- %% 
#define TPWM_VH_PWM        0x008  //��λ -- %% 
#define TPWM_WH_PWM        0x020  //��λ -- %% 
#define TPWM_UL_PWM        0x001  //��λ -- %% 
#define TPWM_VL_PWM        0x004  //��λ -- %% 
#define TPWM_WL_PWM        0x010  //��λ -- %%

#define TPWM_UHVL_PWM      0x006  //��λ -- %% 
#define TPWM_UHWL_PWM      0x012  //��λ -- %% 
#define TPWM_VHWL_PWM      0x018  //��λ -- %% 
#define TPWM_VHUL_PWM      0x009  //��λ -- %% 
#define TPWM_WHUL_PWM      0x021  //��λ -- %% 
#define TPWM_WHVL_PWM      0x024  //��λ -- %% 

#define TPWM_UL_PWM        0x001  //��λ -- %% 
#define TPWM_ULVL_PWM      0x005  //��λ -- %% 
#define TPWM_ULVLWL_PWM    0x015  //��λ -- %% 

#define TPWM_ULVLWL_PWM    0x015  //��λ -- %%   
#define TPWM_UHVHWH_PWM    0x02A  //��λ -- %%  

#define TPWM_UHVLWL_PWM    0x016  //��λ -- %% 

#if (PWM_MODE == M_HPWM_LPWM)
  #define TUVW_OFF     0x0000
  #define TUH_VL       0x0006
  #define TUH_WL       0x0012
  #define TVH_WL       0x0018
  #define TVH_UL       0x0009
  #define TWH_UL       0x0021
  #define TWH_VL       0x0024
  #define TULVLWL_ON   0x0540
#elif (PWM_MODE == M_Hpwm_Lon)
  #define TUVW_OFF     0x0000
  #define TUH_VL       0x0102
  #define TUH_WL       0x0402
  #define TVH_WL       0x0408
  #define TVH_UL       0x0048
  #define TWH_UL       0x0060
  #define TWH_VL       0x0120
  #define TULVLWL_ON   0x0540
#elif (PWM_MODE == M_Hon_Lpwm)           
  #define TUVW_OFF     0x0000
  #define TUH_VL       0x0084
  #define TUH_WL       0x0090
  #define TVH_WL       0x0210
  #define TVH_UL       0x0201
  #define TWH_UL       0x0801
  #define TWH_VL       0x0804
  #define TULVLWL_ON   0x0540
#elif (PWM_MODE == M_HLPWM_Lon)   
  #define TUVW_OFF     0x0000
  #define TUH_VL       0x0103
  #define TUH_WL       0x0403
  #define TVH_WL       0x040C
  #define TVH_UL       0x004C
  #define TWH_UL       0x0070
  #define TWH_VL       0x0130
  #define TULVLWL_ON   0x0540  
#elif (PWM_MODE == M_HLPWM_Lpwm)   
  #define TUVW_OFF     0x0000
  #define TUH_VL       0x0007
  #define TUH_WL       0x0013
  #define TVH_WL       0x001C
  #define TVH_UL       0x000D
  #define TWH_UL       0x0031
  #define TWH_VL       0x0034
  #define TULVLWL_ON   0x0540  
  
#else  (PWM_MODE == M_HONPWM_Lpwm)//M_Hon_Lpwm  M_Hpwm_Lon 
  #define TUVW_OFF     0x0000     //000 000
  #define TULVLWL_ON   0x0540     //054 054
  
  #define TUH_VL       0x0084     //084 102
  #define TUH_WL       0x0402     //090 402
  #define TVH_WL       0x0210     //210 408
  #define TVH_UL       0x0048     //201 048
  #define TWH_UL       0x0801     //801 060
  #define TWH_VL       0x0120     //804 120

  #define TUH_VLB       0x0102     //084 102
  #define TUH_WLB       0x0090     //090 402
  #define TVH_WLB       0x0408     //210 408
  #define TVH_ULB       0x0201     //201 048
  #define TWH_ULB       0x0060     //801 060
  #define TWH_VLB       0x0804     //804 120

#endif
  
#define PWMOUT_OFF        (TPWMOUT_OFF^PWM_BITCON)      //��λ -- %% ��ֹ���
#define PWMOUT_ENABLE     (TPWMOUT_ENABLE^PWM_BITCON)   //��λ -- %% �������
#define PWM_BREAK         (TPWM_BREAK^PWM_BITCON)       //��λ -- %% ɲ��

#define PWM_UH_PWM        (TPWM_UH_PWM^PWM_BITCON)      //��λ -- %% 
#define PWM_VH_PWM        (TPWM_VH_PWM^PWM_BITCON)      //��λ -- %% 
#define PWM_WH_PWM        (TPWM_WH_PWM^PWM_BITCON)      //��λ -- %% 
#define PWM_UL_PWM        (TPWM_UL_PWM^PWM_BITCON)      //��λ -- %% 
#define PWM_VL_PWM        (TPWM_VL_PWM^PWM_BITCON)      //��λ -- %% 
#define PWM_WL_PWM        (TPWM_WL_PWM^PWM_BITCON)      //��λ -- %%

#define PWM_UH_ON         (TPWM_UH_ON^PWM_BITCON)       //��λ -- %% 
#define PWM_VH_ON         (TPWM_VH_ON^PWM_BITCON)       //��λ -- %% 
#define PWM_WH_ON         (TPWM_WH_ON^PWM_BITCON)       //��λ -- %%   
#define PWM_UL_ON         (TPWM_UL_ON^PWM_BITCON)       //��λ -- %% 
#define PWM_VL_ON         (TPWM_VL_ON^PWM_BITCON)       //��λ -- %% 
#define PWM_WL_ON         (TPWM_WL_ON^PWM_BITCON)       //��λ -- %% 


#define PWM_ULVLWL_ON     (TPWM_ULVLWL_ON^PWM_BITCON)   //��λ -- %% 
#define PWM_ULVL_PWM      (TPWM_ULVL_PWM^PWM_BITCON)
#define PWM_ULVLWL_PWM    (TPWM_ULVLWL_PWM^PWM_BITCON)  //��λ -- %%   
#define PWM_UHVLWL_PWM    (TPWM_UHVLWL_PWM^PWM_BITCON)  

#define PWM_UHVL_PWM      (TPWM_UHVL_PWM^PWM_BITCON)  //��λ -- %% 
#define PWM_UHWL_PWM      (TPWM_UHWL_PWM^PWM_BITCON)  //��λ -- %% 
#define PWM_VHWL_PWM      (TPWM_VHWL_PWM^PWM_BITCON)  //��λ -- %% 
#define PWM_VHUL_PWM      (TPWM_VHUL_PWM^PWM_BITCON)  //��λ -- %% 
#define PWM_WHUL_PWM      (TPWM_WHUL_PWM^PWM_BITCON)  //��λ -- %% 
#define PWM_WHVL_PWM      (TPWM_WHVL_PWM^PWM_BITCON)  //��λ -- %% 

#define PWM_ULVL_ON       (TPWM_ULVL_ON^PWM_BITCON)     //��λ -- %% 
#define PWM_UHVL_ON       (TPWM_UHVL_ON^PWM_BITCON)     //��λ -- %% 
#define PWM_UHWL_ON       (TPWM_UHWL_ON^PWM_BITCON)     //��λ -- %% 
#define PWM_VHUL_ON       (TPWM_VHUL_ON^PWM_BITCON)     //��λ -- %% 
#define PWM_VHWL_ON       (TPWM_VHWL_ON^PWM_BITCON)     //��λ -- %% 
#define PWM_WHUL_ON       (TPWM_WHUL_ON^PWM_BITCON)     //��λ -- %% 
#define PWM_WHVL_ON       (TPWM_WHUL_ON^PWM_BITCON)     //��λ -- %%   {DRV_CMR = (TPWM_WHUL_ON^PWM_BITCON)}  


#if  (PWM_MODE == M_HONPWM_Lpwm) 
  #define UVW_OFF           (TUVW_OFF^PWM_BITCON) 
  #define UH_VLA            (TUH_VL^PWM_BITCON)
  #define UH_WLA            (TUH_WL^PWM_BITCON)
  #define VH_WLA            (TVH_WL^PWM_BITCON)
  #define VH_ULA            (TVH_UL^PWM_BITCON)
  #define WH_ULA            (TWH_UL^PWM_BITCON)
  #define WH_VLA            (TWH_VL^PWM_BITCON)
  #define ULVLWL_ON         (TULVLWL_ON^PWM_BITCON)

  #define UH_VLB            (TUH_VLB^PWM_BITCON)
  #define UH_WLB            (TUH_WLB^PWM_BITCON)
  #define VH_WLB            (TVH_WLB^PWM_BITCON)
  #define VH_ULB            (TVH_ULB^PWM_BITCON)
  #define WH_ULB            (TWH_ULB^PWM_BITCON)
  #define WH_VLB            (TWH_VLB^PWM_BITCON)

#else
  #define UVW_OFF           (TUVW_OFF^PWM_BITCON) 
  #define UH_VLA            (TUH_VL^PWM_BITCON)
  #define UH_WLA            (TUH_WL^PWM_BITCON)
  #define VH_WLA            (TVH_WL^PWM_BITCON)
  #define VH_ULA            (TVH_UL^PWM_BITCON)
  #define WH_ULA            (TWH_UL^PWM_BITCON)
  #define WH_VLA            (TWH_VL^PWM_BITCON)
  #define ULVLWL_ON         (TULVLWL_ON^PWM_BITCON)

  #define UH_VLB            (TUH_VL^PWM_BITCON)
  #define UH_WLB            (TUH_WL^PWM_BITCON)
  #define VH_WLB            (TVH_WL^PWM_BITCON)
  #define VH_ULB            (TVH_UL^PWM_BITCON)
  #define WH_ULB            (TWH_UL^PWM_BITCON)
  #define WH_VLB            (TWH_VL^PWM_BITCON)

#endif

#define CMP_UVW_UPDO_PWMOFF (0x7000+UVW_OFF)     //DB ����UVW�����Ƚ���6�����أ��ر�PWM���
#define CMP_UVW_UPDO        (0x7000)//+UVW_OFF)  //
#define CMP_W_DO            (0x2000)//+UVW_OFF)  //
#define CMP_V_UP            (0x3000)//+UVW_OFF)  //
#define CMP_U_DO            (0x4000)//+UVW_OFF)  //
#define CMP_W_UP            (0x5000)//+UVW_OFF)  //
#define CMP_V_DO            (0x6000)//+UVW_OFF)  //
#define CMP_U_UP            (0x1000)//+UVW_OFF)  //
#define CMP_UVW_NO          (0x0000)//+UVW_OFF)  //

//#define ANGLE_MASK(X)   {TIM1_CR1 &= (~0x7F); TIM1_CR1 |= X*127/60;}
//#define ANGLE_DELAY(X)  {TIM1_CR2 &= (~0x7F); TIM1_CR2 |= X*127/60;}
#define ANGLE_MASK(X)   {TIM1_CR1  =(TIM1_CR1 &(~0x7F)) | (X*127/60);}  //���νǶ�   BSEL 
#define ANGLE_DELAY(X)  {TIM1_CR2  =(TIM1_CR2 &(~0x7F)) | (X*127/60);}  //����Ƕ�   CSEL
/* Exported constants --------------------------------------------------------*/
#include <function.h>
#include <tempconstant.h>
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

#endif /* __HD_init_H */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/
