
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : HallICA   HallICB   HallSensor
 P02 P36 P37    -->
                  -->
 P14 P16 P2     --> 
                        -->   CMP0/1/2 -> TI0 TI1 TI2
 (C+P14 C-P15)  -->
 (C+P16 C-P17)  --> -->
 (C+P21 C-P22)  -->             
 
 HallIC_X 
 HallIC_Y
 HallIC_Z �Ӳ��(ģ��)HALL 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FU681X_HALL_H
#define __FU681X_HALL_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

#if (HallMode == HallIC_X)
  #define  HALL_PIN_SEL       ClrBit(CMP_CR1, HALLSEL);

  #define  HA_PIN             P02
  #define  HA_GPIO_PORT       P0_OE
  #define  HA_PU              P0_PU

  #define  HB_PIN             P37
  #define  HB_GPIO_PORT       P3_OE
  #define  HB_PU              P3_PU

  #define  HC_PIN             P36
  #define  HC_GPIO_PORT       P3_OE
  #define  HC_PU              P3_PU
  
#elif (HallMode == HallIC_Y)
  #define  HALL_PIN_SEL       SetBit(CMP_CR1, CMP_HALL_SEL);  

    #define  HA_PIN             P14
    #define  HA_GPIO_PORT       P1_OE
    #define  HA_PU              P1_PU

    #define  HB_PIN             P16
    #define  HB_GPIO_PORT       P1_OE
    #define  HB_PU              P1_PU

    #define  HC_PIN             P21
    #define  HC_GPIO_PORT       P2_OE
    #define  HC_PU              P2_PU
#endif

#if (HALL_SENSORS_PLACEMENT == DEGREES_120)
  #define  HA (CMP_SR&0x1) 
  #define  HAHBHC  CMP_SR&0X07; 
#else 
  #define  HA !(CMP_SR&0x1) 
  #define  HAHBHC  (CMP_SR&0X07)^1; 
#endif    
  #define  HB (CMP_SR&0x2)
  #define  HC (CMP_SR&0x4)    
  
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
extern void Hall_Init(void);
extern void Hall_IRQHandler(void);
#endif /* __HD_init_H */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/