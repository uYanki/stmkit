
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
//�������
u16 d;
u8  dH,dL;
((unsigned char*)(&d))[0] = dH; 
((unsigned char*)(&d))[1] = dL; 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <MC_UserInterface_layer.h>
#include <MC_MotorCotrol_layer.h>  
#include <MC_MotorFunction_layer.h> 
#include <MC_MotorDriver_layer.h>  
#include <fu681x_uart.h>

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

#define ESC_1  1  //1�ŵ��
#define ESC_2  2  //2�ŵ��
#define ESC_3  3  //3�ŵ��
#define ESC_4  4  //4�ŵ��

#if(UARTSREF_EN) 
typedef struct { 
     u8 L:8;       
     u8 H:8;       
}tX; 

union{
  u8  buffer[12];
  u16 UB[6];
  tX  UA[6];
}gESC;

u16 CRC_Data;             //crcУ����
volatile int thro_value;  //������
u8 ESC_Num;
u8 index ;        
#endif
void Uart_cale(void) ;
void thro_calc(u8 *buffer);
void CRC16(u8 *ptr,u16 len);
void ESC_CS_INIT();
void UART_SendData(u16 T_Data);

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : USRT_Config
* Description    : Main program.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USRT_Config(void)
{
  SetBit(PH_SEL,UARTEN);      // p3[3]as UART_RXD; p3[4]as UART_TXD
  ClrBit(PH_SEL,UARTCH);      // p0[6]as UART_RXD; p0[5]as UART_TXD
  ClrBit(P3_OE,P33);         //����ʹ��
  SetBit(P3_PU,P33);         //��������
//  ClrBit(P3_OE,P34);         //����ʹ��
//  SetBit(P3_PU,P34);         //��������


  ClrBit(P0_OE,P04);         //����ʹ��
  SetBit(P0_PU,P04);         //��������
  ClrBit(P0_OE,P05);         //����ʹ��
  SetBit(P0_PU,P05);         //��������  
  UT_MOD1 = 0;
  UT_MOD0 = 1;
  SM2 = 1;
  REN = 1;
  ES0 = 1;	                                                  
  UT_BAUD = 0x19;                       // Baud rate=fosc/(16*UT_BAUD) = 57600Hz  9B

  UT_DR = 0x00;                         //  
}

void UART_SendData(unsigned int T_Data)
{
//  UT_DR = T_Data;
//  while(!(TI==1));		//�ȴ��������
//  TI = 0;							//��������жϱ�־λ����
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void UART_CALE(void)
	Description   :	UART interrupt���������ݣ��ж����ȼ���Ϊ1
	Input         :	��
  Output				:	��   FF FF 10 00 10 00 10 00 10 00 9c 0a
-------------------------------------------------------------------------------------------------*/
void Uart_cale(void) 
{
 
}
