/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : MDUInit.h
* Author             : Vina Peng, Fortiortech Appliction Team
* Version            : V1.0
* Date               : 01/04/2017
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/

#ifndef __MDUINIT_H_
#define __MDUINIT_H_

extern uint16 MDU_MULA_U16(uint16 TData0, uint16 TData1, uint8 ALIGN);
extern void MDU_16MUL16_INT(uint8_t ALIGN, uint8_t SIGN);
extern void MDU_MUL_XDATA_U32(uint16_t TData0, uint16_t TData1, uint16_t xdata *Result32_t);
extern void MDU_MUL_IDATA_U32(uint16_t TData0, uint16_t TData1, uint16_t idata *Result32_t);
extern uint32_t MDU_DIV_XDATA_U32(uint8_t xdata *TData0, uint8_t xdata *TData1);

extern uint32_t MDU_DIV_IDATA_U32(uint8_t idata *TData0, uint8_t idata *TData1);
extern uint16_t MDU_DIV_IDATA_U16(uint8_t idata *TData0, uint8_t idata *TData1);
extern uint16_t MDU_DIV_XDATA_U16(uint8_t xdata *TData0, uint8_t xdata *TData1);