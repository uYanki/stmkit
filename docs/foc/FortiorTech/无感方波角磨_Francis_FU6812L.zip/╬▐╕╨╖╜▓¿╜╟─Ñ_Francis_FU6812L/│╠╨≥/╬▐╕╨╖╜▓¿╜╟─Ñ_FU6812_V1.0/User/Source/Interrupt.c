/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : �ж���ں��� 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/
/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <sys_conf.h>
#include <fu681x_Device.h>
#include <interrupt.h>
#include <Ftech_BLDC.h>
#include <MC_Led.h>
#include <MC_PwmIn.h>
#include <MC_init.h>
#include <MC_UserInterface_layer.h>
#include <MC_MotorCotrol_layer.h>  
#include <MC_MotorFunction_layer.h> 
#include <MC_MotorDriver_layer.h>   

/* Private typedef -----------------------------------------------------------*/
extern u16 idata giEventCounter;

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

 
/*******************************************************************************
* Function Name  : INT0_ISR
* Description    : INT0 interrupt  FO�жϣ�����IPMӲ�������������ж����ȼ����
* Input          : None
* Output         : 
* Return         : None
*******************************************************************************/
#if ((EFAL == FO_INT)||(EFAL == FO_CMPINT))
void INT0_ISR(void) interrupt 1
{
  if(IF0)
  {
    IF0 =0;
//     #if(FO_EN)
//     if(EFAL == FO_CMPINT)
//     {
//       DRV_OE_OFF;
//       Ctl.SysError = E_FAIL;
//       Ctl.State = MOTOR_FAILURE;
//     }
//     else
//     {
       MCL_Bkin_Isr();    //Ӳ������
//     }
//     #endif
  } 
}
#endif
 
/*******************************************************************************
* Function Name  : DRV_ISR    
* Description    : FG�ж� DC�Ƚ�ƥ���ж�
* Input          : 
* Output         : 
* Return         : 1
*******************************************************************************/
void DRV_ISR(void) interrupt 3
{
  if(ReadBit(DRV_SR, FGIF))
  {
    ClrBit(DRV_SR, FGIF);
  }
  if(ReadBit(DRV_SR, DCIF))           //����Ϊ����ж� 0 -> ON  DRV_ARR-1 -> OFF
  {                                   //�����˲�8��
    Drv.AdcMeas.ImeasBus = TIM1__ITRIP + Drv.AdcMeas.IBusMeasOffset; // Q12-->Q15
    MDUAPP(); 

    if(ReadBit(ADC_CR, ADCIF))     //ִ��ʱ��2us
    {
      ADCGetValue();               //ADC���ݶ�ȡ
      ClrBit(ADC_CR, ADCIF);
    }
    else
    {
      SetBit(ADC_CR, ADCBSY);  //����ADC����ת��
    }

    ClrBit(DRV_SR, DCIF);    
  }
}

/*******************************************************************************
* Function Name  : TIM1_INT    
* Description    : HALL��ȡ��ת�ټ���
* Input          : 
* Output         : 
* Return         : 1
*******************************************************************************/
  
void TIM1_ISR(void) interrupt 5
{    
  TIM1_SR &= TIM1_IER;   //���жϱ�־
  if(ReadBit(TIM1_SR,T1WTIF))   //д���ж� �ж�
  {  
    ClrBit(TIM1_SR,T1WTIF);   //CLRFlag_WTIF;
  }
  
  if(ReadBit(TIM1_SR,T1PDIF))     //CMP/HALL λ�ü�� �ж�    
  {
    ClrBit(TIM1_SR,T1PDIF);       //CLRFlag_PDIF;
    MDUFlag.CalcSpeed = 1;        //ת�ټ�������

    Drv.speed.EventPeriod  = TIM1__BCCR;
    Ctl.Tim.STAnms = 0;              //��⵽λ�ã�����

    #if (POS_FB_MODE == SensorLess)  //BEMF ���
    {
      Drv_BemfTim1PDapp();
    }
    #else                            //HALL λ��
    {
      if(!ReadBit(TIM1_CR0,T1RCEN))  //TOM++
      {
        SetReg(TIM1_CR0,(T1RCEN|T1RWEN),(T1RCEN|T1RWEN));
      }     
      Hall_IRQHandler();             //HALL��ȡ   
      DRV_HallEventCalc();
    }
     Drv_RotorCircleNumCalc(); //����,����Ȧ������
    #endif
  }
  
//  if(ReadBit(TIM1_SR,T1ADIF))   //ADC λ�ü�� �ж� 
//  {
//    Ctl.Tim.STAnms = 0;
//    MDUFlag.CalcSpeed = 1;      //ת�ټ�������
//    Drv.speed.EventPeriod  = TIM1__BCCR;
//    
//    Drv_BemfTim1PDapp();
//    MDUFlag.CalcSpeed = 1;      //ת�ټ�������
//    ClrBit(TIM1_SR,T1ADIF);     //CLRFlag_ADIF;
//  }
  if(ReadBit(TIM1_SR,T1BOIF))  //������ʱ�������ж� 
  {
    ClrBit(TIM1_SR,T1BOIF);    //CLRFlag_BOIF;
    if((CMP_CR3&0X0C) == 0X04)
    {
      giEventCounter = 0;
    }
    LED1_ONOFF;
  }
}  

/*******************************************************************************
* Function Name  : CMP_ISR
* Description    : CMP interrupt
* Input          : None
* Output         : 
* Return         : None
*******************************************************************************/
#if ((EFAL == FO_CMP)||(EFAL == FO_CMPINT))
void CMP_ISR(void) interrupt 7
{
  if(ReadBit(CMP_SR, CMP3IF))
  {
    ClrBit(CMP_SR, CMP3IF);
    #if(FO_EN)
    MCL_Bkin_Isr();    //Ӳ������
    #endif
  }
}
#endif
/*******************************************************************************
* Function Name  : TIM3_ISR
* Description    : PWMIN  
* Input          : 
* Output         : 
* Return         : 1
*******************************************************************************/
void TIM3_ISR(void)  interrupt 9
{ 
  ESC_PPMGet();
}

/*******************************************************************************
* Function Name  : TIM4SYS_ISR  100us
* Description    : �ٶȻ����� ���ȼ�1,������ȼ�
* Input          : None
* Output         : 
* Return         : None
*******************************************************************************/
void SYSTIM4_ISR(void) interrupt 10
{
  /*Interrupt*/
  if(ReadBit(DRV_SR, SYSTIF))
  {
    MainISR();
    Key_Filtrate();    
    ClrBit(DRV_SR, SYSTIF);
  }
  /*TIM4 Interrupt*/
  if(ReadBit(TIM4_CR1, T4IF))
  { 
    ClrBit(TIM4_CR1, T4IF);
  }
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void UART_ISR(void)
	Description   :	UART interrupt���������ݣ��ж����ȼ���Ϊ1
	Input         :	��
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void UART_ISR(void) interrupt 12
{
//  Uart_cale();
//  if(RI)
//  {
//    UARTData = UT_DR;
//    RI = 0;
//  }	

//  if(TI)
//  {
//    UT_DR = 0x55;
//    TI = 0;
//  }
}


