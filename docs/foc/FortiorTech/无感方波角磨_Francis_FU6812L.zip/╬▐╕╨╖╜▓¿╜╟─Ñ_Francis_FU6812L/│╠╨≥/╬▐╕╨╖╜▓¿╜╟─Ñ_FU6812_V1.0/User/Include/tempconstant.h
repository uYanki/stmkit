
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/
#ifndef __TEMPCONSTANT_H_
#define __TEMPCONSTANT_H_
#include <sys_conf.h>
 //-----------------------------------------------------------------------------
//PWM PWM��������
//DRV1
#define PWMPeriod                 (1000000/PWM_FREQ)                     //��λ us %% PWMPeriod = 1/PWMFre 
#define RUN_PWMARR                (((SYSCLK_FREQ>>1)/PWM_FREQ) -2)       //��λ -- %% PWMARR = 24MHZ/16KHz

//drv ����жϣ����磬���� �Ƚ�ƥ��
#define PWM_OVERFLOW              (Drv.PWM.DutyArr - 3)
#define PWM_UBDERFLOW             (0)
#define PWM_FLOW                  (PWM_UBDERFLOW)
//-----------------------------------------------------------------------------
//��HALL����ģʽ �ȴ� ���� ����ģʽ   �������ڴ˹��������У����������һ������
#define NO_WAIT                0                //��λ-- %% �޵ȴ�
#define WAIT_STRACK            4                //��λ-- %% ת�ٸ���
#define WAIT_PRECHARGE         5                //��λ-- %% ���
#define WAIT_ALIGNMENGT        6                //��λ-- %% ��λ
#define WAIT_RAMPUP            7                //��λ-- %% �϶�
#define WAIT_STEP              NO_WAIT          //��λ-- && �ȴ�״̬
//-----------------------------------------------------------------------------

#define RAMP_PWMARR           (((SYSCLK_FREQ>>1)/PAMP_PWM_FREQ) - 2) // PWMARR = 24MHZ/16KHz/2
#define ELEC_FREQ             (POLE_PAIR*BASE_SPEED/60)     //��λ -- ����Ƶ��

#define TIM1PSC24M               24000000                       //��λ -- %% 2^0
#define TIM1PSC12M               12000000                       //��λ -- %% 2^1
#define TIM1PSC6M                 6000000                       //��λ -- %% 2^2
#define TIM1PSC3M                 3000000                       //��λ -- %% 2^3
#define TIM1PSC1_5M               1500000                       //��λ -- %% 2^4
#define TIM1PSC750K                750000                       //��λ -- %% 2^5
#define TIM1PSC375K                375000                       //��λ -- %% 2^6
#define TIM1PSC187_5K              187500                       //��λ -- %% 2^7

#if (ELEC_FREQ > 8000)
  #define TIM1_PSC_FREQ   (TIM1PSC24M) //��λ -- 2.73ms  366hz    21973
  #define TIM1_PSC         0
#elif (ELEC_FREQ > 6000)
  #define TIM1_PSC_FREQ   (TIM1PSC12M) //��λ -- 5.46ms  183hz    10986
  #define TIM1_PSC         1
#elif (ELEC_FREQ > 4000)
  #define TIM1_PSC_FREQ   (TIM1PSC6M)  //��λ -- 10.9ms  91.5hz   5493
  #define TIM1_PSC         2
#elif (ELEC_FREQ > 2000)
  #define TIM1_PSC_FREQ   (TIM1PSC3M)  //��λ -- 21.8ms  45.7hz   2746
  #define TIM1_PSC         3
#elif (ELEC_FREQ > 1000)
  #define TIM1_PSC_FREQ   (TIM1PSC1_5M)  //��λ -- 43.68ms  22.8hz 1373
  #define TIM1_PSC         4
#elif (ELEC_FREQ > 500)
  #define TIM1_PSC_FREQ   (TIM1PSC750K) //��λ -- 87.37ms  11.4hz  686
  #define TIM1_PSC         5
#elif (ELEC_FREQ > 250)
  #define TIM1_PSC_FREQ   (TIM1PSC375K) //��λ --  174.7ms  5.7hz 343
  #define TIM1_PSC         6
#else
  #define TIM1_PSC_FREQ   (TIM1PSC187_5K) //��λ --  85.83ms 2.86hz 171
  #define TIM1_PSC         7
#endif


#define STB1                       (10000.0/STB1RPM)             //��λms && 5.0ms
#define STB2                       (10000.0/STB2RPM)             //��λms && 0.08ms  

#define STB1C                       (u16)(STB1*TIM1_PSC_FREQ/1000.0) 
#define STB2C                       (u16)(STB2*TIM1_PSC_FREQ/1000.0) 
/*
20170918  TOM 0060
s = 60*f/p; f = s/60*P ; nms = 1/(f/6)*1000;
ESC_SPEEDLIMITNMS ->����ÿ�λ���ʱ��ʱ�䵥λms
ESC_SPEEDLIMITCNT ->����TIM��������ֵ
  �����ٹ��ܣ����ڲ����ٶȱջ��µĴ��Թ��ܣ�Ҫʵ��׼ȷ���٣���ʹ���ٶȱջ�����
*/       

#define ESC_SPEEDLIMITNMS           (10000.0/(SPEED_LIMITRPMREF*POLE_PAIR))   //     POLE_PAIR
#define ESC_SPEEDLIMITCNT           (u16)(ESC_SPEEDLIMITNMS*TIM1_PSC_FREQ/1000.0) 

/*
20170918 
һ��ת�ٳ���30��erpm���͹ر�λ�ò����ж�
*/
#define STB5RPM                     (300000)                      //��λrpm && ���ٱ���  ����Ϊ1�Լ�
#define STB5                        (10000.0/STB5RPM)             //��λms && 0.08ms  
#define STB5C                       (u16)(STB5*TIM1_PSC_FREQ/1000.0) 

#define STB6RPM                     (350000)                      //��λrpm && ���ٱ���  ����Ϊ1�Լ�
#define STB6                        (10000.0/STB6RPM)             //��λms && 0.08ms  
#define STB6C                       (u16)(STB6*TIM1_PSC_FREQ/1000.0) 
//============================================================================
//TIM3 ��Ƶ
//750Khz   675 722 1374
//����ģ�� 666 1547
//12Mhz    2ms 

//============================================================================
//TIM3 ��Ƶ
#define TIM3_Fre                           (12000000.0)           //TIM3����Ƶ��750KHz
//PWMIN  ������峵 ���ſ���
//PWMIN ����У��                               
#define TempMotorBreakTime                (u16)(MotorBreakTimeA*TIM3_Fre/1000000.0)      //ɲ������ʱ��, us
#define TempMotorONTimeErr                (u16)(MotorONTimeErrA*TIM3_Fre/1000000.0)      // us
#define TempMotorOFFTimeErr               (u16)(MotorOFFTimeErrA*TIM3_Fre/1000000.0)     // us
#define TempPWMHighMinDefault             (u16)(PWMHighMinDefaultA*TIM3_Fre/1000000.0)   // �������У׼����, us
#define TempMotorLinearTimeErr            (u16)(MotorLinearTimeErrA*TIM3_Fre/1000000.0)  // us
#define TempPWMHighMaxDefault             (u16)(PWMHighMaxDefaultA*TIM3_Fre/1000000.0)   // �������У׼����, us
#define TempPWMHighMinAline               (u16)(PWMHighMinAlineA*TIM3_Fre/1000000.0)     // �������У׼����, us
#define TempPWMHighMaxAline               (u16)(PWMHighMaxAlineA*TIM3_Fre/1000000.0)     // �������У׼����, us
#define TempPWMHighMinONAline             (u16)((PWMHighMinDefaultA+MotorONTimeErrA)*TIM3_Fre/1000000.0) //  



#define TempPWMINHighMinFilt              (u16)(PWMINHighMinFiltA*TIM3_Fre/1000000.0)   // �������У׼����, us
#define TempPWMINHighMaxFilt              (u16)(PWMINHighMaxFiltA*TIM3_Fre/1000000.0)   // �������У׼����, us

#define TempPWMINHighMinFiltA              (u16)(PWMINHighMinFiltA*TIM3_Fre/1000000.0)   // �������У׼����, us
#define TempPWMINHighMaxFiltA              (u16)(PWMINHighMaxFiltA*TIM3_Fre/1000000.0)   // �������У׼����, us

#define TempPWMINHighMinFiltB              (TempPWMINHighMinFiltA>>3)//(u16)(PWMINHighMinFiltB*TIM3_Fre/1000000.0)   // �������У׼����, us
#define TempPWMINHighMaxFiltB              (TempPWMINHighMaxFiltA>>3)//(u16)(PWMINHighMaxFiltB*TIM3_Fre/1000000.0)   // �������У׼����, us

#define TempDelayTime                     (u16)(DELAY_TIMEUS*TIM1_PSC_FREQ/1000.0) // �������νǶȣ���λ�� /
#define TempRunMaskTime                   (u16)(RUN_TIM_MASK*TIM1_PSC_FREQ/1000.0) // �������νǶȣ���λ�� /
#define TempRampMaskTime                  (u16)(RAMP_TIM_MASK*TIM1_PSC_FREQ/1000.0) // �������νǶȣ���λ�� 

//-----------------------------------------------------------------------------
//�����˲�ʱ�� ��λ����  С��10ms
#define KEY_FILTERNMS             (10)                          //��λms %%
#define KEY_FILTERCOUNT           (KEY_FILTERNMS*(10))          //��λ -- %% 
#define MSCOUNTE                  (10)                          //��λ -- %%  

//-----------------------------------------------------------------------------
//�ٶȼ���
//Drv.speed.SpeedScaler = _IQ((60*(float)750000)/(6*(float)Ctl.Motor.PolePairs*Ctl.Motor.BaseSpeed)); 
#define SPEEDSCALER             (_IQ((60*(float)TIM1_PSC_FREQ)/(6*(float)POLE_PAIR*BASE_SPEED)))
#define SPEEDSCALER1            ((60*(float)TIM1_PSC_FREQ)/(6*(float)POLE_PAIR))
#define STB1SPEEDVALUE          ((u16)((float)SPEEDSCALER1/(float)STB1SPEED))
#define STB2SPEEDVALUE          ((u16)((float)SPEEDSCALER1/(float)STB2SPEED))
//-----------------------------------------------------------------------------
//ADC�ο���ѹ
#if (HW_ADC_REF == VREF3_0)
  #define HW_ADC_VREF 3.0
#elif (HW_ADC_REF == VREF4_0)
  #define HW_ADC_VREF 4.0
#elif (HW_ADC_REF == VREF4_5)
  #define HW_ADC_VREF 4.5
#else
  #define HW_ADC_VREF 5.0
#endif
//ADC ��ѹ����  �ο���ѹ5.0V  Q12
//Drv.AdcMeas.VdcMeasGain = (float)(RV_BUS_1+RV_BUS_2)/(float)RV_BUS_2;
//VGain = (float)(RV_BUS_1+RV_BUS_2)/(float)RV_BUS_2;
#define  V_GAIN                  (float)((float)(RV_BUS_1+RV_BUS_2)/(float)RV_BUS_2)
#define  VDCMEASEGAIN            (float)(HW_ADC_VREF*(V_GAIN)/0xFFF)  //0X7FFF -> FFF  Q15->Q12

#define  MECASEOVERVOLTAGE        (OVERVOLTAGE/VDCMEASEGAIN)
#define  MECASEUNDERVOLTAGE       (UNDERVOLTAGE/VDCMEASEGAIN)
#define  MECASEOVREERVOLTAGE      (OVREERVOLTAGE/VDCMEASEGAIN) 
#define  MECASEUNREDERVOLTAGE     (UNREDERVOLTAGE/VDCMEASEGAIN)
//-----------------------------------------------------------------------------
//��������  �ο���ѹHW_ADC_VREFV  Q15
//IGain = ((float)RI_BUS_1/(float)RI_BUS_2)+ 1;      
//Drv.AdcMeas.IBusMeasGain = HW_ADC_VREF/(Rs*0x7FFF*IGain);
#define  I_GAIN                   (((float)RI_BUS_1/(float)RI_BUS_2)+ 1)
#define  IBUSMEASGAIN             (HW_ADC_VREF/(Rs*0x7FFF*I_GAIN))   //0X7FFF 

#define  MECASEOVERCURRENT        (u16)(OVERCURRENT/IBUSMEASGAIN)
#define  MECASEOVERLOAD0          (u16)(OVERLOAD0/IBUSMEASGAIN)
#define  MECASEOVERLOAD1          (u16)(OVERLOAD1/IBUSMEASGAIN)
#define  MECASEOVERLOAD2          (u16)(OVERLOAD2/IBUSMEASGAIN)
#define  MECASEOVERLOAD3          (u16)(OVERLOAD3/IBUSMEASGAIN)

#define  MECASENOLOADCURRENT      (u16)(NOLOADCURRENT/IBUSMEASGAIN)
#define  MECASECURRENTLIMITMAXREF (u16)(CURRENT_LIMIT_MAXREF/IBUSMEASGAIN)

/* 20170828
CMP3 Ӳ������ 
���㹫ʽ�� Ifo = (VrefCmp3 - VrefAdc/2)/(Igain*Rs)
    Ӳ�������Ƚϵ�ѹ��ȥVHALF������ �����Ŵ��������� ��������
*/
#define  THWCMP3DACDR1            (u8)(((float)FO_CMP3VREF/(float)HW_ADC_VREF)*255)  //Ӳ������DAC�ο�ֵ
#define  THW_CMP3VREF2            ((float)(FO_OCVALUE)*(float)(I_GAIN*Rs)+HW_ADC_VREF/2)
#define  THWCMP3DACDR2            (u8)(((float)THW_CMP3VREF2/(float)HW_ADC_VREF)*255)  //Ӳ������DAC�ο�ֵ 

#if (FO_CMP3P_VORI==1)
  #define HWCMP3DACDR  THWCMP3DACDR1 
#else
  #define HWCMP3DACDR  THWCMP3DACDR2 

#endif
//======================================================================
#if ((SPEED_CLOSE_EN==1)&&(SPEED_CALC_EN==0))     
#error ERROR  FORBID SPEED_CLOSE_EN+SPEED_CALC_EN
#endif

#if ((ADCSREF_EN==1)&&(PWMINSREF_EN==1))     
//#error ERROR  FORBID ADCSREF_EN+PWMINSREF_EN
#endif

#if ((ADCSREF_EN==1)&&(UARTSREF_EN==1))     
#error ERROR  FORBID ADCSREF_EN+UARTSREF_EN
#endif

#if ((PWMINSREF_EN==1)&&(UARTSREF_EN==1))     
#error ERROR  FORBID PWMINSREF_EN+UARTSREF_EN
#endif

#if ((ADCONOFF_EN==1)&&(PWMINONOFF_EN==1))     
#error ERROR  FORBID ADCONOFF_EN+PWMINONOFF_EN
#endif

#if ((ADCONOFF_EN==1)&&(KEYONOFF_EN==1))     
#error ERROR  FORBID ADCONOFF_EN+KEYONOFF_EN
#endif

#if ((KEYONOFF_EN==1)&&(PWMINONOFF_EN==1))     
#error ERROR  FORBID KEYONOFF_EN+PWMINONOFF_EN
#endif

//======================================================================
#endif