
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : ���棺��ֹ�޸�,ɾ�� �ṹ�嶨�� ����ᵼ��δ֪����
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MC_LED_H
#define __MC_LED_H

/* Includes ------------------------------------------------------------------*/
#include <MC_MotorCotrol_layer.h>  

/* Exported types ------------------------------------------------------------*/
extern u8  gUserLEDCunter;           //LED��˸����  FAULT
extern u16 gUserLEDmsCunter;         //LED��˸����
extern u16 gUserNoOperationDelaynms; //No operation time delay
/* Exported constants --------------------------------------------------------*/

//------------------------------------------------------------------------------
//PDELAY     power dealy ��� 
#define PDELAY           GP34
#define PDELAY_PIN       P34
#define PDELAY_GPIO_PORT P3_OE
#define PDELAY_ON       {PDELAY = 1;}
#define PDELAY_OFF      {PDELAY = 0;}
#define PDELAY_ONOFF    {PDELAY = ~PDELAY;}
//------------------------------------------------------------------------------
//FAULT  ������� 
#define FAULT              GP41
#define FAULT_PIN          P41
#define FAULT_GPIO_PORT    P4_OE

#define FAULT_ON           {FAULT = 0;}
#define FAULT_OFF          {FAULT = 1;}
#define FAULT_ONOFF        {FAULT = ~FAULT;}
//------------------------------------------------------------------------------
//LED    ��ʾ
#define LED1              GP02
#define LED1_PIN          P02
#define LED1_GPIO_PORT    P0_OE

#define LED2              GP41
#define LED2_PIN          P41 
#define LED2_GPIO_PORT    P4_OE

#define LED3              GP41
#define LED3_PIN          P41
#define LED3_GPIO_PORT    P4_OE
//��������
#define LED1_ON           {LED1 = 0;}
#define LED1_OFF          {LED1 = 1;}
#define LED1_ONOFF        {LED1 = ~LED1;}

#define LED2_ON           {LED2 = 0;}
#define LED2_OFF          {LED2 = 1;}
#define LED2_ONOFF        {LED2 = ~LED2;}

#define LED3_ON           {LED3 = 0;}
#define LED3_OFF          {LED3 = 1;}
#define LED3_ONOFF        {LED3 = ~LED3;}

//��������
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

extern void LED_show(void);
extern void Fault_Led(Error_TypeDef value); 

#endif /*  */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/