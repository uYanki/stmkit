
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : ���棺��ֹ�޸�,ɾ�� �ṹ�嶨�� ����ᵼ��δ֪����
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MC_MOTORDRIVER_LAYER_H
#define __MC_MOTORDRIVER_LAYER_H
#include <fu681x_Dmc.h>
/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
typedef struct 
{ 
//s16 VmeasA;         // Output: measured Ib (Q15)   
//s16 VmeasB;         // Output: measured Ib (Q15)   
//s16 VmeasC;         // Output: measured Ib (Q15)         
  float Vdc;
  float VdcMeasGain;  // Parameter: gain for Vdc (Q13)  
  s16 VdcMeas;        // Output: measured Vdc (Q15)  
  s16 VdcAvgMeas;

  float Ibus;
  float IBusMeasGain; // Parameter: gain for Ia (Q13)
  s16 IBusMeasOffset; // Parameter: offset for Ia (Q15)     
  s16 ImeasBus;       // Output: measured Ia (Q15)
  s16 IBusAvgMeasOffset;  
  s16 IBusAvgMeas;    
 
  s16 Vth1Meas;       // Output: measured VthMeas (Q12) 
  s16 Vth2Meas;      // Output: measured Vth1Meas (Q12) 
  s16 Vth3Meas;      // Output: measured Vth1Meas (Q12) 
  s16 Therm1;
  s16 Therm2;
  s16 Therm3;
  s16 SrefMeas;      // Output: measured VthMeas (Q12)
  s16 SrefAvgMeas;
  s16 Sref;          

} ADC2MEAS_TypeDef; 

//CTL
typedef struct   
{
  s8  BemfSetFR;
  s8  BemfValue;                     //�����ֵ
  u8  BemfNum; 
  s8  BemfTabA,BemfTabB,RefNumZ,RefNumY,RefNumX;     //
  u8  BemfFR;                        //
  u8  Calcnum;                       //ת�ٸ��ټ�����
  u8  Calcnms;                       //ת�ٸ��ټ��ʱ��
} Stk_TypeDef;    
  
typedef struct
{
  u8  Status;                 //HALL״̬ 1~6
  u8  Section;                //����     1~6
  u8  u8ChangePhaseNum;       //�������         
  s16 s16AdvanceEangle;       //���೬ǰ�Ƕ�
  u8  u8ChangePhaseFlag;      //������ɱ�־  0XFF �Ѿ����� 0X7F ׼������
} HALL_TypeDef;
  
typedef struct
{ 
  u16  DutyArr;
  s16  DutyCur;
  s16  DutyTar;
  s16  DutyIncValue;        
  s16  DutyDecValue;

  u16  DutyMax;
  u16  DutyMin;  
  u16  DutyLimitMaxRef;
  u16  DutyLimitFlag;
  u16  DutyLimitValue;
}PWM_TypeDef;
  
typedef struct
{
  ADC2MEAS_TypeDef  AdcMeas;           //ADC���ֵ
  PWM_TypeDef       PWM;               //PWM
  SPEED_MEAS_CAP    speed;             //�ٶȼ���
  HALL_TypeDef      Hall;              //hall
  Stk_TypeDef       Stk;
}DRV_TypeDef;

extern DRV_TypeDef xdata Drv;         //ȫ���ⲿ��������
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 

/*******************************************************************************
* Function Name  : Drv_DutyRampCale 
* Description    : ����Ƶ�ʣ�ÿ��ն������һ�� 
* Input          : Ŀ��DUTY  ��ʽ_IQ15 ��0x7FFF
* Output         : ����DUTY  ��ʽ_IQ15 ��0x7FFF
* Return         : 1
*******************************************************************************/  
extern void Drv_DutyRampCale(void);    //�����Ӽ���ģ��

/*******************************************************************************
* Function Name  : Drv_SpeedRampCale �ջ��Ӽ�������
* Description    : �ٶȱջ��Ӽ������� ������Ч
* Input          : Ŀ���ٶ� refTar _IQ15��ʽ
* Output         : �����ٶ� refCur _IQ15��ʽ
* Return         : �����ٶ� refCur _IQ15��ʽ
*******************************************************************************/
extern void Drv_SpeedRampCale(void);  //�ջ��Ӽ���ģ��

/*******************************************************************************
* Function Name  : Fu68xx_PWM_Update
* Description    : PWM����ģ�飬ÿ��ն�����£�ʵʱ����
* Input          : _IQ15 ��ʽduty
* Output         : TIM2_DR
* Return         : TIM2_DR
*******************************************************************************/
extern void Drv_PWM_Update(u16 tduty);   //PWM����ģ��

/*******************************************************************************
* Function Name  : Drv_BemfTim1PDapp    
* Description    : BEMF�����Ƽ��
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
extern void Drv_BemfTim1PDapp(void) ;    
/*******************************************************************************
* Function Name  : DRV_EemfEventPeriodCalc    
* Description    : ʧ�ټ��
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
extern void DRV_EemfEventCalc(void); 
extern void DRV_HallEventCalc(void);
extern void Drv_StallRestart(void);       //��ת����
extern void Drv_DutyLimit(void);
extern void Drv_PosTrack(void);

#endif /* __HD_init_H */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/