
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

#ifndef __MC_USERINTERFACE_H
#define __MC_USERINTERFACE_H

/* Includes ------------------------------------------------------------------*/

/* Exported types ------------------------------------------------------------*/

typedef struct { 
      u8 START:2;        //��ͣ����
      u8 FR:2;           //����ת����
      u8 FAULT:1;        //����
      u8 FO:1;           //Ӳ������     
      u8 KEY2:1; 
      u8 KEY1:1; 
}bit_TypeDef; 

typedef struct
  {
    bit_TypeDef  flg; 
  }Ui_TypeDef;

extern Ui_TypeDef xdata Ui;  //ȫ�ֱ�������
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
extern void Ui_Function(void);        //ȫ�ֺ�������

#endif /* __HD_init_H */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/