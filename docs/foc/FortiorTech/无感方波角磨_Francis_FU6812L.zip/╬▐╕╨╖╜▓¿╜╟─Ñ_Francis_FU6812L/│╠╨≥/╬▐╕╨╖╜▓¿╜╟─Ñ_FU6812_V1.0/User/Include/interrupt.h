
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : ���棺��ֹ�޸�,ɾ�� �ṹ�嶨�� ����ᵼ��δ֪����
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __INTERRUPT_H
#define __INTERRUPT_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

//void LVW_ISR(void) interrupt 0    //��ѹԤ���ж�
//void INT0_ISR(void) interrupt 1
//void DRV_ISR(void) interrupt 3
//void TIM1_ISR(void) interrupt 5
//void ADC_ISR(void) interrupt 6   
//void CMP_ISR(void) interrupt 7
//void TIM3_ISR(void)  interrupt 9
//void SYSTIM4_ISR(void) interrupt 10
//void UART_ISR(void) interrupt 12

#endif /* __INTERRUPT_H */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/
