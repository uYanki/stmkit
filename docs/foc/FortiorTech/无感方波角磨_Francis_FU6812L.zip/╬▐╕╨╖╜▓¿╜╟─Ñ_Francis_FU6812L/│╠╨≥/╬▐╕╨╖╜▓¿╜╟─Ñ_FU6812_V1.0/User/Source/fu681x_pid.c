
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <sys_conf.h>
#include <fu681x_pid.h>

/** @addtogroup FT68xx
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
#if(SPEED_CLOSE_EN)
PIDREG3 idata pid_spd ;                       //�ٶȻ� 
#endif

 #if(CURRENT_CLOSE_EN)
PIDREG3 idata pid_is ;                        //������
#endif
u8 xdata gPItype;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
void Pid_Config(void);                        //pidģ������
void Pid_IsInit(void);
void Pid_SpdInit(void);

s16  Pid_calc( PIDREG3 *v);                   //����

void Pid_Config(void)
{
  /*-----------------------------------------------------------------------------------
  PI���ݸ�ʽ
  Q = PIRANGE + 8(Q8~Q23���ݸ�ʽ)
  ���Ĵ�����ֵʱҪͳһ���ݸ�ʽ
-----------------------------------------------------------------------------------*/		
  SetBit(PI_LPF_CR, RANGR);   //0->12λ   1->15λ

  PI_KP = 0;												//�Ĵ����������ͣ�int16 Q12��ʽ��PI_KP=Kp*2^12��
  PI_KI = 0;												//�Ĵ����������ͣ�int16 Q12��ʽ��PI_KI=Kp*2^12
  PI_EK = 0;												
  PI_UK = 0;												//�Ĵ����������ͣ�int16
  PI_UKMAX = 0;											//�Ĵ����������ͣ�int16
  PI_UKMIN = 0;											//�Ĵ����������ͣ�int16
  gPItype = 0;
}


/*******************************************************************************
* Function Name  : PI_Init
* Description    : 
* Input          : None
* Output         : 
* Return         : None
*******************************************************************************/
void Pid_SpdInit(void)
{
  #if(SPEED_CLOSE_EN)
  pid_spd.type = 0xF1;  pid_spd.Ref = 0;
  pid_spd.Fdb = 0;

  pid_spd.Err = 0;
  pid_spd.Err_Last1 = 0;
  pid_spd.Err_Err = 0;
  pid_spd.Out = 0;

  pid_spd.OutMax = SPEED_OUTMAX;
  pid_spd.OutMin = SPEED_OUTMIN;  
  #endif  
}

/*******************************************************************************
* Function Name  : PI_Init
* Description    : 
* Input          : None
* Output         : 
* Return         : None
*******************************************************************************/
void Pid_IsInit(void)
{
  #if(CURRENT_CLOSE_EN>1)
  pid_is.type = 0xF2;
  pid_is.Ref = 0;
  pid_is.Fdb = 0;
//  pid_is.Kp = CURRENT_PTERM; //Q15��ʽ
//  pid_is.Ki = CURRENT_ITERM; //Q15��ʽ
  pid_is.Err = 0;
  pid_is.Err_Last1 = 0;
  pid_is.Err_Err = 0;
  pid_is.Out = 0;

  pid_is.OutMax = CURRENT_OUTMAX ;
  pid_is.OutMin = CURRENT_OUTMIN;
  #endif
}

/*******************************************************************************
* Function Name  : 
* Description    : 
* Input          : None
* Output         : 
* Return         : None
*******************************************************************************/
s16 Pid_calc(PIDREG3 *v)   
{
  s32 tErr;  if(gPItype != v->type)   //gPItype 0XF1 0XF2 0XF3
  {
    gPItype = v->type;
    PI_KP = v->Kp;         //�Ĵ����������ͣ�int16 Q12��ʽ��PI_KP=Kp*2^12��
    PI_KI = v->Ki;         //�Ĵ����������ͣ�int16 Q12��ʽ��PI_KI=Kp*2^12
    PI_EK = v->Err;                
    PI_UK = v->Out;                //�Ĵ����������ͣ�int16
    PI_UKMAX = v->OutMax;          //�Ĵ����������ͣ�int16
    PI_UKMIN = v->OutMin;          //�Ĵ����������ͣ�int16
    SetBit(PI_LPF_CR,PISTA);      //Ŀ�������EK-1 UK-1
  }

  /*��ֵ����ʱ��3.2us*/
  tErr = (u32)v->Ref - v->Fdb;      //����PID��ǰƫ��  
  if(tErr >=  _IQ(1))
  {
    v->Err = _IQ(1); 
  }
  else if(tErr <=  _IQ(-1))
  {
    v->Err = _IQ(-1); 
  }
  else
  {
    v->Err = tErr;
  }
  /*PIӲ������ʱ��1.8us*/
  PI_EK = v->Err;                //PI����
  PI_UK = v->Out;                //�Ĵ����������ͣ�int16
  SetBit(PI_LPF_CR,PISTA);      //TOM++
  _nop_();
  _nop_();
  _nop_();
  _nop_();
  _nop_();

  v->Out = PI_UK;                //PI���
  return v->Out;
}