
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : �û��ӿڲ�
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <sys_conf.h>
#include <fu681x_Device.h>
#include <interrupt.h>
#include <Ftech_BLDC.h>
#include <MC_Led.h>
#include <MC_key.h>
#include <MC_PwmIn.h>
#include <MC_Beep.h>
#include <MC_init.h>
#include <MC_UserInterface_layer.h>
#include <MC_MotorCotrol_layer.h>  
#include <MC_MotorFunction_layer.h> 
#include <MC_MotorDriver_layer.h>   

/** @addtogroup FT68xx
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
Ui_TypeDef xdata Ui;                  //��������
float xdata tSpeedShiftcoefficient;   //�ٶ�ϵ��
s16 xdata tChipIDLEConter;            //�͹���
/* Private function prototypes -----------------------------------------------*/
void Ui_Function(void);            //ȫ�ֺ���  ����

/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : UI
* Description    : a������ָʾ���¶ȼ��㡢ADCת�����ٶ�ʵ��ֵ���� 
                   b������ת����������ٶ��������
                   c������ִ��
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Ui_Function(void)        //��������
{  
  u16 xdata trefTar;
//-----------------------------------------
//����ָʾ
  Fault_Led(Ctl.SysError);
  
//-----------------------------------------
//��λָʾ��������ʾ
  LED_show();
  
//-----------------------------------------
//ADCʵ��ֵת��
  ADCGetConversionValue();

//-----------------------------------------  
//ʵ��ת�� rpm 
#if (SPEED_CALC_EN == 2)
  MDUFlag.CalcSpeedRpm = 1;    
#endif
//-----------------------------------------
//�����ж�
#if(OVERLOAD_EN) 
  Ctl.OL.Value = MCL_OverLoadCalc(Drv.AdcMeas.ImeasBus);
#endif

//-----------------------------------------
//�¶ȼ���  
#if(OH1_EN)
  Drv.AdcMeas.Therm1 = Drv_PowerThermCalc(Drv.AdcMeas.Vth1);
#endif

#if(OH2_EN)
  Drv.AdcMeas.Therm2 = Drv_PowerThermCalc(Drv.AdcMeas.Vth2); //�¶Ȳ���
#endif

#if(ESC_PPMSREFEN)
  MDUFlag.TargetSpeed = 1;  
  if(Ctl.State >= MOTOR_STOP)
  {
    ESC_PPMSwitch();
  }
  BeepResponse();
#endif
//=====================================================
//���ػ� ����  �ٶȸ��� ����ת����
//-----------------------------------------------------
//ON/OFF ����ģʽ
#if(0)
  if((Ctl.Tim.OnOffnms < 3000))   
  {
    Ui.flg.START = FALSE;
    
    Ctl.SysError = NONE;  //�������
    DRV_OE_ON;
    Ctl.State = MOTOR_STOP; 
  }
  else if (Ctl.Tim.OnOffnms < 6000)
  {
    if((Ctl.SysError == NONE)&&(Ui.flg.START == FALSE))
    {
      Ui.flg.START = TRUE;
    }
  }     
  else
  {
    Ctl.Tim.OnOffnms = 0; 
  }
  #endif
//=====================================================
//---------------------------------------------------
//����ת����λ�������
////Xn�����������  -> ����ִ�� �ᴥ�Ϳ���
#if(0)
  if(X1.Kflg == TRUE)
  {
    X1.Kflg = FALSE;
    X1.KNum = FALSE;
    Ctl.Spd.SpeedShift++;

   if(Ctl.Spd.SpeedShift > 3)
    {
      Ctl.Spd.SpeedShift = 1;
    }
    Rom.WriteValue = (u8)Ctl.Spd.SpeedShift;//���絵λ�洢
  }

  if(Ctl.Spd.SpeedShift == 1)
  {
    tSpeedShiftcoefficient = 0.8;
  }
  else if(Ctl.Spd.SpeedShift == 2)
  {
   tSpeedShiftcoefficient = 0.9;
  }
  else if(Ctl.Spd.SpeedShift == 3)
  {
    tSpeedShiftcoefficient = 1.0;
  }
#endif
//Xn�����������  -> ����ִ��   ����������
#if(0)
  if(X1.XCount == KEY_FILTERCOUNT)
  { 
    Ui.flg.FR = CCW;
  }
  else if(X1.XCount == -KEY_FILTERCOUNT)
  {
    Ui.flg.FR = CW;
  }
#endif

//Xn�����������  -> ����ִ�� �ᴥ�Ϳ���
#if(0)
  if(X0.Kflg == TRUE)
  {
    X0.Kflg = FALSE;
    X0.KNum = FALSE;
     
    if(Ui.flg.FR == CW)
    {
      Ui.flg.FR = CCW;
//      Ctl.gDirectionC = Ui.flg.FR;    //�������
//      SetBit(DRV_CR, DDIR); 

    }
    else if(Ui.flg.FR == CCW)
    {
      Ui.flg.FR = CW;
//      Ctl.gDirectionC = Ui.flg.FR;    //�������
//      ClrBit(DRV_CR, DDIR);
    }
  }

  if(X3.Kflg == TRUE)
  {
    X3.Kflg = FALSE;
    X3.KNum = FALSE;
     
//    if( Ctl.Is.refCur == 2000)
//    {
//      Ctl.Is.refCur = 10000;  
//      Ctl.Is.refTar = 10000;
//    }
//    else
//    {
//      Ctl.Is.refCur = 2000;  
//      Ctl.Is.refTar = 2000;    
//    }
  }  
#endif

  //Drv.AdcMeas.Sref = _IQ(1.0);  
//---------------------------------------------------
//����������� ADC������������������������
//Xn�����������  -> ����ִ�� �ᴥ�Ϳ���
#if (KEYONOFF_EN == 1) 
  if(X2.Kflg == TRUE)
  {
    X2.Kflg = FALSE;
    X2.KNum = FALSE;
    
    if(Ui.flg.START == TRUE)
    {
      Ui.flg.START = FALSE;
      if((Ctl.SysError != NONE)&&(Ctl.SysError !=E_ERR9))
      {  
        Ctl.SysError = NONE;  //�������
        Ctl.State = MOTOR_STOP; 
        DRV_OE_ON;
      }      
    }
    else
    {
      Ui.flg.START = TRUE;
    }      
  }
#elif (KEYONOFF_EN == 2)
  if(X0.XCount == KEY_FILTERCOUNT)
  { 
    Ui.flg.START = TRUE;
    tChipIDLEConter = 0;
  }
  else if(X0.XCount == -KEY_FILTERCOUNT)
  {
    Ui.flg.START = FALSE;
//    if(tChipIDLEConter >= 5000)        //5������͹���ģʽ оƬ˯�ߵ���1mA ��˯��9mA
//    {                                  //�ⲿ�жϻ���˯��ģʽ ��Ҫ���ⲿ�ж�
//      tChipIDLEConter = 5000;
//      SetBit(PCON, STOP);           //оƬ����
//    }
  }
#elif(ADCONOFF_EN)
  //��λ�ƿ���
  //Drv.AdcMeas.Sref = _IQ(0.8);
  if(Drv.AdcMeas.Sref > SREF_IN_ONVALUE)
  {
    Ctl.Spd.SwitchCount++;
  }
  //else if((Drv.AdcMeas.Sref < _IQ(0.02))&&(Drv.PWM.DutyCur < _IQ(0.02)))
  else if(Drv.AdcMeas.Sref < SREF_IN_OFFVALUE)
  {
    Ctl.Spd.SwitchCount--;
  }
  if(Ctl.Spd.SwitchCount > SREFCOUNT)
  {
    Ctl.Spd.SwitchCount = SREFCOUNT;
    Ui.flg.START = TRUE;
  }   
  else if(Ctl.Spd.SwitchCount < -SREFCOUNT) 
  {
    Ctl.Spd.SwitchCount = -SREFCOUNT;
    Ui.flg.START = FALSE;
    Ctl.Spd.MechCircleNum = 0;
    if((Ctl.SysError != NONE)&&(Ctl.SysError !=E_ERR9))
    {  
     Ctl.SysError = NONE;  //�������
     Ctl.State = MOTOR_STOP; 
      DRV_OE_ON;
    }
  }  
#endif

//============================================================
//�ٶȸ���
#if(ADCSREF_EN) //ADC ����
  //ADC->>MDUControl.SpeedSref->>MDUControl.TargetSpeed->>Ctl.Spd.refTar
  
  MDUFlag.TargetSpeed = 1;  //�ٶȸ����������� 
  //MDUControl.SpeedSref = Drv.AdcMeas.Sref*tSpeedShiftcoefficient;
  MDUControl.SpeedSref = Drv.AdcMeas.Sref;
  trefTar = MDUControl.TargetSpeed;
  
  #if(SPEED_CLOSE_EN) //�ٶȱջ�����
    if(trefTar > SPEED_INMAX)
    {
      Ctl.Spd.refTar = trefTar;
    }
  #endif
  
   Ctl.Spd.refTar = (Ui.flg.FR == CCW)?  -trefTar: trefTar;

#endif
//=====================================================
//��HALL ����޷� �Ƚ�������ģʽ
#if (POS_FB_MODE == SensorLess) 

  #if (SPEED_CLOSE_EN)
    if(Ctl.Spd.refTar < Ctl.Ramp.DutyEnd)
    {
      Ctl.Spd.refTar = Ctl.Ramp.DutyEnd ;
    }  
  #endif  

  if(Ctl.State == MOTOR_NORMAL)
  {
    Drv.PWM.DutyTar = Ctl.Spd.refTar;
    //���ٹر�λ�ò����ж� TOM++
    if(TIM1__BCCR < STB6C)
    {
      ClrBit(TIM1_IER, T1PDIE);       
    }
    else if(TIM1__BCCR > STB5C)
    {                                                                    
      SetBit(TIM1_IER, T1PDIE);      
    }    
  }
#else
  Drv.PWM.DutyTar = Ctl.Spd.refTar;
#endif
  
//-----------------------------------------
//����ִ��
  if((Ui.flg.START == TRUE)&&(Ui.flg.FR != NONE))  
  {
    Ctl.gStartC = TRUE;
    gUserNoOperationDelaynms = 0;
  } 
  else if(Ui.flg.START == FALSE)
  {                   
    if(Ctl.gStopmodeC == FREE_DOWN)
    {
      Ctl.gStartC = FALSE;
    }
    else if(Ctl.gStopmodeC == SLOWING_DOWN)
    {
      Ctl.Spd.refTar = 0;
      if(Ctl.State == MOTOR_NORMAL)
      {
        #if(SPEED_CLOSE_EN)
//        if(((Ctl.Spd.refCur<_IQ(0.05))))
//        {
//          Ctl.gStartC = FALSE;
//        }      
//        #else
//        if((Drv.PWM.DutyCur < _IQ(0.05)))
//        {
//          Ctl.gStartC = FALSE;
//        }      
        #endif
      }
      else
      {
        Ctl.gStartC = FALSE;
      }
    } 
    else if(Ctl.gStopmodeC == BREAK_DOWN)
    {
      Ctl.gStartC = FALSE;
    }      
  }
}
