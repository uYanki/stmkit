
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : ���������
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <sys_conf.h>
#include <fu681x_Device.h>
#include <interrupt.h>
#include <Ftech_BLDC.h>
#include <MC_Led.h>
#include <MC_key.h>
#include <MC_PwmIn.h>
#include <MC_Beep.h>
#include <MC_init.h>
#include <MC_UserInterface_layer.h>
#include <MC_MotorCotrol_layer.h>  
#include <MC_MotorFunction_layer.h> 
#include <MC_MotorDriver_layer.h>   

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
DRV_TypeDef xdata Drv; 
u16 idata giEventCounter;

/* Private function prototypes -----------------------------------------------*/
void Drv_DutyLimit(void);
void Drv_StallRestart(void);               //��ת����
void Drv_SpeedRampCale(void);              //�ջ��Ӽ�������
void Drv_DutyRampCale(void);               //�����Ӽ�������   ׼���ϳ� �˺��� TOM20170831

void Drv_PWM_Update(u16 tduty);            //PWM����
void Drv_PosTrack(void);                   //ת�ٸ���
void DRV_HallEventCalc(void);              
void DRV_EemfEventCalc(void);
void Drv_BemfTim1PDapp(void) ;             //bemfλ�ü���жϷ�����
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : Drv_StallRestart    
* Description    : ��ת����
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void Drv_DutyLimit(void)           
{
  #if (CURRENT_CLOSE_EN == 1)
  if(Drv.AdcMeas.ImeasBus >  Drv.PWM.DutyLimitMaxRef)
  {
    Drv.PWM.DutyLimitFlag = 0x01;
  }
  else
  {
    Drv.PWM.DutyLimitFlag &= (~0x1);
  }
  #endif
  
  #if(SPEED_LIMIT_EN)
  if((Drv.speed.EventPeriod < ESC_SPEEDLIMITCNT)&&(Drv.speed.EventPeriod != 0))
  {
    Drv.PWM.DutyLimitFlag |= 0x02;
  }
  else
  {
    Drv.PWM.DutyLimitFlag &= (~0x2);
  }
  #endif
}
/*******************************************************************************
* Function Name  : Drv_StallRestart    
* Description    : ��ת����
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void Drv_StallRestart(void)             //��ת����
{
  #if (STALLRESTARTNUM != 255)
  if(Ctl.Stall.u8Num < STALLRESTARTNUM)
  #endif
  {
    Ctl.Stall.u8Num++;
    Ctl.Tim.STAnms = 0;
    Ctl.Tim.STB1nms = 0;
    Ctl.Tim.STB2nms = 0;
    Ctl.Stall.u8FL = 0;
    DRV_OE_ON;
    Ctl.SysError = NONE;
    if(Ctl.Stall.u16NormalRunms < STANMS+500)
    {
      Ctl.State = MOTOR_STOP;
    }
    else
    {
      Ctl.State = MOTOR_READY;
    }
  }
}


/*******************************************************************************
* Function Name  : Drv_SpeedRampCale �ջ��Ӽ�������
* Description    : �ٶȱջ��Ӽ������� ������Ч
* Input          : Ŀ���ٶ� refTar _IQ15��ʽ
* Output         : �����ٶ� refCur _IQ15��ʽ
* Return         : �����ٶ� refCur _IQ15��ʽ
���⣺TOM++ u16 Q15��ʽ �޷�����30000-(-2000) ����� 20170830 18��43 
*******************************************************************************/
void Drv_SpeedRampCale(void)
{
  if((Ctl.Spd.refTar > 0)&&(Ctl.Spd.refCur < 0))
  {
    Ctl.Spd.refTartemp = 0;
  }
  else if((Ctl.Spd.refTar < 0)&&(Ctl.Spd.refCur > 0))
  {
    Ctl.Spd.refTartemp = 0;
  }
  else
  {
    Ctl.Spd.refTartemp = Ctl.Spd.refTar; 
  }

  if((Ctl.Spd.refTartemp - Ctl.Spd.refCur) > Ctl.Spd.IncValue)
  {
    Ctl.Spd.refCur += Ctl.Spd.IncValue;
  }
  else if((Ctl.Spd.refCur - Ctl.Spd.refTartemp) > Ctl.Spd.DecValue)
  {
    Ctl.Spd.refCur -= Ctl.Spd.DecValue;
  }
  else
  {
    Ctl.Spd.refCur = Ctl.Spd.refTartemp;
  }
}

/*******************************************************************************
* Function Name  : Drv_DutyRampCale 
* Description    : ����Ƶ�ʣ�ÿ��ն������һ�� 
* Input          : Ŀ��DUTY  ��ʽ_IQ15 ��0x7FFF
* Output         : ��ǰDUTY  ��ʽ_IQ15 ��0x7FFF
* Return         : ��ǰDUTY  ��ʽ_IQ15 ��0x7FFF       
*******************************************************************************/
void Drv_DutyRampCale(void)
{
  if((Drv.PWM.DutyDecValue != 0x7FFF)&&(Drv.PWM.DutyIncValue != 0x7FFF))
  {
    if((Drv.PWM.DutyCur - Drv.PWM.DutyTar) > Drv.PWM.DutyDecValue)
    {
      Drv.PWM.DutyCur -= Drv.PWM.DutyDecValue;
    }
    else if((Drv.PWM.DutyTar - Drv.PWM.DutyCur) > Drv.PWM.DutyIncValue) 
    {
      Drv.PWM.DutyCur += Drv.PWM.DutyIncValue;  
    }
    else
    {
      Drv.PWM.DutyCur = Drv.PWM.DutyTar;
    }
  }
  else
  {
    Drv.PWM.DutyCur = Drv.PWM.DutyTar;
  }
}

/*******************************************************************************
* Function Name  : Drv_PWM_Update
* Description    : PWM����ģ�飬ÿ��ն�����£�ʵʱ����
* Input          : _IQ15 ��ʽduty
* Output         : DRV_DR          
* Return         : DRV_DR
*******************************************************************************/
void Drv_PWM_Update(u16 tduty)
{
  if(Drv.PWM.DutyLimitFlag != 0)                 //�������
  {
    Drv.PWM.DutyMax -= Drv.PWM.DutyLimitValue;
    if(Drv.PWM.DutyMax < 3276)
    {
      Drv.PWM.DutyMax = 3276;
    }
  }
  else
  {
    Drv.PWM.DutyMax += Drv.PWM.DutyLimitValue;
    if(Drv.PWM.DutyMax > MOTOR_VS_MAX)
    {
      Drv.PWM.DutyMax = MOTOR_VS_MAX;
    }
  }    
  //#endif
  tduty +=10;
  if(tduty > Drv.PWM.DutyMax)
  {
    tduty = Drv.PWM.DutyMax;
  }
  else if(tduty < Drv.PWM.DutyMin)
  {
    tduty = Drv.PWM.DutyMin;
  }
  
  MDUControl.DutyCur = tduty;
  MDUFlag.PWMDuty = 1;
}


/*******************************************************************************
* Function Name  : Drv_PosTrack
* Description    : ���ת��λ�ø���
* Input          : None
* Output         : None
* Return         : 1
*******************************************************************************/
void Drv_PosTrack(void)
{
#if (POS_FB_MODE == SensorLess)

  #if (WAIT_STEP == WAIT_STRACK)          //����ģʽ
  Drv.Stk.Calcnms = 0;
  #endif
  
  if(Drv.Stk.Calcnms < STKNMS) 
  { 
    if(Drv.Stk.BemfFR != 0xFF)
    {
      if(Ctl.gDirectionC == Drv.Stk.BemfFR)
      {
        if(Ctl.gDirectionC == CW)
        {
          Ctl.gStepCur = Drv.Stk.BemfTabA; 
        }
        else
        {
          Ctl.gStepCur = Drv.Stk.BemfTabB;
        }

        TIM1__RCNTR = 0;
        ANGLE_MASK(10);
        ANGLE_DELAY(10);         
  
        //TIM1__RARR = Ctl.Ramp.MaskTime>>2;
        ClrBit(TIM1_CR0, T1OPS1);
        ClrBit(TIM1_CR0, T1OPS0);                          //CMP��ⷴ����
        
        TIM1_CR4 = Ctl.gStepCur;                            //ѡ������ 
        
        ClrBit(TIM1_CR0, T1OPS1);
        SetBit(TIM1_CR0, T1OPS0);                          //CMP��ⷴ����

        SetBit(CMP_CR3, SAMSEL1);                        // ʹ��ON ����
        ClrBit(CMP_CR3, SAMSEL0);  
        
        SetBit(TIM1_IER, T1PDIE);                          //ʹ��λ�ü���ж�
        SetBit(TIM1_CR2, T1BRS);     //++                  //1λ�ü�⸴λ 0д�븴λTIM

        Drv.PWM.DutyTar = Ctl.Ramp.DutyEnd ;            
        Drv.PWM.DutyCur = Drv.PWM.DutyTar;  
        DRV_DR = MDU_MULA_U16(MDUControl.DutyCur,Drv.PWM.DutyArr+2,15);
        giEventCounter = 0;
        Ctl.State = MOTOR_NORMAL;

      }
      else if(Drv.Stk.BemfFR == 0x7F) 
      {
        #if (STRACK_EN == 2)
        Ctl.FnStopmodeC = FREE_DOWN;
        #endif
        ClrBit(TIM1_CR2, T1BRS);   //TOM++ TIM1_CR2?
        Ctl.State = MOTOR_PRECHARGE;
      }  
      else
      {     
        #if (STRACK_EN == 2)
        Ctl.State = MOTOR_STOP;
        Ctl.FnStopmodeC = BREAK_DOWN;
        #endif
      }
    } 
  }
  else
  {
    #if (STRACK_EN == 2)
    Ctl.FnStopmodeC = FREE_DOWN;
    #endif
    ClrBit(TIM1_CR2, T1BRS);       // 0д�븴λTIM1   1λ�ü�⸴λ 
    Ctl.State = MOTOR_PRECHARGE;
  }

  if(Ctl.gStartC == FALSE) 
  {
    Ctl.State = MOTOR_STOP;
  }
#endif
//  ClrBit(TIM1_CR2, T1BRS);      // 0д�븴λTIM1   1λ�ü�⸴λ 
//  Ctl.State = MOTOR_PRECHARGE;

}


/*******************************************************************************
* Function Name  : Drv_BemfTim1PDapp    
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Drv_BemfTim1PDapp(void) 
{
  if(Ctl.State == MOTOR_NORMAL)
  {
    DRV_EemfEventCalc();                    //���в���
  }
  else if(Ctl.State == MOTOR_OPENLOOP)
  {
    //Drv_SmartStartCalc();                   //�����㷨
  }
  else if(Ctl.State == MOTOR_READY)      
  {
    Drv_SectionCheak();                   //ת�ٸ���
  }
}  


/*******************************************************************************
* Function Name  : DRV_HallEventCalc    
* Description    : 
�ٶȼ���ģ�飬����HALL�źż����ٶ�
1����������
2��Ӳ������
3���������࣬���ó�ǰ�ǣ��ͺ�ǣ� ��Ҫ������Ԥ����ֹ��ǰ����ʱ��hall�ź�������
* Input          : TIM1_BCCR
* Output         : �ٶȵ�λ RPM
* Return         : ��

*******************************************************************************/

#define HALL_ADVANCEEANGLE (20) //��ǰ�Ƕ�  
#define HALL_RUNMODE       (2)  //1->�������� 2->Ӳ������ 3->��ǰ����(��������)

void DRV_HallEventCalc(void)
{
  giEventCounter++;
 
  if(giEventCounter >= 200)
  {
    giEventCounter = 200;
  }
  else if(giEventCounter == 30)
  {
    #if (HALL_RUNMODE == 3)
    ANGLE_DELAY((60-HALL_ADVANCEEANGLE));    
    ClrBit(TIM1_CR0, T1OPS1);         //00->�������� 01->���� 10->λ�ü��|ADC���� 11->����+����
    SetBit(TIM1_CR0, T1OPS0);         //10  01
    #endif
  }
  else if(giEventCounter == 12)
  {   
    #if (HALL_RUNMODE == 2)
    TIM1_CR4 = Ctl.gStepCur;   
    SetBit(TIM1_CR0, T1OPS1);         //00->�������� 01->���� 10->λ�ü��|ADC���� 11->����+����
    ClrBit(TIM1_CR0, T1OPS0);         //10  01 
    #endif
  }
  
  else     //��������
  {
    #if (HALL_RUNMODE == 1)
    giEventCounter = 6;
    #endif
    if(Ctl.gStepPre != Ctl.gStepCur )
    {
      if((Ctl.State == MOTOR_NORMAL)||(Ctl.State == MOTOR_PRECHARGE))
      {
        TIM1_CR4 = Ctl.gStepCur;
        Ctl.gStepPre = Ctl.gStepCur ;
      }
    }  
  }
}

/*******************************************************************************
* Function Name  : DRV_EemfEventCalc    
* Description    : �ٶȼ���ģ�飬����HALL�źż����ٶ�
* Input          : TIM1_BCCR
* Output         : �ٶȵ�λ RPM
* Return         : ��
*******************************************************************************/
#define BEMF_CMP          1 //CMP����
#define BEMF_ADC          2 //ADC����
#define BEMF_CMP_ADC0     3 //CMP+ADC���绻��
#define BEMF_CMP_ADC1     4 //CMP+ADC���̻���
#define BEMF_MODE         BEMF_CMP     
     

void DRV_EemfEventCalc(void)
{  
  #if (POS_FB_MODE == SensorLess) 
  giEventCounter++; 

  if(giEventCounter >= 6)
  {
//    if((Drv.speed.EventPeriod > STB1C))
//    {
//      Ctl.SysError = E_STB1;
//    } 
//    if(Drv.speed.EventPeriod < STB2C)
//    {
//      Ctl.SysError = E_STB2;
//    }

    #if(STB3_EN)
    if(((Drv.speed.EventPeriod >>2) > Drv.speed.EventPeriodPer)||(Drv.speed.EventPeriod < (Drv.speed.EventPeriodPer>>2)))
    {
//      Ctl.SysError = E_STB3;
    }

    #endif
  }
   
  Drv.speed.EventPeriodPer = Drv.speed.EventPeriod;
  
  if(giEventCounter >= 200)
  {
    giEventCounter = 200;
  }
  else if(giEventCounter >= 150)
  {
    #if (BEMF_MODE == BEMF_CMP_ADC0 )
    ANGLE_DELAY(30);                      //ADCģʽ ֻ����ON����
    SetBit(CMP_CR3, SAMSEL1);       // 00->ON+OFF 01->OFF  10->ON 11->ONOFF��MASK
    ClrBit(CMP_CR3, SAMSEL0);       // 
    
    ClrBit(TIM1_CR1, T1BRS);          // 1λ�ü�⸴λ 0д�븴λTIM
    SetBit(TIM1_CR3, T1TIS1);         // 00->GPIO 01->CMP 10->ADC 11->CMP+ADC
    SetBit(TIM1_CR3, T1TIS0);
    SetBit(TIM1_CR0, T1OPS1);         // 00->�������� 01->���� 10->λ�ü��|ADC���� 11->����+����
    SetBit(TIM1_CR0, T1OPS0);         //ע�� 10����û���� 11����û����
    #elif (BEMF_MODE == BEMF_CMP_ADC0 )
    ANGLE_DELAY(30);                      //ADCģʽ ֻ����ON����
    SetBit(CMP_CR3, SAMSEL1);       // 00->ON+OFF 01->OFF  10->ON 11->ONOFF��MASK
    ClrBit(CMP_CR3, SAMSEL0);       // 
    
    ClrBit(TIM1_CR1, T1BRS);          // 1λ�ü�⸴λ 0д�븴λTIM
    SetBit(TIM1_CR3, T1TIS1);         // 00->GPIO 01->CMP 10->ADC 11->CMP+ADC
    SetBit(TIM1_CR3, T1TIS0);
    SetBit(TIM1_CR0, T1OPS1);         // 00->�������� 01->���� 10->λ�ü��|ADC���� 11->����+����
    ClrBit(TIM1_CR0, T1OPS0);         //ע�� 10����û���� 11����û����
    #elif (BEMF_MODE == BEMF_ADC )
    ANGLE_DELAY(30);                      //ADCģʽ ֻ����ON����
    SetBit(CMP_CR3, SAMSEL1);       // 00->ON+OFF 01->OFF  10->ON 11->ONOFF��MASK
    ClrBit(CMP_CR3, SAMSEL0);       // 
    
    ClrBit(TIM1_CR1, T1BRS);          // 1λ�ü�⸴λ 0д�븴λTIM
    SetBit(TIM1_CR3, T1TIS1);         // 00->GPIO 01->CMP 10->ADC 11->CMP+ADC
    ClrBit(TIM1_CR3, T1TIS0);
    SetBit(TIM1_CR0, T1OPS1);         // 00->�������� 01->���� 10->λ�ü��|ADC���� 11->����+����
    ClrBit(TIM1_CR0, T1OPS0);      
    #elif (BEMF_MODE == BEMF_CMP ) 

    ClrBit(TIM1_CR2, T1BRS);      // 1λ�ü�⸴λ 0д�븴λTIM
//    SetBit(TIM1_CR1, BAPE);       
//    SetBit(TIM1_CR0, FORC);      // ǿ�ƻ���60�ȵ�Ƕ�

    ANGLE_MASK(RUN_ANGLE_MASK);
    ANGLE_DELAY(RUN_ANGLE_DELAY);                //
    SetBit(CMP_CR3, SAMSEL1);    // ʹ��ON ����
    SetBit(CMP_CR3, SAMSEL0);    // ʹ��OFF����
    #endif   
  }    
  else if(giEventCounter >= 100)
  {
    ANGLE_MASK(35);
    ANGLE_DELAY(1);  
  }
  else if(giEventCounter == 30)
  {

    Drv.PWM.DutyArr = RUN_PWMARR;
    DRV_ARR = Drv.PWM.DutyArr;
    DRV_COMR = PWM_FLOW ;    

    Drv.PWM.DutyIncValue = SPEED_INCVALUE ;   //loop INC DEC
    Drv.PWM.DutyDecValue = SPEED_DECVALUE ;
  }
    
  #endif
}

