
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <sys_conf.h>
#include <fu681x_adc.h>
#include <fu681x_lpf.h>
#include <MC_MotorDriver_layer.h>    
#include <MC_MotorCotrol_layer.h>    
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
extern u8 Delay(u16 timer);
extern u8 Delayus(u16 timer);
void ADCGetFastValue(void);

/*******************************************************************************
* Function Name  : ADC_Config
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ADC_Config(void)
{
  /*-----------------------------------------------------------------------------------
    ADC�ο���ѹ����
  -----------------------------------------------------------------------------------*/ 
  #if (HW_ADC_REF == VREF3_0)    //3V   10
  SetBit(VREF_VHALF_CR, VRVSEL1);
  ClrBit(VREF_VHALF_CR, VRVSEL0);
  #elif (HW_ADC_REF == VREF4_0) //4V    11
  SetBit(VREF_VHALF_CR, VRVSEL1);
  SetBit(VREF_VHALF_CR, VRVSEL0);
  #elif (HW_ADC_REF == VREF4_5) //4.5   00
  ClrBit(VREF_VHALF_CR, VRVSEL1);
  ClrBit(VREF_VHALF_CR, VRVSEL0);
  #elif (HW_ADC_REF == VREF5_0)  //5V   01
  ClrBit(VREF_VHALF_CR, VRVSEL1);
  SetBit(VREF_VHALF_CR, VRVSEL0);
  #else
    #error ERROR HW_ADC_VREF
  #endif
  SetBit(VREF_VHALF_CR, VREFEN); 

  /*-------------------------------------------------------------------------------------------------
  ADC��������
  1��ʹ��ADC
  2����ֹADC Trigger
  -------------------------------------------------------------------------------------------------*/
  ClrBit(ADC_CR, ADCEN);                               // ʹ��ADC

  /*-------------------------------------------------------------------------------------------------
  ADC�ο���ѹѡ��
  ʹ��VREF�����ڸ�ADC�ṩ�ڲ��ο���׼
  P3.5����ģ��IO��VREFENΪ1-�ڲ��ο���ѹ�ṩ��ADC��ͬʱ�ͳ���P3.5��VREF��ѹ;
  P3.5��������IO��VREFENΪ1-�ڲ��ο���ѹ�ṩ��ADC������P3.5��VREF��ѹ;
  P3.5����ģ��IO��VREFENΪ0-�ⲿ�ο���ѹ�ṩ��ADC�����ⲿ�ṩADC�ο���
  -------------------------------------------------------------------------------------------------*/
  SetBit(VREF_VHALF_CR, VREFEN);                            //ʹ��VREF
  SetBit(P3_AN, P35);                                       //VREF����ģ���
  /*-------------------------------------------------------------------------------------------------
  ADCͨ������
  1��ʹ����ӦPinΪģ��Pin����ֹ���ֹ���
  2��ʹ��ͨ��MASK������Pin��ADCģ��
  -------------------------------------------------------------------------------------------------*/
  SetBit(P1_AN, P15);
  SetBit(ADC_MASK_SYSC, CH11EN);                     //Config P1.5 as ADC11 
//  SetBit(P1_AN, P14);
//  SetBit(ADC_MASK_SYSC, CH10EN);                     //Config P1.4 as ADC10  BEMF_U
//  SetBit(P1_AN, P16); 
//  SetBit(ADC_MASK_SYSC, CH9EN);                      //Config P1.6 as ADC9   BEMF_V
//  SetBit(P2_AN, P21); 
//  SetBit(ADC_MASK_SYSC, CH8EN);                      //Config P2.1 as ADC8   BEMF_W
  SetBit(P3_AN, P34); 
  SetBit(ADC_MASK_SYSC, CH7EN);                        //Config P3.4 as ADC7   SREF
  SetBit(P3_AN, P33); 
  SetBit(ADC_MASK_SYSC, CH6EN);                        //Config P3.3 as ADC6   Tmos
//  SetBit(P3_AN, P32); 
//  SetBit(ADC_MASK_SYSC, CH5EN);                      //Config P3.2 as ADC5   VHALF
  SetBit(P2_AN, P27); 
  SetBit(ADC_MASK_SYSC, CH4EN);                        //Config P2.7 as ADC4   IBUS
  SetBit(P2_AN, P25); 
  SetBit(ADC_MASK_SYSC, CH3EN);                        //Config P2.5 as ADC3   Ibus_avg
  SetBit(P2_AN, P24); 
  SetBit(ADC_MASK_SYSC, CH2EN);                        //Config P2.4 as ADC2   DCBUS
  SetBit(P2_AN, P23); 
//  SetBit(ADC_MASK_SYSC, CH1EN);                      //Config P2.3 as ADC1   IV
//  SetBit(P2_AN, P20);    
//  SetBit(ADC_MASK_SYSC, CH0EN);                      //Config P2.0 as ADC0   IU

  /*ADCͨ������ʱ����������*/                      
  ADC_SYSC  = 0x33;                       

  /*-------------------------------------------------------------------------------------------------
  ADC�ж�����
  1������ADCת��������־λ
  2����ֹADC�ж�
  5������ADC�ж����ȼ���Ϊ0
  -------------------------------------------------------------------------------------------------*/ 
  ClrBit(ADC_CR, ADCIF);
  ClrBit(ADC_CR, ADCIE);          // 0����ֹADC�жϣ�1��ʹ��ADC�ж�
  SetBit(ADC_CR, ADCBSY);         //����ADC����ת��
  SetBit(ADC_CR, ADCEN); 
}

/*******************************************************************************
* Function Name  : ADCInit
* Description    : ADC��ʼ��
* Input          : None
* Output         : None
* Return         : None      
*******************************************************************************/
void ADCInit(void)
{
  u8 i,j;
  u16 xdata tIbusAvg,tIbusTemp;
  // V_bus
  Drv.AdcMeas.VdcMeasGain = VDCMEASEGAIN;
  Drv.AdcMeas.VdcMeas = 0;
  Drv.AdcMeas.Vdc = 0;
  //--------------------------------------------
  //I_bus AD4У׼ 6154-5784 = 370      ռ��flash�ϴ�ע�⣡����
  EA = 0;
  tIbusAvg = 0;  
  for(i = 0,j = 0;i < 8;)
  {
    tIbusTemp = FastADImeasConvert(CH4EN);  //�������ٲ���
    // I_bus                   
    if(tIbusTemp < 4096*0.05)
    {
      tIbusAvg += tIbusTemp;
      i++;
    }
    else if((tIbusTemp < 2048*1.05)&&(tIbusTemp > 2048*0.95))
    {
      tIbusAvg += tIbusTemp;
      i++;
    }
    else
    {
      j++;      
      if(j > 8)
      {
        i = 8;
        Ctl.SysError = E_ERR9;       //�Լ����
      }
    }
  }
  Drv.AdcMeas.IBusMeasOffset = -tIbusAvg; 
  Drv.AdcMeas.IBusMeasGain = IBUSMEASGAIN;
  Drv.AdcMeas.ImeasBus = 0;
  Drv.AdcMeas.Ibus = 0;  
  EA = 1;

  //-------------------------------------  
  // VTH1
  Drv.AdcMeas.Vth1Meas     = 0;
  // VTH2
  Drv.AdcMeas.Vth2Meas     = 0;
  // VTH3
  Drv.AdcMeas.Vth3Meas     = 0;
  // Vref
  Drv.AdcMeas.SrefMeas     = 0;
  Drv.AdcMeas.Sref         = 0;
}


/*******************************************************************************
* Function Name  : FastADConvert    
* Description    : ADC���ټ�� ����
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

u16 FastADImeasConvert(u8 ch)
{
  u8 tempADC_MASK;
  u16 tvalue;

  tempADC_MASK = ADC_MASK_SYSC;

  ADC_MASK_SYSC = ch;

  ClrBit(ADC_CR, ADCIF);
  
  SetBit(ADC_CR, ADCBSY);         //����ADC����ת��
  while(!(ReadBit(ADC_CR, ADCIF)));   //ADC���������жϷ�����
  {
    ClrBit(ADC_CR, ADCIF);
    ADC_MASK_SYSC = tempADC_MASK;
    tvalue = ADC4_DR;
  }
  return tvalue;
}

/*******************************************************************************
* Function Name  : ADCGetValue
* Description    : 2us
* Input          : None
* Output         : None
* Return         : None     
*******************************************************************************/
void ADCGetValue(void)
{ 
  #if(VBUS_CALC_EN)
  Drv.AdcMeas.VdcMeas   = ADC2_DR;   // Q12
  #endif

  #if(ADCSREF_EN)
  Drv.AdcMeas.SrefMeas  = ADC7_DR;   // Q12
  #endif
  
  #if(OH1_EN)
  Drv.AdcMeas.Vth1Meas  = ADC11_DR ;    // Q12
  #endif

  #if(OH2_EN)
  Drv.AdcMeas.Vth2Meas  = ADC3_DR;     // Q12
  #endif

  #if(OH2_EN)
  Drv.AdcMeas.Vth3Meas  = ADC6_DR ;    // Q12
  #endif
}

/*******************************************************************************
* Function Name  : ADCGetConversionValue
* Description    : ����ADC������ת��
                   ������VdcMeas SrefMeas Vth1Meas Vth2Meas Vth3Meas
                   ת����Vdc Ibus Sref
* Input          : None
* Output         : None
* Return         : None      
*******************************************************************************/
void ADCGetConversionValue(void)
{
  
  Drv.AdcMeas.VdcAvgMeas  = MC_LPF(Drv.AdcMeas.VdcMeas,Drv.AdcMeas.VdcAvgMeas, _IQ(0.1));

  #if(ADCSREF_EN)
  Drv.AdcMeas.SrefAvgMeas  = MC_LPF(Drv.AdcMeas.SrefMeas,Drv.AdcMeas.SrefAvgMeas, _IQ(0.1)); 
  Drv.AdcMeas.Sref = Drv.AdcMeas.SrefMeas<<3; // Q12-->Q15 
  #endif

  #if(VBUS_CALC_EN)             //����ʵ�ʵ�ѹ 
  Drv.AdcMeas.Vdc = Drv.AdcMeas.VdcAvgMeas*Drv.AdcMeas.VdcMeasGain;
  #endif
  
  #if(IBUS_CALC_EN)             //����ʵ�ʵ���
  Drv.AdcMeas.Ibus = Drv.AdcMeas.ImeasBus*Drv.AdcMeas.IBusMeasGain;
  #endif
}



