
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <sys_conf.h>
#include <fu681x_hall.h>
#include <MC_MotorCotrol_layer.h> 
#include <MC_MotorDriver_layer.h>  

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/*
  HALL ����                       5 1 3 2 6 4
  ����                      CW    1 2 3 4 5 6 
                            CCW   4 5 6 1 2 3 
 */
 uc8 HALL2SECTIONCW[8]   = {0x7F,2,4,3,6,1,5,0xFF};   //1 2 3 4 5 6
 uc8 HALL2SECTIONCCW[8]  = {0X7F,5,1,6,3,4,2,0xFF};   //4 5 6 1 2 3 
 
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : Hall_Init      �ⲿ�ж����ã�hallʹ��tim1��Ϊ����
* Description    : P02 P36 P37 P14 P16 P21
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Hall_Init(void)
{
  #if (HallMode != HallIC_Z)
  {
    HALL_PIN_SEL;              // ѡ��A�����B��hall����
    #if(HALLPTDPE)
    SetBit(HA_PU, HA_PIN);  // enable P14 pull up
    SetBit(HB_PU, HB_PIN);  // enable P16 pull up
    SetBit(HC_PU, HC_PIN);  // enable P21 pull up

    #else
    ClrBit(HA_PU, HA_PIN);  // disable P14 pull up
    ClrBit(HB_PU, HB_PIN);  // disable P16 pull up
    ClrBit(HC_PU, HC_PIN);  // disable P21 pull up
    #endif
  }
  #else
    SetBit(P1_AN, P14_AN);
    SetBit(P1_AN, P16_AN);
    SetBit(P2_AN, P21_AN);
    SetBit(P1_AN, P15_AN);                                 // CMP0
    SetBit(P1_AN, P17_AN);                                 // CMP1
    SetBit(P2_AN, P22_AN);                                 // CMP2
    SetBit(CMP_CR2, CMP0_MOD0);                         // ���ģʽ
    ClrBit(CMP_CR2, CMP0_MOD1);                         // 
 /*-------------------------------------------------------------------------------------------------
  �Ƚ������͵�ѹѡ��,оƬ�������ܲ� 
  000: �޳���   001: -5mV   010: +5mV   011: +-5mV
  100: �޳���   101: -9mV   110: +9mV   111: +-9mV
  -------------------------------------------------------------------------------------------------*/
    ClrBit(CMP_CR1, CMP0HYS2);
    SetBit(CMP_CR1, CMP0HYS1);
    SetBit(CMP_CR1, CMP0HYS0);                            // �Ƚ���0~2�͵�ѹ+-9mv  
  #endif
    
}

/*******************************************************************************
* Function Name  : Hall_IRQHandler
* Description    : 
  //HallStatus  = HA;
  //HallStatus += HB;
  //HallStatus += HC;
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Hall_IRQHandler(void)
{
  //HALL״̬ ת������
  Drv.Hall.Status = HAHBHC; 
  Drv.Hall.Section = (Ctl.gDirectionC == CW)? HALL2SECTIONCW[Drv.Hall.Status]:HALL2SECTIONCCW[Drv.Hall.Status];
  Ctl.gStepCur = Drv.Hall.Section;
  //------------------------------------------ 
  //HALL ����������  
  #if (POS_FB_MODE == HallSensor) 
  if((Drv.Hall.Section == 0x7F)||(Drv.Hall.Section == 0xFF))
  {
    Ctl.SysError = E_HALL;
  }
  #endif 
}
