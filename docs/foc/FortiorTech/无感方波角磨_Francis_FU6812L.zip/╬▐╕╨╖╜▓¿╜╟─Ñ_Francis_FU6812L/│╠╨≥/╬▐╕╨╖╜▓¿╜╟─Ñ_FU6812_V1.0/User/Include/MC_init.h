
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MC_INIT_H
#define __MC_INIT_H

/* Includes ------------------------------------------------------------------*/
//#include <fu681x_Device.h>
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/

/* Exported define --------------------------------------------------------*/

//�˿ڶ��� START F/R FO FG PWMIN SREF LED UART SPI  HALL
//------------------------------------------------------------------------------
//FO     ��������   IPM�����źţ���ֹ�޸� 
#define FOIN            GP00         //��Ϊ FO�ź�ʱ����ֹռ��
#define FO_PIN          P00
#define FO_GPIO_PORT    P0_OE

//------------------------------------------------------------------------------
//FD6536  ʹ��
//#define FD6536           GP36
//#define FD6536_PIN       P36 
//#define FD6536_GPIO_PORT P3_OE

//#define FD6536_EN        {FD6536 = 0;}
//#define FD6536_DIS       {FD6536 = 1;}

//------------------------------------------------------------------------------
//FG     FG��� 
#define FG              GP41
#define FG_PIN          P41 
#define FG_GPIO_PORT    P4_OE
#define FG_ON           {FG = 1;}
#define FG_OFF          {FG = 0;}
#define FG_ONOFF        {FG = ~FG;}


#define NSS              GP04
#define NSS_PIN          P04 
#define NSS_GPIO_PORT    P0_OE
#define NSS_ON           {NSS = 1;}
#define NSS_OFF          {NSS = 0;}
#define NSS_ONOFF        {NSS = ~NSS;}

#define MOSI              GP05
#define MOSI_PIN          P05 
#define MOSI_GPIO_PORT    P0_OE
#define MOSI_ON           {MOSI = 1;}
#define MOSI_OFF          {MOSI = 0;}
#define MOSI_ONOFF        {MOSI = ~MOSI;}

#define SCLK              GP06
#define SCLK_PIN          P06 
#define SCLK_GPIO_PORT    P0_OE
#define SCLK_ON           {SCLK = 1;}
#define SCLK_OFF          {SCLK = 0;}
#define SCLK_ONOFF        {SCLK = ~SCLK;}

#define MISO              GP07
#define MISO_PIN          P07 
#define MISO_GPIO_PORT    P0_OE
#define MISO_ON           {MISO = 1;}
#define MISO_OFF          {MISO = 0;}
#define MISO_ONOFF        {MISO = ~MISO;}


/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
extern void SoftwareInit(void);
extern void MCL_ModuleDefault(void);
extern void MCL_ModuleInit(void);     //ģ���ʼ��
extern void MCL_DefaultInit(void);    //
extern void gDelayus(u16 timer);
extern void gDelayms(u16 timer);

#endif /* __HD_init_H */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/

