
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU6812_MCU.h>
#include <sys_conf.h>
#include <fu681x_lpf.h>
#include <MC_init.h>
#include <MC_MotorCotrol_layer.h>  
#include <MC_MotorDriver_layer.h> 
#include <fu681x_Dmc.h>
#include <fu681x_Device.h>
/** @addtogroup FT68xx
  * @{
  */


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
MDUControl_TypeDef idata MDUControl;
MDUbit_TypeDef xdata MDUFlag;
  
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/

/* Private functions ---------------------------------------------------------*/
void MDU_Config(void);
void MDUControlInit(void);
void MDUAPP(void);


/*-------------------------------------------------------------------------------------------------
	Function Name :	void MDU_Init(void)
	Description   :	MDUģ���ʼ�����˷������λ���˷�ģʽ
	Input         :	None
  Output				:	None
-------------------------------------------------------------------------------------------------*/
void MDU_Config(void)
{
/*-------------------------------------------------------------------------------------------------
	�˷�����ʼ��
  00:�˷��������0λ	01:�˷��������8λ	10:�˷��������12λ	  11:�˷��������15λ
-------------------------------------------------------------------------------------------------*/
  ClrBit(MDU_CR, ALIGN1);
  ClrBit(MDU_CR, ALIGN0);				                       // 00:�˷��������0λ	

  ClrBit(MDU_CR, MDSN);						                     // ѡ���޷��ų˷�

  MDUControlInit();
}

/*-------------------------------------------------------------------------------------------------
	Function Name : void MDUControlInit(void)
	Description   :	MDU���ƺ�����־λ��ʼ��
	Input         :	��
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void MDUControlInit(void)
{

  #if(ADCSREF_EN) 
  MDUControl.AlineX2 = SREF_IN_MAX;
  MDUControl.AlineX1 = SREF_IN_MIN;
  //MDUControl.SpeedSref = Drv.AdcMeas.Sref;
  MDUControl.SpeedSrefErr = (u32)(MDUControl.AlineX2 - MDUControl.AlineX1);
  
  MDUControl.AlineA = (u16)(SREFlineA*32767);
  MDUControl.AlineB = SREFlineB;
  #endif
  
  MDUFlag.PWMDuty = 0;
  
  MDUFlag.CalcSpeed = 0;
  MDUFlag.CalcSpeedRpm = 0;
}
/*-------------------------------------------------------------------------------------------------
	Function Name : void MDUAPP(void)
	Description   :	MDU���ƺ���������Ƶ��ΪPWMFre(16K)��������ȼ�������ϵͳ������MDU���㶼�ڴ˺���
                  ִ�У�����ɨ�赽��Ӧ�ı�־λ�������Ӧ�����㡣
	Input         :	��
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void MDUAPP(void)
{
  u16 xdata tTargetSpeed;
  s16 tSpeedRpm;
  s16 tSpeed;
  //Ctl.gDirectionS
  
  if(MDUFlag.PWMDuty == 1)
  {
    DRV_DR = MDU_MULA_U16(MDUControl.DutyCur,Drv.PWM.DutyArr+2,15);               //ռ�ձȼ���
    MDUFlag.PWMDuty = 0;
  }
  if(MDUFlag.CalcSpeed == 1)
  {
    tSpeed = MDU_DIV_XDATA_U32(&Drv.speed.SpeedScaler,&Drv.speed.EventPeriod);//�ٶȱ���ֵ���� 
    MDUFlag.CalcSpeed = 0;
  }
  if(MDUFlag.CalcSpeedRpm == 1)
  {
    tSpeedRpm = MDU_MULA_U16(tSpeed,Drv.speed.BaseRpm,15);          //ʵ��ת�ټ���
    MDUFlag.CalcSpeedRpm = 0;
  } 
  if(Ctl.gDirectionS == 1)
  {  
    Drv.speed.Speed  = (-tSpeed);
    Drv.speed.SpeedRpm = -tSpeedRpm;
  }
  else
  {
    Drv.speed.Speed  = tSpeed;
    Drv.speed.SpeedRpm = tSpeedRpm;
  }

  if(MDUFlag.TargetSpeed == 1)
  {
    if(MDUControl.SpeedSref > MDUControl.AlineX1)
    {  
      //y = A*x + B ;             
      tTargetSpeed = MDU_MULA_U16(MDUControl.SpeedSref,MDUControl.AlineA,15) + MDUControl.AlineB;
      if(tTargetSpeed > 0x7FFE)
      {     
        MDUControl.TargetSpeed = 0x7FFE;
      }
      else
      {
        MDUControl.TargetSpeed = tTargetSpeed;
      }
    }
    else
    {
      MDUControl.TargetSpeed = 0;
    }
    MDUFlag.TargetSpeed = 1;
  }    
}
  