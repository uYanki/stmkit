
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FU681X_DMC_H
#define __FU681X_DMC_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
typedef struct 
{
  u32 SpeedScaler;   // Parameter :  Scaler converting 1/N cycles to a GLOBAL_Q speed (Q0) - independently with global Q
  u16 EventPeriod;   // Input/Variable :  Event Period (Q0) - independently with global Q
  u16 EventPeriodPer;
  s8  InputSelect;   // Input : Input selection between TimeStamp (InputSelect=0) and EventPeriod (InputSelect=1)
  u16 BaseRpm;       // Parameter : Scaler converting GLOBAL_Q speed to rpm (Q0) speed - independently with global Q
  s16 SpeedRpm;      // Output : speed in r.p.m. (Q0) - independently with global Q
  s16 Speed;         // Output : �ٶȱ���ֵ  SpeedRpm SpeedRpm Speed TOM++ ԭU32��ʽ 20170831
} SPEED_MEAS_CAP;    // Data type created


typedef struct
{
  u8 DelayAngle;
  u8 MaskAngle;  
  s16 DutyCur;           //ռ�ձ�
  s16 TargetSpeed;           //Ŀ���ٶ�

  s16 SpeedSref;             //�ٶȸ��� ����У׼
  u16 AlineX1,AlineX2,AlineY1,AlineY2;
  u16 AlineA;
  s16 AlineB;
  u16 SpeedSrefErr;

} MDUControl_TypeDef;

typedef struct { 
      u8 PWMDuty:1;        //��ͣ����
      u8 CalcSpeed:1;           //����ת����
      u8 CalcSpeedRpm:1;        //����
      u8 TargetSpeed:1;           //Ӳ������     
      u8 RSV1:1; 
      u8 RSV2:1; 
      u8 RSV3:1; 
      u8 RSV4:1;
}MDUbit_TypeDef; 

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
extern MDUControl_TypeDef idata MDUControl;
extern MDUbit_TypeDef xdata MDUFlag;

extern void MDU_Config(void);
extern void MDUControlInit(void);
extern void MDUAPP(void);
#endif /* __HD_init_H */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/