
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : ���棺��ֹ�޸�,ɾ�� �ṹ�嶨�� ����ᵼ��δ֪����
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FTECH_BLDCC_H
#define __FTECH_BLDCC_H
#include <fu681x_Dmc.h>
/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

extern void Drv_SmartStartCalc(void);
/*******************************************************************************
* Function Name  : Drv_SectionCheak    
* Description    : ת�ٸ�������
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
extern u8 Drv_SectionCheak(void);

///*******************************************************************************
//* Function Name  : DRV_IRPD_F    
//* Description    : 700�ֽ�
//* Input          :         
//* Output         : 
//* Return         : 
//*******************************************************************************/
extern s8 DRV_IRPD_F(u8 ONnms,u8 OFFnms ,u8 Count);
extern u8 DRV_IRPD(u8 ONnms,u8 OFFnms );


#endif