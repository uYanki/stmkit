/**************************** (C) COPYRIGHT 2015 Fortiortech shenzhen *****************************
* File Name          : FocControl.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 01/07/2015
* Description        : This file contains all the add function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>
extern char flag;
extern int16 count;
uint8 LowSpeedBrakeFlag=0;
uint16  Brake_Delay=100;
uint8 BEMFcount1=0;
uint8 BEMFcount2=0;
uint8 BEMFcount3=0;
uint8 BEMFcount4=0;
uint8 BrakeFlag=0;
/*---------------------------------------------------------------------------*/
/* Name		:	void FOC_Init(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	mcInit״̬�£���FOC����ؼĴ�����������
/*---------------------------------------------------------------------------*/
void FOC_Init(void)
{
	/*deadtime set*/	
	TIM0_DTR 			= PWM_LOAD_DEADTIME;											// Deadtime = 0x18/24MHZ = 1us
	
	/*enable FOC register set*/	
	FOCEN					= Enable;																	// enable FOC module
	
	CLR(FOC_SR,FUIF);                                       // ���FOC�жϱ�־λ
	SET(FOC_IER,FUIE);                                      // ʹ��FOC�ж�
		
	PFOC1 = 0;                                              // �ж����ȼ�����Ϊ2�����ȼ�����FOӲ������
	PFOC0 = 1;
		
	/*set FOC register*/	
	FOC_CR1 			= 0;																			// clear FOC_CR1
	FOC_CR2 			= 0;																			// clear FOC_CR2
	FOC_IDREF 		= 0;																			// clear Id
	FOC_IQREF 		= 0;																			// clear Iq
	
	FOC_THETA 		= 0;																			// clear theta
	FOC_RTHEACC 	= 0;																			// ���º����ĳ�ʼ���ٶ�
	FOC_RTHESTEP 	= 0;																			// 0 degree acce speed
	FOC_RTHECNT 	= 0;																			// acce time
	FOC_THECOMP 	= 0x0000;																	// smo estimater angle comp	
	FOC_THECOR 		= 0x0001;																	// Theta error compensate

	FOC_ARR 			= PWM_VALUE_LOAD;     										// set 16Khz carry frequency
	FOC_POWKLPF 	= POWER_KLQFP;														// set FOC power cacl filter value
	
	/*current loop parameter set*/
	FOC_DKP 			= DKP;	
	FOC_DKI 			= DKI;
	FOC_DMAX 			= DOUTMAX;
	FOC_DMIN 			= DOUTMIN;
	
	FOC_QKP 			= QKP;
	FOC_QKI 			= QKI;
	FOC_QMAX 			= QOUTMAX;
	FOC_QMIN 			= QOUTMIN;
		
	/*estimate parameter set*/
	FOC_EK1 			= OBS_K1T;
	FOC_EK2 			= OBS_K2T;
	FOC_EK3 			= OBS_K3T;
	FOC_EK4 			= OBS_K4T;
	
	FOC_FBASE 		= OBS_FBASE;						
	FOC_OMEKLPF 	= SPEED_KLPF;					
	FOC_EBMFK 		= OBS_KLPF;						
	FOC_EKP 			= OBSW_KP_GAIN;					
	FOC_EKI 			= OBSW_KI_GAIN;	
	
	switch (UBUS_ADCCH)
	{
		case 2:
			CLR(FOC_CHC,UCH2);
			SET(FOC_CHC,UCH1);				
			CLR(FOC_CHC,UCH0);
			break;
		case 3:
			CLR(FOC_CHC,UCH2);
			SET(FOC_CHC,UCH1);				
			SET(FOC_CHC,UCH0);
			break;
		case 5:
			SET(FOC_CHC,UCH2);
			CLR(FOC_CHC,UCH1);				
			SET(FOC_CHC,UCH0);
			break;
		case 6:
			SET(FOC_CHC,UCH2);
			SET(FOC_CHC,UCH1);				
			CLR(FOC_CHC,UCH0);
			break;
		case 7:
			SET(FOC_CHC,UCH2);
			SET(FOC_CHC,UCH1);				
			SET(FOC_CHC,UCH0);
			break;
		default:
			CLR(FOC_CHC,UCH2);
			SET(FOC_CHC,UCH1);				
			CLR(FOC_CHC,UCH0);
		  break;
	}

	
	/*FOC�ڲ�SPIģ���ʼ��*/
	#if (FOCSPIEnable)
	{	
	  FocSpi_Init();                                         	//Foc��SPI��ʼ��,���ڹ۲�FOC��ı���	
	}
	#endif
	
	/*���������ת��������*/
	SetBit(FOC_SET1,FOCFR,mcFRState.FR);										// ����F/R		
	
	/*driver mode and active level set*/
	#if (DriverMode == Driver_3P3N)													// FOC 3P3N mode��һ��ʹ���ڵ�ѹ
	{		
		SetBit(FOC_CMR,CCPH,0);																// �Ϲܣ�high level ��Ч
		SetBit(FOC_CMR,CCPL,0);																// �¹ܣ�high level ��Ч
	}
	#elif (DriverMode == Driver_6N)													// FOC 6N mode��һ�������ڸ�ѹ
	{
		#if (PWM_Level_Mode == High_Level)										
		{
			SetBit(FOC_CMR,CCPH,0);															// �Ϲܣ�high level ��Ч
			SetBit(FOC_CMR,CCPL,0);															// �¹ܣ�high level ��Ч		                               
		}
		#elif (PWM_Level_Mode == Low_Level)										
		{
			SetBit(FOC_CMR,CCPH,1);															// �Ϲܣ�low level ��Ч
			SetBit(FOC_CMR,CCPL,1);															// �¹ܣ�low level ��Ч
		}
		#endif
	}
	#endif
	/*Estimate Algorithm set*/
	#if (EstimateAlgorithm == SMO)					             	  // SMO
	{
		FOC_KSLIDE    = OBS_KSLIDE;
    FOC_EKLPFMIN	= OBS_EA_KS;																			                              
	}
	#elif (EstimateAlgorithm == PLL)		                    // PLL		
	{		
		FOC_KSLIDE    = OBSE_PLLKP_GAIN;
    FOC_EKLPFMIN	= OBSE_PLLKI_GAIN;																		
	}
	#endif		
	/*estimate omega mode set*/
	#if (Estimate_Omega_Mode == Sin_Theta)									// sin��PI��ʽ����Ƕ�
	{
			SetBit(FOC_CR2,ESCMS,0);														
	}
	#elif (Estimate_Omega_Mode == Arctan_Theta)							// arctan����Ƕ�
	{
			SetBit(FOC_CR2,ESCMS,1);
	}
	#endif
	
	/*valpha mode set*/
	#if (Valpha_Mode == DC_Bus_Calc)												//  Valpha��Vbeta��DC_bus����
	{
			SetBit(FOC_CR2,EIVMS,0);		
	}
	#elif (Valpha_Mode == Ipark_Calc)												//  Valpha��Vbeta��Ipark����
	{
			SetBit(FOC_CR2,EIVMS,1);
	}
	#endif	
	
	/*sample shunt resister mode set*/
	/*˫�������������Ҫ��С�������ڣ���Ϊ0�����½��ؽ���ǰ��ʼ����Ia������8009*/
	#if (Shunt_Resistor_Mode == Double_Resistor)						// double resistor sample
	{
		SetBit(FOC_CR1,CSM,1);																// ˫����
		FOC_TSMIN = 0;																				// clear min windows time
		FOC_TRGDLY = 0x8003;																	// ADC������ʱ�̣�8009Ϊ�½��ؽ���ǰ��ʼ����Ia��
		                                                      // 0001Ϊ�����ؿ�ʼʱ��ʼ�����������½��ؽ���ǰ����	
		/*double resister SVPWM 5/7 segment*/
		#if (SVPMW_Mode == SVPWM_7_Segment)
		{
			SetBit(FOC_CR2,F5SEG,0);														// 7��ʽSVPWM
		}
		#elif (SVPMW_Mode == SVPWM_5_Segment)
		{
			SetBit(FOC_CR2,F5SEG,1);														// 5��ʽSVPWM
		}
		#endif
		
		/*double resister sample period*/
		#if (DouRes_Sample_Mode == DouRes_1_Cycle)
		{
			SetBit(FOC_CR2,DSS,0);															// ˫����ģʽ��1���ڲ���
		}
		#elif (DouRes_Sample_Mode == DouRes_2_Cycle)
		{
			SetBit(FOC_CR2,DSS,1);															// ˫����ģʽ��2���ڲ���
		}
		#endif
	}
		/*�������������Ҫ��С������,FOC_TRGDLYΪ0���߶�ʽSVPWM��ʽ*/
	#elif (Shunt_Resistor_Mode == Single_Resistor)					// signel resistor sample 
	{
		SetBit(FOC_CR1,CSM,0);																// ������
		FOC_TSMIN = PWM_TS_LOAD;															// ��С��������
		FOC_TRGDLY = 0;																				// 
		SetBit(FOC_CR2,F5SEG,0);															// 7��ʽ
	}
	#endif	
	#if (CalibENDIS == Enable)	                            // ʹ�ܵ�����׼У��				
	{
		if(mcCurOffset.OffsetFlag==1)
		{
			#if (Shunt_Resistor_Mode == Double_Resistor)			// ˫����У��		
			{
				/*set ia, ib current sample offset*/
				SET(FOC_CHC,CSOC0);
				CLR(FOC_CHC,CSOC1);
				if(mcFRState.FR	== CW)
				{
					FOC_CSO = mcCurOffset.IaOffset;
				}
				else			
				{
					FOC_CSO = mcCurOffset.IbOffset;  
				}	
				SET(FOC_CHC,CSOC1);
				CLR(FOC_CHC,CSOC0);
				if(mcFRState.FR	== CW)
				{
					FOC_CSO = mcCurOffset.IbOffset;
				}
				else			
				{
					FOC_CSO = mcCurOffset.IaOffset;  
				}	
			}
			#elif (Shunt_Resistor_Mode == Single_Resistor)	  // ������У��						
			{
				/*set ibus current sample offset*/
				SET(FOC_CHC,CSOC1);
				SET(FOC_CHC,CSOC0);
				FOC_CSO = mcCurOffset.IbusOffset;	              // д��IC��ƫ��        
			}
			#endif	
		}
	}
	#elif (Shunt_Resistor_Mode == Single_Resistor)					
	{
	}
	#endif	

	
	#if (PWM_Level_Mode == High_Level)										
	{                               
	}
	#elif (PWM_Level_Mode == Low_Level)										
	{
	  /*enable FD6536 output*/
		SetBit(P1_OE, P10, 1);	// config P10 as output
		SetBit(P1_PU, P10, 0);  // enable P10 pull up
		GP10 = 1;
	}
	#endif	

}
/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Charge(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	Ԥ��磬��һֱ����Ԥ���״̬�£����ӵ������������֤IPM����Mos
/*---------------------------------------------------------------------------*/
void Motor_Charge(void)
{
     if(MotorStateTime.ChargeOneTime==0)
		 {																					
				MotorStateTime.ChargeOneTime = 1;				 
				FOC_SWDUTY = 0.7*FOC_ARR;						    // IPM 30% duty
				FOC_CR1 = 0x06;								          // FOC������ʹ�ܣ�����дPWMռ�ձ�
				Time.Charge_Count = Charge_Time;
		 }
		 if(Time.Charge_Count == Charge_Time)
		 {
			 #if (IPMState == IPMtest)	 
			 {
			   FOC_CMR |= 0x03;                         // U�����
			 }			 
			 #elif (IPMState == NormalRun)		          // ���������״̬������
			 {			 
			   FOC_CMR |= 0x01;                         // U�����ű�ͨ
			 }
			 #endif	
			 MOE = 1;																								
		 }
		 if(Time.Charge_Count == (Charge_Time<<1)/3)
		 {
			 #if (IPMState == IPMtest)	 
			 {
         FOC_CMR |= 0x0F;                         // U��V�����   
			 }			 
			 #elif (IPMState == NormalRun)		          // ���������״̬������
			 {
         FOC_CMR |= 0x05;                         // U��V�����ű۵�ͨ 
			 }  
       #endif				 
		 }
		 if(Time.Charge_Count == Charge_Time/3)
		 {
			 #if (IPMState == IPMtest)	 
			 {
         FOC_CMR |= 0x3F;                         // U��V��W����� 
	     }			 
			 #elif (IPMState == NormalRun)		          // ���������״̬������
			 {				 
			  FOC_CMR |= 0x15;                         // U��V��W�����ű۵�ͨ  
			 }  
       #endif	
		 }
}
/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Align(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	Ԥ��λ��������������ж�ʱ������Ԥ��λ�̶���ʼλ��;��������ж�ʱ������Ԥ��λɲ��
/*---------------------------------------------------------------------------*/
void Motor_Align(void)
{
	if(MotorStateTime.AlginOneTime==0)
	{
		 MotorStateTime.AlginOneTime=1;
		
			/*enable FOC register set*/	
			FOCEN		= Disable;																	// disable FOC Module
			FOC_Init();
			FOC_CMR |= 0x3F;                         // U��V��W�����  
			MOE = 1;	
			FOC_IDREF = ID_Align_CURRENT;
			FOC_IQREF = IQ_Align_CURRENT ;			
			
			FOC_EKP 	= OBSW_KP_GAIN;					
			FOC_EKI 	= OBSW_KI_GAIN;	
			
			FOC_DKP = DKP_Alignment;	
			FOC_DKI = DKI_Alignment;
			FOC_QKP = QKP_Alignment;	
			FOC_QKI = QKI_Alignment;		
			
			FOC_RTHEACC 	= 0x0000;																	// ���º����ĳ�ʼ���ٶ�
			FOC_RTHESTEP 	= 0x0000;																	// 0.62 degree acce speed

			#if (AlignTestMode)
			{
				FOC_THETA		= _Q15((float)Align_Angle/180.0); 
			}
			#else
			{
				FOC_THETA 	= _Q15((float)mcFocCtrl.mcPosCheckAngle/180.0);// alginment angle
			}
			#endif
			
//			SetBit(FOC_CR1,EFAE,0);															    // ��ֹ������ǿ�����
//			SetBit(FOC_CR1,RFAE,1);															    // ʹ��ǿ��
			
			/*sample shunt resister mode set*/
			#if (Shunt_Resistor_Mode == Double_Resistor)						// ˫����
			{
				FOC_CR1 	= 0x0D;																			// ����ж��Ѿ�ʹ��FOC����																		                            
			}
			#elif (Shunt_Resistor_Mode == Single_Resistor)					// ������
			{
				FOC_CR1 	= 0x05;																		
			}
			#endif	
			/*Estimate Algorithm set*/
			#if (EstimateAlgorithm == SMO)					             	  // SMO
			{
				SetBit(FOC_CR1,ESEL,0);																		                              
			}
			#elif (EstimateAlgorithm == PLL)		                    // PLL		
			{
				SetBit(FOC_CR1,ESEL,1);																				
			}
			#endif		    
			
  }	
}

/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Open(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	���������Ĳ�������
/*---------------------------------------------------------------------------*/
void Motor_Open(void)
{
		static uint8 OpenRampCycles;	
    if(MotorStateTime.OpenOneTime==0)
		{
			MotorStateTime.OpenOneTime=1;
			
			SetBit(FOC_CR1,FCE,1);
			SetBit(FOC_CR1,PWMSS,0);
			
			#if (PosCheckEnable)
			{
				FOC_THETA 	= _Q15((float)mcFocCtrl.mcPosCheckAngle/180.0);//�г�ʼλ�ü�⣬���ó�ʼλ�ý�
			}
			#else
			{
				FOC_THETA		= _Q15((float)Align_Angle/180.0); //�޳�ʼλ�ü�⣬����Ԥ��λ��
			}
			#endif			

			if(TailWindDetect.TailWindBrakeCount>=4)	
			{
				FOC_IDREF = ID_Start_CURRENT;                         // D����������
				mcFocCtrl.mcIqref= IQ_Start_CURRENT+I_Value(0.4);		  // Q����������	
				FOC_IQREF = mcFocCtrl.mcIqref;		                    // Q����������
			}
			else if(TailWindDetect.TailWindBrakeCount>=1)	
			{
				FOC_IDREF = ID_Start_CURRENT;                         // D����������
				mcFocCtrl.mcIqref= IQ_Start_CURRENT+I_Value(0.3);		  // Q����������	
				FOC_IQREF = mcFocCtrl.mcIqref;		                    // Q����������
			}
			else
			{
				FOC_IDREF = ID_Start_CURRENT;                         // D����������
				mcFocCtrl.mcIqref= IQ_Start_CURRENT;		              // Q����������	
				FOC_IQREF = mcFocCtrl.mcIqref;		                    // Q����������
      }
			
			FOC_DKP = DKP;	
			FOC_DKI = DKI;
			FOC_QKP = QKP;	
			FOC_QKI = QKI;	
			
			FOC_EKP 	= OBSW_KP_GAIN;					
			FOC_EKI 	= OBSW_KI_GAIN;	
					         									
			/*open mode set*/
			#if (Open_Start_Mode == Omega_Start)                  //Omega ����
			{
				FOC_EFREQACC 	= Motor_Omega_Ramp_ACC;
				FOC_EFREQMIN 	= Motor_Omega_Ramp_Min;
				FOC_EFREQHOLD = Motor_Omega_Ramp_End;	
				
				SetBit(FOC_CR1,EFAE,1);															// ������ǿ�����
				SetBit(FOC_CR1,RFAE,0);															// ��ֹǿ��
				SetBit(FOC_CR1,ANGM,1);															// ����ģʽ                             
			}
			#elif (Open_Start_Mode == Open_Start)
			{
				FOC_RTHEACC 	= MOTOR_OPEN_ACC;								// ���º����ĳ�ʼ���ٶ�
				FOC_RTHESTEP 	= Motor_Open_Ramp_Min;								// 0.62 degree acce speed
				FOC_RTHECNT 	= MOTOR_OPEN_ACC_CNT;									// acce time			
				
				SetBit(FOC_CR1,EFAE,0);															// ��ֹ������ǿ�����
				SetBit(FOC_CR1,RFAE,1);															// ʹ��ǿ��
				SetBit(FOC_CR1,ANGM,1);															// ����ģʽ
			}
			#elif (Open_Start_Mode == Open_Omega_Start)
			{
				FOC_RTHEACC 	= MOTOR_OPEN_ACC;								// ���º����ĳ�ʼ���ٶ�
				FOC_RTHESTEP 	= Motor_Open_Ramp_Min;								// 0.62 degree acce speed
				FOC_RTHECNT 	= MOTOR_OPEN_ACC_CNT;									// acce time			
				
				FOC_EFREQACC 	= Motor_Omega_Ramp_ACC;
				FOC_EFREQMIN 	= Motor_Omega_Ramp_Min;
				FOC_EFREQHOLD = Motor_Omega_Ramp_End;	
				
				SetBit(FOC_CR1,EFAE,1);															// ��ֹ������ǿ�����
				SetBit(FOC_CR1,RFAE,1);															// ʹ��ǿ��
				SetBit(FOC_CR1,ANGM,1);															// ����ģʽ
			}
			#endif
	  }	
			//OPEN״̬����ʱ�϶����
		  #if (Open_Start_Mode == Open_Start)
			{
				if(OpenRampCycles<(MOTOR_OPEN_ACC_CYCLE-1))
				{
					if(!GetBit(FOC_CR1,RFAE))
					{				
						SetBit(FOC_CR1,RFAE,1);			
						OpenRampCycles++;	
					}
				}		
				else
				{			
					Time.Count = 2;	
			    FOC_EKP = OBSW_KP_GAIN_RUN6;	                        // ���������PI��KP			
				  FOC_EKI	= OBSW_KI_GAIN_RUN6;				                  // ���������PI��KI						
					mcState = mcRun;
				}	
			}
			#elif (Open_Start_Mode == Open_Omega_Start)
			{		
					Time.Count = 2600;					
					mcState = mcRun;
			}
			#elif (Open_Start_Mode == Omega_Start) 
			{			
				Time.Count = 1600;				 
				mcState = mcRun;			
			}			
			#endif
}
/*---------------------------------------------------------------------------*/
/* Name		:	void BEMFTailWindDealwith(void)
/* Input	:	NO
/* Output	:	NO
/* Description:�з��綯�Ƶ�˳�����������ú���
/*---------------------------------------------------------------------------*/
void BEMFTailWindDealwith(void)
{
  	if((BEMFDetect.BEMFTimeCount>0)&&(BEMFDetect.BEMFTimeCount<(BEMF_START_DETECT_TIME-BEMF_START_DELAY_TIME)))				
		{
			#if (PowerOnBreakeEnable)     // �ϵ�ɲ��ʹ��
			{
				BrakeFlag=1;
				
				SetBit(CMP_CR2, CMP0EN, 0);// ��Ϊ˳��������
				SetBit(CMP_CR2, CMP1EN, 0);
				SetBit(CMP_CR2, CMP2EN, 0);	
				
				FOC_SWDUTY                      = FOC_ARR;   
				FOC_CR1                         = 0x02;	 					
				FOC_CMR |= 0x3F;  
				MOE = 1;   

				Time.TailWind_Count											= 2400;	
				
				BEMFDetect.BEMFSpeedInitStatus  = 0;
				
				MotorStateTime.TailWindOneTime 	= 0;
			}	
      #elif (!PowerOnBreakeEnable)
			{
				BrakeFlag=0;
				
				if(BEMFDetect.FRStatus == mcFRState.FR)                    //˳���ķ�����趨�ķ�����ͬ
				{
					if(BEMFcount4++ >= 10)
					{
						BEMFcount4 =10;
						//�����趨ת��ʱֱ������
						if(BEMFDetect.BEMFSpeed > BEMFMotorStartSpeed)
						{
								if(BEMFcount1++ >= 10)
								{
									BEMFcount1 = 0;
									BEMFcount4 = 0;
									BEMFDetect.BEMFStartStatus = 1;
								}
						}else
						{
							BEMFcount1 = 0;
						}
						if(BEMFDetect.BEMFSpeed <= BEMFMotorStartSpeed)
						{
								if(BEMFcount2++ >= 10)
								{
									BEMFcount2 = 0;	

                  BrakeFlag = 1;
									
									SetBit(CMP_CR2, CMP0EN, 0);                        //��Ϊ˳��������
									SetBit(CMP_CR2, CMP1EN, 0);
									SetBit(CMP_CR2, CMP2EN, 0);		
									
									FOC_SWDUTY                      = FOC_ARR;   
									FOC_CR1                         = 0x02;	 					
									FOC_CMR |= 0x3F;  
									MOE = 1;   
									/***����ת��ɲ�����趨Time.CountΪɲ��ʱ��***/				
									if(BEMFDetect.BEMFSpeed <= _Q15(500.0/MOTOR_SPEED_BASE))
									{
										Time.TailWind_Count											= 300;	
									}else
									{
										Time.TailWind_Count											= 500;
									}
									
									BEMFDetect.BEMFSpeedInitStatus = 0;

									MotorStateTime.TailWindOneTime = 0;
								}					
						}else
						{
							BEMFcount2 = 0;
						}
				  }
				}else
				{
					BEMFcount1 = 0;
					BEMFcount2 = 0;
					BEMFcount4 = 0;
				}
				if(BEMFDetect.FRStatus != mcFRState.FR)
				{
					if(BEMFcount3++ >= 10)
					{
						BEMFcount3 = 0;
						SetBit(CMP_CR2, CMP0EN, 0);                            //��Ϊ˳��������
						SetBit(CMP_CR2, CMP1EN, 0);
						SetBit(CMP_CR2, CMP2EN, 0);	
						
						FOC_SWDUTY                      = FOC_ARR;   
						FOC_CR1                         = 0x02;	 					
						FOC_CMR |= 0x3F;  
						MOE = 1;   
						
						//����ת��ɲ�����趨Time.CountΪɲ��ʱ��
						if(BEMFDetect.BEMFSpeed > _Q15(560.0/MOTOR_SPEED_BASE))
						{
							Time.TailWind_Count											= 1200;	
						}
						else if(BEMFDetect.BEMFSpeed > _Q15(440.0/MOTOR_SPEED_BASE))
						{
							Time.TailWind_Count											= 800;	
						}
						else if(BEMFDetect.BEMFSpeed > _Q15(320.0/MOTOR_SPEED_BASE))
						{
							Time.TailWind_Count											= 600;	
						}
						else 
						{
							Time.TailWind_Count											= 400;	
						}			
						
						BEMFDetect.BEMFSpeedInitStatus  = 0;
						
						MotorStateTime.TailWindOneTime 	= 0;						
				}
			}else
			{
				BEMFcount3 = 0;
			}
		}	
		#endif
	}else if(BEMFDetect.BEMFTimeCount==0)                              //���ʱ�䵽�˻�û����˳���״̬�����½���˳�����
	{
			Time.TailWind_Count											= 0;	
						
		  BEMFDetect.BEMFSpeedInitStatus = 0;
		
			MotorStateTime.TailWindOneTime 	= 0;
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Align(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	˳�����������ú���
/*---------------------------------------------------------------------------*/
void TailWindDealwith(void)
{
		   // ��ת��ת�ټ������ʱ�����������򵱼����������1-3��3-1��������2��˵����ǰ�����ֹ
				if(((TailWindDetect.MotorDir == CW)&&(TailWindDetect.SpeedOverFlowStatus))||(TailWindDetect.TimerClearTimes>=3))
				{
					mcState 												= mcPosiCheck;
					MotorStateTime.PosiCheckOneTime	= 0;
				}
				else if(TailWindDetect.MotorDir == CCW)
				{
					//����ɲ��MinBrakeTimes����ת�ٵ���BrakeStartSpeedʱǿ�ƿ�������
					
						FOC_SWDUTY                      = FOC_ARR+1;   
						FOC_CR1                         = 0x06;	 				// enable break function			
						//���ݲ�ͬ�ٶ�����ɲ��ʱ��
						if(TailWindDetect.TailWindSpeed<30)//rpm/min
						{
							Time.TailWind_Count											= 2000;	
						}
						else if(TailWindDetect.TailWindSpeed<80)
						{
							Time.TailWind_Count											= 2500;	
						}
						else if(TailWindDetect.TailWindSpeed<200)
						{
							Time.TailWind_Count											= 3500;	
						}else if(TailWindDetect.TailWindSpeed<300)
						{
							Time.TailWind_Count											= 4000;	
						}
						else
						{
							Time.TailWind_Count											= 5000;	
						}
						
						TailWindDetect.TailWindBrakeCount ++;							//ɲ�������ۼ�	
            if((TailWindDetect.TailWindBrakeCount>=4)&&(TailWindDetect.TailWindSpeed<100))	
						{	
							mcState 												= mcPosiCheck;
							MotorStateTime.PosiCheckOneTime	= 0;	
					 						
						}
						else if(TailWindDetect.TailWindBrakeCount>6)
						{
							 mcFaultSource=FaultOverwind;
					     mcState = mcFault;					
					     FaultProcess();		
            }
					  MotorStateTime.TailWindOneTime 	= 0;
				}
				else if(TailWindDetect.MotorDir == CW)//��ת�����ٶȴ���һ���������������ж϶�����
				{	
					//����������TailWindDetect.SpeedStoreNum��ת��TailWindStartMinSpeed����ʱֱ��˳������
					if((TailWindDetect.TailWindSpeed >TailWindStartMinSpeed)&&(TailWindDetect.SpeedStoreNum > 3))
					{
            		
						FOCCloseLoopStart();		
				  							
					}
				}
	
}
/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Align(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	˳�����������ú���
/*---------------------------------------------------------------------------*/
void Motor_TailWind(void)
{
	if(MotorStateTime.TailWindOneTime ==0)
	{	
		MotorStateTime.TailWindOneTime=1;
		
		TailWindParInit();
		
		FOCEN		= Disable;																	  // FOCģ���ȹرպ����³�ʼ��
		FOC_Init();
		
		FOC_CMR |= 0x3F;                                      // U��V��W�����  
		MOE = 1;			
		
		FOC_IDREF = 0;                                        // D���������
		FOC_IQREF = 0;                                        // Q���������
	
		FOC_DKP = DKP_TailWind;	                              // D��KP
		FOC_DKI = DKI_TailWind;                               // D��KI
		FOC_QKP = QKP_TailWind;	                              // Q��KP
		FOC_QKI = QKI_TailWind;	                              // Q��KI
		
    FOC_OMEKLPF = SPEED_KLPF_WIND;	                      // ����������ٶȼ���ĵ�ͨ�˲�ֵ
		
		FOC_EKP = OBSW_KP_GAIN_WIND;	                        // ���������PI��KP			
	  FOC_EKI	= OBSW_KI_GAIN_WIND;				                  // ���������PI��KI	
	
		FOC_CR2 |= 0x80;							                        //  ʹ�������
	
		/*sample shunt resister mode set*/
		#if (Shunt_Resistor_Mode == Double_Resistor)					
		{
			FOC_CR1 	= 0x0D;				                            // ʹ��˫���裬FOC������������FOC															                             
		}
		#elif (Shunt_Resistor_Mode == Single_Resistor)					
		{
			FOC_CR1 	= 0x05;						                        // ʹ�ܵ����裬FOC������������FOC															
		}
		#endif	
		
		/*Estimate Algorithm set*/
		#if (EstimateAlgorithm == SMO)					             	  // SMO
		{
			SetBit(FOC_CR1,ESEL,0);																		                              
		}
		#elif (EstimateAlgorithm == PLL)		                    // PLL		
		{
			SetBit(FOC_CR1,ESEL,1);	
			FOC_KSLIDE    = OBSE_PLLKP_GAIN;
			FOC_EKLPFMIN	= OBSE_PLLKI_GAIN;						

		}
		#endif	
	}	

}
/*---------------------------------------------------------------------------*/
/* Name		:	void MC_Stop(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	inital motor control parameter
/*---------------------------------------------------------------------------*/
void MC_Stop(void)
{
  FOC_SET0 &= 0x7F;																							// disable FOC and clear all register
	FOC_CR1 = 0x00;																					// disable FOC output and initial register
	mcState = mcInit;
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void MotorControlInit(void)
	Description   :	���Ʊ�����ʼ������,�������������ĳ�ʼ�������״̬��ʼ��
	Input         :	����˵������ϸ��
  Output				:	���˵������ϸ��
-------------------------------------------------------------------------------------------------*/
void MotorcontrolInit(void)
{
/***********����******************/
/*****��ѹ����*****/
	mcFaultDect.mcOverVoltDetecFaultCount  = 0;
	mcFaultDect.mcUnderVoltDetecFaultCount = 0;
	mcFaultDect.mcVoltRecoverCount      = 0;
	
/*******��������*****************/	
	mcFaultDect.Abs_ia				          = 0;
	mcFaultDect.Abs_ib				          = 0;
	mcFaultDect.Abs_ic			            = 0;
	mcFaultDect.OverCurrentValue        = OverSoftCurrentValue;
	mcFaultDect.OverCurCnt              = 0;  
	mcFaultDect.currenttime             = 0;
	mcFaultDect.CurrentRecoverCnt       = 0;

/*******��������*****************/		
	mcFaultDect.SecondStart             = 0;
	mcFaultDect.mcStartDelay            = 0;	
	mcFaultDect.mcStartCnt              = 0;	
	mcFaultDect.mcStartFocmode          = 0;
	mcFaultDect.mcStartSpeedCnt         = 0;
	mcFaultDect.mcStartEsCnt            = 0;
	mcFaultDect.mcStartRecover          =400;
	mcFaultDect.mcStartCount            =0;

/******��ת����*********/	
	mcFaultDect.mcStallCount            = 0;	
	mcFaultDect.mcStallRecover          = 400;//5s
	mcFaultDect.mcStallTimes            = 0;	
	mcFaultDect.mcStallDelaDectEs       = 0;
	mcFaultDect.mcStallDeSpeed          = 0;
	mcFaultDect.mcStallDelaDectSpd      = 0;
	mcFaultDect.mcStallDeCurrent        = 0;
	mcFaultDect.StallCurrentVale        = StallCurrentValue1;
	mcFaultDect.StallFlag               = 0;
	mcFaultDect.StallRecoverCurrent     = 3000;//��ת�����ָ�ֵ
	mcFaultDect.mcEsValue               = 0;	

/*******ȱ�ౣ��*****************/		
	mcFaultDect.LphaseDelayCount        = 0;
	mcFaultDect.Lphasecnt               = 0;
	mcFaultDect.LowCurrent              = I_Value(0.03);//ȱ������ж�����(�͵�������)
	mcFaultDect.NomCurrent              = I_Value(0.08);;//ȱ������ж�����(�ߵ�������)
	mcFaultDect.Max_ia                  = 0;
	mcFaultDect.Max_ia                  = 0;
	mcFaultDect.Max_ia                  = 0;
	mcFaultDect.AOpencnt                = 0;
	mcFaultDect.BOpencnt                = 0;
	mcFaultDect.COpencnt                = 0;
	mcFaultDect.mcLossPHCount           = 0;	
	mcFaultDect.mcLossPHTimes           = 0;
	
/*****��״̬������ʼ��******/	
	MotorStateTime.ChargeOneTime       = 0;
	MotorStateTime.AlginOneTime        = 0;
	MotorStateTime.TailWindOneTime     = 0;
	MotorStateTime.OpenOneTime         = 0;	

/*****�ⲿ���ƻ�*******/
  mcFocCtrl.CtrlMode                 = 0;
	mcFocCtrl.SpeedLoopTime            = 0;
	mcFocCtrl.PowerLoopTime            = 0;
	mcFocCtrl.RunCurrent               = 0;
	mcFocCtrl.mcIqref                  = 0;
	mcFocCtrl.TorqueLoopTime           = 0;
	mcFocCtrl.CurrentPower             = 0;
	mcFocCtrl.McuRef                   = 0;
	mcFocCtrl.Powerlpf                 = 0;


/******ADC�����˲�ֵ*********/
	AdcSampleValue.ADCDcbus            = 0;  
	AdcSampleValue.ADCSpeed            = 0;  
	AdcSampleValue.ADCVref             = 0;	
	
/******ĸ�ߵ�ѹ�˲�ֵ*******/
  mcDcbusFlt	                       = 0;
	
/******�ֶδ����ı���*******/	
	segmentstate                       = 0;

/******״̬����������******/	
	Time.Charge_Count                  = 0;
  Time.TailWind_Count                = 0;
  Time.Break_Count                   = 0;
	Time.Stop_Count                    = 0;
	Time.Count                         = 0;
	Time.RD_Count_Delay                =0;
	
/******����ƫ��У׼����*****/		
	mcCurOffset.IaOffsetSum            = 16383;
	mcCurOffset.IaOffset               = 0;
	mcCurOffset.IbOffsetSum            = 16383;
	mcCurOffset.IbOffset               = 0;
	mcCurOffset.IbusOffsetSum          = 16383;
	mcCurOffset.IbusOffset             = 0;
	mcCurOffset.OffsetCount            = 0;
	mcCurOffset.OffsetFlag             = 0;
	mcCurOffset.OffsetTimes            = Calib_Time;
	
	/*****LED����Ӧ***/	
	mcLedDisplay.LedCount             = 0;
	mcLedDisplay.LedTimCot            = 0;
	mcLedDisplay.Count                = 0;
	mcLedDisplay.Counttime            = 4999;	
	
	/*****�ٶȻ�����Ӧ***/	
	mcSpeedRamp.TargetValue           = 0;
	mcSpeedRamp.ActualValue           = 0;
	mcSpeedRamp.IncValue              = 60;
	mcSpeedRamp.DecValue              = 60;
	mcSpeedRamp.DelayCount            = 0;
	mcSpeedRamp.DelayPeriod           = 2;

  /*****ͨ��***/
	CommuteValue.Read											 = 0;
	CommuteValue.Sum											 = 0;
	CommuteValue.RealValue								 = 0;
	/**���յ�����**/	
	Uart.R_DATA[0]                     = 0;
	Uart.R_DATA[1]                     = 0;
	Uart.R_DATA[2]                     = 0;
	Uart.R_DATA[3]                     = 0;
  Uart.R_DATA[4]                     = 0;	
  Uart.R_DATA[5]                     = 0;
	Uart.R_DATA[6]                     = 0;
  Uart.R_DATA[7]                     = 0;
  Uart.R_DATA[8]                     = 0;	
  Uart.R_DATA[9]                     = 0;
	
	/**���͵�����******/
  Uart.T_DATA[0]                     = 0;
	Uart.T_DATA[1]                     = 0;
  Uart.T_DATA[2]                     = 0;
  Uart.T_DATA[3]                     = 0;
  Uart.T_DATA[4]                     = 0;	
  Uart.T_DATA[5]                     = 0;
	Uart.T_DATA[6]                     = 0;
  Uart.T_DATA[7]                     = 0;
  Uart.T_DATA[8]                     = 0;	
  Uart.T_DATA[9]                     = 0;
	
	Uart.Uredata                       = 0;
  Uart.UARxCnt                       = 0;
  Uart.RxFSM                         = 0;
  Uart.UsaRxLen                      = 0;
  Uart.flagUsaRxComm                 = 0;
  Uart.CheckDate                     = 0;
	Uart.ResponceCount                 = 0;
	Uart.ResponceFlag                  = 0;
	Uart.UsaTxlen                      = 0;
	Uart.SendCnt                       = 0;

  /**˯��ģʽ***/
	MotorSleepFlag                     = 0; 
	MotorSleepDelayCout                = 0;
	Sleep_En                           = 1;
	
	/***PWM����****/
	mcPwmInput.PWMFlag                 = 0;
	mcPwmInput.PWMCount                = 0;
			
  /*****˳����ж�*******/		
	TailWindDetect.TailWindBrakeCount  = 0;	
	TailWindDetect.AntiFlag            = 0;			
	mcFRState.FlagFR = 0;
	mcFRState.FRStatus = 0;	

	Time.RD_Count1                      = 0;
	
	Time.RD_Count2                      = 0;

	Time.RD_Count3                      = 0;
	
	Time.RD_Count4                      = 0;
	
	Time.Stall_Count                    = 0;
	
  Time.Stall_Recover_Count            = 0;
}

/*---------------------------------------------------------------------------*/
/* Name		:	void VariablesPreInit(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	��ʼ���������
/*---------------------------------------------------------------------------*/
void VariablesPreInit(void)
{
	/***********����******************/
	mcFaultSource = 0;
	
  /*****��ѹ����*****/
	mcFaultDect.mcOverVoltDetecFaultCount  = 0;
	mcFaultDect.mcUnderVoltDetecFaultCount = 0;
	mcFaultDect.mcVoltRecoverCount      = 0;

/*******��������*****************/	
	mcFaultDect.Abs_ia				          = 0;
	mcFaultDect.Abs_ib				          = 0;
	mcFaultDect.Abs_ic			            = 0;
	mcFaultDect.OverCurrentValue        = OverSoftCurrentValue;
	mcFaultDect.OverCurCnt              = 0;  
	mcFaultDect.currenttime             = 0;
  mcFaultDect.CurrentRecoverCnt       = 0;
	
/******��ת����*********/	
	mcFaultDect.mcStallCount            = 0;	
	mcFaultDect.mcStallRecover          = 400;//5s
	mcFaultDect.mcStallDelaDectEs       = 0;
	mcFaultDect.mcStallDeSpeed          = 0;
	mcFaultDect.mcStallDelaDectSpd      = 0;
	mcFaultDect.mcStallDeCurrent        = 0;
	mcFaultDect.StallCurrentVale        = StallCurrentValue1;
	mcFaultDect.StallFlag               = 0;
	mcFaultDect.StallRecoverCurrent     = 2090;
	mcFaultDect.mcEsValue               = 0;
	
/*******��������*****************/		
	mcFaultDect.mcStartDelay            = 0;	
	mcFaultDect.mcStartCnt              = 0;	
	mcFaultDect.mcStartFocmode          = 0;
	mcFaultDect.mcStartSpeedCnt         = 0;
	mcFaultDect.mcStartEsCnt            = 0;
  mcFaultDect.mcStartRecover          =400;
	mcFaultDect.mcStartCount            =0;	
/******ȱ�ౣ��*********/	
	mcFaultDect.LphaseDelayCount        = 0;
	mcFaultDect.Lphasecnt               = 0;
	mcFaultDect.LowCurrent              = I_Value(0.03);//ȱ������ж�����(�͵�������)
	mcFaultDect.NomCurrent              = I_Value(0.08);;//ȱ������ж�����(�ߵ�������)
	mcFaultDect.Max_ia                  = 0;
	mcFaultDect.Max_ib                  = 0;
	mcFaultDect.Max_ic                  = 0;
	mcFaultDect.AOpencnt                = 0;
	mcFaultDect.BOpencnt                = 0;
	mcFaultDect.COpencnt                = 0;
	mcFaultDect.mcLossPHCount           = 0;	
//	mcFaultDect.mcLossPHTimes           = 0;
	
	mcFaultDect.Thermal                 =0;
	mcFaultDect.mcThermalCount          =0;
  mcFaultDect.ThermalRecoverCount     =0;
  mcFaultDect.ThermalRecover          =20;
	mcFaultDect.OverThermalCount        =20;
	mcFaultDect.ThermalLimitValue       =OVER_Temperature;
	mcFaultDect.ThermalRecoverValue     =UNDER_Temperature;
	

/*****�ⲿ���ƻ�*******/
  mcFocCtrl.CtrlMode                 = 0;
	mcFocCtrl.SpeedLoopTime            = 0;
	mcFocCtrl.PowerLoopTime            = 0;
	mcFocCtrl.RunCurrent               = 0;
	mcFocCtrl.mcIqref                  = 0;	
	mcFocCtrl.TorqueLoopTime           = 0;
	mcFocCtrl.CurrentPower             = 0;
	
/*****˳����ж�*******/
	TailWindDetect.AntiFlag            = 0;		
	TailWindDetect.TailWindBrakeCount  = 0;
	
/*****���״̬��ʱ�����***********/	
	MotorStateTime.ChargeOneTime       = 0;
	MotorStateTime.AlginOneTime        = 0;
	MotorStateTime.TailWindOneTime     = 0;
	MotorStateTime.OpenOneTime         = 0;

	mcSpeedFlt												 = 0;
	
  BEMF_DETECT_FLAG=0;
  BEMF_DETECT_TIME=0;
	
	Time.LowSpeedBreak_Count           = 1000;
	
	mcSpeedRamp.IncValue               = 100;

	FG_Flag0                           =0;
	FG_Flag1                           =1;
	FG_Flag2                           =0;
	FG_Flag3                           =0;
	
	FG_Enable                          =0;
	
	BrakeFlag                          =0;
	
	Time.RD_Count1                     = 0;
	
	Time.RD_Count2                     = 0;

	Time.RD_Count3                     = 0;
	
	Time.RD_Count4                     = 0;
	
	Time.RunStareCount                 = 0;
	
	#if (PosCheckEnable)//��ʼλ�ü��ʹ��
	{	
			//��ʼλ�ü�����������ʼ��
		PosCheckPWMVar.PWMONTimeUp 				 = PWM_ON_Time_Up;
		PosCheckPWMVar.PWMONTimeDown 			 = PWM_ON_Time_Down;	
		PosCheckPWMVar.PWMOFFTimeInput 		 = PWM_OFF_Time_Input;
		PosCheckPWMVar.PWMBrakeTimeInput 	 = PWM_Brake_Time_Input;
		PosCheckPWMVar.PWMLOADInput        = PWM_VALUE_LOAD;
		PosCheckPWMVar.PWMONDutyInput 		 = (PWM_VALUE_LOAD*(1-(PWM_Duty)));
		PosCheckPWMVar.PWMOFFDutyInput 		 = (PWM_VALUE_LOAD*(PWM_Duty));		
	
		//���ݲ�ͬ��ѹ������ʼλ�ü������ռ�ձ�
//		if(mcDcbusFlt < _Q15(183.0/HW_BOARD_VOLT_MAX_Actual))		//130*1.414
//		{	
//			PosCheckPWMVar.PWMONDutyInput 			 = (PWM_VALUE_LOAD*(1-(PWM_Duty+0.16)));
//			PosCheckPWMVar.PWMOFFDutyInput 			 = (PWM_VALUE_LOAD*(PWM_Duty+0.16));					
//		}
//		else if(mcDcbusFlt < _Q15(254.0/HW_BOARD_VOLT_MAX_Actual))	//180*1.414
//		{
//			PosCheckPWMVar.PWMONDutyInput 			 = (PWM_VALUE_LOAD*(1-(PWM_Duty+0.08)));
//			PosCheckPWMVar.PWMOFFDutyInput 			 = (PWM_VALUE_LOAD*(PWM_Duty+0.08));		
//		}
//		else
//		{
//			PosCheckPWMVar.PWMONDutyInput 			 = (PWM_VALUE_LOAD*(1-(PWM_Duty)));
//			PosCheckPWMVar.PWMOFFDutyInput 			 = (PWM_VALUE_LOAD*(PWM_Duty));					
//		}		
	}
	#endif
}

#endif