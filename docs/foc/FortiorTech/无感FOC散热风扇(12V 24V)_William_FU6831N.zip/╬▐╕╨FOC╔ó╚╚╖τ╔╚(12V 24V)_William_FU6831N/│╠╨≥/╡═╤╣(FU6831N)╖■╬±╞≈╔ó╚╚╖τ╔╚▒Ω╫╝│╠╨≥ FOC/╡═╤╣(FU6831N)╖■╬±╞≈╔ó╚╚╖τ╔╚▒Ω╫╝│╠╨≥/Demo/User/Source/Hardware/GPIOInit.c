/**************************** (C) COPYRIGHT 2015 Fortiortech shenzhen *****************************
* File Name          : GPIOInit.c
* Author             : Fortiortech  Market Dept
* Version            : V1.0
* Date               : 01/07/2015
* Description        : This file contains GPIO initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/ 

/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>


/*-------------------------------------------------------------------------------------------------
	Function Name :	void GPIO_Init(void)
	Description   :	GPIO��ʼ������,�ɽ�I/O�����ó���������ģʽ���������ǲ�������ģ����������������
	Input         :	��
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void GPIO_Init(void)
{
	#if (RDEnable)
	{
		SetBit(P0_OE, P01, 1);  // config P01 as output,0 as input,1 as output
		SetBit(P0_PU, P01, 1);  // enable P01 pull up,0 as disable,1 as enable	
		SetRDPin;
	}
	#endif
	
	#if (FGEnable)
	{
		SetBit(P0_OE, P01, 1);  // config P01 as output,0 as input,1 as output
		SetBit(P0_PU, P01, 1);  // enable P01 pull up,0 as disable,1 as enable	
		ResetFGPin;
	}
	#endif
	
	SetBit(P1_OE, P11, 0);  // config P11 as input,0 as input,1 as output
	SetBit(P1_PU, P11, 0);
}

