/**
  ******************************************************************************
  * @file    FocControl.h 
  * @author  Fortior Application Team
  * @version V1.0.0
  * @date    05/06/2014
  * @brief   define motor contorl parameter
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __FocControl_H_
#define __FocControl_H_


/* Exported types -------------------------------------------------------------------------------*/

typedef enum
{
		mcInit 			= 0,
		mcCharge 		= 1,
		mcTailWind 	= 2,
		mcAlign 		= 3,
		mcStart 		= 4,
		mcRun 			= 5,	
		mcStop 			= 6,
		mcFault 		= 7,
	  mcwait      = 8,
	  mcPosiCheck = 9,
	  mcBrake     =10
}MotStaType;

typedef struct
{
	uint16  TailWind_Count;
	uint16  Charge_Count;
	uint16  Break_Count;
	uint16  LowSpeedBreak_Count;
	uint16	Count;
	int32   Stop_Count;
	uint16  Stall_Count;
	uint16  Stall_Recover_Count;
	uint16  RunStareCount;
	uint16  RD_Count1;
	uint16  RD_Count2;
	
	uint16  RD_Count3;
	uint16  RD_Count4;
	
	uint16  RD_Count_Delay;
}TimeCnt;

typedef struct
{
	uint8 	ChargeOneTime;
	uint8 	AlginOneTime;	
	uint8 	TailWindOneTime;	
	uint8   OpenOneTime;
	uint8   PosiCheckOneTime;
	uint8	  mcSecAlignFlag;
}MotStaTim;

typedef struct
{
	int16 	IaOffset;
	int32   IaOffsetSum;
	int16 	IbOffset;
	int32   IbOffsetSum;
	int16 	IbusOffset;
  int32   IbusOffsetSum;
	int16   OffsetCount;
	int16   OffsetTimes;
	int16   OffsetFlag;
}CurrentOffset;

/* Exported variables ---------------------------------------------------------------------------*/
extern MotStaType mcState;
extern TimeCnt Time;	
extern MotStaTim  MotorStateTime;
extern CurrentOffset mcCurOffset;
/* Exported functions ---------------------------------------------------------------------------*/
extern void MC_Control(void);
extern void MotorcontrolInit(void);
extern void McTailWindDealwith(void);
extern void GetCurrentOffset(void);
extern void TailWindDealwith(void);

#endif
