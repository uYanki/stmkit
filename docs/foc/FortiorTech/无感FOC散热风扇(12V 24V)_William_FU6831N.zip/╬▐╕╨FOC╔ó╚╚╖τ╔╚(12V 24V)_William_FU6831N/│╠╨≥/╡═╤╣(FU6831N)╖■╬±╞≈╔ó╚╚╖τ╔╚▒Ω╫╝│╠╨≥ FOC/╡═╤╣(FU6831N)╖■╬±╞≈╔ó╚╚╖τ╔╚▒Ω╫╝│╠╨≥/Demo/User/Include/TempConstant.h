/**************************** (C) COPYRIGHT 2015 Fortiortech shenzhen *****************************
* File Name          : TempConstant.h
* Author             : Fortiortech  Market Dept
* Version            : V1.0
* Date               : 01/07/2015
* Description        : This file contains all the temp constant calculate used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/ 

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __TEMPCONSTANT_H_
#define __TEMPCONSTANT_H_


#endif