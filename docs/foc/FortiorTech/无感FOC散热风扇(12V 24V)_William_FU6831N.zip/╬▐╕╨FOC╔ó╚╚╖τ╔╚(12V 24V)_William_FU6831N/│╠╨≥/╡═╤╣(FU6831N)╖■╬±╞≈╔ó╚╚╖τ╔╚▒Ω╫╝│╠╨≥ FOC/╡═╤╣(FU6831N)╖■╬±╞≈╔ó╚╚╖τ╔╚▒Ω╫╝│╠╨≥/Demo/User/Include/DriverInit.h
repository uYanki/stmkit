#ifndef __PREDRIVERINIT_H_
#define __PREDRIVERINIT_H_


extern void Driver_Init(void);


#endif