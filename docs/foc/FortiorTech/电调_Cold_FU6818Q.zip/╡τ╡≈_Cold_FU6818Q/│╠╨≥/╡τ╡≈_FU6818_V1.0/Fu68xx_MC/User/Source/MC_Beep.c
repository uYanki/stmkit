
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>

uc8 BeepNote[7] = {229,204,182,171,153,136,121};
Beep_TypeDef xdata Beep;
void BeepRequestFun(u8 mold);
void Beepperform(void);
void BeepResponse(void);

void BeepTone(u8 tBeepNote,u8 tPhase,float tvolume,u16 time)
{
  u16 i;
  #if(BEEPSCAN_EN)
  EA = 0;

  tBeepNote = BeepNote[tBeepNote]*tvolume*BEEP_VOL;
  for(i=0; i< time;i++)
  {
    //if(tPhase == 1)
    {
      PWM_UHVL_ON;
      Delay(tBeepNote);
      PWMOUT_OFF;
      Delay(tBeepNote*3);
      PWM_VHUL_ON;
      Delay(tBeepNote);
      PWMOUT_OFF;
      Delay(tBeepNote*3);
    }
//    if(tPhase == 2)
//    {
//      PWM_VHWL_ON;
//      Delay(tBeepNote);
//      PWMOUT_OFF;
//      Delay(tBeepNote*3);
//      PWM_WHVL_ON;
//      Delay(tBeepNote);
//      PWMOUT_OFF;
//      Delay(tBeepNote*3);    
//    } 
//    if(tPhase == 3)
//    {
//      PWM_UHWL_ON;
//      Delay(tBeepNote);
//      PWMOUT_OFF;
//      Delay(tBeepNote*3);
//      PWM_WHUL_ON;
//      Delay(tBeepNote);
//      PWMOUT_OFF;
//      Delay(tBeepNote*3);    
//    }
  }
  EA = 1;
  #endif
}

void Beepperform(void)
{
  u8 i;

  for(i=1; i<= 3;i++)
  {
    BeepTone(i,1,0.4,500);
    EA = 0;
    gDelayms(30);
    EA = 1;
  }

  EA = 0;
  gDelayms(160);
  EA = 1;
  Beep.BeepType = BeepDone;
}

void BeepResponse(void)
{
  #if(BEEPSCAN_EN)
  if(Beep.BeepRequest == 0x7F)
  {
    switch(Beep.BeepType)
    {
      case PWMINAline:
        BeepTone(1,1,0.3,1000);
        EA = 0;
        gDelayms(80);
        EA = 1;
        BeepTone(1,1,0.3,1000);
        PWMINCtl.FlagPWMAline = 0xFF;
        Beep.BeepRequest = 0xFF;
      break;
      case PWMINReady:
        BeepTone(1,1,0.3,1500);
        Beep.BeepRequest = 0xFF;
        PWMINCtl.FlagPwmIn = 0xFF;
      break;
      case PWMINError:
        BeepTone(1,1,0.2,1000);
        EA = 0;
        gDelayms(328);
        EA = 1;
      break;
      case PWMINinit:
        Beepperform();
        Beep.BeepRequest = 0xFF;
        break; 
      case BeepDone:
        Beep.BeepRequest = 0xFF;
        break;      
      default:
        Beep.BeepRequest = 0xFF;
        break;
    }
  }
  Beep.BeepRequest = 0xFF;
  #else
  PWMINCtl.FlagPwmIn = 0xFF;
  #endif
}

void BeepRequestFun(u8 mold)
{ 
  if(Beep.BeepRequest == 0xFF)
  {
    Beep.BeepRequest = 0x7F;
    Beep.BeepType = mold;
    if(Beep.BeepType == PWMINAline)
    {
      PWMINCtl.FlagPWMAline = 0x7F;
    }
  }
}