
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>

/* Private typedef ------------------------------------------------------------------------------*/
/* Private define -------------------------------------------------------------------------------*/
/* Private macro --------------------------------------------------------------------------------*/
/* Private variables ----------------------------------------------------------------------------*/
PWMINCtl_TypeDef xdata PWMINCtl;
u8 xdata PwmInResetFlag;
u8 xdata tPWMINTim3ITconter;                 //tim3 ���������
u8 xdata tPWMINOutRangeCounter;              //���ſ��ȴ��������
u16 xdata tPWMINErrCotnter;  
float xdata PWMARR  ; 
u16 SpeedSrefpre;
u16 a;
/* Private function prototypes ------------------------------------------------------------------*/
void PWMINOnOffSwitch(void);
/* Private functions ----------------------------------------------------------------------------*/
extern float xdata PWMARR  ; 
/*-------------------------------------------------------------------------------------------------
Function Name :	void PWMIN_Init(void)
Description   :	PWM��������ʼ��
Input         :	��
Output				:	��
-------------------------------------------------------------------------------------------------*/
void PWMINInit(void)
{
  float tfAlineA;
  #if(PWMINSREF_EN)
  PWMINCtl.FlagPWMAline = 0x7F;
  #if(BEEPSCAN_EN)
  PWMINCtl.FlagPwmIn = 0xF1;
  #else
  PWMINCtl.FlagPwmIn = 0xFF;
  #endif
  
  PWMINCtl.PWMStatus  = 0;  PWMINCtl.PWMINBreakCnt = 0;
  PWMINCtl.PWMINHigh = 0;
  PWMINCtl.PWMINHighMin = 0;
  PWMINCtl.PWMINHighMax = 0;
  
  MDUControl.SpeedSrefErr = 32767;

  tfAlineA= ((float)(SPEED_REF_MAX-SPEED_REF_MIN)/(MDUControl.SpeedSrefErr));
  MDUControl.AlineA = (u16)(tfAlineA*32767);                        //ϵ�� a
  MDUControl.AlineB = (SPEED_REF_MAX - 32767*tfAlineA);             //ϵ�� b  
#endif
}

/*-------------------------------------------------------------------------------------------------
Function Name :	void PWMScan(void)
Description   : //670 ~ 1559
Input         :	��
Output				:	��
-------------------------------------------------------------------------------------------------*/
void PWMScan(void)
{
  u32 Temp32A,Temp32B;
  u16 tPWMINHigh;
  u16 tValue;
  
  if(GetBit(TIM3_CR1, T3IR))
  {    
    tPWMINTim3ITconter = 0;
    //�ٶȸ������ۻ�_IQ(15) 0~32767
    #if(PWMINSREF_EN)
    if(PWMINCtl.PWMStatus == 0)    //���ſ���ʶ��125us or 1000us 
    {
      if(Ctl.State == MOTOR_STOP)
      {
        if((TIM3_DR > TempPWMINHighMinFiltA)&&(TIM3_DR < TempPWMINHighMaxFiltA))
        {
          PWMINCtl.PWMINSelfCheck--;
        }
        else if((TIM3_DR > TempPWMINHighMinFiltB)&&(TIM3_DR < TempPWMINHighMaxFiltB))
        {
          PWMINCtl.PWMINSelfCheck++;
        }

        if(PWMINCtl.PWMINSelfCheck >= 3)
        {
          PWMINCtl.PWMINSelfCheck = 3;
          PWMINCtl.PWMStatus = 0x7F;
        }
        else if(PWMINCtl.PWMINSelfCheck <= -3)
        {
          PWMINCtl.PWMINSelfCheck = -3;
          PWMINCtl.PWMStatus = 0xFF;
        }
      }
    }

    if(PWMINCtl.PWMStatus == 0x7F)
    {
      tValue = TIM3_DR<<3;
    }
    else
    {
      tValue = TIM3_DR;
    }
    
    if((tValue > TempPWMINHighMinFilt)&&(tValue < TempPWMINHighMaxFilt))  //PPM ������������Χ��
    {
      tPWMINOutRangeCounter = 0;
      tPWMINErrCotnter = 0;       //���Żָ���������
      
      PWMINCtl.PWMINHigh = tValue;
      if(PWMINCtl.PWMINHigh > PWMINCtl.PWMINHighErr)                    //PPM ���ȴ�����С����
      {            
        if(PWMINCtl.PWMINHigh <= PWMINCtl.PWMINHighMax)                 //PPM ����С��������
        {
          if(PWMINCtl.PWMINHigh < (PWMINCtl.PWMINHighMin+TempMotorLinearTimeErrA))
          {
            tPWMINHigh = 1;
          }
          else
          {
            tPWMINHigh = PWMINCtl.PWMINHigh - PWMINCtl.PWMINHighErr;
          }

          Temp32A = (u32)tPWMINHigh<<15;
          Temp32B = (u32)PWMINCtl.PWMINHighMax - PWMINCtl.PWMINHighErr;
          MDUControl.SpeedSref = MDU_DIV_U16(&Temp32A,&Temp32B); //(0~32767)
					
					 if(MDUControl.SpeedSref<3500)
					{
	         PWMARR= (SYSCLK_FREQ/12000) ;
          }	
          else if(MDUControl.SpeedSref<25000)
					{
	        PWMARR= (SYSCLK_FREQ/16000) ;
          }			
					else if(MDUControl.SpeedSref>27000)
					{
	        PWMARR= (SYSCLK_FREQ/24000) ;
          }	
					if((SpeedSrefpre-MDUControl.SpeedSref>1500)||(MDUControl.SpeedSref-SpeedSrefpre>1500))// �仯����TIM��������
					{TIM2_Config();a=3;	
					}
					SpeedSrefpre=MDUControl.SpeedSref;
          if(Ctl.State == MOTOR_NORMAL)
          {
            //������PWM�ź� ֱ�Ӹ�DR
            if(MDUControl.SpeedSref > MDUControl.AlineX1) //y = A*x + B ;
            {  
              MDUControl.TargetSpeed = MDU_MULA_U16(MDUControl.SpeedSref,MDUControl.AlineA,15) + MDUControl.AlineB;
            }

            Drv.PWM.DutytargetOpen = MDUControl.TargetSpeed;            //MDU�����ٶȸ���ֵ
            Drv.PWM.Dutytarget = Drv.PWM.DutytargetOpen;
            
            Drv.PWM.DutyCurrent = Drv_DutyRampCale(Drv.PWM.Dutytarget); //�ٶȿ����Ӽ�������
            Drv.PWM.u16cycle = Fu68xx_PWM_Update(Drv.PWM.DutyCurrent);  //ռ�ձȸ���
            TIM2_DR = MDU_MULA_U16(MDUControl.DutyCurrent,PWMARR,15);
          }
        }
        else   //PPM ���ȴ���������
        {
          MDUControl.SpeedSref = 32767;               
          Drv.PWM.DutytargetOpen = 32767;
        }
      }
    }
    else
    {
      tPWMINOutRangeCounter++;    
      if((tPWMINOutRangeCounter >= 100)&&(tPWMINErrCotnter >= 1000)) //50*2.73 = 136
      {
        Ctl.SysError = E_ERR3;
        tPWMINOutRangeCounter = 100;
        PWMINCtl.PWMINHigh = 0;
      }
    }
    #endif
    CLRFlag_T3IR;
  }
  if(GetBit(TIM3_CR1, T3IP))
  {
    CLRFlag_T3IP;
  }
  if(GetBit(TIM3_CR1, T3IF))
  {
    #if((PWMINSREF_EN)||(PWMINONOFF_EN))
    tPWMINTim3ITconter++;
    if((tPWMINTim3ITconter >= 100)&&(tPWMINErrCotnter >= 1000))  //50*2.73 = 136
    {
      Ctl.SysError = E_ERR2;
      tPWMINTim3ITconter = 100;
      PWMINCtl.PWMINHigh = 0;
    }
    #endif
    CLRFlag_T3IF;
  }  
}

/*-------------------------------------------------------------------------------------------------
Function Name :	void PWMINOnOffSwitch(void)
Description   :  С��900us ɲ��  С��920us ͣ�� ����920us ~2000us ����
Input         :	��
Output				:	��
-------------------------------------------------------------------------------------------------*/

void PWMINOnOffSwitch(void)
{
  float tfAlineA;
  #if(PWMINSREF_EN)
  if(PWMINCtl.FlagPwmIn == 0xF1)  //�ϵ����ű�����������У׼ ������Ϣ��ȡ
  {
    if(PWMINCtl.PWMINHigh == 0) //���ű���
    { 
      BeepRequestFun(PWMINError);
      PWMINCtl.FlagPwmIn = 0xF1;
    }
    else if(PWMINCtl.PWMINHigh > TempPWMHighMaxAline) //����У׼����A
    {
      #if(PWMINALINE_EN)
      PWMINCtl.FlagPwmIn = 0xF1;
      PWMINCtl.PWMINCnt++;
      if(PWMINCtl.PWMINCnt > 5000)
      {
        PWMINCtl.PWMINCnt = 5000;
        if(PWMINCtl.FlagPWMAline == 0x7F)
        {
          PWMINCtl.PWMINHighMax = PWMINCtl.PWMINHigh - 10; //�������ֵ��ȥ 10
          BeepRequestFun(PWMINAline);
        }
      }
      #else
      PWMINCtl.PWMINCnt = 0;
      PWMINCtl.FlagPwmIn = 0xF1;
      if(PWMINCtl.FlagPWMAline = 0x7F)
      {
        BeepRequestFun(PWMINError);
      }      
      #endif
    }
    else if(PWMINCtl.PWMINHigh < TempPWMHighMinAline) //����У׼����B
    {
      PWMINCtl.FlagPwmIn = 0xF1;
      PWMINCtl.PWMINCnt --;
      
      if(Beep.BeepType != PWMINReady)
      {
        if(PWMINCtl.PWMINCnt < -1000)
        {
          PWMINCtl.PWMINCnt = -1000;
          #if(PWMINALINE_EN)
          if(PWMINCtl.FlagPWMAline == 0xFF)
          {
            PWMINCtl.PWMINHighMin = PWMINCtl.PWMINHigh;
            while(Flash_Sector_Erase((uint8 xdata *)16128)); // ��д��126������16128~16255��
            while(Flash_Sector_Write((uint8 xdata *)16128, PWMINCtl.PWMINHighMin)); // д��С���ŵ��ֽ�
            while(Flash_Sector_Write((uint8 xdata *)16129, (PWMINCtl.PWMINHighMin >> 8))); // д������Ÿ��ֽ�
            while(Flash_Sector_Write((uint8 xdata *)16130, PWMINCtl.PWMINHighMax)); // д������ŵ��ֽ�
            while(Flash_Sector_Write((uint8 xdata *)16131, (PWMINCtl.PWMINHighMax >> 8))); // д������Ÿ��ֽ�
          }
          PWMINCtl.PWMINHighMin = ((*(unsigned char code *)16129)<<8) + (*(unsigned char code *)16128);
          PWMINCtl.PWMINHighMax = ((*(unsigned char code *)16131)<<8) + (*(unsigned char code *)16130);
          #endif 

          if(!(PWMINCtl.PWMINHighMin && PWMINCtl.PWMINHighMax))
          {
            PWMINCtl.PWMINHighMin = TempPWMHighMinDefault;
            PWMINCtl.PWMINHighMax = TempPWMHighMaxDefault; 
          }
        
          PWMINCtl.PWMINHighErr = PWMINCtl.PWMINHighMin + TempMotorONTimeErr;

          tfAlineA = ((float)(SPEED_REF_MAX-SPEED_REF_MIN)/(MDUControl.SpeedSrefErr));
          if(tfAlineA > 2.0)
          {
            tfAlineA = 1.9999;
          }
          MDUControl.AlineA = (u16)(tfAlineA*32767);
          MDUControl.AlineB = (SPEED_REF_MAX - MDUControl.SpeedSrefErr*tfAlineA);

          BeepRequestFun(PWMINReady);
        }
      }
    }
    else                        //���ű���
    {
      PWMINCtl.PWMINCnt = 0;
      PWMINCtl.FlagPwmIn = 0xF1;
      if(PWMINCtl.FlagPWMAline == 0x7F)
      { 
        BeepRequestFun(PWMINError);
      }
    }
  }
  else                          //PWMIN�ϵ�У׼���
  {
    if(PWMINCtl.PWMINHigh == 0) //
    {
      Uc.flg.START = FALSE;
      //BeepRequestFun(PWMINError);
    }
    else if(PWMINCtl.PWMINHigh <= (PWMINCtl.PWMINHighMin + TempMotorOFFTimeErr))
    {
      PWMINCtl.PWMINCnt--;
      if(PWMINCtl.PWMINCnt < -5)
      {
        PWMINCtl.PWMINCnt = -5;

        PwmInResetFlag = 0x7F;
        Uc.flg.START = FALSE;
        
        if(Ctl.SysError != NONE)
        {
          Ctl.SysError = NONE;        //�������
          Ctl.State = MOTOR_STOP; 
          DRV_OE_ON;
        }        
      }
//      if(PWMINCtl.PWMINHigh <= (PWMINCtl.PWMINHighMin + TempMotorBreakTime))    //ɲ���ж�
//      {
//        PWMINCtl.PWMINBreakCnt++;
//        if(PWMINCtl.PWMINBreakCnt > 100)
//        {
//          PWMINCtl.PWMINBreakCnt = 100;
//          PwmInResetFlag = 0x7F;
//          //Ctl.FnStopmodeC = BREAK_DOWN;
//        }
//      }
//      else
//      {
//        PWMINCtl.PWMINBreakCnt--;
//        if(PWMINCtl.PWMINBreakCnt < -100)
//        {
//          PWMINCtl.PWMINBreakCnt = -100;
//          //Ctl.FnStopmodeC = FREE_DOWN;
//        }
//      }
    }
    else if(PWMINCtl.PWMINHigh > (PWMINCtl.PWMINHighMin + TempMotorONTimeErr))
    {
      PWMINCtl.PWMINCnt++;
      if(PWMINCtl.PWMINCnt > 100)
      {
        PWMINCtl.PWMINCnt = 100;
        if((PwmInResetFlag == 0X7F)&&(Uc.flg.START == FALSE)) 
        {
          Beep.BeepRequest = 0xFF;

          Uc.flg.START = TRUE;
          PwmInResetFlag = 0XF2;
        }
      }
    }
  }
  #endif
}