/* Includes ------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>


/** @addtogroup FT68xx
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define LEDFAULTDIS_EN     (1)     //����ָʾ
#define LEDONOFFDIS_EN     (0)     //ONOFFָʾ#define LEDCWCCWDIS_EN     (0)     //����ת��ʾ
#define LEDCELLDIS_EN      (0)     //������ʾ
#define LEDSHIFTDIS_EN     (0)     //��λ��ʾ

/* Private macro -------------------------------------------------------------*/

void LED_show(void);
void Fault_Led(Error_TypeDef value); 
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : Fault_Led   P15 P17 P20
* Description    : 
* Input          : Ctl.SysError���ϴ���
* Output         : None
* Return         : None
*******************************************************************************/
void Fault_Led(Error_TypeDef value)
{
  #if(LEDFAULTDIS_EN)
  u16 temp = 500;
  if(value != 0)
  {
    if(Ctl.Tim.LED_OnOffms > temp)
    {
      if(Ctl.Tim.LED_Cunter <= ((value<<1) - 1))  //һԪ���������ӿո� 3.6.6
      {
        if(Ctl.Tim.LED_OnOffms > (temp + 500))
        {
          Ctl.Tim.LED_OnOffms = temp;
          Ctl.Tim.LED_Cunter++;
          FAULT_ONOFF;
        }       
      }
      else
      {
        #if(0)
        //FAULT_ONOFF;                     //����ָʾ��ɣ�����̶��ź�
        Ctl.Tim.LED_OnOffms = 0;
        #else                              
        FAULT_OFF;
        if(Ctl.Tim.LED_OnOffms>temp+3000)  //����ָʾ��ɣ�3����ٴ���˸
        {
          Ctl.Tim.LED_OnOffms = 0;
          Ctl.Tim.LED_Cunter = 0;
        } 
        #endif                   
      }             
    }
  }
  else
  {
    Ctl.Tim.LED_OnOffms = 0;
  }
  #endif
}

/*******************************************************************************
* Function Name  : LED_show
* Description    : 
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
void LED_show(void)
{
  //����ָʾ
  #if(LAMP_EN) //������˿������ʱ�������
  if(Ctl.Tim.NoOperationDelaynms >= NOOPDELAYNMS)
  {
    Ctl.Tim.NoOperationDelaynms = NOOPDELAYNMS;
    Rom.ReadValue = Flash_GetAddress();     //��
    Flash_ErasePageRom();                  //��
    Flash_KeyWriteValue((Rom.WriteValue));  //д
    PDELAY_OFF;
  } 
  else
  {
    PDELAY_ON;
  }
  #endif   
                          
  #if(LEDONOFFDIS_EN)
  if(Ctl.gStart == TRUE)
  {
    LED1_ON;
  }
  else
  {
    LED1_OFF;
  }
  #endif
//����ת��ʾ
  #if(LEDCWCCWDIS_EN)
  if (Ctl.SysError == NONE)
  {
    if(Uc.flg.FR == CW)
    {
      LED4_OFF;
    }
    else if(Uc.flg.FR == CCW)
    {
      LED4_ON;
    }
  }
  #endif
//������ʾ
  #if(LEDCELLDIS_EN)
  if (Ctl.SysError == NONE)
  {
    if(Drv.AdcMeas.Vdc > 18)
    {
      LED1_ON;
      LED2_ON;
      LED3_ON;
    }
    else if(Drv.AdcMeas.Vdc > 16.5)
    {
      LED1_ON;
      LED2_ON;
      LED3_OFF;
    }
    else if(Drv.AdcMeas.Vdc > 15)
    {
      LED1_ON;
      LED2_OFF;
      LED3_OFF;
    }
    else
    {
      LED1_OFF;
      LED2_OFF;
      LED3_OFF;
    }
  }
  #endif 
//��λ��ʾ

  #if(LEDSHIFTDIS_EN)
  switch(Ctl.spd.SpeedShift)
  {
    case 1:
    {
      LED1_ON;
      LED2_OFF;
      LED3_OFF;
    }
      break;
    case 2:
    {
      LED1_OFF;
      LED2_ON;
      LED3_OFF;
    }
      break;
    case 3:
    {
      LED1_OFF;
      LED2_OFF;
      LED3_ON;
    }      
      break;
    
    default:
      break;
  }
  #endif
}