
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : ���棺��ֹ�޸�,ɾ�� �ṹ�嶨�� ����ᵼ��δ֪����
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MC_PWMIN_H_
#define __MC_PWMIN_H_


/* Exported types -------------------------------------------------------------------------------*/
typedef struct
{
  uint8 FlagPWMAline;         //����У׼��־
  uint8 FlagPWMPowerUp;       //--
  
  u8    FlagPwmIn;            //����У׼��־λ
  uint8 PWMStatus;            //--
  int16 PWMINCnt;             //PWMIN ������
  int16 PWMINStartCnt;        //--
  int16 PWMINBreakCnt;        //break������
  uint16 PWMINHigh;           //H ��ƽ����
  uint32 PWMINPeriod;         //--
  s16    PWMINSelfCheck;      //--
  uint16 PWMINHighMin;        //��СPPM����
  uint16 PWMINHighMax;        //���PPM����
  uint32 PWMINHighErr;        //���ٲ�ֵ
} PWMINCtl_TypeDef;

/* Exported variables ---------------------------------------------------------------------------*/
extern PWMINCtl_TypeDef xdata PWMINCtl;extern u8 xdata PwmInResetFlag;
extern u8 xdata tPWMINTim3ITconter;                 //tim3 ���������
extern u8 xdata tPWMINOutRangeCounter;              //���ſ��ȴ�������� 
extern u16 xdata tPWMINErrCotnter;
  
/* Exported functions ---------------------------------------------------------------------------*/
extern void PWMINInit(void);
extern void PWMScan(void);
extern void PWMINOnOffSwitch(void);
#endif

