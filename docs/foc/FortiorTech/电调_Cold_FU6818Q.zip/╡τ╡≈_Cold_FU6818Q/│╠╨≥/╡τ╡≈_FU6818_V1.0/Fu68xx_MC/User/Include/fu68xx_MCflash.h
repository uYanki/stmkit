
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FLASH_H
#define __FLASH_H

typedef struct
  {
    u8  *PageAddress;     //ҳ��ַ
    u8  OffsetAddressCur; //ƫ�Ƶ�ǰ��ַ 
    u8  OffsetAddressTar; //ƫ��Ŀ��д���ַ
    u8  WriteValue;       //ROM д��ֵ
    u8  ReadValue;        //ROM ����ֵ
  }ROM_TypeDef;

extern ROM_TypeDef xdata  Rom;  
extern u8 Flash_GetAddress(void);
extern void Flash_ErasePageRom(void);
extern void Flash_KeyWriteValue( u8 value);

#endif