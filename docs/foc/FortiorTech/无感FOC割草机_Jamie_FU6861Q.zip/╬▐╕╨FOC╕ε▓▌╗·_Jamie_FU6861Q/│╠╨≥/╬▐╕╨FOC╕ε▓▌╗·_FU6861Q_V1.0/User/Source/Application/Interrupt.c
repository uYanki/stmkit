/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Interrupt.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the interrupt function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <Interrupt.h>
#include <FU68xx_2.h>
#include <Myproject.h>
uint16  Power_Currt;
uint16  BreakTime = 0;             //刹车延时时间
uint16  DormancyTime = 0;
uint16  Pdelay_time =0;
/*-------------------------------------------------------------------------------------------------
    Function Name : void CMP_ISR(void)
    Description   : CMP3：硬件比较器过流保护，关断输出，中断优先级最高
										CMP0/1/2：顺逆风判断
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void CMP_ISR(void) interrupt 7
{
    if(ReadBit(CMP_SR, CMP3IF))
    {
//				GP20 = 0;
				FaultProcess();                                                       // 关闭输出
				mcFaultSource = FaultHardOVCurrent;                                   // 硬件过流保护
				mcState = mcFault;                                                    // 状态为mcFault                                                     
        if(McStaSet.SetFlag.BLDCSetFlag == 1)		
				{
				  ClrBit(DRV_SR, DCIM1); 
					ClrBit(DRV_SR, DCIM0);
          McStaSet.SetFlag.BLDCSetFlag = 2;
				}
        ClrBit(CMP_SR, CMP3IF);
    }
		
		#if (TailWind_Mode == TailWind_BEMF_Method)
        //通过BEMF做顺风启动功能
        BEMFDetectFunc();
    #endif

}


/*---------------------------------------------------------------------------*/
/* Name     :   void Drv_INT(void) interrupt 3
/* Input    :   NO
/* Output   :   NO
/* Description: Drv中断,每两个载波周期执行一次，用于处理响应较高的程序，中断优先级第二。DCEN开了就会产生中断。
/*---------------------------------------------------------------------------*/
void Drv_INT(void) interrupt 3
{

    if(ReadBit(DRV_SR, DCIF))                                 // 比较中断
    {
			if( McStaSet.SetFlag.BLDCSetFlag == 1)
			{
				RPD_C();
      }
	
		 	if(McStaSet.SetFlag.BLDCSetFlag == 0)
			{

				#if (SPI_DBG_Mode == SPI_DBG_SW_Enable) 	//软件调试模式
				{
						spidebug[0] = mcFocCtrl.Speed_Flag*5000;//FOC__EALP;//FOC__EOME;//
					  spidebug[1] = FOC__EBET;
////						spidebug[2] = VSP;//mcSpeedRamp.TargetValue;//FOC__UD;//TIM1__URES;//spidebug[0];//
//						spidebug[3] = mcFocCtrl.RunCurrent<<3;//VSP; mcSpeedRamp.TargetValue;//FOC__UQ;//TIM1__UCOP;
			  }
				#endif
			}
//        GP42=0;
			

        ClrBit(DRV_SR, DCIF);
    }
		
}



/*---------------------------------------------------------------------------*/
/* Name     :   void TIM4_1ms_INT(void) interrupt 10
/* Input    :   NO
/* Output   :   NO
/* Description: 1ms定时器中断（SYS TICK中断），用于处理附加功能，如控制环路响应、各种保护等。中断优先级低于FO中断和FOC中断。
/*---------------------------------------------------------------------------*/
void TIM4_1ms_INT(void) interrupt 10
{
    if(ReadBit(DRV_SR, SYSTIF))          // SYS TICK中断
    {
			  SetBit(ADC_CR, ADCBSY);          //使能ADC的DCBUS采样  会于BLDC采样冲突
			
				Power_Currt = (ADC3_DR<<3);
				if(Power_Currt > mcCurOffset.Iw_busOffset)
				{
				 Power_Currt   = Power_Currt - mcCurOffset.Iw_busOffset;
				}
				else	
				{
					Power_Currt   = 0;
				}	
				
        /****速度滤波、反电动势滤波*****/
        if(mcState == mcRun)
        {
          mcFocCtrl.SpeedFlt = LPFFunction(FOC__EOME, mcFocCtrl.SpeedFlt, 5);//注意低通滤波器系数范围为0---127
          mcFocCtrl.EsValue  = LPFFunction(FOC__ESQU,mcFocCtrl.EsValue,10);
          mcFocCtrl.RunCurrent = Power_Currt;//LPFFunction(Power_Currt, mcFocCtrl.RunCurrent,10);//注意低通滤波器系数范围为0---127
        }
        else
        {
          mcFocCtrl.SpeedFlt = 0;
					mcFocCtrl.EsValue  = 0;
          mcFocCtrl.RunCurrent = 0;
        }
							
			 Speed_response();                                                                   //环路响应，如速度环、转矩环、功率环等
        
       /*****************关机或故障清动作*****************/
       if((mcSpeedRamp.FlagONOFF  == 0)||(mcState == mcFault))
       {
         Pdelay_time++;			             //断电延时时间自加
       }
       else if(mcSpeedRamp.FlagONOFF  == 1)
			 {
				Pdelay_time = 0;
				Pdelay_ON;                      //芯片供电
       }
      if(Pdelay_time >=PDELAY_Vaule)    //掉电延时
			{
				Pdelay_time = PDELAY_Vaule;
				Pdelay_OFF ;
      }
			
			/*********Mos NTC电压值并滤波******/		                                                         
//		   mcFocCtrl.MosTempDecFlt = LPFFunction(ADC6_DR<<3,mcFocCtrl.MosTempDecFlt,10);       //MOS温度检测
							        	 
      /*****DCbus的采样获取值并滤波******/
       mcFocCtrl.mcDcbusFlt = LPFFunction(ADC2_DR<<3,mcFocCtrl.mcDcbusFlt,10);	           //电压检测

			 VSP = ADC7_DR<<3;                                                                   //调速检测
			 

		  /*********电机使能端滤波**********/
//       Motor_En();                                                                         //速度按键滤波	
				
      /*****故障保护函数功能，如过欠压保护、温度保护、过流等********/
       Fault_Detection();                                                                  //故障保护   

      /*****故障指示灯********/				
			 LED_Display();                                                                      //LED灯故障显示

//       VSPSample();	
			 				
			/*****刹车,休眠延时,延时启动计时********/
			if(mcSpeedRamp.FlagONOFF == 1)
			{
				BreakTime = 0;
//			  DormancyTime++;
			}
//			else
//			{
//				BreakTime = 0;
//				DormancyTime =0;
//			 }
	
      /*****芯片断电休眠********/			 
//      if(DormancyTime>=5000)
//			{
//				DormancyTime = 5000;
//				GP22 = 0;
//       }			 
				
      /*****电机状态机的时序处理*****/
      if(mcFocCtrl.State_Count > 0)      mcFocCtrl.State_Count--;			
      if(BEMFDetect.BEMFTimeCount>0)	 	 BEMFDetect.BEMFTimeCount--;		
			if(BreakTime>0)                    BreakTime--;
				
      /*****电机启动爬坡函数处理*****/
			StarRampDealwith();
			
			ClrBit(DRV_SR, SYSTIF);                                    // 清零标志位
    }
}








/* Private variables ----------------------------------------------------------------------------*/
void INT0(void) interrupt 0
{
}

/*-------------------------------------------------------------------------------------------------
    Function Name : void FO_INT(void)
    Description   : FO_INT interrupt，硬件FO过流保护，关断输出，中断优先级最高
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void FO_INT(void) interrupt 1                                                   // 硬件FO过流中断，关闭输出
{
//    FaultProcess();                                                             // 关闭输出
//    mcFaultSource = FaultHardOVCurrent;                                         // 硬件过流保护
//    mcState       = mcFault;                                                    // 状态为mcFault
//    IF0           = 0;                                                          // clear P00 interrupt flag
}
/*---------------------------------------------------------------------------*/
/* Name     :   void EXTERN_INT(void) interrupt 2
/* Input    :   NO
/* Output   :   NO
/* Description: 睡眠唤醒
/*---------------------------------------------------------------------------*/
void EXTERN_INT(void) interrupt 2
{
    if(SleepSet.SleepFlag)
    {
        SleepSet.SleepFlag = 0;
        SleepSet.SleepEn   = 1;
    }

    ClrBit(P1_IF, P11);                    // 清零P10标志位
}
/*---------------------------------------------------------------------------*/
/* Name     :   void TIM2_INT(void) interrupt 4
/* Input    :   NO
/* Output   :   NO
/* Description:	正反转检测(RSD)
/*---------------------------------------------------------------------------*/
void TIM2_INT(void) interrupt 4
{
    if(ReadBit(TIM2_CR1, T2IR))
    {
			ClrBit(TIM2_CR1, T2IR);
    }
    if(ReadBit(TIM2_CR1, T2IP))
    {
			#if (TailWind_Mode == TailWind_RSD_Method)
			{
				RSDFRDetect();//RSD正反转检测
			}
			#endif

			ClrBit(TIM2_CR1, T2IP);
    }
    if(ReadBit(TIM2_CR1, T2IF))//溢出中断,用于判断静止,时间为349ms。
    {
        #if (TailWind_Mode == TailWind_RSD_Method)
			  {
					RSDDetect.RSDState=Static;
					RSDDetect.RSDFlag=1;
				}
        #endif

        ClrBit(TIM2_CR1, T2IF);
    }
}

void TIM1_INT(void) interrupt 5
{
}
void INT6(void) interrupt 6
{
}
void INT8(void) interrupt 8
{
}

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM23_INT(void) interrupt 9
/* Input    :   NO
/* Output   :   NO
/* Description: Capture PWM ，中断优先级第二，高于FOC中断，用于PWM调速
/*---------------------------------------------------------------------------*/
void TIM3_INT(void) interrupt 9
{
//    if(ReadBit(TIM3_CR1, T3IR))
//    {
//			ClrBit(TIM3_CR1, T3IR);
//    }
//    if(ReadBit(TIM3_CR1, T3IP))//周期中断
//    {
//        if(mcPwmInput.PWMFlag != 1)//若正在计算占空比则不更新
//        {
//					mcPwmInput.PWMCompare    = TIM3__DR;
//					mcPwmInput.PWMARR        = TIM3__ARR;
//					mcPwmInput.PWMUpdateFlag = 1;
//        }

//        ClrBit(TIM3_CR1, T3IP);
//    }
//    if(ReadBit(TIM3_CR1, T3IF))
//    {
//        if(GP11 == 1)//PWM 100%输出
//        {
//					mcPwmInput.PWMCompare = 8000;
//					mcPwmInput.PWMARR     = 8000;
//        }
//        else//PWM 为0%
//        {
//					mcPwmInput.PWMCompare = 0;
//					mcPwmInput.PWMARR     = 8000;
//        }
//        mcPwmInput.PWMUpdateFlag =1;

//        ClrBit(TIM3_CR1, T3IF);
//    }
}

void INT11(void) interrupt 11
{
}

/*---------------------------------------------------------------------------*/
/* Name     :   void USART_INT(void) interrupt 12
/* Input    :   NO
/* Output   :   NO
/* Description: 串口中断，中断优先级最低，用于接收调速信号,无中断插入时8us
/*---------------------------------------------------------------------------*/
void USART_INT(void)  interrupt 12
{
    if(RI == 1)
    {
        RI = 0;
//        Uart.Uredata= UT_DR;            //读接收数据
    }
}


void INT13(void) interrupt 13
{
}
void INT14(void) interrupt 14
{
}
void INT15(void) interrupt 15
{
}


