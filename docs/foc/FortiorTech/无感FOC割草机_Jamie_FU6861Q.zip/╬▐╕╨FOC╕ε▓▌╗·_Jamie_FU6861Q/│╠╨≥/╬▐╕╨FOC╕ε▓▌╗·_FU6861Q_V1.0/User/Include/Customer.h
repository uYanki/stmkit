/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Customer.h
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-21
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __CUSTOMER_H_
#define __CUSTOMER_H_

/*芯片参数值-------------------------------------------------------------------*/
 /*CPU and PWM Parameter*/
 #define MCU_CLOCK                      (24.0)                                  // (MHz) 主频
 #define PWM_FREQUENCY                  (16.0)                                  // (kHz) 载波频率

 /*deadtime Parameter*/
 #define PWM_DEADTIME                   (1.0)                                   // (us) 死区时间

 /*single resistor sample Parameter*/
 #define MIN_WIND_TIME                  (PWM_DEADTIME + 1.2)                    // (us) 单电阻最小采样窗口，建议值死区时间+0.9us

/*电机参数值-------------------------------------------------------------------*/// 未知名电机
 #define Pole_Pairs                     (4.0)                                   // 极对数 
 #define RS                             (0.06)                                 // (Ω) 相电阻
 #define LD                             (0.000126)                          // (H) D轴电感
 #define LQ                             (0.000126)                          // (H) Q轴电感
// #define KeVpp                          (25.2)                                // (V) 反电动势测量的峰峰值
// #define KeT                            (12.3)                                // (ms)反电动势测量的周期
// #define Ke                             (Pole_Pairs * KeVpp * KeT / 207.84)   // (V/KRPM) 反电动势常数
 #define Ke                             (8)//(5.9)                                  // (V/KRPM) 反电动势常数

/*硬件板子参数设置值------------------------------------------------------------*/
/*PWM high or low level Mode*/
/*根据驱动芯片的类型选择*/
 #define All_High_Level                 (0)                                     // 驱动高电平有效
 #define All_Low_Level                  (1)                                     // 驱动低电平有效
 #define UP_H_DOWN_L                    (2)                                     // 上桥臂高电平有效，下桥臂低电平有效
 #define UP_L_DOWN_H                    (3)                                     // 上桥臂低电平有效，下桥臂高电平有效
 #define PWM_Level_Mode                 (UP_H_DOWN_L)

/*hardware current sample Parameter*/
/*电流基准的电路参数*/
 #define HW_RSHUNT                      (0.00167)                              // (Ω)  采样电阻
 #define HW_AMPGAIN                     (10.0)                                  // 运放放大倍数
 #define HW_ADC_REF                     (4.5)                                   // (V)  ADC参考电压

/*hardware voltage sample Parameter*/
/*母线电压采样分压电路参数*/
 #define RV1                            (0.0)                                   // (kΩ) 母线电压分压电阻1
 #define RV2                            (100.0)                                 // (kΩ) 母线电压分压电阻2
 #define RV3                            (5.1)                                   // (kΩ) 母线电压分压电阻3
 #define RV                             ((RV1 + RV2 + RV3) / RV3)               // 分压比

/*电压补偿系数*/
 #define VOLT_COMP                       (1.1)                                  // 电压补偿系数

 #define ANGLE_MASK(X)                  {TIM1_CR1  =(TIM1_CR1 &(0x80)) | (X*127/60);}  
 #define ANGLE_DELAY(X)                 {TIM1_CR2  =(TIM1_CR2 &(0x80)) | (X*127/60);}  
 #define ActiveLowEnable                (0x0540)                                //低电平有效
 #define ActiveHighEnable               (0)                                     //高电平有效

 #define H_MOSActive                    (ActiveHighEnable)                      //上桥预驱电平
 #define L_MOSActive                    (ActiveLowEnable)                       //小桥预驱电平
 #define PWM_BITCON                     (L_MOSActive+H_MOSActive*2)            //000高有效 AAA低有效  222上桥低  888下桥低

 #define TUVW_OFF     0x0000
 #define TULVLWL_ON   0x0540

/*****HPWM+LPWM*********/
 #define TUH_VL0       0x0006
 #define TUH_WL0       0x0012
 #define TVH_WL0       0x0018
 #define TVH_UL0       0x0009
 #define TWH_UL0       0x0021
 #define TWH_VL0       0x0024

/*****HPWM+LON*********/
 #define TUH_VL1       0x0102
 #define TUH_WL1       0x0402
 #define TVH_WL1       0x0408
 #define TVH_UL1       0x0048
 #define TWH_UL1       0x0060
 #define TWH_VL1       0x0120

 #define UVW_OFF                         (TUVW_OFF^PWM_BITCON) 
 #define ULVLWL_ON                       (TULVLWL_ON^PWM_BITCON)

 #define CMP_UVW_UPDO                   (0x0000+UVW_OFF)  
 #define CMP_W_DO                       0x2000  
 #define CMP_V_UP                       0x3000 
 #define CMP_U_DO                       0x4000
 #define CMP_W_UP                       0x5000 
 #define CMP_V_DO                       0x6000 
 #define CMP_U_UP                       0x1000 
 #define CMP_UVW_NO                     0x0000  


/*****HPWM+LPWM*********/
 #define UH_VLA0            (TUH_VL0^PWM_BITCON)
 #define UH_WLA0            (TUH_WL0^PWM_BITCON)
 #define VH_WLA0            (TVH_WL0^PWM_BITCON)
 #define VH_ULA0            (TVH_UL0^PWM_BITCON)
 #define WH_ULA0            (TWH_UL0^PWM_BITCON)
 #define WH_VLA0            (TWH_VL0^PWM_BITCON)

/*****HPWM+LON*********/
 #define UH_VLA1            (TUH_VL1^PWM_BITCON)
 #define UH_WLA1            (TUH_WL1^PWM_BITCON)
 #define VH_WLA1            (TVH_WL1^PWM_BITCON)
 #define VH_ULA1            (TVH_UL1^PWM_BITCON)
 #define WH_ULA1            (TWH_UL1^PWM_BITCON)
 #define WH_VLA1            (TWH_VL1^PWM_BITCON)

 #define  Tim1_Ures_Down		              (0)														                                 
 #define  Tim1_Ures_Up									  (1)														                                 

// #define Tim1_KF         _Q15(0.40)
// #define Tim1_KR         _Q15(0.70)  //调试基础


/*顺逆风判断设置*/
 #define NoTailWind                     (0)                                     // 无逆风顺风判断
 #define TailWind_RSD_Method            (1)                                     // RSD比较器方法
 #define TailWind_BEMF_Method           (2)                                     // BEMF方法
 #define TailWind_FOC_Method            (3)                                     // FOC计算方法
 #define TailWind_Mode                  (TailWind_BEMF_Method)

/*逆风判断时的估算算法设置值-----------------------------------------------------*/
 #define TailWind_Time                  (250)                                   // (ms) 顺逆风检测时间
 #define ATO_BW_Wind                    (150.0)//120.0-PLL 120.0-smo            // 逆风判断观测器带宽的滤波值，经典值为8.0-100.0
 #define SPD_BW_Wind                    (10.0)//10.0-PLL  ,10.0-smo             // 逆风判断速度带宽的滤波值，经典值为5.0-40.0

 /**逆风顺风状态下的KP、KI****/
 #define DQKP_TailWind                  _Q12(2.0)                               //_Q12(1.0)-PLL ,   _Q12(1.5)   -smo
 #define DQKI_TailWind                  _Q15(0.2)                              //_Q15(0.08)-PLL  ,_Q15(0.2)-smo
 
/*启动参数参数值----------------------------------------------------------------*/
 #define Charge_Time                    (30)                                    // (ms) 预充电时间，单位：ms
 #define Charge_Duty                    (0.5)                                   // 预充电下桥Duty

/******* 初始位置检查参数 **********/
 #define PosCheckMode                   (Disable)                               // Enable-禁止初始位置检测，Disable-禁止初始位置检测    

/*脉冲注入时间长于2ms 或 低于2ms*/
 #define Long_Inject                    (0)                                     // 脉冲注入时间长于2ms,若时间长于4ms，则要修改定时器分频
 #define Short_Inject                   (1)                                     // 脉冲注入时间低于2ms
 #define InjectTime                     (Short_Inject)

 #define RPD_Time                       (20)                                    // (ms) 每次RPD的间隔时间
 #define RPD_CurValue                   (10.0)                                  // (A)  RPD过流值
 #define DAC_RPDCurValue                _Q7(I_ValueX(RPD_CurValue*2.0))

/******* 预定位测试模式*/
 #define AlignTestMode                  (Disable)                               // Enable-使能预定位测试模式，Disable-禁止预定位测试模式     
 #define Align_Time                     (4000)                                  // (ms) 预定位时间，单位：ms
 
 #define Align_Angle                    (30.0)                                  // (°) 预定位角度
 
 #define ID_Align_CURRENT               I_Value(0.0)                            // (A) D轴定位电流
 #define IQ_Align_CURRENT               I_Value(1.5)                            // (A) Q轴定位电流

 /***预定位的Kp、Ki****/
 #define DQKP_Alignment                 _Q12(0.5)                               // 预定位的KP
 #define DQKI_Alignment                 _Q12(0.01)                              // 预定位的KI

 /***启动电流****/
 #define ID_Start_CURRENT               I_Value(0.00)                           // (A) D轴启动电流
 #define IQ_Start_CURRENT               I_Value(10.0)                            // (A) Q轴启动电流

 /***运行电流****/
 #define ID_RUN_CURRENT                 I_Value(0.0)                            // (A) D轴运行电流
 #define IQ_RUN_CURRENT                 I_Value(20.0)                           // (A) Q轴运行电流

 /***限制电流****/
 #define LIMIT_MIN_CURRENT              I_Value(5.0)                            // (A) Q轴限制电流

 ///********SMO启动的参数**********/
 #define ATO_BW                         (30.0)                                  //40// 观测器带宽的滤波值，经典值为1.0-200.0
 #define ATO_BW_RUN                     (40.0)                                  //60
 #define ATO_BW_RUN1                    (60.0)    //80
 #define ATO_BW_RUN2                    (80.0)   //100
 #define ATO_BW_RUN3                    (120.0)   //120
 #define ATO_BW_RUN4                    (150.0)   //150

 #define SPD_BW                         (30.0)                                  // 速度带宽的滤波值，经典值为5.0-40.0
 #define ATT_COEF                       (0.85)                                  // 无需改动

 ///********PLL启动的参数**********/
 #define OBS_KSLIDE                     _Q15(0.82)                              // SMO算法里的滑膜增益值
 #define E_BW                           (1.50*BASE_FREQ)                        // PLL算法里的反电动势滤波值
 #define E_BW_RUN                       (0.50*BASE_FREQ)                        // PLL算法里的反电动势滤波值
 #define E_BW_RUN1                      (1.00*BASE_FREQ)                        // PLL算法里的反电动势滤波值
 #define E_BW_RUN2                      (1.40*BASE_FREQ)                        // PLL算法里的反电动势滤波值
 #define E_BW_RUN3                      (1.50*BASE_FREQ)                        // PLL算法里的反电动势滤波值
 #define E_BW_RUN4                      (1.50*BASE_FREQ)                        // PLL算法里的反电动势滤波值


/*转速参数值-------------------------------------------------------------------*/
 #define MOTOR_SPEED_BASE               (6000.0)                                // (RPM) 速度基准

 /* motor start speed value */
 //open 算法启动参数
 #define MOTOR_OPEN_ACC                 (1000.0)                                // 强拖启动的增量(每载波周期加一次)
 #define MOTOR_OPEN_ACC_MIN             (500.0)                                 // 强拖启动的初始速度
 #define MOTOR_OPEN_ACC_CNT             (5.0)                                   // 强拖启动的执行次数(MOTOR_OPEN_ACC_CNT*256)
 #define MOTOR_OPEN_ACC_CYCLE           (1)                                     // 强拖启动循环拖动的次数

 //OMEGA启动参数
 #define Motor_Omega_Ramp_ACC           (8.0)                                  // omega启动的增量   12
 #define MOTOR_OMEGA_ACC_MIN            (60.0) //50                                 // (RPM) omega启动的最小切换转速
 #define MOTOR_OMEGA_ACC_END            (1000.0)                                 // (RPM) omega启动的限制转速

 /* motor loop control speed value */
 #define MOTOR_LOOP_RPM                 (30.0)                                // (RPM) 由mode 0到mode1切换转速，即闭环切换转速

 /* motor run speed value */
 //电机运行时最大最小转速、堵转保护转速
 #define MOTOR_SPEED_SMOMIN_RPM         (300.0)                                 // (RPM) SMO运行最小转速
 #define MOTOR_SPEED_MIN_RPM            (3200.0)                                // (RPM) 运行最小转速
 #define MOTOR_SPEED_MAX_RPM            (3200.0)                                // (RPM) 运行最大转速 
 #define MOTOR_SPEED_STAL_MAX_RPM       (5000.0)                                // (RPM) 堵转保护最大转速
 #define MOTOR_SPEED_STAL_MIN_RPM       (500.0)                                 // (RPM) 堵转保护最小转速
 #define MOTOR_SPEED_STAL_MIN_RPM2      (1500.0)                                 // (RPM) 堵转保护最小转速

 /*VSP给定模式*/
 #define PWMMODE                        (0)                                     // PWM调速
 #define SREFMODE                       (1)                                     // 模拟调速
 #define NONEMODE                       (2)                                     // 直接给定值，不调速
 #define SPEED_MODE                     (SREFMODE)

/*电机开机、关机的设置----------------------------------------------------------*/
 /* motor ON/0FF value */
#define 	OFFPWMDuty	                _Q15(0.1)			                          // 关机PWM占空比，小于该占空比关机																				//¹Ø»úPWMÕ¼¿Õ±È£¬Ð¡ÓÚ¸ÃÕ¼¿Õ±ÈÊ±¹Ø»ú
#define 	OFFPWMDutyHigh	            _Q15(1.0)			                          // 关机PWM占空比，大于该占空比关机	
#define 	ONPWMDuty	                  _Q15(0.106)		                          // 开机PWM占空比，大于该占空比开机
#define	  MINPWMDuty			            _Q15(0.11)			                        // 速度曲线上最小PWM占空比
#define	  MAXPWMDuty			            _Q15(0.95)			                        // 速度曲线上最大PWM占空比
#define 	SPEED_K		                  ((float)(Motor_Max_Speed-Motor_Min_Speed)/(float)(MAXPWMDuty-MINPWMDuty)) //2498

/*******运行时的参数*****************/
/*电流环参数设置值--------------------------------------------------------------*/
 #define DQKPStart                       _Q12(1.5)                              // DQ轴KP
 #define DQKIStart                       _Q15(0.08)                             // DQ轴KI
 
 #define DQKP                            _Q12(1.2)                              // DQ轴KP
 #define DQKI                            _Q15(0.05)                             // DQ轴KI

 /* D轴参数设置 */
 #define DOUTMAX                        _Q15(0.28)                              // D轴最大限幅值，单位：输出占空比
 #define DOUTMIN                        _Q15(-0.28)                             // D轴最小限幅值，单位：输出占空比
 /* Q轴参数设置，默认0.99即可 */
 #define QOUTMAX                        _Q15(0.93)                              // Q轴最大限幅值，单位：输出占空比
 #define QOUTMIN                        _Q15(-0.93)                             // Q轴最小限幅值，单位：输出占空比
 
 #define QOUTMAX1                        _Q15(0.92)                              // Q轴最大限幅值，单位：输出占空比
 #define QOUTMIN1                        _Q15(-0.92)                             // Q轴最小限幅值，单位：输出占空比

 
 #define QOUT_INC                        (35)                                   // Q轴电流增大步进值,开环控制时有效
 #define QOUT_DEC                        (35)                                   // Q轴电流减小步进值,开环控制时有效
	
/*外环参数设置值----------------------------------------------------------------*/

 /*外环使能*/
 #define OutLoop_Disable                (0)                                     // 关闭外环
 #define OutLoop_Enable                 (1)                                     // 使能外环
 #define OutLoop_Mode                   (OutLoop_Enable)

/*外环不使能时的Q轴运行电流*/	
 #define OutLoop_IQ_Current             (4.0)                                   // (A) Q轴输出电流,开环控制时有效
 #define OutLoop_IQ_VALUE               I_Value(OutLoop_IQ_Current)

 /*外环选择功率环或速度环*/
 #define Power_Loop_Control             (0)                                     //恒功率
 #define Speed_Loop_Control             (1)                                     //恒转速
 #define UQ_Loop_Control                (2)                                     //恒转速
 #define Motor_Speed_Control_Mode       (Speed_Loop_Control)

 /*环路调节参数*/
 #define SPEED_LOOP_TIME                (3.0)                                  // (ms) 速度环调节周期 风扇速度环50，功率环5

 /*限流环调节参数*/
 #define 	PKP													 _Q12(0.9)	  													  // speed loop KP
 #define 	PKI													 _Q12(0.008)												  	    // speed loop KI
 
 /*速度环调节参数*/
 #define SKP                            _Q12(0.7)                               // 外环KP
 #define SKI                            _Q12(0.005)                              // 外环KI

 #define SOUTMAX                        I_Value(56.0)                           // (A) 外环最大限幅值
 #define SOUTMIN                        I_Value(0.0)                            // (A) 外环最小限幅值

 #define SPEED_INC                      (400.0)                                 // 速度环增量
 #define SPEED_DEC                      (400.0)                                 // 速度环减量
 
 /*限流环调节参数*/
 #define 	I_LimtValue(Curr_limt)			  (uint16)(143.0*Curr_limt)													
 #define 	I_LimtValue_Up							  I_LimtValue(31.5)													  
 #define 	I_LimtValue_Out							  I_LimtValue(30.0)		                    //限制电流											 
 #define 	I_LimtValue_Dw							  I_LimtValue(27.0)

// #define 	I_LimtValue_Up_Start				  I_LimtValue(40.5)													  
// #define 	I_LimtValue_Out_Start				  I_LimtValue(40.0)		                    //限制电流											 
// #define 	I_LimtValue_Dw_Start				  I_LimtValue(39.5)


/*模式选择设置值----------------------------------------------------------------*/
 /*IPM测试模式*/
 #define IPMtest                        (0)                                     // IPM测试或者MOS测试，MCU输出固定占空比
 #define NormalRun                      (1)                                     // 正常按电机状态机运行
 #define IPMState                       (NormalRun)

/*Motor  Direction: CW or CCW*/
 #define  CW										        (0)														          // CW ,正转
 #define  CCW									          (1)														          // CCW,反转
 #define  MotorDirection                (CW)

 /*估算器模式选择*/
 #define SMO                            (0)                                     // SMO ,滑膜估算
 #define PLL                            (1)                                     // PLL ,锁相环
 #define EstimateAlgorithm              (SMO)

 /*开环启动模式选择*/
 #define Open_Start                     (0)                                     // 开环强拖启动
 #define Omega_Start                    (1)                                     // Omega启动
 #define Open_Omega_Start               (2)                                     // 先开环启，后Omega启动
 #define Open_Start_Mode                (Omega_Start)

 /*电流采样模式*/
 #define Single_Resistor                (0)                                     // 单电阻电流采样模式
 #define Double_Resistor                (1)                                     // 双电阻电流采样模式
 #define Three_Resistor                 (2)                                     // 三电阻电流采样模式
 #define Shunt_Resistor_Mode            (Single_Resistor)

/*SVPWM mode*/
 #define SVPWM_5_Segment                 (0)                                    // 五段式SVPWM
 #define SVPWM_7_Segment                 (1)                                    // 七段式SVPWM
 #define SVPMW_Mode                      (SVPWM_7_Segment)

/*OverModulation mode:enable or disable*/
 #define OverModulation                  (Enable)                               // Enable-禁止过调制，Disable-使能过调制


/*保护参数值-------------------------------------------------------------------*/
 /*硬件过流保护*/
 #define Hardware_FO_Protect            (1)                                     // 硬件FO过流保护使能，适用于IPM有FO保护的场合
 #define Hardware_CMP_Protect           (2)                                     // 硬件CMP比较过流保护使能，适用于MOS管应用场合
 #define Hardware_FO_CMP_Protect        (3)                                     // 硬件CMP比较和FO过流保护都使能
 #define Hardware_Protect_Disable       (4)                                     // 硬件过流保护禁止，用于测试
 #define HardwareCurrent_Protect        (Hardware_CMP_Protect)                  // 硬件过流保护实现方式

 /*硬件过流保护比较值来源*/
 #define Compare_DAC                    (0)                                     // DAC设置硬件过流值
 #define Compare_Hardware               (1)                                     // 硬件设置硬件过流值
 #define Compare_Mode                   (Compare_DAC)                           // 硬件过流值的来源
 
 /*硬件过流保护*/
 #define OverHardcurrentValue           (150.0)                                 // (A) DAC模式下的硬件过流值

 /*软件过流保护*/
 #define  OverSoftCurrentProtect        (1)                                     // 软件过流保护：1--使能 0--禁止  						
 #define 	OverSoftCurrent							  I_LimtValue(80.0)                       // (A) 软件过流值
 #define 	OverSoftCurrentTime           (500)                                   // (ms)软件过流检测时间

 /*过欠压保护*/
 #define VoltageProtect                 (1)                                     // 电压保护：1--使能  0--禁止  
 #define Over_Protect_Voltage           (43.0)                                  // (V) 直流电压过压保护值
 #define Over_Recover_Vlotage           (42.0)                                  // (V) 直流电压过压保护恢复值
 #define Under_Protect_Voltage          (24.0)                                  // (V) 直流电压欠压保护值
 #define Under_Recover_Vlotage          (26.0)                                  // (V) 直流电压欠压保护恢复值

 /*缺相保护*/
 #define PhaseLossProtect               (1)                                     // 缺相保护：1--使能  0--禁止  
 #define PhaseLossCurrentValue          I_Value(0.13)                           // (A)  缺相电流值
 #define PhaseLossRecoverTime           (600)                                   // (ms) 缺相保护时间

 /*堵转保护*/
 #define StallProtect                   (1)                                     // 堵转保护：1--使能  0--禁止  
 #define StallCurrentValue1             I_Value(4.4)                            // (A)  堵转过流值
 #define StallRecoverTime               (1000)                                  // (ms) 启动运行时间

 /*启动保护*/
 #define StartProtect                   (0)                                     // 启动保护：1--使能  0--禁止  
 #define StartProtectRestartTimes       (5)                                     // 启动保护重启次数，单位：次

 /*Mos温度保护*/
 #define  Tempera_Value(NTC_Value) 		    _Q15((5.0*NTC_Value/(10.0+NTC_Value))/4.5)
 
 #define 	Mos_TemperatureProtectEnable      (0)														      // MOS温度保护使能：1--使能  0--禁止
 #define  OVER_Mos_Temperature 		         Tempera_Value(1.261)					        // MOS过温保护阈值，根据NTC曲线设定  80度保护
 #define  UNDER_Mos_Temperature            Tempera_Value(1.757)					        // MOS低温恢复阈值，根据NTC曲线设定  70度恢复
 #define 	Over_Mos_TemperRecoverTime	     (1000)				                        // MOS过温恢复时间
 
 /*延时断电*/
 #define PDELAY                         (GP22)
 #define PDELAY_Vaule                   (15000)                                 //延时断电时间 单位：ms
 #define Pdelay_ON                      (GP22 = 1)
 #define Pdelay_OFF                     (GP22 = 0)


 /******启停测试参数******/
 #define StartONOFF                     (Disable)                               //程序自动启停测试：Enable--使能  Disable--禁止  
 #define StartON_Time                   (3500)                                  // (ms) 启动运行时间
 #define StartOFF_Time                  (2500)                                  // (ms) 停止时间

 #define StopBrakeFlag                  (0)
 #define StopWaitTime                   (2000)                                  // (ms) 刹车等待时间


#endif
