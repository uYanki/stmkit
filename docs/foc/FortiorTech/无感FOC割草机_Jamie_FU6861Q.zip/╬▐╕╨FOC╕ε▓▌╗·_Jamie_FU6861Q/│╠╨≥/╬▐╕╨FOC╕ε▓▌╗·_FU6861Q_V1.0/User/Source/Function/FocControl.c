/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : FocControl.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the foc control framework used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <FocControl.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ----------------------------------------------------------------------------*/
MotStaType mcState;
//MotStaTim  MotorStateTime;
MotStaM    McStaSet;
//TailWindSet xdata  mcTailwind;

/*---------------------------------------------------------------------------*/
/* Name     :   void MC_Control(void)
/* Input    :   NO
/* Output   :   NO
/* Description: 电机状态机函数，包括初始化、预充电、顺风逆风判断、预定位、启动、运行、故障等
/*---------------------------------------------------------------------------*/
uint8 ChargeFlag = 0;
void MC_Control(void)
{
    switch(mcState)
    {
        case mcReady:    // 关闭输出,上电会对电流进行采集校准,当采样校准结束标志置1且启动指令置1后，才跳转到mcInit
				{
					Motor_Ready();
					if((mcSpeedRamp.FlagONOFF == 1)
						&&(mcFocCtrl.mcDcbusFlt< OVER_RECOVER_VALUE)
					  &&(mcFocCtrl.mcDcbusFlt> UNDER_RECOVER_VALUE))
					{
						mcState = mcInit;
					}
				}
        break;

        case mcInit:                          // 初始化状态，进入mcCharge状态
				{
					Motor_Init();	
					mcState                   =  mcCharge;               // 跳入mcCharge状态
					mcFocCtrl.State_Count     = Charge_Time;
					
				}
        break;

        case mcCharge:                        // 预充电状态，MCU输出固定频率占空比，预充电结束后，跳入mcTailWind
				{
					if (ChargeFlag == 0)
					{
						Motor_Charge();
						ChargeFlag = 1;
          }
					
					#if (IPMState == NormalRun)           // 正常按电机状态机运行
					{
						if( mcFocCtrl.State_Count == 0)
						{
							MOE     = 0;                      // 关闭输出
							DRV_CMR &= 0xFFC0;							
							mcState = mcTailWind;					
						}
					}
					#endif
				 }
        break;
				 
				 
				case mcTailWind:
        #if (TailWind_Mode == NoTailWind)					// 无顺逆风处理的，直接跳入下一个状态
        mcState = mcBLDC;			

        #elif (TailWind_Mode == TailWind_BEMF_Method)	
        Motor_TailWind();

        #endif
        break;

				case mcBLDC:                          // 初始化状态，进入mcCharge状态
				{
					 Motor_BLDC();
				}
        break;

        case mcStart:                           // 配置电机启动参数，进入mcRun状态。
				{
//          Motor_Open();
				}
        break;

        case mcRun:                             // 运行状态，若运行状态的给定变为0，进入mcStop状态。
				{
					if(mcSpeedRamp.FlagONOFF == 0)
					{
						mcState    = mcStop;	
            BreakTime  = 1200;
            
            MOE        = 0;
            ClrBit(DRV_CR, FOCEN);
            TIM1_CR0 = 0;
            TIM1_CR1 = 0;
            TIM1_CR2 = 0;
            TIM1_CR3 = 0x04;
            TIM1_CR4 = 0;
            TIM1_IER = 0;
            FOC_CR1    = 0x00;
            /*关闭FOC*/
            ClrBit(DRV_CR, FOCEN);
          
            Driver_Init();	
            ClrBit(DRV_CR, OCS);		
            DRV_DR     = DRV_ARR;
            DRV_CMR	  |= 0x0015;	
            MOE        = 1;	
            _nop_();
//            McStaSet.SetFlag.TailWindSetFlag=0;					
            								
					}							
				}
        break;

        case mcStop:
				{
					if(BreakTime==0)
					{
              mcState = mcBrake;
              MOE     = 0;	
					}
					else if(mcSpeedRamp.FlagONOFF == 1) 
					{
              MOE     = 0;
              mcState = mcBrake;
              BreakTime = 0;
//						FOC_IQREF = IQ_RUN_CURRENT;								
					}
									
				}
        break;

        case mcBrake:
				{
					if(mcSpeedRamp.FlagONOFF == 1)
					{
						mcState = mcReady;					
					}		
				}
        break;

        case mcFault:
				{
            if(mcSpeedRamp.FlagONOFF == 0)
            {
              mcState = mcStop;					
            }	
        }
        break;
    }
}


