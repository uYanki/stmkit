/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : FocControl.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the foc control framework used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <FocControl.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ----------------------------------------------------------------------------*/
MotStaType mcState;
//MotStaTim  MotorStateTime;
MotStaM    McStaSet;
//TailWindSet xdata  mcTailwind;

MotStaTim  MotorStateTime;

//uint16 TimeCnt;

TimeCnt Time;

mcHall_TypeDef  xdata mcHall;

/*---------------------------------------------------------------------------*/
/* Name     :   void MC_Control(void)
/* Input    :   NO
/* Output   :   NO
/* Description: 电机状态机函数，包括初始化、预充电、顺风逆风判断、预定位、启动、运行、故障等
/*---------------------------------------------------------------------------*/
void MC_Control(void)
{
    switch(mcState)
    {
        case mcInit:                          					// 初始化状态，进入mcCharge状态
					
						VariablesPreInit();                           // 电机相关变量初始化
				
						//初始化方向
						mcHall.GivenFRStatus          = SetDirection;// ~RollBack;        
						
					
						if(mcCurOffset.OffsetFlag != 3)
						{
							mcCurOffset.OffsetFlag = 2;
						}							
															
						if(mcHall.LastHallSpeed < Q15(50.0/MOTOR_SPEED_BASE))
						{				
							if(mcHall.GivenFRStatus == CW) 
							 {
								mcHall.StartAngleOffset   = StartAngleCW;
							 }
							 else if(mcHall.GivenFRStatus == CCW) 
							 {
								mcHall.StartAngleOffset   = StartAngleCCW;
							 }
							 
								mcState = mcStart;
												 
								MotorStateTime.InitOneTime    = 0;				
								MotorStateTime.OpenOneTime    =0;
						}
						else 
						{					
							mcHall.HallDirectStartStatus = 1;
							
							Time.mcRunStateCount=0;
																			
							mcState = mcStart;
						
							MotorStateTime.InitOneTime    = 0;
							
							MotorStateTime.OpenOneTime    =0;
						}
        break;

//        case mcCharge:											// 预充电状态，MCU输出固定频率占空比，预充电结束后，跳入mcTailWind
//            Motor_Charge();
//            #if (IPMState == NormalRun)							// 正常按电机状态机运行
//						if( mcFocCtrl.State_Count == 0)
//						{
//							MOE = 0;									// 关闭输出

//							mcState		= mcTailWind;
//							mcFocCtrl.State_Count = 0;
//						}

//            #endif
//        break;

//        case mcTailWind:
//					
//            #if (TailWind_Mode == NoTailWind)					// 无顺逆风处理的，直接跳入下一个状态
//                mcState                           = mcPosiCheck;
//                McStaSet.SetFlag.PosiCheckSetFlag = 0;
//                mcFocCtrl.mcPosCheckAngle         = 0xffff;		// 角度赋初值

//            #elif (TailWind_Mode == TailWind)
//                Motor_TailWind();

//            #endif
//        break;

//        case mcPosiCheck:
//					
//            #if (PosCheckEnable==0)								//初始位置检测不使能时初始角度为预定位角度
//                mcFocCtrl.mcPosCheckAngle = Align_Angle;
//                mcState = mcAlign;
//                mcFocCtrl.State_Count = Align_Time;

//            #else
//                RPD();

//            #endif
//        break;

//        case mcAlign:       // 预定位时间结束后，直接启动; AlignTestMode=1用于初始位置检测调试用
//            Motor_Align();

//            #if (AlignTestMode==1)
//                while(1);

//            #else
//                if(mcFocCtrl.State_Count == 0) mcState = mcStart;

//            #endif
//        break;

        case mcStart:                           // 配置电机启动参数，进入mcRun状态。
            Motor_Open();
				
						mcState = mcRun;
        break;

//				case mcPllTect:                           // 配置电机启动参数，进入mcRun状态。
//						#if (EstimateAlgorithm == PLL)
//								Motor_PllStart();

//						#endif
//				break;

        case mcRun:                             // 运行状态，若运行状态的给定变为0，进入mcStop状态。

        break;

        case mcStop:
	
						MotorStop();	

//							FOC_CR1 = 0x00;
//							MOE = 0;
//							/*关闭FOC*/
//							ClrBit(DRV_CR, FOCEN);				
               
        break;

        case mcBrake:

        break;

        case mcFault:
        break;
    }
}


