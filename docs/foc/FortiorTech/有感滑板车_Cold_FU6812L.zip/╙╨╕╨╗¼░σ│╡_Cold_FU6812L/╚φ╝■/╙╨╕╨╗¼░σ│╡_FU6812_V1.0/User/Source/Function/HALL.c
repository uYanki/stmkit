/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains MDU initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>


//HALL �ͺ󷴵綯��25��
//#define	HallDetaAngle		         _Q15(10.0/180.0)    					// HALL��ǰ+�����ͺ�-��  ccw60
// �����ͷ��綯�Ƽ�����ͬ   //5->1->3->2->6->4   0��->60��->120��->180��->240��->300��
int16 xdata Hall_Angle_Arr[6] = {_Q15(91.6/180.0),_Q15(211.6/180.0),_Q15(151.6/180.0),_Q15(331.6/180.0),_Q15(31.6/180.0),_Q15(271.6/180.0)};	

/*---------------------------------------------------------------------------*/
/* Name		:	uint8  HallCommutation(uint8 GivenFR_Status ,uint8 Hall_Status_Result )
/* Input	:	GivenFR_Status ��ǰ����Hall_Status_Result��ǰhall�ź�
/* Output	:	Hall_Status_Next ��һ��hall�ź�
/* Description:	
/*---------------------------------------------------------------------------*/
uint8  HallCommutation(uint8 GivenFR_Status ,uint8 Hall_Status_Result)
{
	static uint8 Hall_Status_Next = 0;
   	//CW  5->1->3->2->6->4
		if(GivenFR_Status == CW)
		{	
				switch(Hall_Status_Result)
				{
					case 1:
						Hall_Status_Next = 3;
						break;
					case 2:
						Hall_Status_Next = 6;
						break;
					case 3:
						Hall_Status_Next = 2;
						break;
					case 4:
						Hall_Status_Next = 5;
						break;
					case 5:
						Hall_Status_Next = 1;
						break;
					case 6:
						Hall_Status_Next = 4;
						break;
					default:
						break;
				 }
		 }		 
		//CCW 5->4->6->2->3->1
		if(GivenFR_Status == CCW)
		{
			switch(Hall_Status_Result)
			{
				case 1:
				  Hall_Status_Next = 5;
					break;
				case 2:
				  Hall_Status_Next = 3;
					break;
				case 3:
				  Hall_Status_Next = 1;
					break;
				case 4:
				  Hall_Status_Next = 6;
					break;
				case 5:
				  Hall_Status_Next = 4;
					break;
				case 6:
				  Hall_Status_Next = 2;
					break;
				default:
					break;
			}
		}
		return Hall_Status_Next;
}


void HallStatus_CaptureFilter(void)
{
	mcHall.HallStatus_Filter2    = mcHall.HallStatus_Filter1;	

	#if (HallFilterlingEnable)
	{
		mcHall.HallStatus_Filter1    = HALLSignalDisposeFilter(mcHall.HallCommutationCount,mcHall.GivenFRStatus,HALLA,HALLB,HALLC);  
	}
	#else
	{
		mcHall.HallStatus_Filter1    = HALLSignalDisposeWithoutFilter(mcHall.HallCommutationCount,mcHall.GivenFRStatus,HALLA,HALLB,HALLC);  
  }
	#endif
	
	 if((mcHall.HallStatus_Filter1  == mcHall.HallStatus_Filter2)
		 &&(mcHall.HallStatus_Filter2 != 0))
	 {
		 mcHall.HallStatus_Result = mcHall.HallStatus_Filter2;
	 }
   else if(mcHall.HallStatus_Filter2==0)
	 {
		 mcHall.HallStatus_Result = mcHall.HallStatus_Filter1;
   }		 
}

void HallTimeCapture(void)
{
	Hall_RTHESTEP_Capture();  //�ٶȼ��㼰���ٶȴ��� 27us
		
	Hall_THETA_Capture();	    //�Ƕȴ��� 14.6us	
	
}

