#ifndef __MYUART_H_
#define __MYUART_H_

/* Exported functions ---------------------------------------------------------------------------*/
extern void SendDataByUart(int in_show);
extern void Send_U_DataByUart(unsigned int in_show);

#endif