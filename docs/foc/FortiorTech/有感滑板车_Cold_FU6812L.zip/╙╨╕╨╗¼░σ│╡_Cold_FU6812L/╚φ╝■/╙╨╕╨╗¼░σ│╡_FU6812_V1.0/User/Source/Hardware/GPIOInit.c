/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : GPIOInit.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 010-Apr-2017
* Description        : This file contains GPIO initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>

/*-------------------------------------------------------------------------------------------------
	Function Name :	void GPIO_Default_Init(void)
	Description   :	为提高芯片的抗干扰能力，降低芯片功耗，请在具体项目时，将不需要用的GPIO默认都配置为输入上拉。
	Input         :	无
  Output				:	无
-------------------------------------------------------------------------------------------------*/
void GPIO_Default_Init(void)//为提高芯片的抗干扰能力，降低芯片功耗，请在具体项目时，将不需要用的GPIO默认都配置为输入上拉。
{
//  P2_OE = 0;
//  P2_PU = P21|P22|P23|P24|P25|P26|P27;      // 需确认这些端口能接受上拉
//  
//  P3_OE = 0;
//  P3_PU = P30|P31|P32|P33|P34|P35|P36|P37;  // 需确认这些端口能接受上拉
//  
//  P0_OE = 0;
//  P0_PU = P00|P01|P02|P03|P04|P05|P06|P07;  // 需确认这些端口能接受上拉
//  
//  P1_OE = 0;
//  P1_PU = P10|P11|P12|P13|P14|P15|P16|P17;  // 需确认这些端口能接受上拉
//  
//  P4_OE = 0;
//  P4_PU = P40|P41;                          // 使用步进电机时，P40，P41不能配置输入上拉，上拉会导致直通
	
	P0_OE = P07;
	P0_PU = P07;
	GP07 = 0;
	
  
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void GPIO_Init(void)
	Description   :	GPIO初始化配置,可将I/O口配置成输入或输出模式，上拉还是不上拉，模拟输出还是数字输出
	Input         :	无
  Output				:	无
-------------------------------------------------------------------------------------------------*/
void GPIO_Init(void)
{
//		P3_OE = P36|P37;
//	P0_OE = P06;
//  P0_PU = P06;
	
//	P3_PU = P37;

//  GP36=0;
//  GP37=0;
	
//	GP06=0;
	  
  //LED灯IO口初始化
	P4_OE = P42;
  GP42=0;
	
//	ClrBit(P3_OE, P33);	
//	ClrBit(P3_PU, P33);	
	
	ClrBit(P0_OE, P00);	
	ClrBit(P0_PU, P00);	

	/**************Hall接口********************/
	ClrBit(P3_OE, P36);	
	ClrBit(P3_PU, P36);	
	
	ClrBit(P0_OE, P02);	
	ClrBit(P0_PU, P02);	
	
	ClrBit(P3_OE, P37);	
	ClrBit(P3_PU, P37);	
	
	
	
	

	ClrBit(P0_OE, P01);	
	ClrBit(P0_PU, P01);	
	
	ClrBit(P0_OE, P02);	
	ClrBit(P0_PU, P02);	
	
	ClrBit(P0_OE, P03);	
	ClrBit(P0_PU, P03);	
	
	ClrBit(P3_OE, P33);	
	ClrBit(P3_PU, P33);
	
	//ClrBit(P0_OE, P07);	
	//ClrBit(P0_PU, P07);
	
//	ClrBit(P1_OE, P14);	
//	ClrBit(P1_PU, P14);
//	SetBit(P3_OE, P35);	
//	ClrBit(P3_PU, P35);	
//	GP35=0;
}

