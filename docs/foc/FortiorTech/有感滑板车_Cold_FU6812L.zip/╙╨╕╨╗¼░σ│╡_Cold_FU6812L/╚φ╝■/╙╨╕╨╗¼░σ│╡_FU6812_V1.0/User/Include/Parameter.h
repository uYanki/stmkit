/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Parameter.h
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-20
* Description        : This file contains all FOC debug parameter.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/

#ifndef __Parameter_H_
#define __Parameter_H_

/* Define to prevent recursive inclusion -------------------------------------*/
/* Q format define ---------------------------------------------------------------------------------*/
#define _Q7(A)                          (int8)(A * 128)
#define _Q10(A)                         (int16)(A * 1024)                                             // Q15 format
#define _Q11(A)                         (int16)(A * 2048)                                                 // Q12 format
#define _Q12(A)                         (int16)(A * 4096)                                                 // Q12 format
#define _Q13(A)                         (int16)(A * 8192)                                                 // Q12 format
#define _Q15(A)                         (int16)(A * 32767)                                                // Q15 format
#define _2PI                            (3.1415926 * 2)                                                 // 2 PI value
#define _Q16                            (65535.0)                                                               // Q16 format value
/* Private define ------------------------------------------------------------*/
#define SystemPowerUpTime               (10000)                                                    // 上电等待时间，cpu计数时钟

/*芯片参数值------------------------------------------------------------------*/
/*CPU and PWM Parameter*/
#define PWM_CYCLE                       (1000.0 / PWM_FREQUENCY)                                  // 周期us
#define SAMP_FREQ                       (PWM_FREQUENCY * 1000)                                    // 采样频率(HZ)
#define TPWM_VALUE                      (1.0 / SAMP_FREQ)                                         // 载波周期(S)
#define PWM_VALUE_LOAD                  (uint16)(MCU_CLOCK * 500 / PWM_FREQUENCY)                 // PWM 定时器重载值

/*double resistor sample Parameter*/
#define DLL_TIME                        (1.0)                                                                     // 双电阻最小脉宽设置(us),建议值为死区时间值+0.2us以上
/*three resistor overmodule Parameter*/
#define OVERMOD_TIME                    (2.0)                                                                       // 三电阻过调制时间(us)，建议值2.0
/*deadtime compensation*/
#define DT_TIME                         (0.0)                                   // 死区补偿时间(us)，适用于双电阻和三电阻，建议值是1/2死区时间
/*min pulse*/
#define GLI_TIME                        (0.5)                                     // 桥臂窄脉宽消除(us),建议值0.5

/*deadtime Parameter*/
#define PWM_LOAD_DEADTIME               (PWM_DEADTIME * MCU_CLOCK)                          // 死区设置值
#define PWM_OVERMODULE_TIME             (OVERMOD_TIME * MCU_CLOCK / 2)                        // 过调制时间
#define PWM_DLOWL_TIME                  (DLL_TIME * MCU_CLOCK / 2)                    //下桥臂最小时间
/*single resistor sample Parameter*/
#define PWM_TS_LOAD                     (uint16)(_Q16 / PWM_CYCLE * MIN_WIND_TIME / 16)            // 单电阻采样设置值
#define PWM_DT_LOAD                     (uint16)(_Q16 / PWM_CYCLE * DT_TIME / 16)                  // 死区补偿值
#define PWM_TGLI_LOAD                   (uint16)(_Q16 / PWM_CYCLE * (GLI_TIME + PWM_DEADTIME) / 16)  // 最小脉冲

/*硬件板子参数设置值------------------------------------------------------------------*/
/*hardware current sample Parameter*/
/*电流基准的电路参数*/
#define HW_BOARD_CURR_MAX               (HW_ADC_REF / 2 / HW_AMPGAIN / HW_RSHUNT)         // 最大采样电流,2.702A
#define HW_BOARD_CURR_MIN               (-HW_BOARD_CURR_MAX)                                        // 最小采样电流,-2.702A
#define HW_BOARD_CURR_BASE              (HW_BOARD_CURR_MAX * 2)                                       // 电流基准//5.4A

/*hardware voltage sample Parameter*/
/*母线电压采样分压电路参数*/
#define HW_BOARD_VOLTAGE_BASE           (HW_BOARD_VOLT_MAX / 1.732)                              // 电压基准
#define HW_BOARD_VOLTAGE_VC             ((RV1 + RV2 + RV3 * VC1) / (RV3 * VC1))
#define HW_BOARD_VOLTAGE_BASE_Start     (HW_ADC_REF * HW_BOARD_VOLTAGE_VC / 1.732)               // 电压基准


/*硬件过流保护DAC值*/
#define DAC_OvercurrentValue            _Q7(I_ValueX(OverHardcurrentValue*2))//+0x7F

#define Align_Theta                     _Q15((float)Align_Angle / 180.0)

#define BASE_FREQ                       ((MOTOR_SPEED_BASE / 60) * Pole_Pairs)  // 基准频率

/*保护参数值------------------------------------------------------------------*/
/* protect value */
#define OVER_PROTECT_VALUE              _Q15(Over_Protect_Voltage  / HW_BOARD_VOLT_MAX)
#define UNDER_PROTECT_VALUE             _Q15(Under_Protect_Voltage / HW_BOARD_VOLT_MAX)
#define OVER_RECOVER_VALUE              _Q15(Over_Recover_Vlotage  / HW_BOARD_VOLT_MAX)
#define UNDER_RECOVER_VALUE             _Q15(Under_Recover_Vlotage / HW_BOARD_VOLT_MAX)


/* motor speed set value */
#define Motor_Open_Ramp_ACC             _Q15(MOTOR_OPEN_ACC     / MOTOR_SPEED_BASE)
#define Motor_Open_Ramp_Min             _Q15(MOTOR_OPEN_ACC_MIN / MOTOR_SPEED_BASE)

#define Motor_Omega_Ramp_Min            _Q15(MOTOR_OMEGA_ACC_MIN / MOTOR_SPEED_BASE)
#define Motor_Omega_Ramp_End            _Q15(MOTOR_OMEGA_ACC_END / MOTOR_SPEED_BASE)

#define Motor_Loop_Speed                _Q15(MOTOR_LOOP_RPM / MOTOR_SPEED_BASE)

#define Motor_Max_Speed                 _Q15(MOTOR_SPEED_MAX_RPM   / MOTOR_SPEED_BASE)
#define Motor_Min_Speed                 _Q15(MOTOR_SPEED_MIN_RPM   / MOTOR_SPEED_BASE)
#define Motor_Limit_Speed               _Q15(MOTOR_SPEED_LIMIT_RPM / MOTOR_SPEED_BASE)
#define Motor_Stop_Speed                _Q15(MOTOR_SPEED_STOP_RPM  / MOTOR_SPEED_BASE)

#define Motor_Stall_Min_Speed           _Q15(MOTOR_SPEED_STAL_MIN_RPM / MOTOR_SPEED_BASE)
#define Motor_Stall_Max_Speed           _Q15(MOTOR_SPEED_STAL_MAX_RPM / MOTOR_SPEED_BASE)

#define Motor_RD_Speed                  _Q15(MOTOR_SPEED_RD_RPM    / MOTOR_SPEED_BASE)
#define Motor_RDPT_Speed                _Q15(MOTOR_SPEED_RDPT_RPM  / MOTOR_SPEED_BASE)
#define Motor_RDRCV_Speed               _Q15(MOTOR_SPEED_RDRCV_RPM / MOTOR_SPEED_BASE)

/*外环增量*/
#define Motor_Speed_Inc                 _Q15(SPEED_INC / MOTOR_SPEED_BASE)
#define Motor_Speed_Dec                 _Q15(SPEED_DEC / MOTOR_SPEED_BASE)

#define SPEED_K                         ((float)(Motor_Max_Speed-Motor_Min_Speed)/(float)(MAXPWMDuty-MINPWMDuty))
#define POWER_K                         ((float)(Motor_Max_Power-Motor_Min_Power)/(float)(MAXPWMDuty-MINPWMDuty))

/* obsever parameter set value */
#define MAX_BEMF_VOLTAGE                ((MOTOR_SPEED_BASE*Ke)/(1000.0))
#define MAX_OMEG_RAD_SEC                ((float)(_2PI*BASE_FREQ))
#define OBS_K1T                         _Q15(LD/(LD+RS*TPWM_VALUE))
#define OBS_K2T                         _Q13((TPWM_VALUE/(LD+RS*TPWM_VALUE))*(HW_BOARD_VOLTAGE_BASE_Start/HW_BOARD_CURR_BASE))
#define OBS_K2T_SMO                     _Q13((TPWM_VALUE/(LD+RS*TPWM_VALUE))*1.4*(HW_BOARD_VOLTAGE_BASE_Start/HW_BOARD_CURR_BASE))
#define OBS_K2T_Actual                  _Q13((TPWM_VALUE/(LD+RS*TPWM_VALUE))*(HW_BOARD_VOLTAGE_BASE/HW_BOARD_CURR_BASE))
#define OBS_K3T                         _Q15((TPWM_VALUE/(LD+RS*TPWM_VALUE))*(MAX_BEMF_VOLTAGE/HW_BOARD_CURR_BASE))
#define OBS_K4T                         _Q15(((LD-LQ)*TPWM_VALUE*MAX_OMEG_RAD_SEC)/(LD+RS*TPWM_VALUE))

#define OBSW_KP_GAIN                    _Q12(2*_2PI*ATT_COEF*ATO_BW/BASE_FREQ)
#define OBSW_KI_GAIN                    _Q15(_2PI*ATO_BW*ATO_BW*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN                _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN/BASE_FREQ)
#define OBSW_KI_GAIN_RUN                _Q15(_2PI*ATO_BW_RUN*ATO_BW_RUN*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN1               _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN1/BASE_FREQ)
#define OBSW_KI_GAIN_RUN1               _Q15(_2PI*ATO_BW_RUN1*ATO_BW_RUN1*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN2               _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN2/BASE_FREQ)
#define OBSW_KI_GAIN_RUN2               _Q15(_2PI*ATO_BW_RUN2*ATO_BW_RUN2*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN3               _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN3/BASE_FREQ)
#define OBSW_KI_GAIN_RUN3               _Q15(_2PI*ATO_BW_RUN3*ATO_BW_RUN3*TPWM_VALUE/BASE_FREQ)

#define OBSW_KP_GAIN_RUN4               _Q12(2*_2PI*ATT_COEF*ATO_BW_RUN4/BASE_FREQ)
#define OBSW_KI_GAIN_RUN4               _Q15(_2PI*ATO_BW_RUN4*ATO_BW_RUN4*TPWM_VALUE/BASE_FREQ)

#define OBS_FBASE                       BASE_FREQ*TPWM_VALUE*32768                          // Fbase*Tpwm*32768
#define OBS_KLPF                        _Q15(_2PI*BASE_FREQ*TPWM_VALUE)                 // 2PI*Fbase*Tpwm
#define SPEED_KLPF                      _Q15(_2PI*SPD_BW*TPWM_VALUE)                        // 2PI*SPD_BW*Tpwm
#define OBS_EA_KS                       _Q15((2*MOTOR_SPEED_SMOMIN_RPM*_2PI*BASE_FREQ*TPWM_VALUE)/MOTOR_SPEED_BASE)     // SMO的最小速度

#define OBSE_PLLKP_GAIN_WIND            _Q11(((2*ATT_COEF*_2PI*E_BW_Wind*LD - RS)*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)
#define OBSE_PLLKI_GAIN_WIND            _Q11((_2PI*E_BW_Wind*_2PI*E_BW_Wind*LD*TPWM_VALUE*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)

#define OBSE_PLLKP_GAIN                 _Q11(((2*ATT_COEF*_2PI*E_BW*LD - RS)*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)
#define OBSE_PLLKI_GAIN                 _Q11((_2PI*E_BW*_2PI*E_BW*LD*TPWM_VALUE*HW_BOARD_CURR_BASE)/HW_BOARD_VOLTAGE_BASE)

/*逆风判断时的估算算法设置值------------------------------------------------------------*/
#define SPEED_KLPF_WIND                 _Q15(_2PI*SPD_BW_Wind*TPWM_VALUE)           // 2PI*SPD_BW_Wind*Tpwm
#define OBSW_KP_GAIN_WIND               _Q12(2*_2PI*ATT_COEF*ATO_BW_Wind/BASE_FREQ)
//#define   OBSW_KI_GAIN_WIND           _Q15(_2PI*0.5*ATO_BW_Wind*ATO_BW_Wind*TPWM_VALUE/BASE_FREQ)//---SMO
#define OBSW_KI_GAIN_WIND               _Q15(_2PI*ATO_BW_Wind*ATO_BW_Wind*TPWM_VALUE/BASE_FREQ)//---PLL


#if (Motor_Speed_Control_Mode == Speed_OpenLoop_Enable)

#define 	Motor_Voltage_Inc							_Q15(Duty_INC/MOTOR_SPEED_BASE)							
#define 	Motor_Voltage_Dec							_Q15(Duty_DEC/MOTOR_SPEED_BASE)							

#endif

#define 	Motor_SoftStart_Inc						_Q15(Duty_SoftStart_INC/MOTOR_SPEED_BASE)

#define  MOTOR_RUN_RecoilVoltage    _Q15(Motor_Run_RecoilVoltage/HW_BOARD_VOLT_MAX)

/*Current Calib:enable or disable*/
#define Disable                         (0)                                                               //
#define Enable                          (1)                                                             //
#define CalibENDIS                      (Enable)

/*SVPWM mode*/
#define SVPWM_5_Segment                 (0)                                                            // 五段式SVPWM
#define SVPWM_7_Segment                 (1)                                                            // 七段式SVPWM
#define SVPMW_Mode                      (SVPWM_7_Segment)

/*double resistor sample mode*/
#define DouRes_1_Cycle                  (0)                                                            // 1 周期采样完 ia, ib
#define DouRes_2_Cycle                  (1)                                                            // 交替采用ia, ib, 2周期采样完成
#define DouRes_Sample_Mode              (DouRes_1_Cycle)

/*时间设置值-------------------------------------------------------------------*/
 #define Calib_Time                     (1000)                                  // 校正次数，固定1000次，单位:次
 #define Charge_Time                    (3)                                     // (ms) 预充电时间，单位：ms
 #define Align_Time                     (3)                                     // (ms) 预定位时间，单位：ms
 
/*正常运行时估算算法的参数设置值-------------------------------------------------*/
 #define OBS_KSLIDE                     _Q15(0.85)                              // SMO算法里的滑膜增益值
 #define E_BW_Wind                      (600.0)//(BASE_FREQ*2)                  // PLL算法里的反电动势滤波值
 
 #define E_BW                           (400.0)//(BASE_FREQ*2)                  // PLL算法里的反电动势滤波值
/*逆风判断时的估算算法设置值-----------------------------------------------------*/
 #define TailWind_Time                  (250)                                   // (ms) 顺逆风检测时间
 #define ATO_BW_Wind                    (100.0)//120.0-PLL 120.0-smo            // 逆风判断观测器带宽的滤波值，经典值为8.0-100.0
 #define SPD_BW_Wind                    (10.0)//10.0-PLL  ,10.0-smo             // 逆风判断速度带宽的滤波值，经典值为5.0-40.0

 /**逆风顺风状态下的KP、KI****/
 #define DQKP_TailWind                  _Q12(1.0)                               //_Q12(1.0)-PLL ,   _Q12(1.5)   -smo
 #define DQKI_TailWind                  _Q15(0.16)                              //_Q15(0.08)-PLL  ,_Q15(0.2)-smo
/*启动参数参数值----------------------------------------------------------------*/
 /*********** RPD parameter ***********/
 /******* 初始位置检查参数 **********/
 #define PosCheckEnable                 (0)                                     // 初始位置使能
 #define AlignTestMode                  (0)                                     // 预定位测试模式
 /*脉冲注入时间长于2ms 或 低于2ms*/
 #define Long_Inject                    (0)                                     // 脉冲注入时间长于2ms,若时间长于4ms，则要修改定时器分频
 #define Short_Inject                   (1)                                     // 脉冲注入时间低于2ms
 #define InjectTime                     (Short_Inject)

 #define RPD_Time                       (3)                                     // (ms) 每次RPD的时间
 #define RPD_CurValue                   (1.0)                                   // (A)  RPD过流值
 #define DAC_RPDCurValue                _Q7(I_ValueX(RPD_CurValue * 2))

 /***预定位的Kp、Ki****/
 #define DQKP_Alignment                 _Q12(0.5)                               // 预定位的KP
 #define DQKI_Alignment                 _Q12(0.05)                              // 预定位的KI
 #define ID_Align_CURRENT               I_Value(0.0)                            // (A) D轴定位电流
 #define IQ_Align_CURRENT               I_Value(0.5)                            // (A) Q轴定位电流
 #define Align_Angle                    (0.0)                                   // (°) 预定位角度
 
 /********Omega启动的参数**********/
 #define ATO_BW                         (15.0)                                  // 观测器带宽的滤波值，经典值为1.0-200.0
 #define ATO_BW_RUN                     (15.0)
 #define ATO_BW_RUN1                    (22.0)
 #define ATO_BW_RUN2                    (40.0)
 #define ATO_BW_RUN3                    (50.0)
 #define ATO_BW_RUN4                    (66.0)

 #define SPD_BW                         (15.0)                                  // 速度带宽的滤波值，经典值为5.0-40.0
 #define ATT_COEF                       (0.85)                                  // 无需改动
/*转速参数值-------------------------------------------------------------------*/
 /* motor start speed value */
 //open 算法启动参数
 #define MOTOR_OPEN_ACC                 (30.0)                                  // 强拖启动的增量(每载波周期加一次)
 #define MOTOR_OPEN_ACC_MIN             (0.0)                                   // 强拖启动的初始速度
 #define MOTOR_OPEN_ACC_CNT             (100.0)                                 // 强拖启动的执行次数(MOTOR_OPEN_ACC_CNT*256)
 #define MOTOR_OPEN_ACC_CYCLE           (1)                                     // 强拖启动循环拖动的次数

 //OMEGA启动参数
 #define Motor_Omega_Ramp_ACC_Antiwind  (15.0)                                  // omega启动的增量   12
 #define Motor_Omega_Ramp_ACC           (5.0)                                   // omega启动的增量   12
 #define MOTOR_OMEGA_ACC_MIN            (15.0)                                  // (RPM) omega启动的最小切换转速
 #define MOTOR_OMEGA_ACC_END            (60.0)                                  // (RPM) omega启动的限制转速

 /* motor loop control speed value */
 #define MOTOR_LOOP_RPM                 (120.0)                                 // (RPM) 由mode 0到mode1切换转速，即闭环切换转速

 /* motor run speed value */
 //电机运行时最大最小转速、堵转保护转速
 #define MOTOR_SPEED_SMOMIN_RPM         (200.0)                                 // (RPM) SMO运行最小转速
 #define MOTOR_SPEED_MIN_RPM            (200.0)                                // (RPM) 运行最小转速
 #define MOTOR_SPEED_MAX_RPM            (1800.0)                                // (RPM) 运行最大转速
 #define MOTOR_SPEED_LIMIT_RPM          (2000.0)
 #define MOTOR_SPEED_STAL_MAX_RPM       (3500.0)                                // (RPM) 堵转保护转速
 #define MOTOR_SPEED_STAL_MIN_RPM       (45.0)

 #define MOTOR_SPEED_STOP_RPM           (250.0)                                 // (RPM) 运行最小转速

 #define Motor_Max_Power                (12600)
 #define Motor_Min_Power                (400)
 
 /*模式选择设置值----------------------------------------------------------------*/
 /*IPM测试模式*/
 #define IPMtest                        (0)                                     // IPM测试或者MOS测试，MCU输出固定占空比
 #define NormalRun                      (1)                                     // 正常按电机状态机运行
 #define IPMState                       (NormalRun)

 /*估算器模式选择*/
 #define SMO                            (0)                                     // SMO ,滑膜估算
 #define PLL                            (1)                                     // PLL ,锁相环
 #define EstimateAlgorithm              (SMO)

 /*顺逆风判断设置*/
 #define NoTailWind                     (0)                                     // 无逆风顺风判断
 #define TailWind                       (1)                                     // 逆风顺风判断
 #define TailWind_Mode                  (TailWind)

 /*顺逆风判断方法*/
 #define RSDMethod                      (0)                                     // RSD比较器方法
 #define BEMFMethod                     (1)                                     // BEMF方法
 #define FOCMethod                      (2)                                     // FOC计算方法
 #define FRDetectMethod                 (FOCMethod)
