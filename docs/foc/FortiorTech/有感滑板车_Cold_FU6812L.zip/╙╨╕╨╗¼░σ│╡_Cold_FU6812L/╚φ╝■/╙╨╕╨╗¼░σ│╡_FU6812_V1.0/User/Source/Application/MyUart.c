				
#include <FU68xx_2.h>
#include <Myproject.h>
#include <MyUart.h>	
/*-------------------------------------------------------------------------------------------------
	Function Name :	void SendDataByUart(void)
	Description   :	UART����һ��int�ͱ���
	Input         :	int�ͱ���
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void SendDataByUart(int in_show)
{
	unsigned char show_result[5];
	
	if(in_show < 0)
	{
		in_show = -in_show;
		UT_DR = '-';	
		while(!TI);
		TI = 0;
	}
	
  show_result[0] = in_show / 10000;
  show_result[1] = in_show / 1000 % 10;
  show_result[2] = in_show / 100 % 10;
  show_result[3] = in_show / 10 % 10;
  show_result[4] = in_show % 10;

	UT_DR = show_result[0] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[1] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[2] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[3] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[4] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = '\n';	
	while(!TI);
	TI = 0;			
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void SendDataByUart(void)
	Description   :	UART����һ��unsigned int�ͱ���
	Input         :	unsigned int�ͱ���
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void Send_U_DataByUart(unsigned int in_show)
{
	unsigned char show_result[5];
	
	
  show_result[0] = in_show / 10000;
  show_result[1] = in_show / 1000 % 10;
  show_result[2] = in_show / 100 % 10;
  show_result[3] = in_show / 10 % 10;
  show_result[4] = in_show % 10;

	UT_DR = show_result[0] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[1] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[2] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[3] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[4] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = '\n';	
	while(!TI);
	TI = 0;			
}