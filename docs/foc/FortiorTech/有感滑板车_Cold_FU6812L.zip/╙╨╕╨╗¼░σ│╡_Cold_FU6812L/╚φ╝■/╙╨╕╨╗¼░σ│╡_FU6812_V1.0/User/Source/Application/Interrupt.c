/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Interrupt.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the interrupt function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <Interrupt.h>
#include <FU68xx_2.h>
#include <Myproject.h>
#include <Customer_Debug.h>
#include <MyUart.h>	


uint16 xdata spidebug[4] = { 0 };
uint16 UartSendCnt = 0; //用于Uart发送数据定时器计数
int Test2 = -12345;

/*-------------------------------------------------------------------------------------------------
    Function Name : void FO_INT(void)
    Description   : FO_INT interrupt，硬件FO过流保护，关断输出，中断优先级最高
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void FO_INT(void) interrupt 1                                                   // 硬件FO过流中断，关闭输出
{
    FaultProcess();                                                             // 关闭输出
    mcFaultSource = FaultHardOVCurrent;                                         // 硬件过流保护
    mcState       = mcFault;                                                    // 状态为mcFault
    IF0           = 0;                                                          // clear P00 interrupt flag
}
/*-------------------------------------------------------------------------------------------------
    Function Name : void CMP_ISR(void)
    Description   : CMP3：硬件比较器过流保护，关断输出，中断优先级最高
										CMP0/1/2：顺逆风判断
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void CMP_ISR(void) interrupt 7
{
    if(ReadBit(CMP_SR, CMP3IF))
    {
//        if(mcState!=mcPosiCheck)
//        {
            //FaultProcess();                                                     // 关闭输出
            //mcFaultSource=FaultHardOVCurrent;                                   // 硬件过流保护
            //mcState = mcFault;                                                  // 状态为mcFault
//        }
//        else
//        {
//            MOE     = 0;                                                                        // 关闭MOE
//            RPDPara.InsetCount[RPDPara.injecttimes]  = TIM2__CNTR;                              // 将定时器2的计数值赋值给数组
//            RPDPara.DetectCount[RPDPara.injecttimes] = RPDPara.InsetCount[RPDPara.injecttimes]; // 两组数据，一组用于观察原始数据，一组用于处理数据
//            TIM2__CNTR                               = 0;                                       // TIM2计数器值清零
//            RPDPara.injecttimes++;                                                              // RPD注入拍数累加

//        }
        ClrBit(CMP_SR, CMP3IF);
    }

    #if (FRDetectMethod == BEMFMethod)
        //通过BEMF做顺风启动功能
        BEMFDetectFunc();
    #endif
}

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM2_INT(void) interrupt 4
/* Input    :   NO
/* Output   :   NO
/* Description:	
/*---------------------------------------------------------------------------*/
 uint16 TempLPFCurrentBUS =0;

void TIM2_INT(void) interrupt 4
{
	uint8  Temp_HallFR;
			
	static uint8 HallCommutationCnt = 0;
				
	static uint8 LockedDutyFLag = 0;
		
	static uint8 LockedFlag = 0;
	
	
    if(ReadBit(TIM2_CR1, T2IR))
    {
        ClrBit(TIM2_CR1, T2IR);
    }
		
    if(ReadBit(TIM2_CR1, T2IP))
    {
        ClrBit(TIM2_CR1, T2IP);
    }
		
    if(ReadBit(TIM2_CR1, T2IF))                          //溢出中断,时间为60us。
    {			
		  SetBit(ADC_CR, ADCBSY);          //使能ADC的DCBUS采样
					
//			if((0<=FOC__VBET)&&(FOC__VBET<=10))
//			{
				mcFocCtrl.mcADCProtectCurrentbus =(ADC4_DR<<3);  //母线电流采样，用于软件过流
					
//				TempLPFCurrentBUS =  (uint16) LPFFunction((ADC6_DR<<3),TempLPFCurrentBUS,120);
			
//			if(mcFocCtrl.mcADCProtectCurrentbus > mcCurOffset.Iw_busOffset)
//			{
//				mcFocCtrl.mcADCProtectCurrentbus = mcFocCtrl.mcADCProtectCurrentbus - mcCurOffset.Iw_busOffset;
//			}
//			else
//			{
//				mcFocCtrl.mcADCProtectCurrentbus = 0;
//      }
													
			if((mcHall.HALLHACWCCWTime > 200)||(mcHall.HALLHBCWCCWTime > 200)||(mcHall.HALLHCCWCCWTime >200)) 
			{
				mcHall.HallSpeed	= 0;
				
				mcFocCtrl.FreeStopDecStatus = 0;
						
				mcHall.HallSpeedInitStatus         = 0;			
			}
						
			HallStatus_CaptureFilter();                               //采集Hall信号      
		
			if(!mcFocCtrl.LockedEnbleFlag)  
			{
				if((mcHall.HallStatus_Result==7)||(mcHall.HallStatus_Result==0))
				{
					mcBreakDowm.BreakDowmValue = 3;	
					
					FaultProcess();	
					
					mcFaultSource = FaulHallFailure;
				}
				else
				{
					if((mcState == mcFault)&&(mcFaultSource == FaulHallFailure))
					{
						mcBreakDowm.BreakDowmValue = 0;
						
						mcState = mcStop;
						
						mcFaultSource = FaultNoSource;
					}				
				}
			}
	
			if(!mcHall.LockedFlag)  
			{			
				mcHall.HallStatusAfterLocked = 0;
				
				if(mcHall.LastHallStatus==0)
				{
					mcHall.LastHallStatus = mcHall.HallStatus_Result;
												
					mcHall.HallFRStatus = 1;
				}
									
				if((mcHall.HallCommutationCount >= 1)||(mcState == mcStop))
				{
					 if((mcHall.LastHallStatus != mcHall.HallStatus_Result)&&(mcHall.HallStatus_Result != 0))
					 {			
						 #if (FGEnable)
						 {
							 #if (FG_Mode == FG_FrequencyConversion_Speed)      
							 {
									FG=~FG;   
							 }					 
							 #endif
						 }
						 #endif
						 
							 if(mcHall.HallCommutationCnt<=6)
							 {
								mcHall.HallCommutationCnt++;
							 }
							 
								if(mcHall.HallCommutationCount < 60000)
								{
									mcHall.HallCommutationCount++;
								}	
																	 
							 if(mcHall.HallFRStatus!=0)
							 {
								 Temp_HallFR = mcHall.HallFRStatus;   
							 }
							
							//判断电机运行方向，1为初始化设定方向，2位初始化方向的反方向
							 mcHall.HallFRStatus = HallStatus_Check(mcHall.GivenFRStatus,mcHall.LastHallStatus,mcHall.HallStatus_Result);
															 
							 if(mcHall.HallFRStatus==1)
							 {
									mcHall.HallFRreverse  =0; 
							 }
							 else if(mcHall.HallFRStatus==2)
							 {
								 mcHall.HallFRreverse ++;
								 
								 if(mcHall.HallFRreverse>=2)
								 {
										mcHall.HallFRreverse =2;
								 }
							 }
							 
							 if(Temp_HallFR != mcHall.HallFRStatus)	
							 {
								 mcHall.HallFRChange      = 1;    //反转
							 }
							 else
							 {
								 mcHall.HallFRChange      = 2;    //正转
							 }
							 
							//角度和角速度计算，处理
							HallTimeCapture();            
													
							mcHall.LastHallStatus = mcHall.HallStatus_Result;												
					 }		 
				}
			}   
			else if(mcHall.LockedFlag)                       
			{		
				mcHall.HallSpeed = 0;
							
				if(mcHall.HallStatusAfterLocked != mcHall.HallStatus_Result)
				{
					if(!LockedDutyFLag)  
					{	
						SpeedRamp.RampStep=0;				

						mcFocCtrl.OpenDutyCycle = SpeedRamp.RampStep;
									
						FOC_QMAX		= SpeedRamp.RampStep;
						FOC_QMIN		= SpeedRamp.RampStep;
					
						mcFocCtrl.mcIqref = SpeedRamp.RampStep;
							
						LockedDutyFLag = 1;
					}	
					
					mcFocCtrl.OpenDutyCycle = 6000;
					
					mcFocCtrl.LockedEnbleFlag  = 1;                   
				
					mcFocCtrl.MotorONOFFStatus = 1; 
							
					FOC__THETA = 0;
									
					FOC__RTHESTEP   = 0;
											
					if(SpeedRamp.RampStep >=5000)  
					{
						mcHall.HallStatusAfterLocked = mcHall.HallStatus_Result;	
					}
											
				}
				else
				{
					if(mcFocCtrl.OpenDutyCycle >=2)
					{
						mcFocCtrl.OpenDutyCycle -=2;   				
					}
					
					if(SpeedRamp.RampStep <SpeedRamp.RampDec)
					{
							mcFocCtrl.LockedEnbleFlag = 0;
							mcFocCtrl.MotorONOFFStatus = 0; 
							mcState = mcStop;
							mcFocCtrl.mcStopMode = FreeStop;
							LockedDutyFLag= 0;					
					}
				}
					
			}	
			
      ClrBit(TIM2_CR1, T2IF);
    }
}
/*---------------------------------------------------------------------------*/
/* Name     :   void TIM23_INT(void) interrupt 9
/* Input    :   NO
/* Output   :   NO
/* Description: Capture PWM ，中断优先级第二，高于FOC中断，用于PWM调速
/*---------------------------------------------------------------------------*/
void TIM3_INT(void) interrupt 9
{
//    if(ReadBit(TIM3_CR1, T3IR))
//    {
//        ClrBit(TIM3_CR1, T3IR);
//    }
//    if(ReadBit(TIM3_CR1, T3IP))//周期中断
//    {
//        if(mcPwmInput.PWMFlag != 1)//若正在计算占空比则不更新
//        {
//            mcPwmInput.PWMCompare    = TIM3__DR;
//            mcPwmInput.PWMARR        = TIM3__ARR;
//            mcPwmInput.PWMUpdateFlag = 1;
//        }

//        ClrBit(TIM3_CR1, T3IP);
//    }
//    if(ReadBit(TIM3_CR1, T3IF))
//    {
//        if(GP11)//PWM 100%输出
//        {
//            mcPwmInput.PWMCompare = 8000;
//            mcPwmInput.PWMARR     = 8000;
//        }
//        else//PWM 为0%
//        {
//            mcPwmInput.PWMCompare = 0;
//            mcPwmInput.PWMARR     = 8000;
//        }
//        mcPwmInput.PWMUpdateFlag =1;

//        ClrBit(TIM3_CR1, T3IF);
//    }
}
/*---------------------------------------------------------------------------*/
/* Name     :   void FOC_INT(void) interrupt 3
/* Input    :   NO
/* Output   :   NO
/* Description: FOC中断(Drv中断),每个载波周期执行一次，用于处理响应较高的程序，中断优先级第二。DCEN开了就会产生中断。
/*---------------------------------------------------------------------------*/
void FOC_INT(void) interrupt 3
{
    if(ReadBit(DRV_SR, DCIF))                                 // 比较中断
    {			
			GP07 = 1;
//			if(mcFocCtrl.mcADCCurrentbus >20000)
//			{
//				MOE = 0;
//				
//				mcFocCtrl.mcADCCurrentbus = 20000;
//			}
			
//        APP_DIV(); 	//启动除法器，避免与过调值中的除法冲突					
		  if(((!mcFocCtrl.LockedEnbleFlag))||(mcFocCtrl.FreeStopDecStatus)) //角度限制  8.2us
		  {
			 //角度限制
				Hall_THETA_Limit(mcHall.HallFRChange,mcHall.HallFRStatus,mcHall.NextSectorAngle);		 			  			
		  }	
		 	 
//       Fault_Overcurrent(&mcCurVarible);                     // 软件过流保护.约30us

//        #if ((FRDetectMethod == FOCMethod) && (TailWind_Mode == TailWind))
//            TailWindSpeedDetect();	//顺逆风检测
//        #endif

        #if defined (SPI_DBG_SW)	//软件调试模式
            spidebug[0] = mcFocCtrl.mcADCCurrentbus*5;//SOFT_SPIDATA0;
            spidebug[1] = mcFocCtrl.RMSLimitTargetCurrent*10;//SOFT_SPIDATA1; mcState SpeedRamp.RampInc
            spidebug[2] =		FOC__THETA;                       //mcHall.HallStatus_Result*5000;//SOFT_SPIDATA2;
            spidebug[3] = FOC__THETA;
        #endif

        ClrBit(DRV_SR, DCIF);
						GP07 = 0;

    }
}

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM4S_INT(void) interrupt 10
/* Input    :   NO
/* Output   :   NO
/* Description: 1ms定时器中断（SYS TICK中断），用于处理附加功能，如控制环路响应、各种保护等。中断优先级低于FO中断和FOC中断。
/*---------------------------------------------------------------------------*/
void TIM4S_INT(void) interrupt 10
{
	  if(ReadBit(TIM4_CR1, T4IF))
    {		
			
      ClrBit(TIM4_CR1, T4IF);
    }
		
		 /****串口发送数据*****/
		UartSendCnt++;
		if(UartSendCnt == 500) 								//0.5s通过Uart发送一次数据,
		{
			UT_DR = 1 + '0';
			while(!TI);
			TI = 0;
			UT_DR = ':';
			while(!TI);
			TI = 0;
			Send_U_DataByUart(mcFocCtrl.mcSpeedVSP);							//Uart发送数据,调用一次耗时7.3ms
		}
		if(UartSendCnt == 1000) 								//0.5s通过Uart发送一次数据,
		{
			UT_DR = 2 + '0';
			while(!TI);
			TI = 0;
			UT_DR = ':';
			while(!TI);
			TI = 0;
			SendDataByUart(Test2);							//Uart发送数据,调用一次耗时7.3ms
		}
		if(UartSendCnt == 1500) 								//0.5s通过Uart发送一次数据,
		{
			UT_DR = 3 + '0';
			while(!TI);
			TI = 0;
			UT_DR = ':';
			while(!TI);
			TI = 0;
			SendDataByUart(Test2);							//Uart发送数据,调用一次耗时7.3ms
		}
		if(UartSendCnt == 2000) 								//0.5s通过Uart发送一次数据,
		{
			UartSendCnt = 0;
			UT_DR = 4 + '0';
			while(!TI);
			TI = 0;
			UT_DR = ':';
			while(!TI);
			TI = 0;
			SendDataByUart(Test2);							//Uart发送数据,调用一次耗时7.3ms
		}
	
    if(ReadBit(DRV_SR, SYSTIF))          // SYS TICK中断
    {		
//			static int16 TempLPFCurrentBUS = 0;
			
//			SetBit(ADC_CR, ADCBSY);          //使能ADC的DCBUS采样
						
			SpeedRamp.SPEEDRampCnt ++;
							
        /****功率滤波*****/
//        if(mcState == mcRun)
//        {
//            mcFocCtrl.CurrentPower = FOC__POW << 1;
//            mcFocCtrl.Powerlpf     = LPFFunction(mcFocCtrl.CurrentPower,mcFocCtrl.Powerlpf,10);//注意低通滤波器系数范围为0---127
//        }

        /****速度滤波、反电动势滤波*****/
//        if((mcState != mcInit) && (mcState != mcReady))
//        {
//            mcFocCtrl.SpeedFlt = LPFFunction(FOC__EOME, mcFocCtrl.SpeedFlt, 10);//注意低通滤波器系数范围为0---127
//            mcFocCtrl.EsValue  = LPFFunction(FOC__ESQU,mcFocCtrl.EsValue,10);
//        }
//        else
//        {
//            mcFocCtrl.SpeedFlt = 0;
//        }

				if((mcState == mcStop)&&(MOE ==0)||(mcCurOffset.OffsetFlag==2))
				{			
					mcFocCtrl.RampVoltage = mcFocCtrl.mcADCVoltagebus;

					mcCurOffset.OffsetFlag = 3;					
				}
				
				/*****环路响应，如速度环、转矩环、功率环等******/
        Speed_response();        

        /*****DCbus的采样获取值并滤波******/
				mcFocCtrl.mcADCVoltagebus   = LPFFunction((ADC2_DR<<3),mcFocCtrl.mcADCVoltagebus,120);//低通滤波
				
				/*****调速信号采集，低通滤波(左移三位的意思是扩大8倍，转换成一个15位的数，也就是0-32767)******/
				mcFocCtrl.mcSpeedVSP = LPFFunction((ADC7_DR<<3),mcFocCtrl.mcSpeedVSP,120);
				
				/*************母线电流采样***********/
				#if (!RMSCurrentLimitEnable)
				{	
					mcFocCtrl.mcADCCurrentbus =(ADC4_DR<<3);// LPFFunction((ADC4_DR<<3),mcFocCtrl.mcADCCurrentbus,30);
				}
				#endif
										
				
				/***********平均电流限流************/
				#if (RMSCurrentLimitEnable)
				{				
//					if(!ReadBit(ADC_CR, ADCBSY))
//					{
						TempLPFCurrentBUS = LPFFunction((ADC6_DR<<3),TempLPFCurrentBUS,127);
//					}
									
					if(TempLPFCurrentBUS >= mcCurOffset.Iw_busOffset)
					{
						TempLPFCurrentBUS = TempLPFCurrentBUS - mcCurOffset.Iw_busOffset;	
					
					}
					else
					{
						TempLPFCurrentBUS = 0;					
					}
					
					mcFocCtrl.mcADCCurrentbus =  TempLPFCurrentBUS;	
																	
					if(!mcHall.HallDirectStartStatus) 
					{
						RMSCurrentLimit();
					}
				}
				#endif
				
				/******开关机函数***********/
				ONOFFControl();

        /*****故障保护函数功能，如过欠压保护、启动保护、缺相、堵转等********/
        Fault_Detection();
				
				/***********堵转保护监测***************/
				HallLockCheckFuntion();
				
				/***********顺风启动******************/
				mcTailWindDispose();

//        LED_Display();//LED灯显示

        /********睡眠模式*******/
        //    Sleepmode();

        /**********************电机状态机的时序处理***************************/
        if(mcFocCtrl.State_Count > 0)    mcFocCtrl.State_Count--;
        if(BEMFDetect.BEMFTimeCount > 0) BEMFDetect.BEMFTimeCount--;
        if(RSDDetect.RSDCCWSBRCnt > 0)     RSDDetect.RSDCCWSBRCnt--;
						
        ClrBit(DRV_SR, SYSTIF);                                    // 清零标志位
    }
}


/*---------------------------------------------------------------------------*/
/* Name     :   void USART_INT(void) interrupt 12
/* Input    :   NO
/* Output   :   NO
/* Description: 串口中断，中断优先级最低，用于接收调速信号,无中断插入时8us
/*---------------------------------------------------------------------------*/
void USART_INT(void)  interrupt 12
{
    if(RI == 1)
    {
        RI = 0;
        Uart.Uredata= UT_DR;            //读接收数据
    }
}

/*---------------------------------------------------------------------------*/
/* Name     :   void EXTERN_INT(void) interrupt 2
/* Input    :   NO
/* Output   :   NO
/* Description: 睡眠唤醒
/*---------------------------------------------------------------------------*/
void EXTERN_INT(void) interrupt 2
{
    if(SleepSet.SleepFlag)
    {
        SleepSet.SleepFlag = 0;
        SleepSet.SleepEn   = 1;
    }

    ClrBit(P1_IF, P11);                    // 清零P10标志位
}


/* Private variables ----------------------------------------------------------------------------*/
void INT0(void) interrupt 0
{
}
void INT5(void) interrupt 5
{
}
void INT6(void) interrupt 6
{
}
void INT8(void) interrupt 8
{
}
void INT11(void) interrupt 11
{
}
void INT13(void) interrupt 13
{
}
void INT14(void) interrupt 14
{
}
void INT15(void) interrupt 15
{
}




