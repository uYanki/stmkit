/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : FocControl.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains all the foc control function used for motor control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>
#include <FU68xx_2_DMA.h>
#endif
CurrentOffset xdata mcCurOffset;



/*---------------------------------------------------------------------------*/
/* Name		:	void FOC_Init(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	mcInit状态下，对FOC的相关寄存器进行配置,先清理寄存器，后配置，最后使能
/*---------------------------------------------------------------------------*/
void FOC_Init(void)
{
	/*使能FOC*/
	ClrBit(DRV_CR, FOCEN);
	SetBit(DRV_CR, FOCEN);
	/*配置FOC寄存器*/
	FOC_CR1 			= 0;																			// 清零 FOC_CR1
	FOC_CR2 			= 0;																			// 清零 FOC_CR2
	FOC_IDREF 		= 0;																			// 清零 Id
	FOC_IQREF 		= 0;																			// 清零 Iq

//	FOC__THETA 		= 0;																			// 清零 角度
	FOC_RTHEACC 	= 0;																			// 清零 爬坡函数的初始加速度
	FOC__RTHESTEP = 0;																		
	FOC__RTHECNT 	= 0;																			
	
	/*电流环参数配置*/
	
	
	#if (CurrentCycleEnable == 1)//使能电流环
	{
			ClrBit(FOC_CR2, UQD);
			ClrBit(FOC_CR2, UDD);//D轴电流环不关闭
	}
	#elif (CurrentCycleEnable == 0)//不使能电流环
	{
			SetBit(FOC_CR2, UQD);
			ClrBit(FOC_CR2, UDD);//D轴电流环不关闭
	}
	#endif //end SVPMW_Mode
	
	
	FOC_DMAX 			= DOUTMAX;
	FOC_DMIN 			= DOUTMIN;

    FOC__UQ = StartPWMDuty;

    FOC_TGLI      = PWM_TGLI_LOAD;

	SetBit(FOC_CR1, SVPWMEN);															// SVPWM模式


	/**过调制**/
	#if (OverModulation == 1)
	{
			SetBit(FOC_CR1,OVMDL);													// 过调制
	}
	#endif //end OverModulation

	/*单电阻采样；需要最小采样窗,FOC_TRGDLY为0，七段式SVPWM方式*/
	#if (Shunt_Resistor_Mode == Single_Resistor)
	{
		SetReg(FOC_CR1, CSM0 | CSM1, 0x00);
		FOC_TSMIN = PWM_TS_LOAD;															// 最小采样窗口
		FOC_TRGDLY = 0x05;          													// 采样时刻在中点，一般考虑开关噪声影响，会设置延迟；
		                                                      // 0x0c表示延迟12个clock，提前用反码形式，如0x84表示提前12个clock。
		ClrBit(FOC_CR2,F5SEG);															  // 7段式
		SetReg(CMP_CR1, CMP3MOD0 | CMP3MOD1, 0x00);
	}
	/*双电阻采样，可设置死区补偿值，在下降沿结束前开始采样Ia，配置81*/
	#elif (Shunt_Resistor_Mode == Double_Resistor)					// double resistor sample
	{
		SetReg(FOC_CR1, CSM0 | CSM1, CSM0);

		FOC_TSMIN = PWM_DT_LOAD;															// 死区补偿值
		FOC_TRGDLY = 0x80;																	  // ADC采样的时刻，采样时刻在计数器零点附近，83为下降沿结束前3个clock采样Ia，与单电阻不同
		                                                      // 01为上升沿开始后第一个clock开始采样。根据实际情况调整。
		FOC_TBLO=PWM_DLOWL_TIME;                              //下桥臂最小脉冲，保证采样
		SetReg(CMP_CR1, CMP3MOD0 | CMP3MOD1, 0x00);

		/*五段式或七段式选择*/
		#if (SVPMW_Mode == SVPWM_7_Segment)
		{
			ClrBit(FOC_CR2,F5SEG);															// 7段式
		}
		#elif (SVPMW_Mode == SVPWM_5_Segment)
		{
			SetBit(FOC_CR2,F5SEG);															// 7段式
		}
		#endif

		#if (DouRes_Sample_Mode == DouRes_1_Cycle)
		{
			ClrBit(FOC_CR2,DSS);															  // 7段式
		}
		#elif (DouRes_Sample_Mode == DouRes_2_Cycle)
		{
			SetBit(FOC_CR2,FOC_DSS);														// 7段式
		}
		#endif //end DouRes_Sample_Mode
	}
	/*三电阻采样*/
	#elif (Shunt_Resistor_Mode == Three_Resistor)					  // signel resistor sample
	{

		SetReg(FOC_CR1, CSM0 | CSM1, CSM0 | CSM1);// 三电阻

		FOC_TSMIN  = PWM_DT_LOAD;															// 死区补偿值
		FOC_TRGDLY =06;																			  // ADC采样的时刻，采样时刻在计数器零点附近，83为下降沿结束前3个clock采样Ia，与单电阻不同。
		                                                      // 01为上升沿开始后第一个clock开始采样。根据实际情况调整。

		SetReg(CMP_CR1, CMP3MOD0 | CMP3MOD1, CMP3MOD0 | CMP3MOD1);
		FOC_TBLO= PWM_OVERMODULE_TIME;                        // 过调制电流采样处理的TB脉宽

		/*五段式或七段式选择*/
		#if (SVPMW_Mode == SVPWM_7_Segment)
		{
			ClrBit(FOC_CR2,F5SEG);															// 7段式
		}
		#elif (SVPMW_Mode == SVPWM_5_Segment)
		{
			SetBit(FOC_CR2,F5SEG);															// 7段式
		}
		#endif //end SVPMW_Mode

		#if (DouRes_Sample_Mode == DouRes_1_Cycle)
		{
			ClrBit(FOC_CR2,DSS);															// 7段式
		}
		#elif (DouRes_Sample_Mode == DouRes_2_Cycle)
		{
			SetBit(FOC_CR2,DSS);															// 7段式
		}
		#endif //end DouRes_Sample_Mode
	}
	#endif	//end Shunt_Resistor_Mode

	/* 使能电流基准校正	*/
	#if (CalibENDIS == Enable)
	{
		if(mcCurOffset.OffsetFlag>=1)
		{
			#if (Shunt_Resistor_Mode == Single_Resistor)	      // 单电阻校正
			{
				/*set ibus current sample offset*/
				SetReg(FOC_CR2, CSOC0 | CSOC1, 0x00);
				FOC_CSO = mcCurOffset.Iw_busOffset;	              // 写入Ibus的偏置

			}
			#elif (Shunt_Resistor_Mode == Double_Resistor)			// 双电阻校正
			{
				/*set ia, ib current sample offset*/
				SetReg(FOC_CR2, CSOC0 | CSOC1, CSOC0);
				FOC_CSO  = mcCurOffset.IuOffset;                  // 写入IA的偏置

				SetReg(FOC_CR2, CSOC0 | CSOC1, CSOC1);
				FOC_CSO  = mcCurOffset.IvOffset;	                // 写入IB的偏置

			}
			#elif (Shunt_Resistor_Mode == Three_Resistor)	      // 三电阻校正
			{
				/*set ibus current sample offset*/
				SetReg(FOC_CR2, CSOC0 | CSOC1, CSOC0);
				FOC_CSO = mcCurOffset.IuOffset; 									// 写入IA的偏置

				SetReg(FOC_CR2, CSOC0 | CSOC1, CSOC1);
				FOC_CSO = mcCurOffset.IvOffset;	                  // 写入IB的偏置

				SetReg(FOC_CR2, CSOC0 | CSOC1, 0x00);
				FOC_CSO = mcCurOffset.Iw_busOffset;	              // 写入IC的偏置
			}
			#endif	//end Shunt_Resistor_Mode
		}
	}
	#endif	//end CalibENDIS
	/*-------------------------------------------------------------------------------------------------
	DRV_CTL：PWM来源选择
	OCS = 0, DRV_COMR
	OCS = 1, FOC/SVPWM/SPWM
	-------------------------------------------------------------------------------------------------*/
	/*计数器比较值来源FOC*/
	SetBit(DRV_CR, OCS);
}

/*---------------------------------------------------------------------------*/
/* Name		:	void Motor_Open(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	开环启动的参数配置
/*---------------------------------------------------------------------------*/
void Motor_Open(void)
{	
	uint8 hall_status= 0;
	
	if(MotorStateTime.OpenOneTime==0)
	{
		MotorStateTime.OpenOneTime=1;
		
		/*FOC初始化*/
		FOC_Init();
							
//		TimeCnt=FOC__ETHETA;							
		/*启动电流、KP、KI、FOC_EKP、FOC_EKI*/
		FOC_IDREF = ID_Start_CURRENT;               // D轴启动电流

		

		
		FOC_DQKP	= DQKP;
		FOC_DQKI	= DQKI;



		

		/*启动方式选择*/
		#if (Open_Start_Mode == Omega_Start)            // Omega 启动
		{



			
			SetBit(FOC_CR1,EFAE);						// 估算器强制输出
			ClrBit(FOC_CR1,RFAE);						// 禁止强拉
			SetBit(FOC_CR1,ANGM);						// 估算模式
		}
		#elif (Open_Start_Mode == Open_Start)
		{
//			FOC_RTHEACC 	= Motor_Open_Ramp_ACC;		// 爬坡函数的初始加速度
//			FOC__RTHESTEP 	= Motor_Open_Ramp_Min;		// 0.62 degree acce speed
//			RPDPara.ThetaGet=Motor_Open_Ramp_Min;
//			FOC__RTHECNT 	= MOTOR_OPEN_ACC_CNT;		// acce time

			ClrBit(FOC_CR1,EFAE);						// 估算器强制输出
			ClrBit(FOC_CR1,RFAE);						// 禁止强拉
			ClrBit(FOC_CR1,ANGM);						// 估算模式
		}
		#elif (Open_Start_Mode == Open_Omega_Start)
		{
			FOC_RTHEACC 	= Motor_Open_Ramp_ACC;		// 爬坡函数的初始加速度
//			FOC__RTHESTEP 	= Motor_Open_Ramp_Min;		// 0.62 degree acce speed
			FOC__RTHECNT 	= MOTOR_OPEN_ACC_CNT;		// acce time

			FOC_EFREQACC 	= Motor_Omega_Ramp_ACC;
			FOC_EFREQMIN 	= Motor_Omega_Ramp_Min;
			FOC_EFREQHOLD 	= Motor_Omega_Ramp_End;

			SetBit(FOC_CR1,EFAE);						// 估算器强制输出
			SetBit(FOC_CR1,RFAE);						// 禁止强拉
			SetBit(FOC_CR1,ANGM);						// 估算模式
		}
		#endif //end Open_Start_Mode
	}
		
	if(HALLC)
	{
		hall_status += 4;
	}
	
	if(HALLB)
	{
		hall_status += 2;
	}
	
	if(HALLA)
	{
		hall_status += 1;
	}
		
	mcHall.HallStatus_Result = hall_status;
	
	FOC__RTHESTEP                  = 0; 
	
// 	FOC__THETA = hall_status;
				
	mcState = mcRun;
		
	DRV_CMR |= 0x3F;                         // U、V、W相输出
		
	MOE = 0;
					
}


/*---------------------------------------------------------------------------*/
/* Name		:	void MC_Stop(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	inital motor control parameter
/*---------------------------------------------------------------------------*/
void MC_Stop(void)
{
	MOE     = 0;
	ClrBit(DRV_CR, FOCEN, 0);	//关闭FOC																											// disable FOC output and initial register
	mcState = mcInit;
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void MotorControlInit(void)
	Description   :	控制变量初始化清零,包括保护参数的初始化、电机状态初始化
	Input         :	输入说明（详细）
  Output				:	输出说明（详细）
-------------------------------------------------------------------------------------------------*/
void MotorcontrolInit(void)
{
  /***********保护******************/
	memset(&mcFaultDect,0, sizeof(FaultVarible));																// FaultVarible变量清零
  /******堵转保护*********/
//	mcFaultDect.StallRecover          = 1000;//5s

  /******保护次数*********/
	memset(&mcProtectTime,0, sizeof(ProtectVarible));														// ProtectVarible保护次数清零 

	


	
  /*****电机目标方向**********/
	mcFRState.TargetFR                 = 0;

  /*****外部控制环*******/
	memset(&mcFocCtrl,0, sizeof(FOCCTRL));																// mcFocCtrl变量清零


	
	
  /******电流偏置校准变量*****/
	memset(&mcCurOffset,0, sizeof(CurrentOffset));												// mcCurOffset变量清零
	mcCurOffset.IuOffsetSum            = 16383;
	mcCurOffset.IvOffsetSum            = 16383;
	mcCurOffset.Iw_busOffsetSum        = 16383;

	/*****LED灯响应***/
	memset(&mcLedDisplay,0, sizeof(MCLedDisplay));												// mcLedDisplay变量清零
	mcLedDisplay.Counttime            = 4999;

	/*****速度环的响应***/
	memset(&mcSpeedRamp,0, sizeof(MCRAMP));												        // mcSpeedRamp变量清零
//	mcSpeedRamp.IncValue              = Motor_Speed_Inc;
//	mcSpeedRamp.DecValue              = Motor_Speed_Dec;
//	mcSpeedRamp.DelayPeriod           = 1;

	/*串口变量*/
	memset(&Uart,0, sizeof(MCUART));												              // MCUART变量清零
	
	memset(&MotorStateTime,0, sizeof(MotStaTim));	                        //清零
	
	memset(&mcHall,0, sizeof(mcHall_TypeDef));	                          //清零
	
}

/*---------------------------------------------------------------------------*/
/* Name		:	void VariablesPreInit(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	初始化电机参数
/*---------------------------------------------------------------------------*/
void VariablesPreInit(void)
{
	/***********保护******************/
	mcFaultSource = 0;
	
	memset(&mcFaultDect,0, sizeof(FaultVarible));												// FaultVarible变量清零

  /*****外部控制环*******/
//	memset(&mcFocCtrl,0, sizeof(FOCCTRL));														// mcFocCtrl变量清零
  
	mcFocCtrl.OpenDutyCycle	           = 0;
	
//	mcFocCtrl.mcBrakeStatus          = 0;
		
	mcFocCtrl.mcSpeedVSP               = 0;
	
	mcFocCtrl.mcADCVoltagebus          = 0;
	
	mcFocCtrl.OverCurrentFlag          = 0;
		

	
	mcFocCtrl.mcADCCurrentbus					 = 0;
	
	mcFocCtrl.mcADCProtectCurrentbus   = 0;  

	/*****LED灯响应***/
	memset(&mcLedDisplay,0, sizeof(MCLedDisplay));												// mcLedDisplay变量清零
	mcLedDisplay.Counttime            = 4999;
	
	memset(&MotorStateTime,0, sizeof(MotStaTim));	                        //清零
	
	mcHall.HALLLockHCTime             = 0;
  mcHall.HALLLockHBTime             = 0;
	mcHall.HALLLockHATime             = 0;
	mcHall.HALLHACWCCWTime            = 0;
	mcHall.HALLHBCWCCWTime            = 0;
	mcHall.HALLHCCWCCWTime            = 0;
	mcHall.HALLLockStatus             = 0;
	mcHall.mcStallTimeCnt             = 0;
	mcHall.mcFallWarningSignal        = 1;   
	mcHall.RTheStep                   = 0;	
	mcHall.PeriodTime                 = 0;	
	mcHall.AngleCompensate            = 0;
//	mcHall.HallFRreverse               =0;	
	mcHall.HallDirectStartStatus			 = 0;				
	mcHall.StartAngleOffset					   = 0;
	mcHall.HallSpeedInitStatus         = 0;
		
        
    memset(&SeconBoardData,0, sizeof(SeconBoardVari));		// 两机通信变量清零
    memset(&MainBoardData,0, sizeof(MainBoardVari));		// 两机通信变量清零
}
/*---------------------------------------------------------------------------*/
/* Name		:	void GetCurrentOffset(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	上电时，先对硬件电路的电流进行采集，写入对应的校准寄存器中。
								调试时，需观察mcCurOffset结构体中对应变量是否在范围内。采集结束后，OffsetFlag置1。
/*---------------------------------------------------------------------------*/
void GetCurrentOffset(void)
{
	  SetBit(ADC_CR, ADCBSY);		                           // 使能ADC
		
		while(ReadBit(ADC_CR, ADCBSY));
		
		#if (Shunt_Resistor_Mode == Single_Resistor)			       // 29.2ms 单电阻模式，上电验证硬件电路时，需观察mcCurOffset.IbusOffset是否为4096
		{
			mcCurOffset.Iw_busOffsetSum+=((ADC4_DR& 0x0fff) << 3);
			mcCurOffset.Iw_busOffset = mcCurOffset.Iw_busOffsetSum >> 4;
			mcCurOffset.Iw_busOffsetSum -= mcCurOffset.Iw_busOffset;
		}
		#elif (Shunt_Resistor_Mode == Double_Resistor)				   //44ms 双电阻模式，上电验证硬件电路时，需观察mcCurOffset.IaOffset、mcCurOffset.IbOffset是否为4096
		{
			mcCurOffset.IuOffsetSum+=((ADC0_DR& 0x0fff) << 3);
			mcCurOffset.IuOffset = mcCurOffset.IuOffsetSum >> 4;
			mcCurOffset.IuOffsetSum -= mcCurOffset.IuOffset;

			mcCurOffset.IvOffsetSum+=((ADC1_DR& 0x0fff) << 3);
			mcCurOffset.IvOffset = mcCurOffset.IvOffsetSum >> 4;
			mcCurOffset.IvOffsetSum -= mcCurOffset.IvOffset;
			
			mcCurOffset.Iw_busOffsetSum+=((ADC4_DR& 0x0fff) << 3);
			mcCurOffset.Iw_busOffset = mcCurOffset.Iw_busOffsetSum >> 4;
			mcCurOffset.Iw_busOffsetSum -= mcCurOffset.Iw_busOffset;
		}
		#elif (Shunt_Resistor_Mode == Three_Resistor)			      //58.2ms 三电阻模式，上电验证硬件电路时，需观察mcCurOffset.IaOffset、mcCurOffset.IbOffset、mcCurOffset.IcOffset是否为4096
		{
			mcCurOffset.IuOffsetSum+=((ADC0_DR& 0x0fff) << 3);
			mcCurOffset.IuOffset = mcCurOffset.IuOffsetSum >> 4;
			mcCurOffset.IuOffsetSum -= mcCurOffset.IuOffset;

			mcCurOffset.IvOffsetSum+=((ADC1_DR& 0x0fff) << 3);
			mcCurOffset.IvOffset = mcCurOffset.IvOffsetSum >> 4;
			mcCurOffset.IvOffsetSum -= mcCurOffset.IvOffset;

			mcCurOffset.Iw_busOffsetSum+=((ADC4_DR& 0x0fff) << 3);
			mcCurOffset.Iw_busOffset = mcCurOffset.Iw_busOffsetSum >> 4;
			mcCurOffset.Iw_busOffsetSum -= mcCurOffset.Iw_busOffset;			
		}
		#endif

		mcCurOffset.OffsetCount++;
		
		if(mcCurOffset.OffsetCount>Calib_Time)
		{
			mcCurOffset.OffsetFlag=1;
            mcState = mcInit;
//            FOC_EFREQACC = 0;
//            FOC_EFREQMIN = 0;
//            FOC_EFREQHOLD = 0;
        }
}
#endif