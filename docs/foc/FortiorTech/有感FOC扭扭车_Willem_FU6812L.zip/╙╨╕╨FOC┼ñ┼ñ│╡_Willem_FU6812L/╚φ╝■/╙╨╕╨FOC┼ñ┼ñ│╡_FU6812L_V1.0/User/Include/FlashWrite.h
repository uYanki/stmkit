#ifndef __FLASHWRITE_H_
#define __FLASHWRITE_H_

#define USERCODEADDRESS 0X3F00


extern int16 Get2ByteFromFlash(uint8 xdata *BlockStartAddr);
extern uint8 Write2Byte2Flash(uint8 xdata *BlockStartAddr,uint16 NewData2Flash);
extern void Write2Byte2FlashWithoutCheck(uint8 xdata *BlockStartAddr,int16 NewData2Flash);

#endif
