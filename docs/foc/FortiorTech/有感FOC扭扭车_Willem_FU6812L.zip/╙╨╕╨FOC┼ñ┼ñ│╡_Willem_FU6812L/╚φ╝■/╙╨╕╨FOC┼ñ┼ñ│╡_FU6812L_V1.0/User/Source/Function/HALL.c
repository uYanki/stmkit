/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains MDU initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>


//HALL �ͺ󷴵綯��25��
//#define	HallDetaAngle		         _Q15(10.0/180.0)    					// HALL��ǰ+�����ͺ�-��  ccw60
// �����ͷ��綯�Ƽ�����ͬ   //5->1->3->2->6->4   0��->60��->120��->180��->240��->300��
//int16 xdata Hall_Angle_Arr[6] = {_Q15(91.6/180.0),_Q15(211.6/180.0),_Q15(151.6/180.0),_Q15(331.6/180.0),_Q15(31.6/180.0),_Q15(271.6/180.0)};	
int16 xdata Hall_Angle_Arr[6] = {_Q15(60.0/180.0),_Q15(180.0/180.0),_Q15(120.0/180.0),_Q15(300.0/180.0),_Q15(0.0/180.0),_Q15(240.0/180.0)};	

extern	int Test2;
extern	int tTest3;

uint8 ThetaOverflow = 0;
extern uint8 HallFRStatusTeat;
    
/*---------------------------------------------------------------------------*/
/* Name		:	uint8  HallStatus_Get(uint8 HA, uint8 HB, uint8 HC)
/* Input	:	HA-HALLA��״̬��HB-HALLB��״̬��HC-HALLC��״̬
/* Output	:	��ǰ����״̬
/* Description:	
/*---------------------------------------------------------------------------*/

uint8  HallStatus_Get(uint8 HA, uint8 HB, uint8 HC)
{
    uint8 HS = 0;
	if(HC)
	{
		HS += 4;
	}
	
	if(HB)
	{
		HS += 2;
	}
	
	if(HA)
	{
		HS += 1;
	}
		
	return HS;
}
	
/*---------------------------------------------------------------------------*/
/* Name		:	uint8  HallCommutation(uint8 GivenFR_Status ,uint8 Hall_Status_Result )
/* Input	:	GivenFR_Status ��ǰ����Hall_Status_Result��ǰhall�ź�
/* Output	:	Hall_Status_Next ��һ��hall�ź�
/* Description:	
/*---------------------------------------------------------------------------*/
uint8  HallCommutation(uint8 GivenFR_Status ,uint8 Hall_Status_Result)
{
	static uint8 Hall_Status_Next = 0;
   	//CW  5->1->3->2->6->4
		if(GivenFR_Status == CW)
		{	
				switch(Hall_Status_Result)
				{
					case 1:
						Hall_Status_Next = 3;
						break;
					case 2:
						Hall_Status_Next = 6;
						break;
					case 3:
						Hall_Status_Next = 2;
						break;
					case 4:
						Hall_Status_Next = 5;
						break;
					case 5:
						Hall_Status_Next = 1;
						break;
					case 6:
						Hall_Status_Next = 4;
						break;
					default:
						break;
				 }
		 }		 
		//CCW 5->4->6->2->3->1
		if(GivenFR_Status == CCW)
		{
			switch(Hall_Status_Result)
			{
				case 1:
				  Hall_Status_Next = 5;
					break;
				case 2:
				  Hall_Status_Next = 3;
					break;
				case 3:
				  Hall_Status_Next = 1;
					break;
				case 4:
				  Hall_Status_Next = 6;
					break;
				case 5:
				  Hall_Status_Next = 4;
					break;
				case 6:
				  Hall_Status_Next = 2;
					break;
				default:
					break;
			}
		}
		return Hall_Status_Next;
}


void HallStatus_CaptureFilter(void)
{

	

    mcHall.HallStatus_Result = HallStatus_Get(HALLA,HALLB,HALLC);
	
}


/*---------------------------------------------------------------------------*/
/* Name		:	int16 ThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,uint16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 Angle_Compensate,int16 StartAngle_Offset)
/* Input	:	
						
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
int16 ThetaDispose1 (uint8 Hall_Status_Result,uint8 GivenFR_Status,int16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 Angle_Compensate)
{
	 int16 Hall_Angle = 0;
	
	 int16 TempHallAngle = 0;
	
	Hall_Angle            = Hall_Angle_Arr[Hall_Status_Result-1];
	
	if(GivenFR_Status == CW)
	{
		TempHallAngle  = Hall_Angle + TempAngle_OffsetCW + Angle_Compensate ;
	}
	else if(GivenFR_Status == CCW)		
	{					
		TempHallAngle = Hall_Angle + TempAngle_OffsetCCW - Angle_Compensate ;
		
//		TempHallAngle =((0 - TempHallAngle)+ Angle_Compensate);										
	}
	
	
	return TempHallAngle;
}

/*---------------------------------------------------------------------------*/
/* Name		: void AngleLimit(void)
/* Input	: No
/* Output	: No
/* Description:	�Ƕ����ƺ��������Ƕȳ�����ֵ���ԽǶȽ�������
/*---------------------------------------------------------------------------*/
void AngleLimit(void)
{
    if(HallFRStatusTeat==1)
    {
        if((mcHall.NextSectorAngle - FOC__THETA) < 0)
        {
            FOC__THETA    = (uint16)mcHall.NextSectorAngle;
            FOC__RTHESTEP  = 0;
        }
      
    }
    
    else if(HallFRStatusTeat == 2)
    {
        if((mcHall.NextSectorAngle-(int16)FOC__THETA) > 0)
        {
            FOC__THETA    = mcHall.NextSectorAngle;
            FOC__RTHESTEP  = 0;
        }
    }
}
