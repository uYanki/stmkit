/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : KeyScan.h
* Author             : Vina Peng, Fortiortech Appliction Team
* Version            : V1.0
* Date               : 01/04/2017
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __KEYSCAN_H_
#define __KEYSCAN_H_

/* Exported types -------------------------------------------------------------------------------*/


/* Exported functions ---------------------------------------------------------------------------*/

extern uint8 KeyValue(void);
extern void KeyScan(void);

#endif

