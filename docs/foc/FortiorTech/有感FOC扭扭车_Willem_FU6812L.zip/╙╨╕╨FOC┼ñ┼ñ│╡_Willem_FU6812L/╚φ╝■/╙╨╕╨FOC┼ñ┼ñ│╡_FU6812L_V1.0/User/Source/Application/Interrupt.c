/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Interrupt.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the interrupt function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <Interrupt.h>
#include <FU68xx_2.h>
#include <Myproject.h>
#include <Customer_Debug.h>
#include <MyUart.h>	


uint16 xdata spidebug[4] = { 0 };
uint16 UartSendCnt = 0; //用于Uart发送数据定时器计数
char UartSendFlag = 0;

extern char KeyBrake;
int16 RampStepIncFlag = 0;

extern int16 RealAngleGivenToFoc;


uint8 HallFRStatusTeat = 0;
uint8 LastHallFRStatusTeat = 0;
int8 CarAccSpSmo = 1;
int8 CarAccSpSmoCnt = 0;



extern uint8 SmoothFlag;
extern uint8 SmoothCnt;

uint8 Tim4CntOverflow = 0;

int16 AngleOutput = 0;
int16 LastAngleOutput = 0;





extern int32 AngleOutI;
extern int16 AccAngle;
extern int16 AccAngleALPF;
extern int32 GyrYoutAF;
extern float angle;                 
extern int16 GyrAngVel;
int16 angleALPF = 0;

extern uint8 TurnOffMusic;


extern int16 CarAccSpeedALPF;

extern int16 LastCarSpeed;
extern int16 CarAccSpeed;

extern char PowerAngleFlag;

extern uint8 PowerBoardProtect;

int16 SpeRespPowDelay = 0;

uint16 TempMcADCCurrentbus = 0;

uint16 PowerOffCnt = 0;

int8 AnglePolarity = 0;
int16 angleALPFForBoardUart = 0;

extern int8 BalancePointMoveLock;

int16 LastAngleALPF = 0;



//extern float GetAngIncre;

int16 HallSpeedALPF = 0;

extern uint8 ErrorMusic ;

extern uint8 SeconBoardErrorMusic;

int16 FOCTHETAValue = 0;
int16 FOCUQValue = 0;

uint16 TIM4Cnt = 0;

extern uint8 OverUnderVoltageMusic;

int8 OverSpeedLed = 0;

extern uint8 AnglePro ;

uint8 MainBoardOverSpeedLed = 0;
extern uint8 MainBoardOverSpLedstat;


uint8 HallErrMisic = 0;
extern uint8 LimitCurMusicLed;

extern uint8 SeconBoardLimitCurMusicLed ;
extern uint8 MainBoardLimitCurMusicLed ;
extern uint8 HallErrMisic ;
extern uint8 MainBoardHallErrLed ;
extern uint8 PhaselossMusic ;
extern uint8 MainBoardPhaselossMusicLed ;

uint8 DMAWaitTimeCnt = 0;
extern uint8 DataSequenceErr;
uint8 DMAErr = 0;
extern uint8 DMARecAddr[8];
uint16 DMAReCnt1 = 0;
uint16 DMAReCnt2 = 0;
extern int16 ABSHallSpeedALPF ;




uint8 UQUpdate = 0;



int16 AngleOutputMax = 0;

int16 UQMax = BalanceUQMax;
int16 UQMin = BalanceUQMin;
int8 BeepCnt = 0;
extern int8 BeepOnOff;
int16 CurrentLimitVal = IQ_RUN_MAX_RMS_CURRENT;

int16 StallProjectCnt = 0;
int8 StallProject = 0;
extern uint8 OverUnderVoltageFlag ;

extern int8 BatteryNumber ;

int16 mcADCVoltagebus2 = 0;

uint8 AccYoutH = 0;
uint8 AccYoutL = 0;
int16 AccYout = 0;
int16 AccYoutALPF = 0;
int8 SideUpFlag = 0;

extern uint8 PowerBoardFlag ;

extern int8 BrokenFlag ;

extern int8 CurrentLimMode ;

extern int16 TempHall_Angle ;

extern uint8 OverSpeedFlag ;
/*-------------------------------------------------------------------------------------------------
    Function Name : void FO_INT(void)
    Description   : FO_INT interrupt，硬件FO过流保护，关断输出，中断优先级最高
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void FO_INT(void) interrupt 1                                                   // 硬件FO过流中断，关闭输出
{
}


/*---------------------------------------------------------------------------*/
/* Name     :   void EXTERN_INT(void) interrupt 2
/* Input    :   NO
/* Output   :   NO
/* Description: 睡眠唤醒
/*---------------------------------------------------------------------------*/
void EXTERN_INT(void) interrupt 2
{
	
    ClrBit(P1_IF, P11);                    // 清零P10标志位
}


/*---------------------------------------------------------------------------*/
/* Name     :   void FOC_INT(void) interrupt 3
/* Input    :   NO
/* Output   :   NO
/* Description: FOC中断(20kHz下为50us)(Drv中断),每个载波周期执行一次，用于处理响应较高的程序，中断优先级第二。DCEN开了就会产生中断。
/*---------------------------------------------------------------------------*/
void FOC_INT(void) interrupt 3
{
    if(ReadBit(DRV_SR, DCIF))                                 // 比较中断
    {


        SetBit(ADC_CR, ADCBSY);
         //角度限制
		AngleLimit();
		
		///////////////////////////
		FOCTHETAValue = FOC__THETA;
		
		
		TIM4Cnt = TIM4__CNTR;
        if(TIM4Cnt >= 45000)
        {
            mcHall.HallSpeed = 0;
//            CarAccSpeed = 0;
        }
		
		//DMA中断等待时间计数
		if(SpeRespPowDelay >= 250)
		{
			
			if(DataSequenceErr == 1)				
			{
				DataSequenceErr = 0;
				DMAErr = 1;
				ClrBit(DMA0_CR0, DMAIE);            //关DMA中断
//				RI = 0;
				ClrBit(DMA0_CR0, DMAEN);            //关DMA
				ClrBit(DMA0_CR0, DMAIF);
				
			}
			
			if(DMAErr == 1)
			{
				DMAWaitTimeCnt ++;
				RI = 0;
				if(DMAWaitTimeCnt >=16)			//延时1ms后开DMA
				{
					DMAErr = 0;

					DataSequenceErr = 0;
					
					SetBit(DMA0_CR0, DMAIE);            //使能DMA中断
					SetBit(DMA0_CR0, DMAEN);            //使能DMA
					SetBit(DMA0_CR0, DMABSY);
					
					DMAWaitTimeCnt = 0;
					
				}
			}
			
		}
		
        TempMcADCCurrentbus   = (ADC3_DR<<3);//LPFFunction((ADC3_DR<<3),TempMcADCCurrentbus,120);//母线电流采样,进行限流保护
        mcFocCtrl.mcADCCurrentbus = TempMcADCCurrentbus - mcCurOffset.Iw_busOffset;
		
		//限流保护程序
		
		
		if(mcFocCtrl.mcADCCurrentbus >= CurrentLimitVal)
		{
			if(FOC__UQ >= 0)
			{
				UQMax = FOC__UQ;
				UQMin = 0 - UQMax;
			}
			else
			{
				UQMin = FOC__UQ;
				UQMax = 0 - UQMin;
			}
			
			UQMax -= CurLimValInc;
			UQMin += CurLimValInc;
			if(UQMax < 0)
				UQMax = 0;
			if(UQMin > 0)
				UQMin = 0;
		}
		else
		{
			UQMax += CurLimValInc;
			UQMin -= CurLimValInc;
			if(UQMax > BalanceUQMax)
				UQMax = BalanceUQMax;
			if(UQMin < BalanceUQMin)
				UQMin = BalanceUQMin;
		}
		
		FOC__UQ = AngleOutput;
		
		if(FOC__UQ > UQMax)
			FOC__UQ = UQMax;
		else if(FOC__UQ < UQMin)
			FOC__UQ = UQMin;

		
		
//		if(BeepOnOff == 1)
//		{
//			BeepCnt ++;
//			if(BeepCnt >= 4)
//			{
//				Beep = ~Beep;
//				BeepCnt = 0;
//			}
//		}
//		else
//			Beep = 0;

		
		/*霍尔错误检测*/
        if((mcHall.HallStatus_Result==7)||(mcHall.HallStatus_Result==0))
        {
//			mcState = mcFault;
			AnglePro = 1;
			HallErrMisic = 1;
//            MOE = 0;
//            mcFaultSource = FaulHallFailure;
        }
		else
			HallErrMisic = 0;
		
		
        ClrBit(DRV_SR, DCIF);

    }
}


/*---------------------------------------------------------------------------*/
/* Name     :   void TIM2_INT(void) interrupt 4
/* Input    :   NO
/* Output   :   NO
/* Description:	60us定时器中断
/*---------------------------------------------------------------------------*/
void TIM2_INT(void) interrupt 4
{
			
    if(ReadBit(TIM2_CR1, T2IF))                          //溢出中断,时间为60us。
    {
        ClrBit(TIM2_CR1, T2IF);

    }
}

/*-------------------------------------------------------------------------------------------------
    Function Name : void CMP_ISR(void)
    Description   : CMP3：硬件比较器过流保护，关断输出，中断优先级最高
										CMP0/1/2：顺逆风判断
    Input         : 无
		Output        : 无
-------------------------------------------------------------------------------------------------*/
void CMP_ISR(void) interrupt 7
{
    if(ReadBit(CMP_SR, CMP3IF))
    {		
		
		Beep = 1;																	//蜂鸣器报警
		MOE = 0;
		ClrBit(DRV_CR, FOCEN);	//关闭FOC
		EA = 0;
		mcFaultSource = FaultHardOVCurrent;
		mcState = mcFault;
		
        ClrBit(CMP_SR, CMP3IF);
    }
}

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM23_INT(void) interrupt 9
/* Input    :   NO
/* Output   :   NO
/* Description: 
/*---------------------------------------------------------------------------*/
void TIM3_INT(void) interrupt 9
{
//    if(ReadBit(TIM3_CR1, T3IR))
//    {
//        ClrBit(TIM3_CR1, T3IR);
//    }
//    if(ReadBit(TIM3_CR1, T3IP))
//    {
//        ClrBit(TIM3_CR1, T3IP);
//    }
    if(ReadBit(TIM3_CR1, T3IF))
    {
        
		/*霍尔速度滤波*/
        HallSpeedALPF = LPFFunction(mcHall.HallSpeed, HallSpeedALPF, 6);			
		ABSHallSpeedALPF = Abs_F16(HallSpeedALPF);
		
		/*霍尔加速度滤波*/
//	    CarAccSpeedALPF = LPFFunction(CarAccSpeed, CarAccSpeedALPF, 6);
				
        if((mcState == mcStop)&&(MOE ==0)||(mcCurOffset.OffsetFlag==2))
        {
            

            mcCurOffset.OffsetFlag = 3;					
        }
        
        /****************IIC读MPU6050**********************/
        Read_Acc_Gyr(ACCEL_XOUT_H, GYRO_YOUT_H);
        
        /*低通滤波*/
//        AccAngleALPF = LPFFunction(AccAngle, AccAngleALPF, 10);

        /*卡尔曼滤波*/
        Kalman_Filter( AccAngle, GyrAngVel);                   //980us

        /*低通滤波*/
//        angleALPF = LPFFunction((int16)angle, angleALPF, 100);
		
		if((int16)angle > 11444) angle = 11444.0;
		if((int16)angle < -11444) angle = -11444.0;
		
        /*角度PID运算*/
        AngleOutput = (int16)AngleControl((int16)angle, (int16)GyrAngVel);
		
		
                
        /*环路响应,需上电后延时一段时间执行*/
		SpeRespPowDelay ++;
		if(SpeRespPowDelay >= 400)
		{
			if(BalancePointMoveLock == 0)
			{
				PowerOnSelfBalance();
			}
			else
				Speed_response();
						
			
			
			if(BalancePointMoveLock == 1 && SpeRespPowDelay >= 600)
			{
				//自平衡完成灯光
				#if (BoardRole == SeconBoard)
				
				if(MainBoardData.MainBoardBrokenFlag == 1 || BrokenFlag == 1 || HallErrMisic == 1 || OverSpeedFlag == 1)
				{
					PowerStatueLedGreen = 0;
					PowerStatueLedRed = 1;
				}
				else
				{
					PowerStatueLedGreen = 1;
					PowerStatueLedRed = 0;
				}
				#endif
				
				
				SpeRespPowDelay = 600;
			}
			

		}

        /*读取ADC采样值*/
        mcFocCtrl.mcADCVoltagebus   = LPFFunction((ADC2_DR<<3),mcFocCtrl.mcADCVoltagebus,6)  ;//母线电压采样，进行欠压保护
		mcADCVoltagebus2 = mcFocCtrl.mcADCVoltagebus / BatteryNumber;
		
//		mcFocCtrl.mcADCVoltagebus -= 1000;
		
		/*堵转保护*/
		if(StallProject == 0)
		{
			if(mcFocCtrl.mcADCCurrentbus >= I_ValueRC(7.0) && ABSHallSpeedALPF <= TEMP_STALL_SPEED)
				StallProjectCnt ++;
			else if(StallProjectCnt > 0)
				StallProjectCnt --;
		}
		else if(StallProject == 1)
		{
			if(mcFocCtrl.mcADCCurrentbus >= I_ValueRC(1.6) && ABSHallSpeedALPF <= TEMP_STALL_SPEED)
				StallProjectCnt ++;
			else if(StallProjectCnt > 0)
				StallProjectCnt --;
		}
		
		if(StallProjectCnt >= 5000)
		{
			StallProjectCnt = 5000;
			StallProject = 1;
		}
		else
			StallProject = 0;
		
		
		#if (BoardRole == MainBoard)
		if(StallProject == 1 )
		{
			if(CurrentLimMode == 0)
				CurrentLimitVal = (int16)UNDERVOL_RMS_CURRENT;
			else if(CurrentLimMode == 1)
				CurrentLimitVal = (int16)UNDERVOL_RMS_CURRENT_Mode1;
			else
				CurrentLimitVal = (int16)UNDERVOL_RMS_CURRENT_Mode2;
		}
		else
		{	
			if(CurrentLimMode == 0)
				CurrentLimitVal = (int16)IQ_RUN_MAX_RMS_CURRENT;
			else if(CurrentLimMode == 1)
				CurrentLimitVal = (int16)IQ_RUN_MAX_RMS_CURRENT_Mode1;
			else
				CurrentLimitVal = (int16)IQ_RUN_MAX_RMS_CURRENT_Mode2;
		}
		
		#elif (BoardRole == SeconBoard)
		if(StallProject == 1 )
		{
			if(MainBoardData.MainBoardCurrentLimMode == 0)
				CurrentLimitVal = (int16)UNDERVOL_RMS_CURRENT;
			else if(MainBoardData.MainBoardCurrentLimMode == 1)
				CurrentLimitVal = (int16)UNDERVOL_RMS_CURRENT_Mode1;
			else
				CurrentLimitVal = (int16)UNDERVOL_RMS_CURRENT_Mode2;
		}
		else
		{	
			if(MainBoardData.MainBoardCurrentLimMode == 0)
				CurrentLimitVal = (int16)IQ_RUN_MAX_RMS_CURRENT;
			else if(MainBoardData.MainBoardCurrentLimMode == 1)
				CurrentLimitVal = (int16)IQ_RUN_MAX_RMS_CURRENT_Mode1;
			else
				CurrentLimitVal = (int16)IQ_RUN_MAX_RMS_CURRENT_Mode2;
		}
		#endif
		
		
        /*检测Y轴加速度计用于侧立保护*/
		Read_I2C_Byte(SlaveAddress >> 1, ACCEL_YOUT_H, &AccYoutH, &AccYoutL);
		AccYout = (AccYoutH << 8) + AccYoutL; 
		AccYoutALPF = LPFFunction( AccYout, AccYoutALPF, 4);
		

		//如果3分钟内没人踩踏板以及霍尔没跳变，则关机
//		if(ChargeDetectIO == 1)
//		{
			PowerOffCnt ++;
			if(PowerOffCnt >= 45000)
				TurnOffMusic = 1;
//		}
//		else
//			PowerOffCnt = 0;
		
        		
		    Fault_Detection();

        /***********串口发送周期计数***************/
		
//		if(SpeRespPowDelay >= 250)
//		{
			
			UartSendCnt++;
			if(UartSendCnt >= 6)
			{
				//两机通信发送数据
				UartSendCnt = 0;
				UartSendFlag = 1;
			}		
				#if (BoardRole == MainBoard)
					BoardsCom_Main_Slave();
					SetBit(DMA1_CR0, DMABSY);
				#elif (BoardRole == SeconBoard)
					BoardsCom_Slave_Main();         
					SetBit(DMA1_CR0, DMABSY);
				#endif
//		}
		
			
			
		/*铃声和灯光控制*/
        #if (BoardRole == MainBoard)
            MusicControl();	
					
		#elif (BoardRole == SeconBoard)
		#endif
			
		/*灯光闪烁控制*/	
		LedControl();
        
		

        ClrBit(TIM3_CR1, T3IF);
    }
}

/*---------------------------------------------------------------------------*/
/* Name     :   void TIM4S_INT(void) interrupt 10
/* Input    :   NO
/* Output   :   NO
/* Description: 2ms定时器中断（SYS TICK中断），用于处理附加功能，如控制环路响应、各种保护等。中断优先级低于FO中断和FOC中断。
/*---------------------------------------------------------------------------*/
void TIM4S_INT(void) interrupt 10
{
    if(ReadBit(TIM4_CR1, T4IF))
    {
        Tim4CntOverflow = 1;
        mcHall.HallSpeed = 0;
//        CarAccSpeedALPF = 0;
//        CarAccSpeed = 0;
        LastCarSpeed = 0;
		
		FOC__RTHESTEP = 0;
		
        if(mcHall.HallFRStatus==1)
		{
            FOC__THETA = TempHall_Angle + AngleOffset;
		}
        else
		{
            FOC__THETA = TempHall_Angle - AngleOffset;
		}
		
        ClrBit(TIM4_CR1, T4IF);
    }
		
	
    if(ReadBit(DRV_SR, SYSTIF))          // SYS TICK中断
    {
        ClrBit(DRV_SR, SYSTIF);                                    // 清零标志位
    }
}


/*---------------------------------------------------------------------------*/
/* Name     :   void USART_INT(void) interrupt 12
/* Input    :   NO
/* Output   :   NO
/* Description: 串口中断，中断优先级最低，用于接收调速信号,无中断插入时8us
/*---------------------------------------------------------------------------*/
void USART_INT(void)  interrupt 12
{
//    static BoardComCnt = 0;
    
    if(RI == 1)
    {
        RI = 0;
    }
}

void DMA_INT15(void) interrupt 15
{
	if(ReadBit(DMA1_CR0, DMAIF))
	{
//		SetBit(DMA1_CR0, DMABSY);
		ClrBit(DMA1_CR0, DMAIF);
	}
	if(ReadBit(DMA0_CR0, DMAIF))
	{
		
		#if (BoardRole == MainBoard)
			MainBoardDealWithData();
		#elif (BoardRole == SeconBoard)
			SeconBoardDealWithData();                                               
		#endif
		
		SetBit(DMA0_CR0, DMABSY);
		ClrBit(DMA0_CR0, DMAIF);
	}
}


/* Private variables ----------------------------------------------------------------------------*/
void INT0(void) interrupt 0
{
}
void TIM1_HALL_INT(void) interrupt 5
{
	if(ReadBit(TIM1_SR,T1PDIF))
	{
        HallStatus_CaptureFilter();                               //采集Hall信号      
    
                        
        if(mcHall.LastHallStatus==0)
        {
            mcHall.LastHallStatus = mcHall.HallStatus_Result;
        }
                            
        if( (PowerAngleFlag == 1))
        {
			PowerOffCnt = 0;
                                                         
            //判断电机运行方向，1为初始化设定方向，2位初始化方向的反方向
            HallFRStatusTeat = HallStatus_Check(0,mcHall.LastHallStatus,mcHall.HallStatus_Result);
            mcHall.HallFRStatus = HallFRStatusTeat;

                                                                                      
            //角度和角速度计算，处理
            Hall_RTHESTEP_Capture();    //速度计算及角速度处理 27us
            Hall_THETA_Capture();	    //角度处理 14.6us	
            
            if(LastHallFRStatusTeat != HallFRStatusTeat)
            {
                CarAccSpSmo = 1;
                CarAccSpSmoCnt = 0;
            }
            
            if(CarAccSpSmo == 1 && LastHallFRStatusTeat == HallFRStatusTeat)
            {
                CarAccSpSmoCnt ++;
            }
            
            if(CarAccSpSmoCnt >= 1)
            {
                CarAccSpSmo = 0;
                CarAccSpSmoCnt = 0;
            }
            
            if(CarAccSpSmo == 1)
            {
                mcHall.HallSpeed = 0;
//                CarAccSpeed = 0;
//                CarAccSpeedALPF = 0;
//                LastCarSpeed = 0;
            }
            
            LastHallFRStatusTeat = HallFRStatusTeat;
            mcHall.LastHallStatus = mcHall.HallStatus_Result;												
        }
		
		ClrBit(TIM1_SR, T1PDIF);
	}
	
	if(ReadBit(TIM1_SR,T1BOIF))
	{					
		ClrBit(TIM1_SR, T1BOIF);
	}
}
void INT6(void) interrupt 6
{
}
void INT8(void) interrupt 8
{
}
void INT11(void) interrupt 11
{
}
void INT13(void) interrupt 13
{
}
void INT14(void) interrupt 14
{
}




