/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Vina Peng,Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains MDU initial function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>

extern uint8 HallFRStatusTeat;
extern int16 LastCarSpeed;
extern int16 CarAccSpeed;

//MDUControl_TypeDef xdata MDUControl;

/*-------------------------------------------------------------------------------------------------
	Function Name : void MDUAPP1(void)
	Description   :
	Input         :	��
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void MDUAPP1(void)
{
	mcHall.RTheStep   = MDU_DIV_XDATA_U32(&mcHall.HallThetaBase, &mcHall.PeriodTime);

	if(HallFRStatusTeat == 2)
		mcHall.HallSpeed = 0 - MDU_DIV_XDATA_U32(&mcHall.HallSpeedBase, &mcHall.PeriodTime);	
	else
		mcHall.HallSpeed = MDU_DIV_XDATA_U32(&mcHall.HallSpeedBase, &mcHall.PeriodTime);	

	/*����ٶ�*/
//	CarAccSpeed = mcHall.HallSpeed - LastCarSpeed;

	/*�����ϴ��ٶ�ֵ*/
//	LastCarSpeed = mcHall.HallSpeed;

}









