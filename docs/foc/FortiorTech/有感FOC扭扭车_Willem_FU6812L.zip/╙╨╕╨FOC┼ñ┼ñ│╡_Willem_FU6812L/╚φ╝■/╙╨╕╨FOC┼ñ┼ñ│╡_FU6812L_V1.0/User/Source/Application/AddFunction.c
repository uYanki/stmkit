/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the add function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <AddFunction.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ---------------------------------------------------------*/
FaultStateType			       mcFaultSource;
FaultVarible       idata   mcFaultDect;

ProtectVarible     xdata   mcProtectTime;

FOCCTRL            xdata   mcFocCtrl;


MCLedDisplay       xdata   mcLedDisplay;
MCRAMP             xdata   mcSpeedRamp;
MotorFRTypeDef		 xdata   mcFRState;
BreakDowmVarible   xdata     mcBreakDowm;


int16 RealAngleGivenToFoc = 0;


extern char KeyBrake;

extern uint8 HallFRStatusTeat;

uint8 SmoothFlag = 0;
uint8 SmoothCnt = 0;

extern uint8 Tim4CntOverflow;

extern uint8 ThetaOverflow;

extern int16 AngleOutput;
extern int16 UQAddition;

extern float GetAngIncre;

uint8 BoardMusicFlag = 0;
extern uint8 BoardMusic;

/*蜂鸣器变量*/
uint8 MuSca = 0;
uint8 SpeakCnt = 0;

uint8 OverUnderVoltageMusic = 0;
uint8 OverUnderVoltageFlag = 0;
uint8 ErrorMusic = 0;
uint8 TurnOffMusic = 0;
uint8 OCMusic = 0;
uint8 BoardMusic = 0;
uint16 MusicCnt = 0;

uint8 PowerBoardFlag = 0;
uint8 PowerBoardProtect = 1;

extern int16 angleALPF;

extern int16 BalancePoint;

uint8 SeconBoardMusic = 0;
uint8 SeconBoardMusicFlag = 0;

uint8 SeconBoardErrorMusic = 0;

int16 TempHall_Angle = 0;

extern float AngPosConP ;
extern float AngPosConD ;

extern float AngIncConP ;     

extern uint16 TempMcADCCurrentbus;



extern uint16 PowerOffCnt;


extern int16 RecSlaveAngle;
extern int16 RecMainAngle;

int8 BalancePointMoveLock = 0;

uint8 AnglePro = 0;
uint8 BalancePointMoveFlag = 0;



extern int16 HallSpeedALPF;

uint8 BalanPointMovCnt = 0;

int16 RampStepInc1 = 40;

extern float AngSpLoopP ;

extern float AngSpLoopD ;



uint8 HallFRStatusForRTHESTEP = 0;
extern uint8 LastHallFRStatusTeat;

extern int16 FOCTHETAValue;
extern float angle;

extern int8 OverSpeedLed;

uint8 MainBoardOverSpLedstat = 0;

uint8 LimitCurMusicLed = 0;



extern uint8 HallErrMisic ;
extern uint8 SeconBoardHallErrorState;
extern uint8 SeconBoardLimitCurMusicLed ;
extern uint8 MainBoardLimitCurMusicLed ;
extern uint8 MainBoardHallErrLed ;
extern float AngPosConI ;
extern float AngPosOutI ;
uint8 PhaselossMusic = 0;

extern uint8 SeconBoardPhaselossMusicLed ;
extern uint8 MainBoardPhaselossMusicLed ;
int16 TwoBoaAngErrAve = 0;
int16 ABSHallSpeedALPF = 0;
int16 BalancePointBef = 0;
extern float PosConIOutLimValMax ;
extern float PosConIOutLimValMin ;

float BalancePointIncRate = 0;
float BalancePointInc = 0;

int16 HallSpeedALPFMax = 0;
int16 ABSHallSpeedALPFLast = 0;

float HighSpSynchRate = 0.0;

int16 NormalOSVal = 0;
extern int16 RecSlaveSpeed ;
extern int16 RecMainSpeed ;
uint16 LastPowerOnOffAD = 10000;
uint8 PowerOnOffADFlag = 0;
uint16 PowerOnOffADCnt = 0;

extern int16 BalanceGyrALPF;
extern int16 BalanceAccALPF;
extern uint8 BoardMusic ;
extern int16 SpeRespPowDelay ;

int8 BeepOnOff = 0;
uint8 MainBoardSelfBalModeLast = 0;

extern int16 BalConOutputMax ;
extern int16 BalConOutputMin ;

int8 BalFlag1AtMode1 = 1;
int8 BalFlag2AtMode1 = 0;

extern int16 mcADCVoltagebus2 ;

extern int8 PowerFrom35to36LedFlag ;

int16 LedCnt = 0;

extern int8 StallProject ;

extern int16 AccYoutALPF ;
extern int8 SideUpFlag ;
extern int8 ChargeYelLedSFlashFlag ;

uint16 PowerOnOffAD = 0;

uint8 TurnOffTimeCnt = 0;
uint8 TurnOffCnt = 0;

int8 CurrentLimMode = 0;

extern int8 BrokenMusic ;

extern int8 ChargeFlag;
uint8 SeconBoardUnderVolCurrentFlag = 1;

uint8 OverSpeedFlag = 0;
/*---------------------------------------------------------------------------*/
/* Name		:	int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
/* Input	:	INVlaue，OutLastValue
/* Output	:	int16的变量
/* Description:	滤波函数,用乘法器做的
/*---------------------------------------------------------------------------*/
int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
{
	int16 Result = 0;
	MDU_MA = (INVlaue-OutLastValue);
	MDU_MB = (int16)480;		           			/*写被乘数和乘数*/

	Result = MDU_MB;
	Result += OutLastValue;
	return(Result);
}

/*---------------------------------------------------------------------------*/
/* Name		:	void FaultProcess(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	错误处理函数，将状态变为mcFault
/*---------------------------------------------------------------------------*/
void FaultProcess(void)
{
    ErrorMusic = 1;
	mcState = mcFault;
}


/*---------------------------------------------------------------------------*/
/* Name		:	int16 Abs_F16(int16 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint16 Abs_F16(int16 value)
{
	if(value < 0)
	{
		return (0 - value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	int32 Abs_F32(int32 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint32 Abs_F32(int32 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	void APP_DIV(void)
/* Input	:	void
/* Output	:	void
/* Description:	将所有用到除法的地方，放在同一个中断，以避免中断串扰
/*---------------------------------------------------------------------------*/
void APP_DIV(void)
{
    if( mcFocCtrl.ESDIVFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcFocCtrl.SQUSpeedDIVEs = MDU_DIV_XDATA_U32(&mcFocCtrl.SQUSysSpeed,&mcFocCtrl.EsValue);
       mcFocCtrl.ESDIVFlag=0;
    }
}
/*****************************************************************************
 * Function:		 void	Fault_OverVoltage(mcFaultVarible *h_Fault)
 * Description:	 过压欠压保护函数：程序每5ms判断一次，母线电压大于过压保护值时，计数器加一，计数器值超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
                 同理，欠压保护。
	               电机过欠压保护状态下，母线电压恢复到欠压恢复值以上，过压恢复值以下时，计数器加一，超过200次后，恢复。根据档位信息来决定恢复到哪个状态。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_OverUnderVoltage(FaultVarible *h_Fault)
{
//		if(mcFaultSource == FaultNoSource)//程序无其他保护下
//		{

			//欠压保护

				if((mcADCVoltagebus2 < UNDER_PROTECT_VALUE2) || (mcADCVoltagebus2 <= UNDER_PROTECT_VALUE1 && mcFocCtrl.mcADCCurrentbus <= I_ValueRC(1.0) && SeconBoardData.SeconBoardUnderVolCurrentFlag == 1))	
				{
					h_Fault->UnderVoltDetecCnt += 5;
					
					if(h_Fault->UnderVoltDetecCnt > 500)
						h_Fault->UnderVoltDetecCnt = 500;
						
					if(h_Fault->UnderVoltDetecCnt >= 500)//累计超过100次（2秒）则欠压
					{
						mcFaultSource=FaultUnderVoltage;
						OverUnderVoltageMusic = 1;
						OverUnderVoltageFlag = 1;						
					}
				}
				else if(mcADCVoltagebus2 > UNDER_RECOVER_VALUE)
				{
					if(h_Fault->UnderVoltDetecCnt>2)
						h_Fault->UnderVoltDetecCnt -= 2;
					
					else
					{
						mcFaultSource = FaultNoSource;
						OverUnderVoltageMusic = 0;
						OverUnderVoltageFlag = 0;						
					}
				}
//		}

}


/*****************************************************************************
 * Function:		 void	Fault_OverCurrentRecover(mcFaultVarible *h_Fault)
 * Description:	 软硬件过流保护恢复
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_OverCurrentRecover(FaultVarible *h_Fault)
{
	if((mcState == mcFault)&&((mcFaultSource==FaultSoftOVCurrent)||(mcFaultSource==FaultHardOVCurrent))&&(mcProtectTime.CurrentPretectTimes<5))
	{
		h_Fault->CurrentRecoverCnt++;
		if(h_Fault->CurrentRecoverCnt>=OverCurrentRecoverTime)//200*5=1s
		{
			h_Fault->CurrentRecoverCnt=0;
			mcProtectTime.CurrentPretectTimes++;
			mcState = mcInit;
			mcFaultSource=FaultNoSource;
    }
  }
}

 /*****************************************************************************
 * Function:		 void	Fault_phaseloss(mcFaultVarible *h_Fault)
 * Description:	 缺相保护函数，当电机运行状态下，10ms取三相电流的最大值，
	               1.5s判断各相电流最大值，若存在两相电流值大于一定值，而第三相电流值却非常小，则判断为缺相保护，电机停机；
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_phaseloss(FaultVarible *h_Fault)
{
	if(mcState == mcRun)
	{
		h_Fault->Lphasecnt++;
		if(h_Fault->Lphasecnt >= 25)
		{
			h_Fault->Lphasecnt = 0;
			if(h_Fault->Max_ib > (h_Fault->Max_ia * 4) && h_Fault->Max_ic > (h_Fault->Max_ia * 4) && h_Fault->Max_ib > NomCurrent)
			{
				h_Fault->AOpencnt++;
			}
			else
			{
				h_Fault->AOpencnt = 0;
			}								 
			if(h_Fault->Max_ia > (h_Fault->Max_ib * 4) && h_Fault->Max_ic > (h_Fault->Max_ib * 4) && h_Fault->Max_ic > NomCurrent)
			{
				h_Fault->BOpencnt++;
			}
			else
			{
				h_Fault->BOpencnt = 0;
			}								 
			if(h_Fault->Max_ia > (h_Fault->Max_ic * 4) && h_Fault->Max_ib > (h_Fault->Max_ic * 4) && h_Fault->Max_ib > NomCurrent)
			{
				h_Fault->COpencnt++;
			}
			else
			{
				h_Fault->COpencnt = 0;
			}								 

			h_Fault->Max_ia = 0;
			h_Fault->Max_ib = 0;
			h_Fault->Max_ic = 0;
		}
		if(h_Fault->AOpencnt > 1|| h_Fault->BOpencnt > 1 || h_Fault->COpencnt > 1)
		{
			PhaselossMusic = 1;
		}
		else
			PhaselossMusic = 0;
	}
}



/*---------------------------------------------------------------------------*/
/* Name		:	void Fault_Detection(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护函数，因保护的时间响应不会很高，采用分段处理，每5个定时器中断执行一次对应的保护
	              常见保护有过欠压、过温、堵转、启动、缺相等保护，调试时，可根据需求，一个个的调试加入。
/*---------------------------------------------------------------------------*/
void Fault_Detection(void)
{
	mcFaultDect.segment++;
	if(mcFaultDect.segment>=5)
	{
		mcFaultDect.segment=0;
	}
	if(mcFaultDect.segment==0)
	{
//		if(CurrentRecoverEnable)   //过流保护恢复使能
//		{
//			Fault_OverCurrentRecover(&mcFaultDect);
//		}
	}
	else if(mcFaultDect.segment==1)
	{
		#if (BoardRole == MainBoard)
			Fault_OverUnderVoltage(&mcFaultDect);									//过欠压保护
		
		#elif (BoardRole == SeconBoard)
		
			if(mcFocCtrl.mcADCCurrentbus <= I_ValueRC(1.0))
				SeconBoardUnderVolCurrentFlag = 1;
			else
				SeconBoardUnderVolCurrentFlag = 0;
		
		#endif
	}
	else if(mcFaultDect.segment==2)												//限流保护程序
	{
	}
	else if(mcFaultDect.segment==3)
	{
	}
	else if(mcFaultDect.segment==4)
	{
		if(PhaseLossProtectEnable==1)//缺相保护使能
		{
//			Fault_phaseloss(&mcFaultDect);
		}
	}
	else
	{

	}
}

void PowerOnSelfBalance(void)
{
	int16 RampStepInc = 0;
	
	PowerBoardFlag = 0;
	MOE = 1;
//	GetAngIncre = 0;
	
	
	
	SetBit(FOC_CR2, UDD);
	PowerBoardProtect = 0;
	
	AngPosConP = SelfBalAngPosConParaP;
	AngPosConD = SelfBalAngPosConParaD;
	AngPosConI = 0.0;   

    AngSpLoopP = SelfBalAngSpConParaP;

    AngSpLoopD = SelfBalAngSpConParaD;
	
	if(BalancePoint != 0)
	{
		if(BalancePoint < 0)
		{	
			if(BalancePoint < -2000)
				RampStepInc = 80;
			else
				RampStepInc = 10;
			
			if((BalancePoint + RampStepInc) < 0)
			{
				BalancePoint += RampStepInc;
			}
			else
			{
				BalancePoint = 0;
				BalancePointMoveLock = 1;
			}
		}
		else
		{
			if(BalancePoint > 2000)
				RampStepInc = 80;
			else
				RampStepInc = 10;
			
			if((BalancePoint - RampStepInc) > 0)
			{
				BalancePoint -= RampStepInc;
			}
			else
			{
				BalancePoint = 0;
				BalancePointMoveLock = 1;
			}
		}
	}
	else
		BalancePointMoveLock = 1;
	
}

/*---------------------------------------------------------------------------*/
/* Name		:	void Speed_response(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	速度响应函数，可根据需求加入控制环，如恒转矩控制、恒转速控制、恒功率控制
/*---------------------------------------------------------------------------*/
void Speed_response(void)
{
	static int8 BalPoiFolRecAng = 10;
	
	
	if(mcState != mcFault)
	{
		/*启动（踩踏板）平滑处理*/
		if((FootBoardKey1 == 1 || FootBoardKey2 == 1) && AnglePro == 0 && (BalFlag1AtMode1 == 1 || BalFlag2AtMode1 == 1) )
		{
			PowerOffCnt = 0;										//关机计数清零
			FOC_DMAX = 1000;
			FOC_DMIN = -1000;

			PowerBoardProtect = 0;
			PowerBoardFlag = 1;										//踩踏板的标志位
			BalFlag2AtMode1 = 1;									//当踩着踏板时，不判断角度
			
			
			
			/*蜂鸣器*/
			#if (BoardRole == MainBoard)
			
				if(BoardMusicFlag == 0)
				{
					if(SeconBoardData.SeconBoardPowerBoardFlag == 0)
					{
						BoardMusic = 1;
						BoardMusicFlag = 1;
					}
					else
						BoardMusicFlag = 1;
					
					
					
				}
			#elif (BoardRole == SeconBoard)
				if(SeconBoardMusicFlag == 0)
				{
					if(MainBoardData.MainBoardPowerBoardFlag == 0)
					{
						SeconBoardMusic = 1;     
						SeconBoardMusicFlag = 1;         
					}
					else
						SeconBoardMusicFlag = 1;
					
					
										
				}
			#endif
			
			ClrBit(FOC_CR2, UDD);
					
			if(BalancePointMoveFlag == 0)
			{
				BalanPointMovCnt ++;
				if(BalanPointMovCnt == 1)
				{
					AngPosConP = AngPosConParaP;
					AngPosConD = AngPosConParaD;
					AngSpLoopP = AngSpLoopParaP;
					AngSpLoopD = AngSpLoopParaD;
					BalancePoint = (int16)angle;
					
					/*使AngleControlOut限幅值等于现在的UQ*/
					if(AngleOutput >= 0)
					{
						BalConOutputMax = AngleOutput;
						BalConOutputMin = 0 - BalConOutputMax;
					}
					else
					{
						BalConOutputMin = AngleOutput;
						BalConOutputMax = 0 - BalConOutputMin;
					}
				}
				else if(BalanPointMovCnt >= 20)
				{
					BalanPointMovCnt = 250;
					if(BalancePoint == 0)
						BalancePointMoveFlag = 1;
					else if(BalancePoint < 0)
					{
						if((BalancePoint + RampStepInc1) < 0)
						{
							BalancePoint += RampStepInc1;
						}
						else
						{
							BalancePoint = 0;
							BalancePointMoveFlag = 1;
						}
					}
					else
					{
						if((BalancePoint - RampStepInc1) > 0)
						{
							BalancePoint -= RampStepInc1;
						}
						else
						{
							BalancePoint = 0;
							BalancePointMoveFlag = 1;
						}
					}
				}
			}
			
			else
			{
				AngPosConP = AngPosConParaP;
				AngPosConD = AngPosConParaD;
				AngSpLoopP = AngSpLoopParaP;
				AngSpLoopD = AngSpLoopParaD;
				
				AngPosConI = AngPosConParaI;
				
				
				/*两板高速同步*/
				#if (BoardRole == MainBoard)
					TwoBoaAngErrAve = (int16)((RecSlaveAngle + angle) / 2);
				#elif (BoardRole == SeconBoard)
					TwoBoaAngErrAve = (int16)((RecMainAngle + angle) / 2);
				#endif
									
//				HighSpSynchRate = (float)ABSHallSpeedALPF * 0.0002;
//				if(HighSpSynchRate > 1.0)
//					HighSpSynchRate = 1.0;
				
//				HighSpSynchRate = 1.2;
//				
//				BalancePointBef = (0 - (int16)(HighSpSynchRate * (float)TwoBoaAngErrAve));
					
				BalancePointBef = 0;
				
				//低电压和正常运行速度阈值切换
				if(OverUnderVoltageFlag == 0)
					NormalOSVal = (int16)TEMP_NORMAL_OS;
				else
					NormalOSVal = (int16)TEMP_OVER_VOL_OS;
				
				#if (BoardRole == MainBoard)
				/*移动平衡点抬板*/
				if(((RecSlaveSpeed + ABSHallSpeedALPF) / 2) > NormalOSVal)
				{
					if(NormalOSVal == (int16)TEMP_NORMAL_OS)
						OverSpeedFlag = 1;
					else
						OverSpeedFlag = 0;
					
					if(HallSpeedALPF >= 0)
					{
						BalancePointInc += 1.0;
					}
					else if(HallSpeedALPF < 0)
					{
						BalancePointInc -= 1.0;
					}
				}
				#elif (BoardRole == SeconBoard)
				/*移动平衡点抬板*/
				if(((RecMainSpeed + ABSHallSpeedALPF) / 2) > NormalOSVal)
				{
					if(NormalOSVal == (int16)TEMP_NORMAL_OS)
						OverSpeedFlag = 1;
					else
						OverSpeedFlag = 0;
					
					if(HallSpeedALPF >= 0)
					{
						BalancePointInc += 1.0;
					}
					else if(HallSpeedALPF < 0)
					{
						BalancePointInc -= 1.0;
					}
				}
				#endif
				else
				{
					if(BalancePointInc >= 4.0)
						BalancePointInc -= 4.0;
					else if(BalancePointInc <= -4.0)
						BalancePointInc += 4.0;
					else
						BalancePointInc = 0;
					
					OverSpeedFlag = 0;
				}
				
				if(BalancePointInc > 1800.0)
					BalancePointInc = 1800.0;
				else if(BalancePointInc < -1800.0)
					BalancePointInc = -1800.0;
				
				BalancePointBef += (int16)BalancePointInc;
				
				BalancePoint = LPFFunction(BalancePointBef, BalancePoint, 120);
			}
			
			if(BalConOutputMax < BalanceUQMax)
				BalConOutputMax += 250;
			else
				BalConOutputMax = BalanceUQMax;
			
			if(BalConOutputMin > BalanceUQMin)
				BalConOutputMin -= 250;
			else
				BalConOutputMin = BalanceUQMin;
			
			
			

		}
		
		else
		{
				FOC_DMAX = 0;
				FOC_DMIN = 0;
				
				AngPosConI = 0.0;
				AngPosOutI = 0.0;
				
				TwoBoaAngErrAve = 0;
			
				PowerBoardFlag = 0;
				BalanPointMovCnt = 0;
				BalFlag2AtMode1 = 0;
			
				/*蜂鸣器*/
				#if (BoardRole == MainBoard)
					if(BoardMusicFlag == 1)
					{
						if(SeconBoardData.SeconBoardPowerBoardFlag == 0)
						{
							BoardMusic = 1;
							BoardMusicFlag = 0;
						}
						else
							BoardMusicFlag = 1;
						
						
					}
				#elif (BoardRole == SeconBoard)
					if(SeconBoardMusicFlag == 1)
					{
						if(MainBoardData.MainBoardPowerBoardFlag == 0)
						{
							SeconBoardMusic = 1;     
							SeconBoardMusicFlag = 0;        
						}
						else
							SeconBoardMusicFlag = 1;
					
						
					}
				#endif
				
				
		//        GetAngIncre = 0;
				
				BalancePointMoveFlag = 0;
				
				SetBit(FOC_CR2, UDD);
				PowerBoardProtect = 0;
				AngPosConP = SelfBalAngPosConParaP;
				AngPosConD = SelfBalAngPosConParaD;
		//		AngIncConP = SelfBalAngIncConParaP;   
					
				AngSpLoopP = SelfBalAngSpConParaP;

				AngSpLoopD = SelfBalAngSpConParaD;
				
				#if (BoardRole == MainBoard)
					if(RecSlaveAngle - BalancePoint > BalPoiFolRecAng)
						BalancePoint += BalPoiFolRecAng;
					else if(BalancePoint - RecSlaveAngle > BalPoiFolRecAng)
						BalancePoint -= BalPoiFolRecAng;
					else
						BalancePoint = RecSlaveAngle;
					
					//空转保护
					if(SeconBoardData.SeconBoardPowerBoardFlag == 0  && PowerBoardFlag == 0)
					if(RecSlaveSpeed > TEMP_Free_Run_OS && ABSHallSpeedALPF > TEMP_Free_Run_OS)
					{
						AnglePro = 1;
					}
					
				
				#elif (BoardRole == SeconBoard)
					if(RecMainAngle - BalancePoint > BalPoiFolRecAng)
						BalancePoint += BalPoiFolRecAng;
					else if(BalancePoint - RecMainAngle > BalPoiFolRecAng)
						BalancePoint -= BalPoiFolRecAng;
					else
						BalancePoint = RecMainAngle;
					
					//空转保护
					if(MainBoardData.MainBoardPowerBoardFlag == 0  && PowerBoardFlag == 0)
					if(RecSlaveSpeed > TEMP_Free_Run_OS && ABSHallSpeedALPF > TEMP_Free_Run_OS)
					{
						AnglePro = 1;
					}
					
					
					
				#endif
					
					BalFlag1AtMode1 = 1;
					
			if (AnglePro == 1)
			{
				MOE = 0;
			}
//			else
//				MOE = 1;
				
		//角度保护
		if((int16)angle >= 10000 || (int16)angle <= -10000)
			AnglePro = 1;
		
		//侧立角度保护
		if(AccYoutALPF > 13000 || AccYoutALPF < -13000)
			SideUpFlag = 1;
		else
			SideUpFlag = 0;
		
		
		
		
		#if (BoardRole == MainBoard)
			if(SeconBoardData.SeconBoardSideUpProject == 1 && SideUpFlag == 1)
				mcState = mcFault;
			
		#elif (BoardRole == SeconBoard)
			if(MainBoardData.MainBoardSideUpProject == 1 && SideUpFlag == 1)
				mcState = mcFault;
			
		#endif
		
		
		
			/*关机或切换自平衡模式操作*/
			TurnOrShiftSelfBalanceMode();
			
		}
	}
	else
	{
		TurnOrShiftSelfBalanceMode();
		MOE = 0;
		PowerBoardProtect = 1;
	}                        
}


/*---------------------------------------------------------------------------*/
/* Name		:	 uint16 SoftLPF(uint16 Xn1, uint16 Xn0, uint16 K)
/* Input	:	uint16 Xn1, uint16 Xn0, uint16 K
/* Output	:	uint16
/* Description:	软件低通滤波
/*---------------------------------------------------------------------------*/
 int16 SoftLPF(int16 Xn1, int16 Xn0, int16 K)
 {
 	int16 Temp16 = 0;
 	int32 Temp32 = 0;

 	Temp32 = (((int32)Xn1 - (int32)Xn0) * (int32)K) >> 15;
 	Temp16 = Xn0 + (int16)Temp32;
 	return Temp16;
 }



 
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_Genal_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	U(K) = U(k-1) + Kp*(E(k)-E(k-1)) + Ki*E(k) ----- (Uk_min < U(k) < Uk_max)b
	Description   :	PI控制
	Input         :	Xn1--E(K-1)
	                Yn0--U(K-1)
					Xn2--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间为3.8us
-------------------------------------------------------------------------------------------------*/
//int16 HW_Genal_PI(int16 Xn1, int16 Yn0, int16 Xn2)
//{
//		PI_KP = SKP;
//		PI_KI = SKI;
//		PI_UKMAX = SOUTMAX;
//		PI_UKMIN = SOUTMIN;
//		PI_EK =  Xn1;     	  //初始化E(K-1)
//		PI_LPF_CR |= 0x02;	  // Start PI
//		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//		PI_UK =  Yn0;           //初始化U(K-1)
//		PI_EK =  Xn2;	      //填入EK
//		PI_LPF_CR |= 0x02;	  // Start PI
//		_nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//		PI_UK+=(SKP/4096 +1);
//		return PI_UK;
//}
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_One_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	Description   :	PI控制
	Input         :	Xn1--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间us
-------------------------------------------------------------------------------------------------*/
//int16 HW_One_PI(int16 Xn1)
//{
//	  PI_EK =  Xn1;	      //填入EK
//	  PI_LPF_CR |= 0x02;	  // Start PI
//	  _nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//	  PI_UK+=(SKP/4096 +1);
//	  return PI_UK;
//}

/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 LPF(int16 Xn1, int16 Xn0, int8 K)
	Description   :	LFP控制
	Input         :	Xn1--当前输入值
	                Xn0--上一次滤波输出值
									K--LPF滤波系数
  Output				:	LPF_Y--当前滤波输出值，执行时间为4us。
-------------------------------------------------------------------------------------------------*/
int16 LPFFunction(int16 Xn1, int16 Xn0, int8 K)
{
	LPF_K = K;
	LPF_X = Xn1;
	LPF_Y = Xn0;
	SetBit(PI_LPF_CR, LPFSTA);
	_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();
	return LPF_Y;
}

/*---------------------------------------------------------------------------*/
/* Name		:	void VSPSample(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	VSP采样
/*---------------------------------------------------------------------------*/
//void VSPSample(void)
//{
////	 if((VSP > ONPWMDuty)&&(VSP <= OFFPWMDutyHigh))//在ONPWMDuty-OFFPWMDutyHigh之间，电机有转速运行
////		{
////			mcSpeedRamp.FlagONOFF = 1;
////		}
////	 else if((VSP < OFFPWMDuty)||(VSP > OFFPWMDutyHigh))//电机停机
////		{
////			mcSpeedRamp.FlagONOFF = 0;
////		}
//			
//		//转速曲线计算
//		if(mcSpeedRamp.FlagONOFF==1)
//		{
//      #if (Motor_Speed_Control_Mode == SPEED_LOOP_CONTROL)
//      {
//        if(VSP <= MINPWMDuty)    //最小转速运行
//        {
//          mcSpeedRamp.TargetValue = Motor_Min_Speed;
//        }
//        else if(VSP < MAXPWMDuty)//调速
//        {
//          mcSpeedRamp.TargetValue = Motor_Min_Speed + SPEED_K*(VSP-MINPWMDuty);
//        }
//        else		     //最大转速运行
//        {
//          mcSpeedRamp.TargetValue	=	Motor_Max_Speed;
//        }
//      }
////      #elif (Motor_Speed_Control_Mode == POWER_LOOP_CONTROL)
////      {
////        if(VSP <= MINPWMDuty)    //最小转速运行
////        {
////          mcSpeedRamp.TargetValue = Motor_Min_Power;
////        }
////        else if(VSP < MAXPWMDuty)//调速
////        {
////          mcSpeedRamp.TargetValue = Motor_Min_Power + POWER_K*(VSP-MINPWMDuty);
////        }
////        else		                //最大转速运行
////        {
////          mcSpeedRamp.TargetValue	=	Motor_Max_Power;
////        }
////      }
//      #endif
//		}
//		else
//		{
//			mcSpeedRamp.TargetValue =0;
//		}
//}

void Hall_RTHESTEP_Capture(void)
{
		ClrBit(TIM4_CR1, T4EN);			                           // 0，停止计数；1,使能计数	
		
        if(Tim4CntOverflow)
        {
//            mcHall.PeriodTime = 65535;
			FOC__RTHESTEP = 0;
//            Tim4CntOverflow = 0;
			TIM4__CNTR = 0;
			SetBit(TIM4_CR1, T4EN);
        }
        else
		{
			mcHall.PeriodTime = TIM4__CNTR; 
			
			TIM4__CNTR = 0;
			
			SetBit(TIM4_CR1, T4EN);			                           // 0，停止计数；1,使能计数
											
			mcHall.HallThetaBase = TempHallThetaBaseOneStep;//TempHallThetaBase = TempHallThetaBaseOneStep * 6
			mcHall.HallSpeedBase = TempHallSpeedBaseOneStep;		
				
			MDUAPP1();  //16us

			if(mcHall.HallFRStatus == 2)
			{
				FOC__RTHESTEP  = 0- mcHall.RTheStep;	 	
			}
			else if(mcHall.HallFRStatus == 1)
			{
				FOC__RTHESTEP  = mcHall.RTheStep;	
			}
		}
		
		
//		if((FOC__UQ >= 0 && HallFRStatusTeat == 2 ) || (FOC__UQ < 0 && HallFRStatusTeat == 1 ))
//		{
//			SmoothFlag = 1;
//			SmoothCnt = 0;

//		}
//		
//		if(SmoothFlag == 1 && ((FOC__UQ < 0 && HallFRStatusTeat == 2) || (FOC__UQ >= 0 && HallFRStatusTeat == 1)))
//		{
//			SmoothCnt ++;
//		}
//		
//		if(SmoothCnt >= 2)
//		{
//			SmoothFlag = 0;
//			SmoothCnt = 0;
//		}
		

		if(LastHallFRStatusTeat != HallFRStatusTeat)
			HallFRStatusForRTHESTEP = 1;
		else
			HallFRStatusForRTHESTEP = 0;

		if(HallFRStatusForRTHESTEP == 1)
			FOC__RTHESTEP = 0;
}

void Hall_THETA_Capture(void)  
{
	uint8 GiveFR=0;    
	
	// 当赋值为16400（约90度）时，定子磁场方向与转子磁场相同,电机不会转动，说明在正常工作时，定子磁场方向与转子磁场方向相差90度
	mcHall.AngleCompensate = 0;
	GiveFR = mcHall.HallFRStatus-1;
	TempHall_Angle = ThetaDispose1 (mcHall.HallStatus_Result,GiveFR,TempAngleOffsetCW,TempAngleOffsetCCW,mcHall.AngleCompensate); //10us
	
	
	
	
	
	if(Tim4CntOverflow || HallFRStatusForRTHESTEP == 1)
	{
		
		
        if(mcHall.HallFRStatus==1)
		{
			
            FOC__THETA = TempHall_Angle + AngleOffset;
		}
        else
		{
			
            FOC__THETA = TempHall_Angle - AngleOffset;
		}
		
		Tim4CntOverflow = 0;
	}
	else
		FOC__THETA   = TempHall_Angle;//算出角度后给FOC强拉

	RealAngleGivenToFoc = TempHall_Angle;
    
    if(mcHall.HallFRStatus==1)
        mcHall.NextSectorAngle = TempHall_Angle + 10922;
    
    else if(mcHall.HallFRStatus==2)
        mcHall.NextSectorAngle = TempHall_Angle - 10922;
	
	ThetaOverflow = 0;
}

void Check_Start_Posi(void)
{
    uint8 hall_status= 0;

	if(HALLC)
	{
		hall_status += 4;
	}
	
	if(HALLB)
	{
		hall_status += 2;
	}
	
	if(HALLA)
	{
		hall_status += 1;
	}
    mcHall.HallStatus_Result = hall_status;
	mcHall.LastHallStatus = mcHall.HallStatus_Result;
	TempHall_Angle = ThetaDispose1(mcHall.HallStatus_Result,mcHall.HallFRStatus-1,TempAngleOffsetCW,TempAngleOffsetCCW,mcHall.AngleCompensate); //10us
    FOC__THETA = TempHall_Angle;
	
	
	FOCTHETAValue = FOC__THETA;
	
	if(mcHall.HallFRStatus==1)
	{
		FOCTHETAValue += AngleOffset;
		FOC__THETA = FOCTHETAValue;
	}
	else
	{
		FOCTHETAValue -= AngleOffset;
		FOC__THETA = FOCTHETAValue;
	}
    
    if(mcHall.HallFRStatus==1)
        mcHall.NextSectorAngle = TempHall_Angle + 10922;
    
    else if(mcHall.HallFRStatus==2)
        mcHall.NextSectorAngle = TempHall_Angle - 10922;
	
	ThetaOverflow = 0;
}

void MusicControl(void)
{
    if(TurnOffMusic == 1 || ChargeDetectIO == 0)
    {
        MusicCnt ++;
        if(MusicCnt <= 113)
            Beep = 1;
        else if(MusicCnt > 113)
        {
            Beep = 1;
            MusicCnt = 0;
            TurnOffMusic = 0;
			PowerOnOffIO = 0;
            
        }
    }
	
	else if(HallErrMisic == 1 || SeconBoardData.SeconBoardHallErrStat == 1)
	{
        MusicCnt ++;
        if(MusicCnt <= 62)
            Beep = 1;
        else if(MusicCnt > 62 && MusicCnt <= 70)
            Beep = 0;
        else if(MusicCnt > 70 && MusicCnt <= 132)
            Beep = 1;
        else if(MusicCnt > 132 && MusicCnt <= 140)
            Beep = 0;
        else if(MusicCnt > 140 && MusicCnt <= 202)
            Beep = 1;
        else if(MusicCnt > 202 && MusicCnt <= 210)
            Beep = 0;
        else if(MusicCnt > 272)
        {
            MusicCnt = 0;
        }
	}
			
	
    else if(OverUnderVoltageMusic == 1 || BrokenMusic == 1 || AnglePro == 1 || OverSpeedFlag == 1)
    {
        MusicCnt ++;
        if(MusicCnt <= 100)
            Beep = 1;
        else if(MusicCnt > 100 && MusicCnt <= 175)
            Beep = 0;
        else if(MusicCnt > 175)
        {
            MusicCnt = 0;
        }
    }
	

    else if(BoardMusic == 1)
    {
        MusicCnt ++;
        if(MusicCnt <= 22)
            Beep = 1;
        else if(MusicCnt > 22 && MusicCnt <= 30)
            Beep = 0;
        else if(MusicCnt > 30 && MusicCnt <= 52)
            Beep = 1;
        else if(MusicCnt > 52 && MusicCnt <= 60)
            Beep = 0;
        else if(MusicCnt > 60)
        {
            MusicCnt = 0;
            BoardMusic = 0;
        }
    }
		
	else
	{
		Beep = 0;
		MusicCnt = 0;
	}
}

void LedControl(void)
{
	#if (BoardRole == MainBoard)
	if(OverUnderVoltageFlag == 1)
	{
        LedCnt ++;
        if(LedCnt <= 125)
            PowerStatueLedRed = 1;
        else if(LedCnt > 125 && LedCnt <= 250)
            PowerStatueLedRed = 0;
        else if(LedCnt > 250)
        {
            LedCnt = 0;
        }
	}
	
	if(ChargeYelLedSFlashFlag == 1)
	{
        LedCnt ++;
        if(LedCnt <= 125)
            PowerStatueLedYellow = 1;
        else if(LedCnt > 125 && LedCnt <= 250)
            PowerStatueLedYellow = 0;
        else if(LedCnt > 250)
        {
            LedCnt = 0;
        }
	}
	#endif
}

/*关机或切换自平衡模式操作*/
void TurnOrShiftSelfBalanceMode(void)
{
		#if (BoardRole == MainBoard)
			PowerOnOffAD = ADC1_DR;//关机AD值采集
			
			if(LastPowerOnOffAD < 1000 && PowerOnOffAD >= 1000)
				PowerOnOffADFlag = 1;
			if(PowerOnOffADFlag == 1 && PowerOnOffAD < 1000)
			{
				PowerOnOffADFlag = 0;
				TurnOffMusic = 1;
				
			}
						
			LastPowerOnOffAD = PowerOnOffAD ;
		
		#elif (BoardRole == SeconBoard)
			
			
			
		#endif

}