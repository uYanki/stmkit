				
#include <FU68xx_2.h>
#include <Myproject.h>

extern char BalStaToSlave ;

extern uint8 SeconBoardMusic;
extern uint8 SeconBoardErrorMusic;

uint8 UART_DMAData = 0;
uint8 UART_DMADataTest = 0;

SeconBoardVari xdata SeconBoardData;
MainBoardVari xdata MainBoardData;

extern uint8 ErrorMusic ;
extern uint8 TurnOffMusic ;
extern uint8 BoardMusic ;

extern uint8 OverUnderVoltageMusic;

int8 MainToSlaveFraCnt = 0;
int8 SlaveToMainFraCnt = 0;

int8 MainBoardDealWithDataCnt = 0;

extern int16 angleALPF;

int16 RecSlaveAngle = 0;
int16 RecMainAngle = 0;

uint16 RecSlaveAngleH = 0;
uint16 RecSlaveAngleL = 0;
uint16 RecMainAngleH = 0;
uint16 RecMainAngleL = 0;

extern int8 AnglePolarity ;
extern int16 angleALPFForBoardUart ;



extern uint8 AnglePro;

extern float angle;
extern int8 OverSpeedLed;
extern uint8 MainBoardOverSpeedLed ;
extern uint8 MainBoardOverSpLedstat;
extern uint8 LimitCurMusicLed ;




uint8 SeconBoardHallErrorState = 0;
extern uint8 HallErrMisic ;

uint8 SeconBoardLimitCurMusicLed = 0;
uint8 MainBoardLimitCurMusicLed = 0;

uint8 MainBoardHallErrLed = 0;

extern uint8 PhaselossMusic ;

uint8 SeconBoardPhaselossMusicLed = 0;
uint8 MainBoardPhaselossMusicLed = 0;

extern uint8 DMATraAddr[8];
extern uint8 DMARecAddr[8];

uint16 TraCheckCode = 0;
uint16 RecCheckCode = 0;


uint16 UartErrCnt = 0;

uint8 DataSequenceErr = 0;

extern uint8 OverUnderVoltageFlag ;

extern int16 ABSHallSpeedALPF;

int16 RecMainSpeed = 0;
int16 RecSlaveSpeed = 0;

extern uint8 PowerBoardFlag ;
extern int8 SideUpFlag ;

extern int8 BrokenFlag ;

extern int8 CurrentLimMode ;

extern int8 ChargeFlag;

extern uint8 SeconBoardUnderVolCurrentFlag;

/*-------------------------------------------------------------------------------------------------
	Function Name :	void SendDataByUart(void)
	Description   :	UART����һ��int�ͱ���
	Input         :	int�ͱ���
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void SendDataByUart(int in_show)
{
	unsigned char show_result[5];
	
	if(in_show < 0)
	{
		in_show = -in_show;
		UT_DR = '-';	
		while(!TI);
		TI = 0;
	}
	
  show_result[0] = in_show / 10000;
  show_result[1] = in_show / 1000 % 10;
  show_result[2] = in_show / 100 % 10;
  show_result[3] = in_show / 10 % 10;
  show_result[4] = in_show % 10;

	UT_DR = show_result[0] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[1] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[2] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[3] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[4] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = '\n';	
	while(!TI);
	TI = 0;
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void SendDataByUart(void)
	Description   :	UART����һ��unsigned int�ͱ���
	Input         :	unsigned int�ͱ���
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void Send_U_DataByUart(unsigned int in_show)
{
	unsigned char show_result[5];
	
	
  show_result[0] = in_show / 10000;
  show_result[1] = in_show / 1000 % 10;
  show_result[2] = in_show / 100 % 10;
  show_result[3] = in_show / 10 % 10;
  show_result[4] = in_show % 10;

	UT_DR = show_result[0] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[1] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[2] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[3] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = show_result[4] + '0';	
	while(!TI);
	TI = 0;
	UT_DR = '\n';	
	while(!TI);
	TI = 0;

}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void SendDataByUart(void)
	Description   :	UART����һ��int�ͱ���
	Input         :	int�ͱ���
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void SendPictureDataByUart(int in_show1,int in_show2,int in_show3,int in_show4)
{
	char show_result1[2];
	char show_result2[2];
	char show_result3[2];
	char show_result4[2];
	
//	if(in_show < 0)
//	{
//		in_show = -in_show;
//		UT_DR = '-';	
//		while(!TI);
//		TI = 0;
//	}
	
	
    show_result1[0] = (in_show1 >>8) & 0xff;//�߰�λ
    show_result1[1] = in_show1 & 0xff;//�Ͱ�λ

    show_result2[0] = (in_show2 >>8) & 0xff;//�߰�λ
    show_result2[1] = in_show2 & 0xff;//�Ͱ�λ

    show_result3[0] = (in_show3 >>8) & 0xff;//�߰�λ
    show_result3[1] = in_show3 & 0xff;//�Ͱ�λ

    show_result4[0] = (in_show4 >>8) & 0xff;//�߰�λ
    show_result4[1] = in_show4 & 0xff;//�Ͱ�λ

	UT_DR = 0x03;	
	while(!TI);
	TI = 0;
	UT_DR = 0xfc;	
	while(!TI);
	TI = 0;
	UT_DR = show_result1[1];	
	while(!TI);
	TI = 0;
	UT_DR = show_result1[0];	
	while(!TI);
	TI = 0;
	UT_DR = show_result2[1];	
	while(!TI);
	TI = 0;
	UT_DR = show_result2[0];	
	while(!TI);
	TI = 0;
	UT_DR = show_result3[1];	
	while(!TI);
	TI = 0;
	UT_DR = show_result3[0];	
	while(!TI);
	TI = 0;
	UT_DR = show_result4[1];	
	while(!TI);
	TI = 0;
	UT_DR = show_result4[0];	
	while(!TI);
	TI = 0;
	UT_DR = 0xfc;	
	while(!TI);
	TI = 0;
	UT_DR = 0x03;	
	while(!TI);
	TI = 0;

}

void BoardsCom_Master_Tran_For_BalPoi(void)
{
    char MasterTran;
    
    MasterTran = BalStaToSlave;                  //�����0λ���Ϳ�����ƽ��״̬

	UT_DR = 0xff;	
	while(!TI);
	TI = 0;
	UT_DR = 0x00;	
	while(!TI);
	TI = 0;
    
	UT_DR = MasterTran;	
	while(!TI);
	TI = 0;

}

void BoardsCom_Main_Slave(void)
{
    uint8 MainToSlave;
	uint8 MainAngleH;
	uint8 MainAngleL;
	
	
	//����ĵ�0��1λ����֡ͷ
	DMATraAddr[0] = 0xff;
	DMATraAddr[1] = 0x00;
		
	//�����2λ����״̬��־λ
	if((int16)angle >= 0) 
	{
		AnglePolarity = 0;
		angleALPFForBoardUart = (int16)angle;
	}
	else if((int16)angle < 0) 
	{
		AnglePolarity = 1;
		angleALPFForBoardUart = 0 - (int16)angle;
	}
	
	MainToSlave = (BrokenFlag << 7)
				| (AnglePolarity << 6)
				| (AnglePro << 5)
				| (MainBoardOverSpeedLed << 4)
				| (SideUpFlag << 3)
				| (PowerBoardFlag << 2)
				| (OverUnderVoltageFlag << 1)
				| (ChargeFlag);
	
	DMATraAddr[2] = MainToSlave;	
		
	//�����3λ���ͽǶȾ���ֵ�ĸ�8λ
	MainAngleH = (uint8)((angleALPFForBoardUart >> 8) & 0xff);
	DMATraAddr[3] = MainAngleH;	
		
	//�����4λ���ͽǶȾ���ֵ�ĵ�8λ
	MainAngleL = (uint8)(angleALPFForBoardUart & 0xff);
	DMATraAddr[4] = MainAngleL;	
	
	//�����5λ�����ٶȵĸ�8λ
	DMATraAddr[5] = (uint8)((ABSHallSpeedALPF >> 8) & 0xff);
	
	//�����6λ�����ٶȵĵ�8λ
	DMATraAddr[6] = (uint8)(ABSHallSpeedALPF & 0xff);
	
	//�����7λ����У����
	TraCheckCode = (uint16)(DMATraAddr[2] + DMATraAddr[3] + DMATraAddr[4] + DMATraAddr[5] + DMATraAddr[6]) & 0x00ff;
	DMATraAddr[7] = (uint8)TraCheckCode;	
}

void BoardsCom_Slave_Main(void)
{
    uint8 SlaveToMain;
    uint8 SlaveAngleH;
    uint8 SlaveAngleL;
	
	//����ĵ�0��1λ����֡ͷ
	DMATraAddr[0] = 0xff;
	DMATraAddr[1] = 0x00;
	
	//�����2λ����״̬��־λ
	if((int16)angle >= 0) 
	{
		AnglePolarity = 0;
		angleALPFForBoardUart = (int16)angle;
	}
	else if((int16)angle < 0) 
	{
		AnglePolarity = 1;
		angleALPFForBoardUart = 0 - (int16)angle;
	}
	SlaveToMain = (SeconBoardMusic << 7) 
				| (HallErrMisic << 6)
				| (AnglePolarity << 5)
				| (AnglePro << 4)
				| (SeconBoardUnderVolCurrentFlag << 3)
				| (SideUpFlag << 2)
				| (PowerBoardFlag << 1)
				| (BrokenFlag);
	
	DMATraAddr[2] = SlaveToMain;	
	SeconBoardMusic = 0;	
		
	//�����3λ���ͽǶȾ���ֵ�ĸ�8λ
	SlaveAngleH = (uint8)((angleALPFForBoardUart >> 8) & 0xff);
	DMATraAddr[3] = SlaveAngleH;	
		
	//�����4λ���ͽǶȾ���ֵ�ĵ�8λ
	SlaveAngleL = (uint8)(angleALPFForBoardUart & 0xff);
	DMATraAddr[4] = SlaveAngleL;	
	
	//�����5λ�����ٶȵĸ�8λ
	DMATraAddr[5] = (uint8)((ABSHallSpeedALPF >> 8) & 0xff);
	
	//�����6λ�����ٶȵĵ�8λ
	DMATraAddr[6] = (uint8)(ABSHallSpeedALPF & 0xff);
	
	//�����7λ����У����
	TraCheckCode = (uint16)(DMATraAddr[2] + DMATraAddr[3] + DMATraAddr[4] + DMATraAddr[5] + DMATraAddr[6]) & 0x00ff;
	DMATraAddr[7] = (uint8)TraCheckCode;	

}

void MainBoardDealWithData(void)
{
		RecCheckCode = (uint16)(DMARecAddr[2] + DMARecAddr[3] + DMARecAddr[4] + DMARecAddr[5] + DMARecAddr[6]) & 0x00ff;
		if(DMARecAddr[0] == 0xff && DMARecAddr[1] == 0x00)
		{
			if(DMARecAddr[7] == RecCheckCode)
			{
				
				SeconBoardData.SecondBoardStat = (DMARecAddr[2] >> 7) & 0x01;
				SeconBoardData.SeconBoardHallErrStat = (DMARecAddr[2] >> 6) & 0x01;
				SeconBoardData.SeconBoardAngleStat = (DMARecAddr[2] >> 5) & 0x01;
				SeconBoardData.SeconBoardAnglePro = (DMARecAddr[2] >> 4) & 0x01;
				SeconBoardData.SeconBoardUnderVolCurrentFlag = (DMARecAddr[2] >> 3) & 0x01;
				SeconBoardData.SeconBoardSideUpProject = (DMARecAddr[2] >> 2) & 0x01;
				SeconBoardData.SeconBoardPowerBoardFlag = (DMARecAddr[2] >> 1) & 0x01;
				SeconBoardData.SeconBoardBroked = DMARecAddr[2] & 0x01;
				if(SeconBoardData.SecondBoardStat == 1)
				{
					BoardMusic = 1;
					SeconBoardData.SecondBoardStat = 0;
				}
				if(SeconBoardData.SecondBoardError == 1)
				{
					ErrorMusic = 1;
	//				SeconBoardData.SecondBoardError = 0;
				}
				if(SeconBoardData.SeconBoardAnglePro == 1)
				{
					AnglePro = 1;
					SeconBoardData.SeconBoardAnglePro = 0;
				}
				if(SeconBoardData.SeconBoardLimitCurStat == 1)
				{
					SeconBoardLimitCurMusicLed = 1;
	//				SeconBoardData.SeconBoardLimitCurStat = 0;
				}
				else
					SeconBoardLimitCurMusicLed = 0;				
				
				RecSlaveAngleH = DMARecAddr[3];
				RecSlaveAngleL = DMARecAddr[4];
				
				if(SeconBoardData.SeconBoardAngleStat == 0)
					RecSlaveAngle = (RecSlaveAngleH << 8) | RecSlaveAngleL;
				else if(SeconBoardData.SeconBoardAngleStat == 1)
					RecSlaveAngle = 0 - ((RecSlaveAngleH << 8) | RecSlaveAngleL);
				
				RecSlaveSpeed = ((int16)DMARecAddr[5] << 8) + DMARecAddr[6];
			}
		}
		else
		{
			DataSequenceErr = 1;
			UartErrCnt ++;
		}

}

void SeconBoardDealWithData(void)
{
		RecCheckCode = (uint16)(DMARecAddr[2] + DMARecAddr[3] + DMARecAddr[4] + DMARecAddr[5] + DMARecAddr[6]) & 0x00ff;
		if(DMARecAddr[0] == 0xff && DMARecAddr[1] == 0x00)
		{
			if(DMARecAddr[7] == (uint8)RecCheckCode)
			{
					MainBoardData.MainBoardBrokenFlag = (DMARecAddr[2] >> 7) & 0x01;
					MainBoardData.MainBoardAngleStat = (DMARecAddr[2] >> 6) & 0x01;
					MainBoardData.MainBoardAnglePro = (DMARecAddr[2] >> 5) & 0x01;
					MainBoardData.MainBoardOverSpeedStat = (DMARecAddr[2] >> 4) & 0x01;
					MainBoardData.MainBoardSideUpProject = (DMARecAddr[2] >> 3) & 0x01;
					MainBoardData.MainBoardPowerBoardFlag = (DMARecAddr[2] >> 2) & 0x01;
					MainBoardData.OverUnderValProSta = (DMARecAddr[2] >> 1) & 0x01;
					MainBoardData.MainBoardChargeFlag = (DMARecAddr[2]) & 0x01;
					if(MainBoardData.OverUnderValProSta == 1)
					{
						OverUnderVoltageMusic = 1;
						OverUnderVoltageFlag = 1;
					}
					else
					{
						OverUnderVoltageMusic = 0;
						OverUnderVoltageFlag = 0;
					}
					
					if(MainBoardData.MainBoardAnglePro == 1)
					{
						AnglePro = 1;
						MainBoardData.MainBoardAnglePro = 0;
					}
					if(MainBoardData.MainBoardOverSpeedStat == 1)
					{
						MainBoardOverSpLedstat = 1;
						MainBoardData.MainBoardOverSpeedStat = 0;
					}
					else
						MainBoardOverSpLedstat = 0;
					
					if(MainBoardData.MainBoardLimitCurStat == 1)
						MainBoardLimitCurMusicLed = 1;
					else
						MainBoardLimitCurMusicLed = 0;
					
				
					RecMainAngleH = DMARecAddr[3];
					RecMainAngleL = DMARecAddr[4];
					
					if(MainBoardData.MainBoardAngleStat == 0)
						RecMainAngle = (RecMainAngleH << 8) | RecMainAngleL;
					else if(MainBoardData.MainBoardAngleStat == 1)
						RecMainAngle = 0 - ((RecMainAngleH << 8) | RecMainAngleL);
					
					RecMainSpeed = ((int16)DMARecAddr[5] << 8) + DMARecAddr[6];
			}
		}
		else
			DataSequenceErr = 1;
		
}
