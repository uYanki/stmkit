#ifndef __HALLDISPOSE_H_
#define __HALLDISPOSE_H_


/*---------------------------------------------------------------------------*/
/* Name		:	uint8  HallStatus_Check(uint8 GivenFR_Status,uint8 Last_HallStatus,uint8 Hall_Status_Result)
/* Input	:	GivenFR_Status ��ǰ����Last_HallStatus��һ��hall�źţ�Hall_Status_Result��ǰhall�ź�
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
extern uint8  HallStatus_Check(uint8 GivenFR_Status,uint8 Last_HallStatus,uint8 Hall_Status_Result);

/*---------------------------------------------------------------------------*/
/* Name		:	void FocRtheStep_Control (uint8 Hall_FRChange,uint8 HallFR_Status,int16 RThe_Step)
/* Input	:	RThe_Step ���ٶ�
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
extern void FocRtheStep_Control (int16 RThe_Step);

/*---------------------------------------------------------------------------*/
/* Name		:	int16 ThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,uint16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 Angle_Compensate,int16 StartAngle_Offset)
/* Input	:	Hall_Status_Result��ǰhall�źţ�GivenFR_StatusĿ�귽��TempAngle_OffsetCW CW�����ƫ�ƽǶȣ�
						TempAngle_OffsetCCW CCW�����ƫ�ƽǶȣ�Angle_Compensate��ǰ�ǣ�
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
extern int16 ThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,int16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 Angle_Compensate);


/*---------------------------------------------------------------------------*/
/* Name		:	void StartThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,uint16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 StartAngle_Offset)
/* Input	:	Hall_Status_Result��ǰhall�źţ�GivenFR_StatusĿ�귽��TempAngle_OffsetCW CW�����ƫ�ƽǶȣ�
						TempAngle_OffsetCCW CCW�����ƫ�ƽǶȣ�Angle_Compensate��ǰ�ǣ�StartAngle_Offset
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
extern int16 StartThetaDispose (uint8 Hall_Status_Result,uint8 GivenFR_Status,int16 TempAngle_OffsetCW,int16 TempAngle_OffsetCCW,int16 StartAngle_Offset);


/*---------------------------------------------------------------------------*/
/* Name		:	void FOCCurrentKPIControl (int16 Focdkp,int16 Focdki,int16 Focqkp,int16 Focqki,int16 Focdmax,int16 Focdmin)
/* Input	:	Focdkp D�����KP,Focdki D�����KI,Focqkp Q�����KP,Focqki Q�����KI,Focdmax D��DOUTMAX,Focdmin D��DOUTMIN
						
/* Output	:	
/* Description:	FOC���й��̵���KP KI FOCDMAX FOCDMIN����
/*---------------------------------------------------------------------------*/
void FOCCurrentKPIControl (int16 Focdkp,int16 Focdki,int16 Focqkp,int16 Focqki,int16 Focdmax,int16 Focdmin);


/*---------------------------------------------------------------------------*/
/* Name		:	void Hall_THETA_Limit(uint8 GivenFR_Status,uint8 HallFR_Change,uint8 HallFR_Status,uint8 Hall_Status_Result,uint16 TempAngle_OffsetCW,int16 Next_SectorAngle,int16 Last_SectorAngle,int16 Now_SectorAngle)
/* Input	:	HallFR_Change ˲�䷽��HallFR_Status ��ǰ����,Next_SectorAngle��һ���Ƕ�
						
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
extern void Hall_THETA_Limit(uint8 HallFR_Change,uint8 HallFR_Status,int16 Next_SectorAngle);

/*---------------------------------------------------------------------------*/
/* Name		:	extern void SpeedFollow(uint16 SRampInc)
/* Input	:	SRampInc �ٶȸ�������������� 327-1638 ,MaxDuty���ռ�ձȣ�MinDuty��Сռ�ձ� 
						
/* Output	:	
/* Description:	
/*---------------------------------------------------------------------------*/
extern void SpeedFollow(uint16 SRampInc,int16 MaxDuty,int16 MinDuty);

/*---------------------------------------------------------------------------*/
/* Name		:	void FOCQMAXLimit (int16 TempQM)
/* Input	:	��
/* Output	:	��
/* Description:	
/*---------------------------------------------------------------------------*/
extern void FOCQMAXLimit (int16 TempQM);

/*---------------------------------------------------------------------------*/
/* Name		:	uint8  HALLSignalDisposeFilter(uint16 Hall_CommutationCount,uint8 GivenFR_Status,uint8 HA,uint8 HB,uint8 HC)
/* Input	:	Hall_CommutationCount hall�źŲ�����GivenFR_Status��ǰ����HA hallA�źţ�HB HallB�ź�
						HC HallC�ź�
/* Output	:	HALLSignalDisposeFilter �������hall�ź�
/* Description:	
/*---------------------------------------------------------------------------*/
extern uint8  HALLSignalDisposeFilter(uint16 Hall_CommutationCount,uint8 GivenFR_Status,uint8 HA,uint8 HB,uint8 HC);

/*---------------------------------------------------------------------------*/
/* Name		:	uint8  HALLSignalDisposeWithoutFilter(uint16 Hall_CommutationCount,uint8 GivenFR_Status,uint8 HA,uint8 HB,uint8 HC)
/* Input	:	Hall_CommutationCount hall�źŲ�����GivenFR_Status��ǰ����HA hallA�źţ�HB HallB�ź�
						HC HallC�ź�
/* Output	:	HALLSignalDisposeWithoutFilter �������hall�ź�
/* Description:	
/*---------------------------------------------------------------------------*/
extern uint8  HALLSignalDisposeWithoutFilter(uint16 Hall_CommutationCount,uint8 GivenFR_Status,uint8 HA,uint8 HB,uint8 HC);

/*---------------------------------------------------------------------------*/
/* Name		:	 void SamplingPrepare(void)
/* Input	:		��			
/* Output	:	  ��
/* Description:	��������׼�� 
/*---------------------------------------------------------------------------*/
extern void SamplingPrepare(void);

/*---------------------------------------------------------------------------*/
/* Name		:	uint16 CompensateTargetDuty (uint16 Ramp_Step,uint16 Duty_Cycle,uint16 Ramp_Inc,uint16 mcADC_Voltagebus,uint16 Battery_Voltage,uint16 MOTORRUN_RecoilVoltage,uint16 Compensate_Duty)
/* Input	:	Ramp_Step ����ʵ��ֵ,Duty_Cycle Ŀ��ռ�ձ�,Ramp_Inc ��������,mcADC_Voltagebus ĸ�ߵ�ѹ,Battery_Voltage ��ص�ѹ ,MOTORRUN_RecoilVoltage ���������ѹ,Compensate_Duty ����ռ�ձ�
						HC HallC�ź�
/* Output	:	Target_Duty  ����Ŀ��ռ�ձ�
/* Description:	 
/*---------------------------------------------------------------------------*/
extern uint16 CompensateTargetDuty (uint16 Ramp_Step,uint16 Duty_Cycle,uint16 Ramp_Inc,uint16 mcADC_Voltagebus,uint16 Battery_Voltage,uint16 MOTORRUN_RecoilVoltage,uint16 Compensate_Duty);


#endif