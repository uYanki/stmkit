/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : FocControl.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the foc control framework used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <FocControl.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ----------------------------------------------------------------------------*/
MotStaType mcState;
//MotStaTim  MotorStateTime;
MotStaM    McStaSet;
//TailWindSet xdata  mcTailwind;

MotStaTim  MotorStateTime;

//uint16 TimeCnt;

TimeCnt Time;

mcHall_TypeDef  idata mcHall;


/*---------------------------------------------------------------------------*/
/* Name     :   void MC_Control(void)
/* Input    :   NO
/* Output   :   NO
/* Description: 电机状态机函数，包括初始化、预充电、顺风逆风判断、预定位、启动、运行、故障等
/*---------------------------------------------------------------------------*/
void MC_Control(void)
{
    switch(mcState)
    {
        case mcInit:                          					// 初始化状态，进入mcCharge状态
					
            VariablesPreInit();                           // 电机相关变量初始化
                            
        
            if(mcCurOffset.OffsetFlag != 3)
            {
                mcCurOffset.OffsetFlag = 2;
            }							
                                                             
            mcState = mcStart;
                             
            MotorStateTime.InitOneTime    = 0;				
            MotorStateTime.OpenOneTime    =0;
        break;

        case mcStart:                           // 配置电机启动参数，进入mcRun状态。
            Motor_Open();
            EA = 1;                 //在电机运行前一步开总中断
            mcState = mcRun;
        break;

        case mcRun:                             // 运行状态，若运行状态的给定变为0，进入mcStop状态。

        break;

        case mcFault:
        break;
    }
}


