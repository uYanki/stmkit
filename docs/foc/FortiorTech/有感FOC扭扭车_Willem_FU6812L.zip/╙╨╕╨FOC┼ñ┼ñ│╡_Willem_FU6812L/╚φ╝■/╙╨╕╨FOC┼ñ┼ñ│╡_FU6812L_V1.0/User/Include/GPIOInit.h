/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : PIOInit.h
* Author             : Vina Peng, Fortiortech Appliction Team
* Version            : V1.0
* Date               : 10-Apr-2017
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __PIOINIT_H_
#define __PIOINIT_H_

#define PowerOnOffIO			GP20

#define	PowerStatueLedRed		GP17
#define	PowerStatueLedGreen		GP16
#define	PowerStatueLedYellow	GP15

#define ChargeDetectIO			GP03

#define TestIO					GP10

#define	Beep					GP11

#define FootBoardKey1			GP21
#define FootBoardKey2			GP22

/* Exported functions ---------------------------------------------------------------------------*/
extern void GPIO_Init(void);
extern void GPIO_Default_Init(void);
#endif