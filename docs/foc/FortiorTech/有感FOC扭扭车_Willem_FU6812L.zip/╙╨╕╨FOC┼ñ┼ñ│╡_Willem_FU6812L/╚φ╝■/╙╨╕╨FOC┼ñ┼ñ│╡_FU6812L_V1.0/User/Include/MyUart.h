#ifndef __MYUART_H_
#define __MYUART_H_

/* Exported functions ---------------------------------------------------------------------------*/
typedef struct
{
		uint8 SecondBoardStat;               
		uint8 SecondBoardError;                
		uint8 SeconBoardDerictionStat;             
		uint8 SeconBoardAngleStat;      
		uint8 SeconBoardAnglePro;	
		uint8 SeconBoardLimitCurStat;
		uint8 SeconBoardHallErrStat;
		uint8 SeconBoardPhaselossStat;
		uint8 SeconBoardPowerBoardFlag;
		uint8 SeconBoardSideUpProject;
		uint8 SeconBoardBroked;
		uint8 SeconBoardUnderVolCurrentFlag;
}SeconBoardVari;

typedef struct
{
		uint8 OverUnderValProSta;               
		uint8 MainBoardDerictionStat;             
		uint8 MainBoardAngleStat;    
		uint8 MainBoardAnglePro;
		uint8 MainBoardOverSpeedStat;
		uint8 MainBoardLimitCurStat;
		uint8 MainBoardHallErrStat;
		uint8 MainBoardPhaselossStat;
		uint8 MainBoardSelfBalMode;
		uint8 MainBoardPowerBoardFlag;
		uint8 MainBoardSideUpProject;
		uint8 MainBoardBrokenFlag;
		uint8 MainBoardCurrentLimMode;
		uint8 MainBoardChargeFlag;
}MainBoardVari;



extern void SendDataByUart(int in_show);
extern void Send_U_DataByUart(unsigned int in_show);
extern void SendPictureDataByUart(int in_show1,int in_show2,int in_show3,int in_show4);
extern void BoardsCom_Master_Tran_For_BalPoi(void);
extern void BoardsCom_Main_Slave(void);
extern void BoardsCom_Slave_Main(void);
extern void MainBoardDealWithData(void);
extern void SeconBoardDealWithData(void);

extern SeconBoardVari xdata SeconBoardData;
extern MainBoardVari xdata MainBoardData;

#endif