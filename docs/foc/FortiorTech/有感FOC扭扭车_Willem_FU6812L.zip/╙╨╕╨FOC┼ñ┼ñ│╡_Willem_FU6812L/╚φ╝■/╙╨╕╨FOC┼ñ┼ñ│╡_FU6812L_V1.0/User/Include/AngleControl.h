#ifndef __AngleControl_H_
#define __AngleControl_H_

/* Exported functions ---------------------------------------------------------------------------*/
extern void Read_Acc_Gyr(uint8 AccAddr, uint8 GyrAddr);
extern int16 AngleControl(int16 AngleA, int16 AngleG) ;
extern void Kalman_Filter(int16 angle_m,int16 gyro_m) ;

#endif