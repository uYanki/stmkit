/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Customer.h
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-21
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __CUSTOMER_H_
#define __CUSTOMER_H_

/*芯片参数值-------------------------------------------------------------------*/
 /*CPU and PWM Parameter*/
 #define MCU_CLOCK                      (24.0)                                  // (MHz) 主频
 #define PWM_FREQUENCY                  (16.0)                                  // (kHz) 载波频率

 /*deadtime Parameter*/
 #define PWM_DEADTIME                   (1.0)                                   // (us) 死区时间

 /*single resistor sample Parameter*/
 #define MIN_WIND_TIME                  (1.9)                                   // (us) 单电阻最小采样窗口，建议值死区时间+0.9us

/*电机参数值-------------------------------------------------------------------*/
 #define Pole_Pairs                     (15)                                     // 极对数

 #define LD                             (0.00044)                               // (H) D轴电感
 #define LQ                             (0.00044)                               // (H) Q轴电感

 #define RS                             (0.127)                                 // (Ω) 相电阻

 #define KeVpp                          (22.5)                                   // (V)      反电动势测量的峰峰值
 #define KeF                            (45.04)                                  // (Hz)     反电动势测量的频率
 #define KeT                            (1000 / KeF)                            // (ms)     反电动势测量的周期
 #define Ke                             (Pole_Pairs * KeVpp * KeT / 207.84)		  // (V/KRPM) 反电动势常数

 #define MOTOR_SPEED_BASE               (2000.0)                                 // (RPM) 速度基准
 
 /*正常超速抬头速度阈值*/
 #define NORMAL_OS						(10.0)									//单位：km/h
 
 #define TEMP_NORMAL_OS					(NORMAL_OS / 16.51 / 3.14 / 60.0 / MOTOR_SPEED_BASE * 32767.0 * 100000.0)		
 
 /*低电压超速抬头速度阈值*/
 #define OVER_VOL_OS					(1.0)									//单位：km/h
 
 #define TEMP_OVER_VOL_OS				(OVER_VOL_OS / 16.51 / 3.14 / 60.0 / MOTOR_SPEED_BASE * 32767.0 * 100000.0)	
 
 /*空转保护速度阈值*/
 #define Free_Run_OS					(8.0)									//单位：km/h
 
 #define TEMP_Free_Run_OS				(Free_Run_OS / 16.51 / 3.14 / 60.0 / MOTOR_SPEED_BASE * 32767.0 * 100000.0)	
 
 /*堵转速度*/
 #define STALL_SPEED					(0.5)
 
 #define TEMP_STALL_SPEED				(STALL_SPEED * 32767.0 / 16.51 / 3.14 / 60.0 / MOTOR_SPEED_BASE * 100000.0)	
 
/*硬件板子参数设置值------------------------------------------------------------*/
 /*PWM high or low level Mode*/
 /*根据驱动芯片的类型选择，大部分芯片为High_Level 6287*/
 #define High_Level                     (0)                                     // 驱动高电平有效
 #define Low_Level                      (1)                                     // 驱动低电平有效
 #define UP_H_DOWN_L                    (2)                                     // 上桥臂高电平有效，下桥臂低电平有效
 #define UP_L_DOWN_H                    (3)                                     // 上桥臂低电平有效，下桥臂高电平有效
 #define PWM_Level_Mode                 (UP_H_DOWN_L)

 /*hardware current sample Parameter*/
 /*电流基准的电路参数*/
 //**********运放1、运放2放大倍数以及相电流采样电阻参数设置		
 #define  HW_RSHUNT                   (0.0035)							
 #define  HW_AMPGAIN                  (1.56)													

 //**********运放0放大倍数以及母线电流采样电阻参数设置
 #define 	HW_RSHUNT0                  (0.002)		
 #define 	HW_AMPGAIN0                 (10.0)	

 #define  HW_ADC_REF                  (4.5)                                     // (V)  ADC参考电压

 /*hardware voltage sample Parameter*/
 /*母线电压采样分压电路参数*/
 #define RV1                            (15.0)                                  // (kΩ) 母线电压分压电阻1
 #define RV2                            (15.0)                                  // (kΩ) 母线电压分压电阻2
 #define RV3                            (1.0)                                   // (kΩ) 母线电压分压电阻3
 #define VC1                            (1)                                   // 电压补偿系数
 #define RV                             ((RV1 + RV2 + RV3) / RV3)               // 分压比
 #define HW_BOARD_VOLT_MAX              (HW_ADC_REF * RV)                       // (V)  ADC可测得的最大母线电压
 
 /***启动电流****/
 #define ID_Start_CURRENT               I_Value(0.0)                            // (A) D轴启动电流
 #define IQ_Start_CURRENT               I_Value(1.0)                            // (A) Q轴启动电流

 /***运行电流****/
 #define ID_RUN_CURRENT                 I_Value(0.0)                            // (A) D轴运行电流
 #define IQ_RUN_CURRENT                 I_Value(2.0)                            // (A) Q轴运行电流

 /* current set value */
 #define 	I_Value(Curr_Value)					_Q15(((Curr_Value*HW_RSHUNT*HW_AMPGAIN)/(HW_ADC_REF)))      //Unit in A

 #define 	I_ValueRC(Curr_Value)				_Q15(((Curr_Value*HW_RSHUNT0*HW_AMPGAIN0)/(HW_ADC_REF)))    //Unit in A
	 
 /*--------使能均值限流功能需要硬件电路支持，即需要将运放0输出经过RC滤波，再用AD采样该信号作处理---------------*/
 /*---------均值限流的RC参数：R = 10K ,C =10nf-------------*/
 #define 	IQ_RUN_MAX_RMS_CURRENT			I_ValueRC(7.5)													 // 最大均值限流值，A
 #define	UNDERVOL_RMS_CURRENT			(0.3 * IQ_RUN_MAX_RMS_CURRENT)
 #define	STALL_RMS_CURRENT				(0.4 * IQ_RUN_MAX_RMS_CURRENT)
 
 #define 	IQ_RUN_MAX_RMS_CURRENT_Mode1	I_ValueRC(10.0)													 // 最大均值限流值，A
 #define	UNDERVOL_RMS_CURRENT_Mode1		(0.6 * IQ_RUN_MAX_RMS_CURRENT_Mode1)
 #define	STALL_RMS_CURRENT_Mode1			(0.4 * IQ_RUN_MAX_RMS_CURRENT_Mode1)
 
 #define 	IQ_RUN_MAX_RMS_CURRENT_Mode2	I_ValueRC(12.0)													 // 最大均值限流值，A
 #define	UNDERVOL_RMS_CURRENT_Mode2		(0.6 * IQ_RUN_MAX_RMS_CURRENT_Mode2)
 #define	STALL_RMS_CURRENT_Mode2			(0.4 * IQ_RUN_MAX_RMS_CURRENT_Mode2)
 
 
 

/*电流环参数设置值--------------------------------------------------------------*/

 #define CurrentCycleEnable             (0)                         //电流环使能，如果电流环不使能，需手动给定FOC__UQ的值
 
 #define DQKP                           _Q12(0.2)                               // DQ轴KP
 #define DQKI                           _Q15(0.01)                               // DQ轴KI
 
 /* D轴参数设置 */
 #define DOUTMAX                        _Q15(0)                              // D轴最大限幅值，单位：输出占空比
 #define DOUTMIN                        _Q15(0)                             // D轴最小限幅值，单位：输出占空比
 
 /* Q轴参数设置，默认0.99即可 */
 #define QOUTMAX                        _Q15(0.99)                              // Q轴最大限幅值，单位：输出占空比
 #define QOUTMIN                        _Q15(-0.99)                             // Q轴最小限幅值，单位：输出占空比

/*********电机开机、关机设置------------------------------------------------------*/
#define 	OFFPWMDuty	    						(0.5)		                                 //关机电平百分比，当电平小于（OFFPWMDuty*HW_ADC_REF）关机
#define 	ONPWMDuty	      						(0.5)	                                 //开机电平百分比，当电平大于（ONPWMDuty*HW_ADC_REF）开机       
#define 	BackOFFPWMDuty	    				(0.5)		                                 //关机电平百分比，当电平小于（OFFPWMDuty*HW_ADC_REF）关机
#define 	BackONPWMDuty	      				(0.5)	                                 //开机电平百分比，当电平大于（ONPWMDuty*HW_ADC_REF）开机       
#define 	MAXPWMDuty	    						(1.0)                                    //最大有效调速电平，当电平大于（MAXPWMDuty*HW_ADC_REF），维持最大输出力矩
#define   ProtecMinPWMDuty   				  (0.1338)                                    //最小保护电平，当调速电平小于于（ProtecMinPWMDuty*HW_ADC_REF），关机
#define   ProtecMaxPWMDuty   					(0.8714)                                    //最大保护电平，当调速电平大于（ProtecMaxPWMDuty*HW_ADC_REF），关机

//档位占空比设置 
#define   MSPPWMDuty_48V              QOUTMAX                                 //最高档占空比设置
#define   MIDSPWMDuty_48V             QOUTMAX                                 //中档占空比设置
#define   LSPPWMDuty_48V              QOUTMAX                                 //低档占空比设置

#define   BackOffPWMDuty           _Q15(0.30)                                 //倒车占空比设置

#define 	VOPEN_MIDSP_K_48V		   (((float)((float)(MIDSPWMDuty_48V-MinPWMDuty)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))))*64) 
#define 	VOPEN_MSP_K_48V		       (((float)((float)(MSPPWMDuty_48V-MinPWMDuty)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))))*64) 
#define 	VOPEN_LSP_K_48V		       (((float)((float)(LSPPWMDuty_48V-MinPWMDuty)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))))*64) 

#define 	VOPEN_BACKOFF_K		       (((float)((float)(BackOffPWMDuty-MinPWMDuty)/(float)(_Q15(MAXPWMDuty)-_Q15(ONPWMDuty))))*64) 
		 
#define		MinPWMDuty									_Q15(0.05)                               //最小运行电压百分比
#define		StartPWMDuty								_Q15(0)                               //启动电压百分比

/*设置主副机*/
#define     MainBoard              			(0)
#define     SeconBoard              		(1)
#define     BoardRole              			(SeconBoard)

/*正常运行平衡控制角度PID参数*/
#define     AngPosConParaP             		(16.0)
#define     AngPosConParaD             		(-1.1)
#define     AngPosConParaI             		(0.04)


#define 	AngSpLoopParaP					(2.1)
#define 	AngSpLoopParaD					(2.0)


/*踩踏板平衡点移动时的参数*/
#define     BoaMovAngPosConParaP            (16.0)//(16.0)
#define     BoaMovAngPosConParaD            (-0.8)//(-0.8)
#define     BoaMovAngPosConParaI            (0.0)


#define 	BoaMovAngSpLoopParaP			(2.2)//(2.2)
#define 	BoaMovAngSpLoopParaD			(0.6)//(0.6)


/*正常运行时外环I项限幅值*/
#define		PosConIOutMax					(4000.0)
#define		PosConIOutMin					(-4000.0)

/*低电压平衡控制PID参数*/
#define     UVProAngPosConParaP             (9.0)//(27)


///*平衡控制PID参数和I项限幅值由正常向低电压过渡增量*/
#define     UVProAngPosConParaPInc          ((AngPosConParaP - UVProAngPosConParaP) / 2000)
//#define     UVProAngPosConParaDInc          ((AngPosConParaD - UVProAngPosConParaD) / 1500)

#define		UVProPosConIOutInc				(PosConIOutMax / 2000)

/*开机自平衡PID参数*/
#define     SelfBalAngPosConParaP           (2.5)//
#define     SelfBalAngPosConParaD           (-0.5)//
#define     SelfBalAngIncConParaP           (0.0)//

#define     SelfBalAngSpConParaP            (1.0)//
#define     SelfBalAngSpConParaI            (0.0)//
#define     SelfBalAngSpConParaD            (0.4)//

/*自平衡向踩踏板过渡时的PID增量*/
#define     SelfBalAngPosConParaPInc        ((AngPosConParaP - SelfBalAngPosConParaP) / 150.0)
#define     SelfBalAngPosConParaDInc        ((AngPosConParaD - SelfBalAngPosConParaD) / 150.0)

#define     SelfBalAngIncConParaPInc        ((AngIncConParaP - SelfBalAngIncConParaP) / 150.0)

/*直接电压控制时的UQ限幅值*/
#define		BalanceUQMax					(30000)
#define		BalanceUQMin					(-30000)

/*限流保护UQ增量*/
#define		CurLimValInc					(5)


/*********方向设置------------------------------------------------------*/
#define CW                            (0)
#define CCW                           (1)
#define SetDirection                  (CW)                                 //方向选择

/*----------------------------------------Hall传感器安装模式------------------------------------------------------------*/
/*Hall滤波选择*/
#define HallFilterlingEnable              (0)                               //hall滤波使能，1使能，0不使能

#define StartAngleCW                      _Q15(125.0/180.0)                  //CW方向的启动角度
#define StartAngleCCW                     _Q15(-125.0/180.0)                 //CCW方向的启动角度

/*Hall安装与反电动势的关系*/
#define HallAdvanceBEMF30Degree						(0)											          //Hall超前反电动势30°
#define HallSameWithBEMF									(1)											          //Hall与反电动势重合
#define HallDelayBEMF30Degree							(2)											          //Hall滞后反电动势30°
#define	HallAndBEMF										    (HallAdvanceBEMF30Degree)         //Hall安装模式选择

#define HallInverseEnable									(0)											          // Hall信号是否反相

#define AngleOffset											(3640)

#if   (HallAndBEMF == HallAdvanceBEMF30Degree)
#define	AngleOffsetCW											(-25.0)//-20                // CW方向的偏移角度，单位：度   标准 -30°
#define AngleOffsetCCW										(25.0)//24	          	  // CCW方向的偏移角度，单位：度 标准 -90°

#elif (HallAndBEMF == HallSameWithBEMF)
#define	AngleOffsetCW											(0.0)	                          // CW方向的偏移角度，单位：度  标准 0°
#define AngleOffsetCCW										(60.0)			          	          // CCW方向的偏移角度，单位：度 标准 -60°

#elif (HallAndBEMF == HallDelayBEMF30Degree)
#define	AngleOffsetCW											(30.0)	                          //CW方向的偏移角度，单位：度   标准 30°
#define AngleOffsetCCW										(90.0)			                      //CCW方向的偏移角度，单位：度  标准 -30°
#endif

#define TempAngleOffsetCW							    _Q15(AngleOffsetCW/180.0)
#define TempAngleOffsetCCW							  _Q15(AngleOffsetCCW/180.0)

/*speed loop mode*/
#define   Speed_OpenLoop_Enable           (0)                                     // 开环控制
#define   Speed_Loop_Enable               (1)                                     // 速度环控制
#define 	Speed_Loop_Mode                 (Speed_OpenLoop_Enable)

//#if (Speed_Loop_Mode == Speed_Loop_Enable)
///***********************速度环参数设置**************************************/
//#define 	Motor_INC_Speed           	_Q15(10.0/MOTOR_SPEED_BASE)            
//#define 	Motor_DEC_Speed							_Q15(10.0/MOTOR_SPEED_BASE)             

//#define 	SKP													_Q12(0.2)																// speed loop KP
//#define 	SKI													_Q12(0.001)															// speed loop KI
//#define 	SOUTMAX											I_Value(40.0)													  // speed loop output max value
//#define 	SOUTMIN											I_Value(0.0)												    // speed loop output min value

#if (Speed_Loop_Mode == Speed_OpenLoop_Enable)
/*--------------------------开环参数设置------------------------------------*/
#define   SPEEDRampTIME               10                                    	  
#define 	Duty_INC										50																	    
#define 	Duty_SoftStart_INC					10																	    
#define 	Duty_DEC										20	                                    

#endif
 
 /*开环启动模式选择*/
 #define Open_Start                     (0)                                     // 开环强拖启动
 #define Omega_Start                    (1)                                     // Omega启动
 #define Open_Omega_Start               (2)                                     // 先开环启，后Omega启动
 #define Open_Start_Mode                (Open_Start)

 /*电流采样模式*/
 #define Single_Resistor                (0)                                     // 单电阻电流采样模式
 #define Double_Resistor                (1)                                     // 双电阻电流采样模式
 #define Three_Resistor                 (2)                                     // 三电阻电流采样模式
 #define Shunt_Resistor_Mode            (Single_Resistor)

 #define OverModulation                 (0)                                     // 0-禁止过调制，1-使能过调制

/*保护参数值-------------------------------------------------------------------*/
 /*硬件过流保护*/
 #define Hardware_FO_Protect            (1)                                     // 硬件FO过流保护使能，适用于IPM有FO保护的场合
 #define Hardware_CMP_Protect           (2)                                     // 硬件CMP比较过流保护使能，适用于MOS管应用场合
 #define Hardware_FO_CMP_Protect        (3)                                     // 硬件CMP比较和FO过流保护都使能
 #define Hardware_Protect_Disable       (4)                                     // 硬件过流保护禁止，用于测试
 #define HardwareCurrent_Protect        (Hardware_CMP_Protect)                  // 硬件过流保护实现方式

 /*硬件过流保护比较值来源*/
 #define Compare_DAC                    (0)                                     // DAC设置硬件过流值
 #define Compare_Hardware               (1)                                     // 硬件设置硬件过流值
 #define Compare_Mode                   (Compare_DAC)                      		// 硬件过流值的来源

 #define OverHardcurrentValue           (5.0)                                   // (A) DAC模式下的硬件过流值

 /*软件过流保护*/
 #define OverSoftCurrentValue           I_ValueRC(150.0)                        // (A) 软件过流值

 /*过流恢复*/
 #define CurrentRecoverEnable           (0)                                     // 过流保护使能位, 0，不使能；1，使能
 #define OverCurrentRecoverTime         (1000)                                  // (ms) 过流保护恢复时间

 #define PhaseLossProtectEnable         (0)                                     // 缺相保护，0,不使能；1，使能

 /*欠压保护值*/
 #define Under_Protect_Voltage1         (3.33)                                    // (V) 直流电压欠压保护值
 #define Under_Protect_Voltage2         (3.03)                                    // (V) 直流电压欠压保护值
 
 #define Under_Recover_Vlotage          (3.43)                                    // (V) 直流电压欠压保护恢复值
 
  /*电池节数判断阈值电压*/
 #define Bat_Voltage_Detect		         (30)                                    // (V) 直流电压欠压保护值


 /*反冲电压限制*/
 #define   Motor_Run_RecoilVoltage      (2.0)                                   // 运行过程运行的反冲电压

 /*缺相保护*/
 #define PhaseLossCurrentValue          I_Value(0.2)                            // (A)  缺相电流值
 #define PhaseLossRecoverTime           (600)                                   // (ms) 缺相保护时间
 
 #define NomCurrent						(1000)
 #define LowCurrent						I_Value(0.2)

 /*堵转保护*/
 #define 	 StallProtectEnable				  (0)														           // 堵转保护使能，1使能，0不使能
 #define   StallDetectTime						(2000)															     // 堵转保护监测时间，单位ms
 #define   StallTime                  (1500)                                   // 堵转保护时间，单位ms
 #define   StallMINPWMDuty            _Q15(0.10)                               // 堵转保护最小占空比

#endif
