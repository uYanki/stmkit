//////////////////////////////////////////////////////////////////////
//文件名：FU6802_I2C.c                                              //
//说明：FU68系列芯片的I2C底层驱动                                   //
//Log                                                               //
//Timer         Writer      Thing                               Ver //
//2017-02-07    Any         由FU68xx_UART.c移植过来             V1.0//
//2017-02-07    Any         把使能、启动和停止函数extern        V1.1//
//2017-02-16    Any         从机地址修改为直接输入要发送的地址  V1.2//
//2017-07-28    Any         配置I2C在头文件里配置               V1.3//
//                          I2C使能由两个宏定义控制                 //
//2017-07-31    Any         I2C应答由两个宏控制                 V1.4//
//                          删除I2C位操作函数                       //
//                          I2C地址设定改由宏设置                   //
//                          删除单字节读写函数                      //
//                          I2C地址设定改由宏设置                   //
//                          添加从机地址初始化                      //
//////////////////////////////////////////////////////////////////////

#include <FU68xx_2.h>
#include <Myproject.h>
#include <Customer_Debug.h>
#include "FU68xx_Sys.h"
//#include <FU6812_Config.h>

/**
 * 初始化I2C配置
 *
 */
void Init_I2C(void)
{
    //P0_PU |= 0x03;                         //SCL和SDA若无硬件上拉，需要软件上拉
    
    I2C_CR = 0x00
    #if defined(I2C_MASTER)                 //I2C被配置为主机模式时进行以下配置
        | I2CMS | I2C_SPEED                //配置I2C作为主机，并设置速度
    #endif

    #if defined(EN_IRQ_I2C)                 //I2C中断使能时进行以下配置
        | I2CIE                             //使能I2C中断
    #endif

    #if defined(I2C_LPF)                    //当I2C启用提高滤波宽度时进行以下配置
        | I2CFMOD                           //提高滤波宽度
    #endif
    ;

    #if !defined(I2C_MASTER)                //当I2C为从机时进行以下配置
        I2C_ID = I2C_ADDR7 << 1;            //配置本机I2C地址
    #endif
}

/**
 * 启动I2C传输
 *
 * @param   rw         读写标志位
 *                     0：I2C写
 *                     1：I2C读
 */
void Start_I2C(bool rw)
{
    if (rw) I2C_SR = I2CSTA | DMOD;
    else    I2C_SR = 0x10;

	
    while (!ReadBit(I2C_SR, STR));
}

/**
 * 发送停止信号
 *
 */
void Stop_I2C(void)
{
    SetBit(I2C_SR, I2CSTP);
    ClrBit(I2C_SR, STR);
    while (ReadBit(I2C_SR, I2CSTP));
}

/**
 * I2C发送数据
 *
 * @param   Dat        要发送的数据
 */
void Send_I2C(uint8 Dat)
{
    I2C_DR = Dat;
    ClrBit(I2C_SR, STR);
    while (!ReadBit(I2C_SR, STR));
}

/**
 * 接收数据
 *
 * @return             收到的数据
 */
uint8 Receive_I2C(void)
{
    ClrBit(I2C_SR, STR);
    while (!ReadBit(I2C_SR, STR));
    return I2C_DR;
}

/**
 * 写入一包数据
 *
 * @param   addr7      从机的7位地址
 * @param   reg        寄存器首地址
 * @param   len        数据包长度
 * @param   dat        数据包数组指针
 *
 * @return             反馈I2C状态
 *                     I2C_FA_ADD： 写过程启动信号发送失败
 *                     I2C_FA_REG： 写寄存器失败
 *                     I2C_FA_DAT： 写数据失败
 *                     I2C_SU：     写成功
 */
uint8 Write_I2C(uint8 addr7, uint8 reg, uint8 len, uint8* dat)
{
    uint8 i;

    Enable_I2C();                                              //使能I2C

    Set_Addr_I2C(addr7);                                       //填写从机地址

    #if defined(I2C_AUTO_ADDR)                                 //与从设备相关，详见头文件
        Start_I2C(false);                                      //发送启动信号、地址和写信号
        if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;      //读取应答信号，判断是否发送成功

        Send_I2C(reg);                                         //发送寄存器地址
        if (ReadBit(I2C_SR, NACK)) return I2C_FA_REG;      //读取应答信号，判断是否发送成功

        for (i = 0; i != len; i++)
        {
            Send_I2C(*dat);                                    //发送数据
            if (ReadBit(I2C_SR, NACK)) return I2C_FA_DAT;  //读取应答信号，判断是否发送成功
            dat++;
        }

        Stop_I2C();
    #else
        for (i = 0; i != len; i++)
        {
            Start_I2C(false);
            if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;

            Send_I2C(reg);
            if (ReadBit(I2C_SR, NACK)) return I2C_FA_REG;

            Send_I2C(*dat);
            if (ReadBit(I2C_SR, NACK)) return I2C_FA_DAT;

            dat++;
            reg++;

            Stop_I2C();
        }
    #endif


    Disable_I2C();

    return I2C_SU;
}

/**
 * 读出一包数据
 *
 * @param  addr7  从机7位地址
 * @param  reg    第一个读出的寄存器
 * @param  len    读出的数据长度
 * @param  dat    读出的数据包
 *
 * @return             反馈I2C状态
 *                     I2C_FA_ADD： 写过程启动信号发送失败
 *                     I2C_FA_REG： 写寄存器失败
 *                     I2C_FA_DAT： 写数据失败
 *                     I2C_SU：     写成功
 */
uint8 Read_I2C(uint8 addr7, uint8 reg, uint8 len, uint8* dat)
{
    uint8 i;

    Enable_I2C();                                              //使能I2C


    Set_Addr_I2C(addr7);                                       //填写从机地址


    #if defined(ADDR_AUTO_ADD)                                 //与从设备相关，详见头文件

        Start_I2C(false);                                      //发送启动信号、地址和写信号
        if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;      //读取应答信号，判断是否发送成功


        Send_I2C(reg);                                         //发送寄存器地址
        if (ReadBit(I2C_SR, NACK)) return I2C_FA_REG;      //读取应答信号，判断是否发送成功


        Start_I2C(true);                                       //发送启动信号、地址和读信号
        if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;

        for (i = 0; i != len; i++)
        {
            *dat = Receive_I2C();

            if (i == (len - 1)) Set_Ack_I2C();
            else                Set_Nack_I2C();

            dat++;
        }

        Stop_I2C();
    #else
        for (i = 0; i != len; i++)
        {
            Start_I2C(false);
            if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;

            Send_I2C(reg);
            if (ReadBit(I2C_SR, NACK)) return I2C_FA_REG;

            Start_I2C(true);
            if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;

            *dat = Receive_I2C();
            Set_Nack_I2C();

            dat++;
            reg++;

            Stop_I2C();
        }
    #endif

    Disable_I2C();

    return I2C_SU;
}

uint8 Write_I2C_Byte(uint8 addr7, uint8 reg, uint8 date)
{
    Enable_I2C();                                              //使能I2C

    Set_Addr_I2C(addr7);                                       //填写从机地址

		Start_I2C(false);
		if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;

		Send_I2C(reg);
		if (ReadBit(I2C_SR, NACK)) return I2C_FA_REG;

		Send_I2C(date);
		if (ReadBit(I2C_SR, NACK)) return I2C_FA_DAT;


		Stop_I2C();


    Disable_I2C();

    return I2C_SU;
}

uint8 Read_I2C_Byte(uint8 addr7, uint8 reg, uint8* dat1, uint8* dat2)
{
    Enable_I2C();                                              //使能I2C


    Set_Addr_I2C(addr7);                                       //填写从机地址


    Start_I2C(false);
    if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;

    Send_I2C(reg);
    if (ReadBit(I2C_SR, NACK)) return I2C_FA_REG;

    Start_I2C(true);
    if (ReadBit(I2C_SR, NACK)) return I2C_FA_ADD;

    *dat1 = Receive_I2C();
    Set_Ack_I2C();

	*dat2 = Receive_I2C();
    Set_Nack_I2C();
	
    Stop_I2C();

    Disable_I2C();

    return I2C_SU;
}


void MPU6060_Init(void)
{
	Write_I2C_Byte(SlaveAddress >> 1, PWR_MGMT_1, 0x00);            //电源管理
	Write_I2C_Byte(SlaveAddress >> 1, SMPLRT_DIV, 0x01);            //陀螺仪采样频率为500Hz，加速度计的采样频率固定为1kHz    
	Write_I2C_Byte(SlaveAddress >> 1, CONFIG, 0x06);                //低通滤波频率，带宽5Hz，延时19ms
	Write_I2C_Byte(SlaveAddress >> 1, GYRO_CONFIG, 0x18);           //陀螺仪自检及测量范围，典型值：0x18(不自检，2000deg/s)
	Write_I2C_Byte(SlaveAddress >> 1, ACCEL_CONFIG, 0x01);          //加速计自检、测量范围及高通滤波频率，典型值：0x01(不自检，2G，5Hz)    
}
