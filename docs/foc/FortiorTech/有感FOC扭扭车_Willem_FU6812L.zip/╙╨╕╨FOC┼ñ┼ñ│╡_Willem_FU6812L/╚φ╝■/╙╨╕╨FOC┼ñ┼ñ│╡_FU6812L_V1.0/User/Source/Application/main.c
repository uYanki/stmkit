/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : main.c
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-27
* Description        : This file contains main function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Includes -------------------------------------------------------------------------------------*/
// #include <main.h>
#include <FU68xx_2.h>
#include <Myproject.h>
#include <Customer_Debug.h>
#include "FU68xx_Sys.h"
#include <MyUart.h>	

/* Private typedef ------------------------------------------------------------------------------*/
/* Private define -------------------------------------------------------------------------------*/
/* Private macro --------------------------------------------------------------------------------*/
/* Private variables ----------------------------------------------------------------------------*/
/* Private function prototypes ------------------------------------------------------------------*/
/* Private functions ----------------------------------------------------------------------------*/
void SoftwareInit(void);
void HardwareInit(void);
void DebugSet(void);
void MotorControlInit(void);

extern char UartSendFlag;
extern int Test2;


char KeyBrake = 0;

extern int16 RampStepIncFlag;

extern uint8 AccXoutH;
extern uint8 AccXoutL;
extern int16 AccXout;

extern int32 AccXoutAF;

extern uint8 GyrYoutH;
extern uint8 GyrYoutL;
extern int16 GyrYout;

extern int32 GyrYoutAF;

extern int16 AngleOutput;
extern int32 AngleOutP;
extern int32 AngleOutD;
extern int16 AccAngle;
extern float angle;      //融合角度
extern int16 AccAngleALPF;

extern float Q_angle;                               
extern float Q_gyro ;                                  
extern float R_angle;    
extern float dt;//0.00095;                      	        //积分时间，滤波器采样时间

extern char C_0;                                           //H矩阵的一个数                                          
extern float q_bias, angle_err;                        //q_bias为陀螺仪漂移
extern float PCt_0, PCt_1, E;                      //中间变量
extern float K_0, K_1, t_0, t_1;               //K是卡尔曼增益，t是中间变量
extern float Pdot[4];                               //计算P矩阵的中间变量
extern float PP[2][2];                   //公式中P矩阵，X的协方差

extern float angle_dot;                                      //卡尔曼滤波器的输出值，最优估计的角速度
extern int16 GyrAngVel;
extern int16 angleALPF;

extern uint8 HallFRStatusTeat;


extern int16 CarAccSpeedALPF;
extern int16 CarAccSpeed;
extern int16 LastCarSpeed;

extern int16 GyrAngAcc;

extern int16 gryacctest ;

extern uint8 HallFRStatusTeat ;
extern uint8 LastHallFRStatusTeat ;
extern int8 CarAccSpSmo ;
extern int8 CarAccSpSmoCnt ;

int16 FlTe = 0;

/*开机调平衡变量*/
uint8 BalanceGyrH = 0;
uint8 BalanceGyrL = 0;
int16 BalanceGyr = 0;
int32 BalanceGyrAdd = 0;
int16 BalanceGyrALPF = 0;

uint8 BalanceAccH = 0;
uint8 BalanceAccL = 0;
int16 BalanceAcc = 0;
int32 BalanceAccAdd = 0;
int16 BalanceAccALPF = 0;


char BalStaToSlave = 0;
char SlaReCnt = 0;

extern int16 BalancePoint;

extern uint8 BoardMusic;

extern uint8 UART_DMAData;

extern uint8 SeconBoardMusic ;

extern int16 TempHall_Angle;

extern float AngPosConP ;
extern float AngPosConD ;
extern float AngIncConP ;     
//extern float GetAngIncre;

extern int32 AngSpPoint ;

extern int32 AngSpLoopPOut ;

extern int32 AngSpLoopDOut ;

extern float AngSpLoopP ;

extern float AngSpLoopD ;
extern uint8 MainBoardHallErrLed;
extern int16 HallSpeedALPF;
extern int16 ABSHallSpeedALPF ;
extern int16 TwoBoaAngErrAve ;
extern int16 BalancePointBef ;

extern float AngPosOutP ;
extern float AngPosOutI ;
extern float AngPosOutD ;
extern int16 AngleATEST ;
extern int16 RecSlaveAngle ;
extern float BalancePointIncRate ;
extern float BalancePointInc ;
extern int16 LastAngleOutput ;


extern int16 FOCUQValue ;
extern int16 UQMax ;
extern int16 UQMin ;

int16 BatStartADValue = 0;
int8 BatteryNumber = 0;


extern uint8 MainBoardSelfBalModeLast;
extern int8 BalancePointMoveLock ;

extern int16 mcADCVoltagebus2 ;

extern int16 AccYout ;
extern int16 AccYoutALPF;

int8 PowerFrom35to36LedFlag = 0;

int8 BrokenFlag = 0;

extern int8 StallProject ;

extern uint8 AnglePro ;

extern uint8 OverUnderVoltageFlag ;

int8 ChargeYelLedSFlashFlag = 0;

extern uint16 PowerOnOffAD;

extern int16 SpeRespPowDelay ;

extern uint8 HallErrMisic ;

extern uint8 OverUnderVoltageMusic ;

int8 BrokenMusic = 0;

int8 ChargeFlag = 0;

uint8 AccZoutH = 0;
uint8 AccZoutL = 0;
int16 AccZout = 0;
int16 AccZoutALPF = 0;

/********************/

/*-------------------------------------------------------------------------------------------------
        Function Name : void main(void)
        Description   : 主函数主要功能是初始化，包括上电等待，软件初始化，硬件初始化，调试模式设置，主循环扫描。
                                    软件初始化--初始化所有定义的变量
                                    硬件初始化--初始化硬件设备配置
                                    调试模式设置--调试模式
        Input         : 无
        Output        : 无
-------------------------------------------------------------------------------------------------*/
void main(void)
{
    uint8 PowerUpFlag = 0;
    
    uint16 PowerOnCnt1 = 0;
    uint16 PowerOnCnt2 = 0;
    uint8 PowerOnFlag = 0;
    
    uint8 Balance_i = 0;
    
    uint16 PowerUpCnt = 0;
    
    for(PowerUpCnt=0;PowerUpCnt<SystemPowerUpTime;PowerUpCnt++){};
    
    /*Software Init*/
    SoftwareInit();

    /*Hardware Init*/
    HardwareInit();

    /*调试模式设置--内部变量查询；CMP输出查询；ADC触发信号查询*/
    //DebugSet();
    
	
	//主板开机操作
	for(Balance_i = 0; Balance_i < 64; Balance_i ++)
	{
		if(Balance_i == 0)
			AccZoutALPF = AccZout;
		else
		{
			Read_I2C_Byte(SlaveAddress >> 1, ACCEL_ZOUT_H, &AccZoutH, &AccZoutL);
			AccZout = (AccZoutH << 8) + AccZoutL; 
			
			AccZoutALPF = LPFFunction(AccZout, AccZoutALPF, 20);
		}
	}
		
    #if (BoardRole == MainBoard)
		if(ChargeDetectIO == 0 || AccZoutALPF > -3000)
		{
			while(1);
		}
		else if(ChargeDetectIO == 1)
		{
			/*开机*/
			SetBit(P2_OE, P20);					//绿灯（电量指示灯）
			SetBit(P2_PU, P20);
			PowerOnOffIO = 1;
		}
    #endif

		
		

    /*开机调平衡检测*/	    
    #if (BoardRole == MainBoard)
    {
        while(1)
        {
            Balance_i = 2;
            
            SetBit(ADC_CR, ADCBSY);          //使能ADC采样
            while(Balance_i--);                 //延时一下等待AD转换完成
            PowerOnOffAD = ADC1_DR;         //开机AD值采集

            if(PowerOnOffAD >= 1000)
            {
                PowerOnCnt1 ++;
                if(PowerOnCnt1 >= 30000)
                {
                    PowerOnCnt2 ++;
                    PowerOnCnt1 = 0;
                }
            }
            else
            {
                //读取存在Flash中的上次零偏值
                BalStaToSlave = 1;
                BoardsCom_Master_Tran_For_BalPoi();                            //发送开机调平衡状态
                BalanceGyrALPF = Get2ByteFromFlash(0x3F00);         //从0x3F00和0x3F01读取上次的陀螺仪零偏
                BalanceAccALPF = Get2ByteFromFlash(0x3F02);         //从0x3F00和0x3F01读取上次的陀螺仪零偏
				
                BoardMusic = 1;
                break;
            }
            
            if(PowerOnCnt2 >= 15)
            {
                BalStaToSlave = 2;
                BoardsCom_Master_Tran_For_BalPoi();                            //发送开机调平衡状态
                //读取此时的陀螺仪作为零偏值并存在Flash中
                for(Balance_i = 0; Balance_i < 100; Balance_i++)
                {
                    Read_I2C_Byte(SlaveAddress >> 1, GYRO_YOUT_H, &BalanceGyrH, &BalanceGyrL);
                    BalanceGyr = (BalanceGyrH << 8) + BalanceGyrL;
                    
                    BalanceGyrAdd += BalanceGyr;
                }
                BalanceGyrALPF = (BalanceGyrAdd / 100);
                
                //读取此时的加速度计作为零偏值并存在Flash中
                for(Balance_i = 0; Balance_i < 100; Balance_i++)
                {
                    Read_I2C_Byte(SlaveAddress >> 1, ACCEL_XOUT_H, &BalanceAccH, &BalanceAccL);
                    BalanceAcc = (BalanceAccH << 8) + BalanceAccL;
                    
                    BalanceAccAdd += BalanceAcc;
                }
                BalanceAccALPF = (BalanceAccAdd / 100);
                
				
				
                Flash_Sector_Erase(0x3F00);                 //先擦该扇区
                Write2Byte2FlashWithoutCheck(0x3F00, BalanceGyrALPF);       //0x3F00和0x3F01存放陀螺仪零偏
                Write2Byte2FlashWithoutCheck(0x3F02, BalanceAccALPF);       //0x3F02和0x3F03存放加速度计零偏
                
                BoardMusic = 1;
                break;
            }
        }
    }
    #elif (BoardRole == SeconBoard)
    {
        while(1)
        {
            if(RI == 1)
            {
                if(SlaReCnt == 0)
                {
                    if(UT_DR == 0xff)
                        SlaReCnt ++;
                }
                if(SlaReCnt == 1)
                {
                    if(UT_DR == 0x00)
                        SlaReCnt ++;
                }
                if(SlaReCnt == 2)
                {
                    if(UT_DR == 1)
                    {
                        BalanceGyrALPF = Get2ByteFromFlash(0x3F00);         //从0x3F00和0x3F01读取上次的陀螺仪零偏
                        BalanceAccALPF = Get2ByteFromFlash(0x3F02);         //从0x3F00和0x3F01读取上次的陀螺仪零偏
					
						
						
                        break;
                    }
                    else if(UT_DR == 2)
                    {
                        //读取此时的陀螺仪作为零偏值并存在Flash中
                        for(Balance_i = 0; Balance_i < 100; Balance_i++)
                        {
                            Read_I2C_Byte(SlaveAddress >> 1, GYRO_YOUT_H, &BalanceGyrH, &BalanceGyrL);
                            BalanceGyr = (BalanceGyrH << 8) + BalanceGyrL;
                            
                            BalanceGyrAdd += BalanceGyr;
                        }
                        BalanceGyrALPF = (BalanceGyrAdd / 100);
                        
                        //读取此时的加速度计作为零偏值并存在Flash中
                        for(Balance_i = 0; Balance_i < 100; Balance_i++)
                        {
                            Read_I2C_Byte(SlaveAddress >> 1, ACCEL_XOUT_H, &BalanceAccH, &BalanceAccL);
                            BalanceAcc = (BalanceAccH << 8) + BalanceAccL;
                            
                            BalanceAccAdd += BalanceAcc;
                        }
                        BalanceAccALPF = (BalanceAccAdd / 100);
                        
						
						
						
                        Flash_Sector_Erase(0x3F00);                 //先擦该扇区
                        Write2Byte2FlashWithoutCheck(0x3F00, BalanceGyrALPF);       //0x3F00和0x3F01存放陀螺仪零偏
                        Write2Byte2FlashWithoutCheck(0x3F02, BalanceAccALPF);       //0x3F02和0x3F03存放加速度计零偏
                        
                        break;
                    }
                }
                
                RI = 0;
            }
        }
        
    }
    #endif
	RI = 0;
	
	#if (BoardRole == MainBoard)
		DMA1_For_Uart_Tx();
		DMA0_For_Uart_Rx();
	#elif (BoardRole == SeconBoard)
		DMA1_For_Uart_Tx();
		DMA0_For_Uart_Rx();
	#endif
	

	
//	//开机灯光
//    #if (BoardRole == MainBoard)
//    {
//		PowerHighLed = 1;
//    }
    #if (BoardRole == SeconBoard)
    {
		PowerStatueLedRed = 1;
    }
    #endif
    
	/*开机检测电池串数*/
	BatStartADValue = (ADC2_DR<<3);
	
	if(BatStartADValue >= BAT_VOL_DETECT_VALUE)
	{
		BatteryNumber = 10;
	}
	else
	{
		BatteryNumber = 7;
	}	
	
	
    while(1)
    {
        if(mcCurOffset.OffsetFlag==0)
        {
            if(PowerUpFlag==0)
            {
                FOC_Init();			
                SamplingPrepare();		   //采样准备
                PowerUpFlag = 1;
                mcCurOffset.OffsetCount         = 0;
            }

            GetCurrentOffset();      // 电流偏置的获取
        }
        
        
        /*喂狗*/
        //WatchDogRefresh();
                
        if(mcCurOffset.OffsetFlag>=1)
        {
            MC_Control();          // 主控函数，状态扫描 
        }
         /****串口发送数据*****/				
        
		#if (BoardRole == MainBoard)
		/*电量灯的灯光控制*/
//		if(ChargeDetectIO == 1)
//		{
			if(OverUnderVoltageFlag == 0)
			{
				PowerStatueLedGreen = 1;
				PowerStatueLedRed = 0;
			}
			else
			{
				PowerStatueLedGreen = 0;
//				PowerStatueLedRed = 0;
			}
//			PowerStatueLedYellow = 0;
//		}
//		else
//		{
//			AnglePro = 1;
//			
//			PowerStatueLedYellow = 1;
//			PowerStatueLedRed = 0;
//			PowerStatueLedGreen = 0;
//			
//		}
		#endif
		
		/*主副板故障标志位检测*/
		
		#if (BoardRole == MainBoard)
		if( mcState == mcFault || AnglePro == 1 || HallErrMisic == 1)
			BrokenFlag = 1;
		else
			BrokenFlag = 0;
		
		if(SeconBoardData.SeconBoardBroked == 1 || mcState == mcFault )
			BrokenMusic = 1;
		else
			BrokenMusic = 0;
		
		
		#elif (BoardRole == SeconBoard)
		
		if( mcState == mcFault  )
			BrokenFlag = 1;
		else
			BrokenFlag = 0;
		
		#endif
		
		
        if(UartSendFlag == 1)
        {
            
            #if (BoardRole == MainBoard)
//                SendPictureDataByUart((int16)(AccYout ), (int16)(AccYoutALPF ), (int16)(BatteryNumber ),  (int16)(mcADCVoltagebus2 ));		//发送4通道int型数据到波形上位机
				
//				BoardsCom_Main_Slave();
            #elif (BoardRole == SeconBoard)
			
//                BoardsCom_Slave_Main();         

            #endif
            
            
            //GP07 = 1;
//            SendPictureDataByUart((int16)(BalancePoint ), (int16)(angleALPF ), (int16)(FOC__UQ ),  (int16)(AngleOutput ));		//发送4通道int型数据到波形上位机，发送周期100ms
            //AccYoutAF,mcFocCtrl.mcSpeedVSP,mcFocCtrl.OpenDutyCycle,SpeedRamp.RampStep,FOC__UQ,KeyBrakeAngleCompensate,mcHall.RealSpeed
            //GP07 = 0;
            UartSendFlag = 0;
        }

    }
}
/*-------------------------------------------------------------------------------------------------
    Function Name : void DebugSet(void)
    Description   : 调试模式配置
    Input         : 无
    Output        : 无
-------------------------------------------------------------------------------------------------*/
void DebugSet(void)
{
	  #if (SPI_DBG_HW)      // 硬件调试模式
        Set_DBG_DMA(&HARD_SPIDATA);
    #elif (SPI_DBG_SW)    // 软件调试模式
        Set_DBG_DMA(spidebug);
    #endif

    #if  ((SPI_DBG_HW) && (SPI_DBG_SW))
        #error Only one DBG mode can be selected
    #endif

    SetReg(CMP_CR3, DBGSEL0 | DBGSEL1,  GP01_DBG_Conf);
    SetReg(CMP_CR3, CMPSEL0 | CMPSEL1 | CMPSEL2, GP07_DBG_Conf);
}

/*-------------------------------------------------------------------------------------------------
        Function Name : void SoftwareInit(void)
        Description   : 软件初始化，初始化所有定义变量，按键初始化扫描
        Input         : 无
        Output        : 无
-------------------------------------------------------------------------------------------------*/
void SoftwareInit(void)
{
    /****初始化所有定义的参数变量****/
    MotorcontrolInit();

	  ClrBit(DRV_CR, FOCEN);         // 关闭FOC
	
    MOE			= 0;                  // 关闭MOE
	
    mcFaultSource = 0;
}


/*-------------------------------------------------------------------------------------------------
        Function Name : void HardwareInit(void)
        Description   : 硬件初始化，初始化需要使用的硬件设备配置，FOC必须配置的是运放电压、运放初始化、ADC初始化、Driver初始化
                                    TIM4初始化，其他的可根据实际需求加。
        Input         : 无
        Output        : 无
-------------------------------------------------------------------------------------------------*/
void HardwareInit(void)
{
    // 为提高芯片的抗干扰能力，降低芯片功耗，请在具体项目时，将不需要用的GPIO默认都配置为输入上拉。
    // 具体配置可在GPIO_Default_Init设置。
    GPIO_Default_Init();

    /******硬件FO过流，比较器初始化，用于硬件过流比较保护******/
    #if (HardwareCurrent_Protect == Hardware_FO_Protect)  //外部中断初始化，用于外部中断硬件过流FO的保护
        EXTI_Init();
    #elif (HardwareCurrent_Protect == Hardware_CMP_Protect)//选择比较过流，比较器初始化
        CMP3_Init();
    #elif (HardwareCurrent_Protect == Hardware_FO_CMP_Protect)    //两者都选择
        EXTI_Init();
        CMP3_Init();
    #endif

    //  Sleepmode_Init();

    /****功能IO初始化***********/
    GPIO_Init();

    /*****运算放大器初始化*********/
    AMP_Init();

    /*****ADC初始化*********/
    ADC_Init();
		
    /****比较器中断配置***********/
    CMP3_Inter_Init();                         // 建议和比较器初始化间隔一段时间

    /*****Driver初始化*********/
    Driver_Init();
		
		/*****MDU初始化*********/
//		MDU_16MUL16_INT(15,1);
		
    /*****UART初始化*********/ 
     UART_Init();//

     /*****DMA0初始化*********/ 
//    Set_DMA(0, UART_XDATA, &UART_DMAData, 1);
	
    /*****IIC初始化*********/
    Init_I2C();
    
    /*****MPU6050初始化*********/
    MPU6060_Init();

    #if  ((SPI_DBG_SW) | (SPI_DBG_HW))   // 调试模式
        //SPI_Init();   //调试模式下，占用SPI端口的NSS(GP04),MOSI(GP05),SCK(GP06)
    #endif

    /*****Timer初始化*******/
	TIM1_Init();
    TIM2_Init();
		
    TIM3_Init();

    TIM4_Init();
		
//    TIM1ms_Init();//采用1ms定时器中断作为常见中断,处理故障保护等附加功能
		
		/*****看门狗初始化*******/
		//WatchDogConfig(100,1);

 }
