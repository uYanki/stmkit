/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : FlashWrite.c
* Author             : 
* Version            : 
* Date               : 
* Description        : 
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/
#include <FU68xx_2.h>
#include <Myproject.h>

/*Private variables------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------------------------
	Function Name :	uint16 GetLastDataFromFlash(uint8 xdata *BlockStartAddr)
	Description   :	��Ŀ��FLASH������ȡ2�ֽ�����д�������
	Input         :	uint8 xdata *BlockStartAddr��Ŀ��FLASH����
	Output        :	����������
-------------------------------------------------------------------------------------------------*/
int16 Get2ByteFromFlash(uint8 xdata *BlockStartAddr)
{
	uint8 tempofFlashDataH;
	uint8 tempofFlashDataL;
	int16 tempofFlashData;
	
    tempofFlashDataH = *(uint8 code *)(BlockStartAddr);
    tempofFlashDataL = *(uint8 code *)(BlockStartAddr+1);
    tempofFlashData = (tempofFlashDataH << 8) + tempofFlashDataL;
    
    return tempofFlashData;
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void WriteData2Flash(uint8 xdata *BlockStartAddr,uint16 NewData2Flash)
	Description   :	д��2���ֽڵ�FLASH
	Input         :	uint8 xdata *BlockStartAddr��Ŀ��FLASH��ַ  NewData2Flash����д������
    Output		  :	1:����δ��,д�����  0:��������,д��ʧ��
-------------------------------------------------------------------------------------------------*/
void Write2Byte2FlashWithoutCheck(uint8 xdata *BlockStartAddr,int16 NewData2Flash)
{
	uint8 tempofFlashData=0;
		
        
    
        tempofFlashData = NewData2Flash>>8;                            //��д���������ֽ�
        Flash_Sector_Write((BlockStartAddr),(uint8)tempofFlashData);
        _nop_();
        tempofFlashData = NewData2Flash&0x00ff;                        //��д������ĩ�ֽ�
        Flash_Sector_Write((BlockStartAddr+1),(uint8)tempofFlashData);
        _nop_();		

}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void WriteData2Flash(uint8 xdata *BlockStartAddr,uint16 NewData2Flash)
	Description   :	д��2���ֽڵ�FLASH
	Input         :	uint8 xdata *BlockStartAddr��Ŀ��FLASH��ַ  NewData2Flash����д������
    Output		  :	1:����δ��,д�����  0:��������,д��ʧ��
-------------------------------------------------------------------------------------------------*/
uint8 Write2Byte2Flash(uint8 xdata *BlockStartAddr,uint16 NewData2Flash)
{
	uint8 xdata *FlashStartAddr = BlockStartAddr;
	uint16 tempofFlashData=0;
	uint16 tempofNewFlashData=0;
	uint8 i;
	
	tempofNewFlashData = NewData2Flash;
	
	for(i=0;i<64;i++)
	{
		tempofFlashData = *(uint16 code *)(FlashStartAddr+2*i);
		if(tempofFlashData==0)
		{
			tempofFlashData = tempofNewFlashData>>8;                            //��д���������ֽ�
			Flash_Sector_Write((FlashStartAddr+2*i),(uint8)tempofFlashData);
			_nop_();
			tempofFlashData = tempofNewFlashData&0x00ff;                        //��д������ĩ�ֽ�
			Flash_Sector_Write((FlashStartAddr+2*i+1),(uint8)tempofFlashData);
			_nop_();		

			return 1;
		}
		else
		{
			if(i==63)
			{
				return 0;
			}
		}
	}
	return 0;
}
/*-------------------------------------------------------------------------------------------------
    Function Name :	uint8 Get4ByteFromFlash(uint8 xdata *BlockStartAddr)
	Description   :	��Ŀ��FLASH������ȡ4�ֽ�����д�������
	Input         :	uint8 xdata *BlockStartAddr��Ŀ��FLASH����
    Output		  :	����������
-------------------------------------------------------------------------------------------------*/
uint32 Get4ByteFromFlash(uint8 xdata *BlockStartAddr)
{
	uint8 xdata *FlashStartAddr = BlockStartAddr;
	uint8 i;
	uint32 tempofFlashData;
	
	for(i=0;i<32;i++)
	{
		tempofFlashData = *(uint32 code *)(FlashStartAddr + 4*i);
		if(tempofFlashData==0)
		{
			if(i!=0)
			{
				tempofFlashData = *(uint32 code *)(FlashStartAddr + 4*(i-1));
				return tempofFlashData;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			if(i==31)
			{
				return tempofFlashData;
			}
		}	
	}
	return 0;
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void Write4Byte2Flash(uint8 xdata *BlockStartAddr,uint32 NewData2Flash)
	Description   :	д��4���ֽڵ�FLASH
	Input         :	uint8 xdata *BlockStartAddr��Ŀ��FLASH��ַ  NewData2Flash����д������
    Output		  :	��
-------------------------------------------------------------------------------------------------*/
void Write4Byte2Flash(uint8 xdata *BlockStartAddr,uint32 NewData2Flash)
{
	uint8 i;
    uint8 xdata *FlashStartAddr = BlockStartAddr;
	uint32 tempofFlashData=0;
	uint32 tempofNewFlashData=0;	
		
	tempofNewFlashData = NewData2Flash;
	
	for(i=0;i<32;i++)
	{
		tempofFlashData = *(uint32 code *)(FlashStartAddr+4*i);
		if(tempofFlashData==0)
		{
			tempofFlashData = (tempofNewFlashData>>24)&0x000000ff;
			Flash_Sector_Write((FlashStartAddr+4*i),(uint8)tempofFlashData);
			_nop_();
			tempofFlashData = (tempofNewFlashData>>16)&0x000000ff;
			Flash_Sector_Write((FlashStartAddr+4*i+1),(uint8)tempofFlashData);
			_nop_();
			tempofFlashData = (tempofNewFlashData>>8)&0x000000ff;
			Flash_Sector_Write((FlashStartAddr+4*i+2),(uint8)tempofFlashData);
			_nop_();
			tempofFlashData = tempofNewFlashData&0x000000ff;
			Flash_Sector_Write((FlashStartAddr+4*i+3),(uint8)tempofFlashData);
			_nop_();			
			break;
		}
		else
		{
			/*��������д��,����������д������*/
            if(i==31)
			{
				Flash_Sector_Erase(FlashStartAddr);
				_nop_();
				tempofFlashData = (tempofNewFlashData>>24)&0x000000ff;
				Flash_Sector_Write((FlashStartAddr),(uint8)tempofFlashData);
				_nop_();
				tempofFlashData = (tempofNewFlashData>>16)&0x000000ff;
				Flash_Sector_Write((FlashStartAddr+1),(uint8)tempofFlashData);
				_nop_();
				tempofFlashData = (tempofNewFlashData>>8)&0x000000ff;
				Flash_Sector_Write((FlashStartAddr+2),(uint8)tempofFlashData);
				_nop_();
				tempofFlashData = tempofNewFlashData&0x000000ff;
				Flash_Sector_Write((FlashStartAddr+3),(uint8)tempofFlashData);
				_nop_();				
			}
		}
	}	
}

