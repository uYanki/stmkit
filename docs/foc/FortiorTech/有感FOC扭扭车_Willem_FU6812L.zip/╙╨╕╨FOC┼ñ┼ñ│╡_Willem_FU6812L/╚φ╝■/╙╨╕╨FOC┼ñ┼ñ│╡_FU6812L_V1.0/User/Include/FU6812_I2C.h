#ifndef __FU6812_I2C_H__
#define __FU6812_I2C_H__

//#include <FU6812_MCU.h>

//****************定义MPU6050内部地址************************
#define	SMPLRT_DIV		0x19	//陀螺仪采样率，典型值：0x07(125Hz)
#define	CONFIG			0x1A	//低通滤波频率，典型值：0x06(5Hz)
#define	GYRO_CONFIG		0x1B	//陀螺仪自检及测量范围，典型值：0x18(不自检，2000deg/s)
#define	ACCEL_CONFIG	0x1C	//加速计自检、测量范围及高通滤波频率，典型值：0x01(不自检，2G，5Hz)
#define	ACCEL_XOUT_H	0x3B
#define	ACCEL_XOUT_L	0x3C
#define	ACCEL_YOUT_H	0x3D
#define	ACCEL_YOUT_L	0x3E
#define	ACCEL_ZOUT_H	0x3F
#define	ACCEL_ZOUT_L	0x40
#define	TEMP_OUT_H		0x41
#define	TEMP_OUT_L		0x42
#define	GYRO_XOUT_H		0x43
#define	GYRO_XOUT_L		0x44	
#define	GYRO_YOUT_H		0x45
#define	GYRO_YOUT_L		0x46
#define	GYRO_ZOUT_H		0x47
#define	GYRO_ZOUT_L		0x48
#define	PWR_MGMT_1		0x6B	//电源管理，典型值：0x00(正常启用)
#define	WHO_AM_I			0x75	//IIC地址寄存器(默认数值0x68，只读)
#define	SlaveAddress	0xD0	//IIC写入时的地址字节数据，+1为读取
/*****************************************************************************************/

/*************************************************************************************///ConfigCMD(Don't touch)
//配置时用的参数，请勿改动

//SpeedPara
#define I2C_SPD_100k            0x00
#define I2C_SPD_400k            I2CSPD0
#define I2C_SPD_1M              I2CSPD1

//Read-write status flag
#define I2C_FA_ADD              0x01
#define I2C_FA_REG              0x02
#define I2C_FA_DAT              0x04
#define I2C_SU                  0x00
/*************************************************************************************///Config
//I2C的主/从机模式设置，注释掉该句则I2C将会配置为从机模式
#define I2C_MASTER

//I2C速度设置，参数值在上方SpeedPara中，I2C为主机模式时必须关注
#define I2C_SPEED               (I2C_SPD_400k)

//本机I2C的7位地址，初始化会自动挪位，I2C为从机模式时必须关注
#define I2C_ADDR7               (0x68)

//I2C滤波宽度设置，注释掉该句I2C将使用较窄的滤波宽度
// #define I2C_LPF

//I2C主机模式下该项才有效，针对从器件在读写地址相邻的寄存器时，寄存器指针是否自动加1
#define I2C_AUTO_ADDR

/*************************************************************************************///Function
#define Enable_I2C()                  SetBit(I2C_CR, I2CEN)                           //使能I2C
#define Disable_I2C()                 ClrBit(I2C_CR, I2CEN)                           //禁能I2C
#define Set_Nack_I2C()                SetBit(I2C_SR, NACK)                         //不发送应答信号
#define Set_Ack_I2C()                 ClrBit(I2C_SR, NACK)                         //发送应答信号
#define Set_Addr_I2C(a)               I2C_ID = a << 1                                  //设置I2C地址(主要用于主机模式)

extern void Init_I2C(void);                                                            //初始化I2C
extern void Start_I2C(bool rw);                                                        //发送I2C启动信号、I2C_ID的内容和读写信号
extern void Stop_I2C(void);                                                            //发送停止信号

extern void Send_I2C(uint8 Dat);                                                     //I2C发送1字节数据
extern uint8 Receive_I2C(void);                                                      //I2C接收1字节数据

extern uint8 Write_I2C(uint8 addr7, uint8 reg, uint8 len, uint8* dat);       //I2C从从机addr7的reg处开始发送长度为len的数据包dat[]
extern uint8 Read_I2C(uint8 addr7, uint8 reg, uint8 len, uint8* dat);        //I2C从从机addr7的reg处开始接收长度为len的数据包dat[]
extern uint8 Write_I2C_Byte(uint8 addr7, uint8 reg, uint8 date);
extern uint8 Read_I2C_Byte(uint8 addr7, uint8 reg, uint8* dat1, uint8* dat2);

extern void MPU6060_Init(void);


#endif
