/**************************** (C) COPYRIGHT 2015 Fortiortech shenzhen *****************************
* File Name          : MDU.h
* Author             : Fortiortech  Market Dept
* Version            : V1.0
* Date               : 01/07/2015
* Description        : This file contains all the common data types used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/ 

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __MDU_H_
#define __MDU_H_

typedef struct
{
	
//	uint8 FlagTheta;
//  uint8 FlagAngleErrCW;
//	uint8 FlagAngleErrCCW;
	
	
	uint8 FlagSpeed;
//	uint8 FlagPISpeed;
//	uint8 FlagTargetSpeed;
//	uint8 FlagPITargetSpeed;
	
//	uint8 FlagCurrentBUS;
//	uint8 FlagPICurrentBUS;
//	uint8 FlagPITargetCurrentBUS;
	
//	uint8 FlagPWMINHighDuty;
	
} MDUControl_TypeDef;

///* Exported variables ---------------------------------------------------------------------------*/
extern MDUControl_TypeDef xdata MDUControl;

/* Exported functions ---------------------------------------------------------------------------*/
extern void MDUAPP(void);
extern void MDUAPP1(void);
extern void MDUControlInit(void);
extern uint16 MDU_MUL_U16(uint16 TData0, uint16 TData1);
extern void MDU_MUL_U32(uint16 TData0, uint16 TData1, uint16 xdata *Result32);
extern int16 MDU_MUL_S16(int16 TData0, int16 TData1);
extern void MDU_MUL_S32(int16 TData0, int16 TData1, uint16 xdata *Result32);
extern uint16 MDU_MULA_U16(uint16 TData0, uint16 TData1, uint8 ALIGN);
extern void MDU_MULA_U32(uint16 TData0, uint16 TData1, uint8 ALIGN, uint16 xdata *Result32);
extern int16 MDU_MULA_S16(int16 TData0, int16 TData1, uint8 ALIGN);
extern void MDU_MULA_S32(int16 TData0, int16 TData1, uint8 ALIGN, uint16 xdata *Result32);
extern uint16 MDU_DIV_U16(uint16 xdata *TData0, uint16 xdata *TData1);
extern void MDU_DIV_U32(uint16 xdata *TData0, uint16 xdata *TData1, uint16 xdata *Result32);

#endif