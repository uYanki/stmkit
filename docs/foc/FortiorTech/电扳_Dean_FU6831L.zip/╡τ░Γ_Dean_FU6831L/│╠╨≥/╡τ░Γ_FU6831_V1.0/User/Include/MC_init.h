
/************************ (C) COPYRIGHT 2015 FT *******************************
* File Name          : 
* Author             : Application Team  Tom.wang 
* Version            : V2.0.0
* Date               : 06/15/2015
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MC_INIT_H
#define __MC_INIT_H

/* Includes ------------------------------------------------------------------*/
#include <fu68xx_MCDevice.h>
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/

/* Exported define --------------------------------------------------------*/

//�˿ڶ��� START F/R FO FG PWMIN SREF LED UART SPI  HALL
//------------------------------------------------------------------------------
//FO     ��������   IPM�����źţ���ֹ�޸� 
//#define FO              GP00         //��Ϊ FO�ź�ʱ����ֹռ��
//#define FO_PIN          P00
//#define FO_GPIO_PORT    P0_OE
//------------------------------------------------------------------------------
//PWMIN  ��������   ��ֹ�޸�
#define PWMIN              GP27
#define PWMIN_PIN          P27
#define PWMIN_GPIO_PORT    P2_OE

#define PWMIN_ON           {PWMIN = 0;}
#define PWMIN_OFF          {PWMIN = 1;}
#define PWMIN_ONOFF        {PWMIN = ~PWMIN;}
//------------------------------------------------------------------------------
//SPI     MOSI��� 
#define NSS              GP04
#define NSS_PIN          P04 
#define NSS_GPIO_PORT    P0_OE
#define NSS_ON           {NSS = 0;}
#define NSS_OFF          {NSS = 1;}
#define NSS_ONOFF        {NSS = ~NSS;}    //�����ź�

#define MOSI              GP05
#define MOSI_PIN          P05 
#define MOSI_GPIO_PORT    P0_OE
#define MOSI_ON           {MOSI = 0;}
#define MOSI_OFF          {MOSI = 1;}
#define MOSI_ONOFF        {MOSI = ~MOSI;} //λ�ò����ź�

#define MISO              GP06
#define MISO_PIN          P06 
#define MISO_GPIO_PORT    P0_OE
#define MISO_ON           {MISO = 0;}
#define MISO_OFF          {MISO = 1;}
#define MISO_ONOFF        {MISO = ~MISO;}  //�����ź�

#define SCLK              GP07            
#define SCLK_PIN          P07 
#define SCLK_GPIO_PORT    P0_OE
#define SCLK_ON           {SCLK = 0;}
#define SCLK_OFF          {SCLK = 1;}
#define SCLK_ONOFF        {SCLK = ~SCLK;} //�Ƚ����ź�

//------------------------------------------------------------------------------
////FD6536  ʹ��
#define FD6536           GP15
#define FD6536_PIN       P15 
#define FD6536_GPIO_PORT P3_OE

#define FD6536_EN        {FD6536 = 0;}
#define FD6536_DIS       {FD6536 = 1;}

//------------------------------------------------------------------------------

//PDELAY     power dealy ��� 
#define PDELAY           GP11
#define PDELAY_PIN       P11 
#define PDELAY_GPIO_PORT P1_OE
#define PDELAY_ON       {PDELAY = 1;}
#define PDELAY_OFF      {PDELAY = 0;}
#define PDELAY_ONOFF    {PDELAY = ~PDELAY;}


//------------------------------------------------------------------------------
//FAULT  ������� 
#define FAULT              GP22
#define FAULT_PIN          P22
#define FAULT_GPIO_PORT    P2_OE

#define FAULT_ON           {FAULT = 0;}
#define FAULT_OFF          {FAULT = 1;}
#define FAULT_ONOFF        {FAULT = ~FAULT;}

//------------------------------------------------------------------------------
//�������� ������Ը���
#define X0_GPIO_PIN           GP10
#define X0_PIN                P10
#define X0_GPIO_PORT          P1_OE
#define X0_PU                 P1_PU

//#define X1_GPIO_PIN           GP01
//#define X1_PIN                P01
//#define X1_GPIO_PORT          P0_OE
//#define X1_PU                 P0_PU

//#define X2_GPIO_PIN           GP13
//#define X2_PIN                P13
//#define X2_GPIO_PORT          P1_OE
//#define X2_PU                 P1_PU

#define X3_GPIO_PIN           GP13
#define X3_PIN                P13
#define X3_GPIO_PORT          P1_OE
#define X3_PU                 P1_PU
//------------------------------------------------------------------------------
//LED    ��ʾ
#define LED1              GP37
#define LED1_PIN          P37 
#define LED1_GPIO_PORT    P3_OE

#define LED2              GP36
#define LED2_PIN          P36 
#define LED2_GPIO_PORT    P3_OE

#define LED3              GP22
#define LED3_PIN          P22 
#define LED3_GPIO_PORT    P2_OE

#define LED4              GP03
#define LED4_PIN          P03 
#define LED4_GPIO_PORT    P0_OE

#define LED5              GP02
#define LED5_PIN          P02
#define LED5_GPIO_PORT    P0_OE

#define LED6              GP01
#define LED6_PIN          P01 
#define LED6_GPIO_PORT    P0_OE

#define LED7              GP00
#define LED7_PIN          P00 
#define LED7_GPIO_PORT    P0_OE
//#define LED8              GP00
//#define LED8_PIN          P00 
//#define LED8_GPIO_PORT    P0_OE

//#define LED9              GP11
//#define LED9_PIN          P11 
//#define LED9_GPIO_PORT    P1_OE

//------------------------------------------------------------------------------
#define LED1_ON           {LED1 = 0;}
#define LED1_OFF          {LED1 = 1;}
#define LED1_ONOFF        {LED1 = ~LED1;}

#define LED2_ON           {LED2 = 0;}
#define LED2_OFF          {LED2 = 1;}
#define LED2_ONOFF        {LED2 = ~LED2;}

#define LED3_ON           {LED3 = 0;}
#define LED3_OFF          {LED3 = 1;}
#define LED3_ONOFF        {LED3 = ~LED3;}

#define LED4_ON           {LED4 = 0;}
#define LED4_OFF          {LED4 = 1;}
#define LED4_ONOFF        {LED4 = ~LED4;}

#define LED5_ON           {LED5 = 0;}
#define LED5_OFF          {LED5 = 1;}
#define LED5_ONOFF        {LED5 = ~LED5;}

#define LED6_ON           {LED6 = 0;}
#define LED6_OFF          {LED6 = 1;}
#define LED6_ONOFF        {LED6 = ~LED6;}

#define LED7_ON           {LED7 = 0;}
#define LED7_OFF          {LED7 = 1;}
#define LED7_ONOFF        {LED7 = ~LED7;}

//#define LED8_ON           {LED8 = 0;}
//#define LED8_OFF          {LED8 = 1;}
//#define LED8_ONOFF        {LED8 = ~LED8;}

//#define LED9_ON           {LED9 = 0;}
//#define LED9_OFF          {LED9 = 1;}
//#define LED9_ONOFF        {LED9 = ~LED9;}

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
extern void SoftwareInit(void);
extern void MCL_ModuleDefault(void);
extern void MCL_ModuleInstance(void); //ģ������
extern void MCL_ModuleInit(void);     //ģ���ʼ��
extern void MCL_DefaultInit(void);    //
extern u8 Delay(u16 timer);
extern u8 Delayus(u16 timer);
extern void gDelayus(u16 timer);
extern void gDelayms(u16 timer);
#endif /* __HD_init_H */

/******************* (C) COPYRIGHT 2014 FT *****END OF FILE****/

