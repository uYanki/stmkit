
/************************ (C) COPYRIGHT 2017 FT *******************************
* File Name          : 
* Author             : 
* Version            : V2.0.0
* Date               : 04/15/2017
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>

/* Private typedef ------------------------------------------------------------------------------*/
/* Private define -------------------------------------------------------------------------------*/
/* Private macro --------------------------------------------------------------------------------*/
/* Private variables ----------------------------------------------------------------------------*/
PWMINCtl_TypeDef xdata PWMINCtl;
u8 xdata PwmInResetFlag;

u16 xdata tTempMotorBreakTime;                //ɲ������ʱ��, us
u16 xdata tTempMotorONTimeErr;                // us
u16 xdata tTempMotorOFFTimeErr;               // us
u16 xdata tTempPWMHighMinDefault;             // �������У׼����, us
u16 xdata tTempPWMHighMaxDefault;             // �������У׼����, us
u16 xdata tTempPWMHighMinAline;               // �������У׼����, us
u16 xdata tTempPWMHighMaxAline;               // �������У׼����, us
u16 xdata tTempPWMHighMinONAline;             //  
u16 xdata tTempPWMINHighMinFilt;              // �������У׼����, us
u16 xdata tTempPWMINHighMaxFilt;              // �������У׼����, us

u8 xdata tPWMINTim3ITconter;                 //tim3 ���������
u8 xdata tPWMINOutRangeCounter;              //���ſ��ȴ��������
u16 xdata tPWMINErrCotnter;  
/* Private function prototypes ------------------------------------------------------------------*/
void PWMINOnOffSwitch(void);
/* Private functions ----------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
Function Name :	void PWMIN_Init(void)
Description   :	PWM��������ʼ��
Input         :	��
Output				:	��
-------------------------------------------------------------------------------------------------*/
void PWMINInit(void)
{
  float tfAlineA;
  #if(PWMINSREF_EN)
  PWMINCtl.FlagPWMAline = 0x7F;
  #if(BEEPSCAN_EN)
  PWMINCtl.FlagPwmIn = 0xF1;
  #else
  PWMINCtl.FlagPwmIn = 0xFF;
  #endif
  
  PWMINCtl.PWMStatus  = 0;
  PWMINCtl.PWMINBreakCnt = 0;
  PWMINCtl.PWMINHigh = 0;
  PWMINCtl.PWMINHighMin = 0;
  PWMINCtl.PWMINHighMax = 0;
  
  MDUControl.AlineX1 = 0;//32767*((float)(PWMINCtl.PWMINHighMin + TempMotorONTimeErr)/(float)PWMINCtl.PWMINHighMax);
  MDUControl.AlineX2 = 32767;//32767*((float)PWMINCtl.PWMINHighMax/(float)PWMINCtl.PWMINHighMax);
  MDUControl.SpeedSrefErr = MDUControl.AlineX2 - MDUControl.AlineX1; ;

  tfAlineA= ((float)(SPEED_REF_MAX-SPEED_REF_MIN)/(MDUControl.SpeedSrefErr));
  MDUControl.AlineA = (u16)(tfAlineA*32767);                        //ϵ�� a
  MDUControl.AlineB = (SPEED_REF_MAX - MDUControl.AlineX2*tfAlineA);//ϵ�� b
  
#endif
}

/*-------------------------------------------------------------------------------------------------
Function Name :	void PWMScan(void)
Description   : //670 ~ 1559
Input         :	��
Output				:	��
-------------------------------------------------------------------------------------------------*/
void PWMScan(void)
{
  u32 Temp32A,Temp32B;
  u16 tPWMINHigh;
  
  if(GetBit(TIM3_CR1, T3IR))
  {    
    tPWMINTim3ITconter = 0;
    //�ٶȸ������ۻ�_IQ(15) 0~32767
    #if(PWMINSREF_EN)
    if(PWMINCtl.PWMStatus == 0)    //���ſ���ʶ��125us or 1000us 
    {
      if(Ctl.State == MOTOR_STOP)
      {
        if((TIM3_DR > TempPWMINHighMinFiltA)&&(TIM3_DR < TempPWMINHighMaxFiltA))
        {
          PWMINCtl.PWMINSelfCheck--;
        }
        else if((TIM3_DR > TempPWMINHighMinFiltB)&&(TIM3_DR < TempPWMINHighMaxFiltB))
        {
          PWMINCtl.PWMINSelfCheck++;
        }

        if(PWMINCtl.PWMINSelfCheck >= 3)
        {
          PWMINCtl.PWMINSelfCheck = 3;
          PWMINCtl.PWMStatus = 0x7F;
          
          tTempMotorBreakTime = TempMotorBreakTimeB;
          tTempMotorONTimeErr = TempMotorONTimeErrB;
          tTempMotorOFFTimeErr = TempMotorOFFTimeErrB;
          tTempPWMHighMinDefault = TempPWMHighMinDefaultB;
          tTempPWMHighMaxDefault = TempPWMHighMaxDefaultB;
          tTempPWMHighMinAline = TempPWMHighMinAlineB;
          tTempPWMHighMaxAline = TempPWMHighMaxAlineB;
          tTempPWMHighMinONAline = TempPWMHighMinONAlineB;
          tTempPWMINHighMinFilt = TempPWMINHighMinFiltB;
          tTempPWMINHighMaxFilt = TempPWMINHighMaxFiltB;
        }
        else if(PWMINCtl.PWMINSelfCheck <= -3)
        {
          PWMINCtl.PWMINSelfCheck = -3;
          PWMINCtl.PWMStatus = 0xFF;

          tTempMotorBreakTime = TempMotorBreakTimeA;
          tTempMotorONTimeErr = TempMotorONTimeErrA;
          tTempMotorOFFTimeErr = TempMotorOFFTimeErrA;
          tTempPWMHighMinDefault = TempPWMHighMinDefaultA;
          tTempPWMHighMaxDefault = TempPWMHighMaxDefaultA;
          tTempPWMHighMinAline = TempPWMHighMinAlineA;
          tTempPWMHighMaxAline = TempPWMHighMaxAlineA;
          tTempPWMHighMinONAline = TempPWMHighMinONAlineA;
          tTempPWMINHighMinFilt = TempPWMINHighMinFiltA;
          tTempPWMINHighMaxFilt = TempPWMINHighMaxFiltA;
        }
      }
    }

    if((TIM3_DR > tTempPWMINHighMinFilt)&&(TIM3_DR < tTempPWMINHighMaxFilt))  //PPM ������������Χ��
    {
      tPWMINOutRangeCounter = 0;
      tPWMINErrCotnter = 0;       //���Żָ���������
      
      PWMINCtl.PWMINHigh = TIM3_DR;
      if(TIM3_DR > PWMINCtl.PWMINHighErr)                    //PPM ���ȴ�����С����
      {            
        if(TIM3_DR <= PWMINCtl.PWMINHighMax)                 //PPM ����С��������
        {
          tPWMINHigh = TIM3_DR - PWMINCtl.PWMINHighErr;
          Temp32A = (u32)tPWMINHigh<<15;
          Temp32B = (u32)PWMINCtl.PWMINHighMax - PWMINCtl.PWMINHighErr;
          MDUControl.SpeedSref = MDU_DIV_U16(&Temp32A,&Temp32B); //(0~32767)

          if(Ctl.State == MOTOR_NORMAL)
          {
            //������PWM�ź� ֱ�Ӹ�DR
            //MDUAPP();
            if(MDUControl.SpeedSref > MDUControl.AlineX1) //y = A*x + B ;
            {  
              MDUControl.TargetSpeed = MDU_MULA_U16(MDUControl.SpeedSref,MDUControl.AlineA,15) + MDUControl.AlineB;
            }
            //MDUControl.FlagTargetSpeed = 0xFF;
            
            Drv.PWM.DutytargetOpen = MDUControl.TargetSpeed;            //MDU�����ٶȸ���ֵ
            Drv.PWM.Dutytarget = Drv.PWM.DutytargetOpen;
            //MDUControl.FlagTargetSpeed = 0x7F ;                       //�ٶȸ����������� 
            
            Drv.PWM.DutyCurrent = Drv_DutyRampCale(Drv.PWM.Dutytarget); //�ٶȿ����Ӽ�������
            Drv.PWM.u16cycle = Fu68xx_PWM_Update(Drv.PWM.DutyCurrent);  //ռ�ձȸ���
            TIM2_DR = MDU_MULA_U16(MDUControl.DutyCurrent,PWMARR,15);
          }
        }
        else   //PPM ���ȴ���������
        {
          MDUControl.SpeedSref = 32767;  
          //MDUControl.FlagTargetSpeed = 0x7F ;              
          Drv.PWM.DutytargetOpen = 32767;//MDUControl.TargetSpeed;     
        }
      }
    }
    else
    {
      tPWMINOutRangeCounter++;    
      if((tPWMINOutRangeCounter >= 100)&&(tPWMINErrCotnter >= 1000)) //50*2.73 = 136
      {
        Ctl.SysError = E_ERR3;
        tPWMINOutRangeCounter = 100;
        PWMINCtl.PWMINHigh = 0;
      }
    }
    #endif
    CLRFlag_T3IR;
  }
  if(GetBit(TIM3_CR1, T3IP))
  {
    CLRFlag_T3IP;
  }
  if(GetBit(TIM3_CR1, T3IF))
  {
    #if((PWMINSREF_EN)||(PWMINONOFF_EN))
    tPWMINTim3ITconter++;
    if((tPWMINTim3ITconter >= 100)&&(tPWMINErrCotnter >= 1000))  //50*2.73 = 136
    {
      Ctl.SysError = E_ERR2;
      tPWMINTim3ITconter = 100;
      PWMINCtl.PWMINHigh = 0;
    }
    #endif
    CLRFlag_T3IF;
  }  
}

/*-------------------------------------------------------------------------------------------------
Function Name :	void PWMINOnOffSwitch(void)
Description   :  С��900us ɲ��  С��920us ͣ�� ����920us ~2000us ����
Input         :	��
Output				:	��
-------------------------------------------------------------------------------------------------*/

void PWMINOnOffSwitch(void)
{
  float tfAlineA;
  #if(PWMINSREF_EN)
  if(PWMINCtl.FlagPwmIn == 0xF1)  //�ϵ����ű�����������У׼ ������Ϣ��ȡ
  {
    if(PWMINCtl.PWMINHigh == 0) //���ű���
    { 
      BeepRequestFun(PWMINError);
      PWMINCtl.FlagPwmIn = 0xF1;
    }
    else if(PWMINCtl.PWMINHigh > tTempPWMHighMaxAline) //����У׼����A
    {
      #if(PWMINALINE_EN)
      PWMINCtl.FlagPwmIn = 0xF1;
      PWMINCtl.PWMINCnt ++;
      if(PWMINCtl.PWMINCnt > 3000)
      {
        PWMINCtl.PWMINCnt = 3000;	
        if(PWMINCtl.FlagPWMAline == 0x7F)
        {
          PWMINCtl.PWMINHighMax = PWMINCtl.PWMINHigh - 20; //�������ֵ��ȥ 30
          BeepRequestFun(PWMINAline);
        }
      }
      #else
      PWMINCtl.PWMINCnt = 0;
      PWMINCtl.FlagPwmIn = 0xF1;
      if(PWMINCtl.FlagPWMAline = 0x7F)
      {
        BeepRequestFun(PWMINError);
      }      
      #endif
    }
    else if(PWMINCtl.PWMINHigh < tTempPWMHighMinAline) //����У׼����B
    {
      PWMINCtl.FlagPwmIn = 0xF1;
      PWMINCtl.PWMINCnt --;
      
      if(Beep.BeepType != PWMINReady)
      {
        if(PWMINCtl.PWMINCnt < -100)
        {
          PWMINCtl.PWMINCnt = -100;
          #if(PWMINALINE_EN)
          if(PWMINCtl.FlagPWMAline == 0xFF)
          {
            PWMINCtl.PWMINHighMin = PWMINCtl.PWMINHigh;
            while(Flash_Sector_Erase((uint8 xdata *)16128)); // ��д��126������16128~16255��
            while(Flash_Sector_Write((uint8 xdata *)16128, PWMINCtl.PWMINHighMin)); // д��С���ŵ��ֽ�
            while(Flash_Sector_Write((uint8 xdata *)16129, (PWMINCtl.PWMINHighMin >> 8))); // д������Ÿ��ֽ�
            while(Flash_Sector_Write((uint8 xdata *)16130, PWMINCtl.PWMINHighMax)); // д������ŵ��ֽ�
            while(Flash_Sector_Write((uint8 xdata *)16131, (PWMINCtl.PWMINHighMax >> 8))); // д������Ÿ��ֽ�
          }
          PWMINCtl.PWMINHighMin = ((*(unsigned char code *)16129)<<8) + (*(unsigned char code *)16128);
          PWMINCtl.PWMINHighMax = ((*(unsigned char code *)16131)<<8) + (*(unsigned char code *)16130);
          #endif 

          if(!(PWMINCtl.PWMINHighMin && PWMINCtl.PWMINHighMax))
          {
            PWMINCtl.PWMINHighMin = tTempPWMHighMinDefault;
            PWMINCtl.PWMINHighMax = tTempPWMHighMaxDefault; 
          }
        
          PWMINCtl.PWMINHighErr = PWMINCtl.PWMINHighMin + tTempMotorONTimeErr;
          
          MDUControl.AlineX2 = 32767;
          MDUControl.AlineX1 = 0;

          MDUControl.SpeedSrefErr = MDUControl.AlineX2 - MDUControl.AlineX1; ;

          tfAlineA = ((float)(SPEED_REF_MAX-SPEED_REF_MIN)/(MDUControl.SpeedSrefErr));
          if(tfAlineA > 2.0)
          {
            tfAlineA = 1.9999;
          }
          MDUControl.AlineA = (u16)(tfAlineA*32767);
          MDUControl.AlineB = (SPEED_REF_MAX - MDUControl.AlineX2*tfAlineA);

          BeepRequestFun(PWMINReady);
        }
      }
    }
    else                        //���ű���
    {
      PWMINCtl.PWMINCnt = 0;
      PWMINCtl.FlagPwmIn = 0xF1;
      if(PWMINCtl.FlagPWMAline == 0x7F)
      {
        BeepRequestFun(PWMINError);
      }
    }
  }
  else                          //PWMIN�ϵ�У׼���
  {
    if(PWMINCtl.PWMINHigh == 0) //
    {
      //PwmInResetFlag = 0x7F;
      Uc.flg.START = FALSE;
      //BeepRequestFun(PWMINError);
    }
    else if(PWMINCtl.PWMINHigh <= (PWMINCtl.PWMINHighMin + tTempMotorOFFTimeErr))
    {
      PWMINCtl.PWMINCnt --;
      if(PWMINCtl.PWMINCnt < -5)
      {
        PWMINCtl.PWMINCnt = -5;

        PwmInResetFlag = 0x7F;
        Uc.flg.START = FALSE;
        
        if(Ctl.SysError != NONE)
        {
          Ctl.SysError = NONE;        //�������
          Ctl.State = MOTOR_STOP; 
          DRV_OE_ON;
        }        
      }
//      if(PWMINCtl.PWMINHigh <= (PWMINCtl.PWMINHighMin + TempMotorBreakTime))    //ɲ���ж�
//      {
//        PWMINCtl.PWMINBreakCnt++;
//        if(PWMINCtl.PWMINBreakCnt > 100)
//        {
//          PWMINCtl.PWMINBreakCnt = 100;
//          PwmInResetFlag = 0x7F;
//          //Ctl.FnStopmodeC = BREAK_DOWN;
//        }
//      }
//      else
//      {
//        PWMINCtl.PWMINBreakCnt--;
//        if(PWMINCtl.PWMINBreakCnt < -100)
//        {
//          PWMINCtl.PWMINBreakCnt = -100;
//          //Ctl.FnStopmodeC = FREE_DOWN;
//        }
//      }
    }
    else if(PWMINCtl.PWMINHigh > (PWMINCtl.PWMINHighMin + tTempMotorONTimeErr))
    {
      PWMINCtl.PWMINCnt++;
      if(PWMINCtl.PWMINCnt > 100)
      {
        PWMINCtl.PWMINCnt = 100;
        if((PwmInResetFlag == 0X7F)&&(Uc.flg.START == FALSE)) 
        {
          Beep.BeepRequest = 0xFF;

          Uc.flg.START = TRUE;
          PwmInResetFlag = 0XFF;
        }
      }
    }
  }
  #endif
}