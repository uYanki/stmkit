
/************************ (C) COPYRIGHT 2017 FT *******************************
* File Name          : 
* Author             : 
* Version            : V2.0.0
* Date               : 05/15/2017
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>

/** @addtogroup FT68xx
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
Power_TypeDef xdata Power;  

s16 xdata F_OverLoadCounter;
u8 xdata  F_OverLoadFlag;    
/* Private function prototypes -----------------------------------------------*/
u32 Drv_RotorCircleNumCalc(u8 value);       //����Ȧ������
void MCL_OverLoadInit(u16 OL0A,u16 OL1A,u16 OL2A,u16 OL3A,u32 OL0ms,u32 OL1ms,u32 OL2ms,u32 OL3ms);
u8 MCL_OverLoadCalc(u16 Ibus);              //���ؼ���

void Mcl_MotorRestart(void);                //�������
u8 Mcl_StallRestart(void);                  //��ת����
void Mcl_NoloadCale(void);                  //�����ж�
void Drv_PowerClosedCalc(void);             //--

/* Private functions ---------------------------------------------------------*/


/*******************************************************************************
* Function Name  : MCL_OverLoadInit    //���� 
* Description    : �¶�200-> 20��  
* Input          : PTC�¶�
* Output         : None
* Return         : ADC�ɼ�ֵ
*******************************************************************************/

#if(OVERLOAD_EN)
void MCL_OverLoadInit(u16 OL0A,u16 OL1A,u16 OL2A,u16 OL3A,
                      u32 OL0ms,u32 OL1ms,u32 OL2ms,u32 OL3ms)
  {
    Ctl.OL.Value = 0x7F; 
    Ctl.OL.Group[0].Current = OL0A;
    Ctl.OL.Group[1].Current = OL1A;
    Ctl.OL.Group[2].Current = OL2A;
    Ctl.OL.Group[3].Current = OL3A;

    Ctl.OL.Group[0].Nms = OL0ms;
    Ctl.OL.Group[1].Nms = OL1ms;
    Ctl.OL.Group[2].Nms = OL2ms;
    Ctl.OL.Group[3].Nms = OL3ms;
      
    Ctl.OL.Group[0].msCounter = 0;
    Ctl.OL.Group[1].msCounter = 0;
    Ctl.OL.Group[2].msCounter = 0;
    Ctl.OL.Group[3].msCounter = 0;
    
    Ctl.OL.Group[0].flg = 0;
    Ctl.OL.Group[1].flg = 0;
    Ctl.OL.Group[2].flg = 0;
    Ctl.OL.Group[3].flg = 0;
  }
#endif


 /******************************************************************************* 
* Function Name  : MCL_OverLoadCalc 
* Author         : wangt  
* Description     
* Input          : None 
* Output         : None 
* Return         : 
*******************************************************************************/  
#if(OVERLOAD_EN) 
u8 MCL_OverLoadCalc(u16 Ibus)   
  { 
    u16 tIbus = 0;    //�������ֵ
    tIbus = Ibus;

    if((Ctl.OL.msFlag == 0x7F)&&(Ctl.OL.Value == 0x7F)&&(Ctl.State == MOTOR_NORMAL))
      {
        if(tIbus >= Ctl.OL.Group[0].Current)    
          {  
             Ctl.OL.Group[0].msCounter++;
             if(tIbus >= Ctl.OL.Group[1].Current)  
             {
                 Ctl.OL.Group[0].msCounter++;
                 Ctl.OL.Group[1].msCounter++;
                 if(tIbus >= Ctl.OL.Group[2].Current) 
                 {
                     Ctl.OL.Group[0].msCounter++;
                     Ctl.OL.Group[1].msCounter++;
                     Ctl.OL.Group[2].msCounter++;
                     if(tIbus>=Ctl.OL.Group[3].Current) 
                     {  
                         Ctl.OL.Group[0].msCounter++;
                         Ctl.OL.Group[1].msCounter++;
                         Ctl.OL.Group[2].msCounter++;
                         Ctl.OL.Group[3].msCounter++;
                     }
                     else
                     {
                        Ctl.OL.Group[3].msCounter--;  
                     }
                 }
                 else
                 {
                     Ctl.OL.Group[2].msCounter--;  
                     Ctl.OL.Group[3].msCounter--;  
                 }
             }
             else
             {
                 Ctl.OL.Group[1].msCounter--;  
                 Ctl.OL.Group[2].msCounter--;  
                 Ctl.OL.Group[3].msCounter--;                
             }
          }
          else
          {   
             Ctl.OL.Group[0].msCounter--; 
             Ctl.OL.Group[1].msCounter--;  
             Ctl.OL.Group[2].msCounter--;  
             Ctl.OL.Group[3].msCounter--;  
          } 
       if(Ctl.OL.Group[0].msCounter >= Ctl.OL.Group[0].Nms) 
       {
         Ctl.OL.Group[0].flg = TRUE;
         Ctl.OL.Value = 0xF0; 
       }
       if(Ctl.OL.Group[1].msCounter >= Ctl.OL.Group[1].Nms)
       {
         Ctl.OL.Group[1].flg = TRUE; 
         Ctl.OL.Value = 0xF1; 
       }
       if(Ctl.OL.Group[2].msCounter >= Ctl.OL.Group[2].Nms)
       {
         Ctl.OL.Group[2].flg = TRUE; 
         Ctl.OL.Value = 0xF2; 
       }
       if(Ctl.OL.Group[3].msCounter >= Ctl.OL.Group[3].Nms)
       {
         Ctl.OL.Group[3].flg = TRUE;  
         Ctl.OL.Value = 0xF3; 
       }
       
       if(Ctl.OL.Group[0].msCounter<-100)
       {
         Ctl.OL.Group[0].msCounter = -100; 
       }
       if(Ctl.OL.Group[1].msCounter<-100)
       {
         Ctl.OL.Group[1].msCounter = -100;  
       }
       if(Ctl.OL.Group[2].msCounter<-100)
       {
         Ctl.OL.Group[2].msCounter = -100;  
       }
       if(Ctl.OL.Group[3].msCounter<-100)
       {
         Ctl.OL.Group[3].msCounter = -100;  
       }

       Ctl.OL.msFlag = 0;
      }   
    return Ctl.OL.Value; 
  } 
#endif

/*******************************************************************************
* Function Name  : Drv_RotorCircleNumCalc    
* Description    : 
* Input          : �������Ȧ������
* Output         : None
* Return         : 
*******************************************************************************/
#if(F_MOTORCIRCLECALEEN)
u32 Drv_RotorCircleNumCalc(u8 value)   //Ctl.Step
{  
  s32 CircleNum;        
  s8 StepERR; 
  Ctl.spd.RotorPosition = value;

  StepERR = Ctl.spd.RotorPosition - Ctl.spd.RotorPositionqPre;
  if(StepERR == 5)
  {
    StepERR = -1;
  }
  else if(StepERR == -5)
  {
    StepERR = 1;
  }
  if(StepERR  == -1) 
  {
    Ctl.spd.ComNum--;
  }    
  else if(StepERR == 1)
  {
    Ctl.spd.ComNum++;
  }    

  Ctl.spd.RotorPositionqPre = Ctl.spd.RotorPosition; 

  //Ctl.spd.MechCircleNum =  Ctl.spd.ComNum/(6*Ctl.Motor.PolePairs);  
  
  return CircleNum;  
}
#endif

/*******************************************************************************
* Function Name  : Mcl_MotorRestart    
* Description    : ������������
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void Mcl_MotorRestart(void)
{
  DRV_OE_ON;
  Ctl.SysError = NONE;     
  Ctl.State = MOTOR_READY;
}

/*******************************************************************************
* Function Name  : Mcl_StallRestart    
* Description    : ��ת����
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
u8 Mcl_StallRestart(void)             //��ת����
{
  #if (STALLRESTARTNUM != 255)
  if(Ctl.Stall.u8Num < STALLRESTARTNUM)
  #endif
  {
    Ctl.Stall.u8Num++;
    Ctl.Tim.STAnms = 0;
    Ctl.Tim.STB1nms = 0;
    Ctl.Tim.STB2nms = 0;
    Ctl.Stall.u8FL = 0;
    DRV_OE_ON;
    Ctl.SysError = NONE;
    if(Ctl.Stall.u16NormalRunms < STANMS+500)
    {
      Ctl.State = MOTOR_STOP;
    }
    else
    {
      Ctl.State = MOTOR_READY;
    }
  }
  return 1;
}

/*******************************************************************************
* Function Name  : Mcl_NoloadCale    
* Description    : ��������ж�
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void Mcl_NoloadCale(void)            
{
//  #if(NOLOAD_EN)
//  if(Ctl.Noload.Counter > NOLOADNUM)
//  {
//     if(Ctl.Noload.Counter > (NOLOADNUM))
//     {
//       Ctl.Noload.Counter = (NOLOADNUM);
//     }
//     Ctl.Noload.Flag = 0X7F;
//  }
//  else
//  {
//    Ctl.Noload.Flag = 0XFF;
//  }
//  #endif
}


/*******************************************************************************
* Function Name  : Drv_PowerClosedCalc
* Description    : ���Գ���
* Input          : 
* Output         : None
* Return         : 
*******************************************************************************/
void Drv_PowerClosedCalc(void)
{
  Power.err = Power.ref - Power.fdb;
  if(Power.err > 0)  
  {
    Drv.PWM.DutytargetOpen += 20;
  }
  else
  {
    Drv.PWM.DutytargetOpen -= 20;
  }  
}

