
/************************ (C) COPYRIGHT 2017 FT *******************************
* File Name          : 
* Author             : 
* Version            : V2.0.0
* Date               : 05/15/2017
* Description        : 
********************************************************************************
/*******************************************************************************
* All Rights Reserved
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>

/** @addtogroup FT68xx
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
Uc_TypeDef xdata Uc;                  //��������
float xdata tSpeedShiftcoefficient;   //�ٶ�ϵ��
s16 xdata tChipIDLEConter;            //�͹���
u8 xdata tSpeedShift;                 //0X01 0X02 0X03  ����λ
u8 xdata tAutoStop;                   //0x10 ����ͣ��ģʽ 0x20 ��ͣ��ģʽ
u32 xdata gONOFFconuter;          //��ͣ����ʹ��
extern s16 xdata F_OverLoadCounter;
extern u8 xdata F_OverLoadFlag; 
extern u8 xdata u8KeyForbid;         //������ֹ��־
u16 xdata gLoadFlag= 0;    
u16 xdata COUNT_NUMER = 0;
u16 xdata DIANLIU_TIME;
s16 xdata DIANLIU_TIME2 = 0; 
extern  u16 xdata MechCircleNum_count;
extern  u8 temperature_flage;
u8 xdata tSpeedShift;                 //0X01 0X02 0X03  ����λ
u8 xdata tAutoStop;                   //0x10 ����ͣ��ģʽ 0x20 ��ͣ��ģʽ
extern  u8 temperature_flage;
u8 xdata tAutoStop2 = 0;
u8 xdata  SpeedShift2 = 0;
u8 xdata OFFflag;
extern u8 xdata OFFtime;
extern int16 xdata IBusAvgMeas;
/* Private function prototypes -----------------------------------------------*/
void UI(void);         //ȫ�ֺ���  ����

/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : UI
* Description    : a������ָʾ���¶ȼ��㡢ADCת�����ٶ�ʵ��ֵ���� 
                   b������ת����������ٶ��������
                   c������ִ��
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UI(void)        //��������
{   
 if(((tAutoStop != tAutoStop2)||(Ctl.spd.SpeedShift != SpeedShift2))&&(Uc.flg.START == FALSE))
 {

	EA = 0;
	Rom.WriteValue = (u8)Ctl.spd.SpeedShift+(u8)tAutoStop;
	Rom.ReadValue = Flash_GetAddress();     //��
	Flash_ErasePageRom();                  //��
	Flash_KeyWriteValue((Rom.WriteValue));  //д
	EA = 1;

 }
 
   Rom.ReadValue = Flash_GetAddress();    //4.88ms 
   Rom.WriteValue = Rom.ReadValue;
  if(Rom.WriteValue == 0x7F)
  {
	  Ctl.spd.SpeedShift = 2;
    tAutoStop = 0x10;                    //�綯��������ͣ����
  }
  else
  {
	  tAutoStop = Rom.WriteValue&0x30; 
    Ctl.spd.SpeedShift = Rom.WriteValue&0x03;
    if((Ctl.spd.SpeedShift == 0)||(Ctl.spd.SpeedShift > 3))
    {
     Ctl.spd.SpeedShift  = 2;
    }
    if((tAutoStop == 0x00)||(tAutoStop > 0x30))
    {
      tAutoStop = 0x10;
    }
  }

	 SpeedShift2 = Ctl.spd.SpeedShift;
	 tAutoStop2  = tAutoStop;	
	
	
//-----------------------------------------
//hall��ȡ
  //Drv.Hall.Status = Hall_IRQHandler();
  
//-----------------------------------------
//����ָʾ
  Fault_Led(Ctl.SysError);
  
//-----------------------------------------
//��λָʾ��������ʾ
  LED_show();
  
//-----------------------------------------
//ADCʵ��ֵת��
  ADCGetConversionValue();

//-----------------------------------------  
//ʵ��ת�� rpm 
#if (SPEED_CALC_EN == 2)
  MDUControl.FlagCalcSpeedRpm = 0x7F;    
#endif
//-----------------------------------------
//�����ж�
#if(OVERLOAD_EN) 
  Ctl.OL.Value = MCL_OverLoadCalc(IBusAvgMeas);
#endif
  
  //Mcl_NoloadCale();//�жϵ���Ƿ����   Ctl.Noload.Flag = 0x7F ���� OXFF����
#if(BEEPSCAN_EN)
  BeepResponse();
#endif
//=====================================================
//���ػ� ����  �ٶȸ��� ����ת����
//-----------------------------------------------------
//ON/OFF ����ģʽ
#if(0)
  if((Ctl.Tim.OnOffnms < 300))   
  {
    Uc.flg.START = FALSE;
    
    Ctl.SysError = NONE;  //�������
    DRV_OE_ON;
    Ctl.State = MOTOR_STOP; 
  }
  else if (Ctl.Tim.OnOffnms < 1000)
  {
    if((Ctl.SysError == NONE)&&(Uc.flg.START == FALSE))
    {
      Uc.flg.START = TRUE;
    }
  }     
  else
  {
    Ctl.Tim.OnOffnms = 0; 
  }
  #endif
//=====================================================
//---------------------------------------------------
//����ת����λ�������
//Xn�����������  -> ����ִ�� �ᴥ�Ϳ���
//Xn�����������  -> ����ִ�� ����������
#if(1)
  if(X0.XCount == -KEY_FILTERCOUNT)
  { 
    Uc.flg.FR = CW;
  }
  else if(X0.XCount == KEY_FILTERCOUNT)
  {
    Uc.flg.FR = CCW;          //��ת��ж��˿
  }
#endif

#if(1)
 if(Uc.flg.FR == CW)
  {
    if((X3.Kflg == TRUE)&&(Uc.flg.START == FALSE))
    {
      X3.Kflg = FALSE;
      X3.KNum = FALSE;
      Ctl.spd.SpeedShift++;

     if(Ctl.spd.SpeedShift > 2)
      {
        Ctl.spd.SpeedShift = 1;
      }
    }

    if(Ctl.spd.SpeedShift == 1)
    {
      tSpeedShiftcoefficient = 0.85;
    }
    else if(Ctl.spd.SpeedShift == 2)
    {
      tSpeedShiftcoefficient =1.0;
    }
  }
  else if(Uc.flg.FR == CCW)
  {
    tSpeedShiftcoefficient = 1.0;
    if((X3.Kflg == TRUE)&&(Uc.flg.START == FALSE))
    {
      X3.Kflg = FALSE;
      X3.KNum = FALSE;

      if(tAutoStop != 0x20)
      {
        tAutoStop = 0x20;
      }
      else
      {
        tAutoStop = 0x10;
      }
    }
  }

#endif

//---------------------------------------------------
//����������� ADC������������������������
//Xn�����������  -> ����ִ�� �ᴥ�Ϳ���
#if (KEYONOFF_EN == 1) 
  if(X2.Kflg == TRUE)
  {
    X2.Kflg = FALSE;
    X2.KNum = FALSE;
    
    if(Uc.flg.START == TRUE)
    {
      Uc.flg.START = FALSE;
    }
    else
    {
      Uc.flg.START = TRUE;
    }      
  }
#elif (KEYONOFF_EN == 2)
  if(X0.XCount == KEY_FILTERCOUNT)
  { 
    Uc.flg.START = TRUE;
    tChipIDLEConter = 0;
  }
  else if(X0.XCount == -KEY_FILTERCOUNT)
  {
    Uc.flg.START = FALSE;
//    if(tChipIDLEConter >= 5000)        //5������͹���ģʽ оƬ˯�ߵ���1mA ��˯��9mA
//    {                                  //�ⲿ�жϻ���˯��ģʽ ��Ҫ���ⲿ�ж�
//      tChipIDLEConter = 5000;
//      SetBit(PCON, STOP, 1);           //оƬ����
//    }
  }
#elif(ADCONOFF_EN)
  if((Drv.AdcMeas.Sref > ADCREFONVALUE)&&(Drv.AdcMeas.Vdc > 15.0)&&(temperature_flage == 1))
  {
    Ctl.spd.SwitchCount++;
  }
  else if(Drv.AdcMeas.Sref < ADCREFOFFVALUE)
  {
    Ctl.spd.SwitchCount--;
  }
	
	
  if(Ctl.spd.SwitchCount > SREFCOUNT)
  {
    Ctl.spd.SwitchCount = SREFCOUNT;
    if(tAutoStop == 0x20)
    {
      if((COUNT_NUMER == 1)||(MechCircleNum_count == 1))
      {
        Uc.flg.START = FALSE;
      }
      else
      {
        if (OFFtime >= 100)
        {
          Uc.flg.START = TRUE;
          OFFflag = 0;
          OFFtime = 0;
        }
      }
    } 
    else
    {
      if (OFFtime >= 100)
      {
        Uc.flg.START = TRUE;
        OFFflag = 0;
        OFFtime = 0;
      }
    }
  }
  else if(Ctl.spd.SwitchCount < -SREFCOUNT) 
  {
    OFFflag = 1;
    Ctl.spd.SwitchCount = -SREFCOUNT;
    Uc.flg.START = FALSE;
    Ctl.spd.MechCircleNum = 0;
    Ctl.SysError = NONE;  //�������
    Ctl.State = MOTOR_STOP; 
    DRV_OE_ON;
    COUNT_NUMER = 0;
    DIANLIU_TIME = 100;
    gLoadFlag = 0;
    DIANLIU_TIME2 = 0;
    Ctl.spd.ComNum  = 0;
    MechCircleNum_count = 0;
  }  
#endif

//============================================================
//�ٶȸ���
#if(PWMINSREF_EN)                          //PWMIN ����
  //MDUControl.FlagTargetSpeed = 0x7F ;    //�ٶȸ�����������          
  if(giEventCounter < 30)
  {
    Drv.PWM.DutyIncValue = 100;
    Drv.PWM.DutyDecValue = 100;
  }
  else 
  {
    Drv.PWM.DutyIncValue = SPEED_INCVALUE;
    Drv.PWM.DutyDecValue = SPEED_DECVALUE;
  }
  
#elif(ADCSREF_EN) //ADC ����
  MDUControl.FlagTargetSpeed = 0x7F ;     //�ٶȸ����������� 
  MDUControl.SpeedSref = Drv.AdcMeas.Sref*tSpeedShiftcoefficient;
  if((tAutoStop == 0x20)&&(Uc.flg.FR == CCW))
	  {
			MDUControl.SpeedSref = 32766;
    }		
  Ctl.spd.refTar = MDUControl.TargetSpeed;
  Drv.PWM.DutytargetOpen = MDUControl.TargetSpeed;
#endif

#if(SPEED_CLOSE_EN) //�ٶȱջ�����
  if(Ctl.spd.refTar > SPEED_INMAX)
  {
    Ctl.spd.refTar = SPEED_INMAX;
  }
#endif

//=====================================================
//��HALL ����޷� �Ƚ�������ģʽ
#if (POSITION_FB_MODE == SENSORLESS)
  
      if(Drv.PWM.DutytargetOpen < Ctl.Ramp.cpDutyEnd)
      {
        Drv.PWM.DutytargetOpen = Ctl.Ramp.cpDutyEnd;
      }

  #if (CMPSAME_EN == 1) 
    SetBit(CMP_CR2, CMPSAME, 1);
  #elif (CMPSAME_EN == 2)
    if((Drv.PWM.DutyCurrent > CMPSAMESWITCH)||(Ctl.State <= MOTOR_STRACK))
    {
      SetBit(CMP_CR2, CMPSAME, 0);
    }
    else
    {
      SetBit(CMP_CR2, CMPSAME, 1);
    }
  #endif

  if(Ctl.State == MOTOR_NORMAL)
  {
    Drv.PWM.Dutytarget = Drv.PWM.DutytargetOpen;
  }
#else
  Drv.PWM.Dutytarget = Drv.PWM.DutytargetOpen;
#endif
  
//-----------------------------------------
//����ִ��
  if((Uc.flg.START == TRUE)&&(Uc.flg.FR != NONE))  
  {
    Ctl.gStart = TRUE;
    Ctl.Tim.NoOperationDelaynms = 0;
  } 
  else if(Uc.flg.START == FALSE)
  {                   
    if(Ctl.gStopmodeC == FREE_DOWN)
    {
      Ctl.gStart = FALSE;
    }
    else if(Ctl.gStopmodeC == SLOWING_DOWN)
    {
      Ctl.spd.refTar = 0;
      Drv.PWM.DutytargetOpen = 0;
      if(Ctl.State == MOTOR_NORMAL)
      {
        #if(SPEED_CLOSE_EN)
        if(((Ctl.spd.refCur<_IQ(0.05))))
        {
          Ctl.gStart = FALSE;
        }      
        #else
        if((Drv.PWM.DutyCurrent < _IQ(0.05)))
        {
          Ctl.gStart = FALSE;
        }      
        #endif
      }
      else
      {
        Ctl.gStart = FALSE;
      }
    } 
    else if(Ctl.gStopmodeC == BREAK_DOWN)
    {
      Ctl.gStart = FALSE;
    }      
  }
}


