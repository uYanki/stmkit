/**************************** (C) COPYRIGHT 2015 Fortiortech shenzhen *****************************
* File Name          : GPIOInit.h
* Author             : Fortiortech  Market Dept
* Version            : V1.0
* Date               : 01/07/2015
* Description        : This file contains all the common data types used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/ 

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __GPIOINIT_H_
#define __GPIOINIT_H_


//#define SPIncPin        GP00
#define ONOFFPin        GP00

#define SPDecPin        GP02
#define FRPin						GP03


#define LEDPin			 		GP36
#define SetLEDPin				{GP36 = 1;}
#define ResetLEDPin			{GP36 = 0;}
#define LEDPinONOFF			{GP36 = ~GP36;}


#define FGPin 				  GP07
#define SetFGPin			  {GP07 = 1;}
#define ResetFGPin		  {GP07 = 0;}
#define FGPinONOFF      {GP07 = ~GP07;}
																				
/* Exported functions ---------------------------------------------------------------------------*/
extern void GPIO_Init(void);

#endif