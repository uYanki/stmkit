#ifndef __LPFINIT_H_
#define __LPFINTI_H_

extern uint16 LPF(uint16 Xn1, uint16 Xn0, uint16 K);


#endif