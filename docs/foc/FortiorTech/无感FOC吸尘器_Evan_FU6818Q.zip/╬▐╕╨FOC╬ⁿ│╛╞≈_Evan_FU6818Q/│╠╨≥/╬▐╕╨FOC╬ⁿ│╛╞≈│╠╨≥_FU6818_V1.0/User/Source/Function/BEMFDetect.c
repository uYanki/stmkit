/**************************** (C) COPYRIGHT 2015 Fortiortech shenzhen *****************************
* File Name          : BEMFDetect.c
* Author             : Glen.ZHU
* Version            : V1.0
* Date               : 01/07/2015
* Description        : This file contains main function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/ 


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx.h>
#include <Myproject.h>

/* Private typedef ------------------------------------------------------------------------------*/
/* Private define -------------------------------------------------------------------------------*/
/* Private macro --------------------------------------------------------------------------------*/
/* Private variables ----------------------------------------------------------------------------*/

/* Private function prototypes ------------------------------------------------------------------*/
/* Private functions ----------------------------------------------------------------------------*/

BEMFDetect_TypeDef BEMFDetect;


void BEMFDetectInit(void)
{	
	if(MotorStateTime.TailWindOneTime == 0)
	{	
		MotorStateTime.TailWindOneTime =1;
		//BEMF���ǰ�ر�mos���
		MOE = 0;
		
		BEMFDetect.BEMFStartStatus =0;
		BEMFDetect.FlagSpeedCal =0;
		BEMFDetect.BEMFSpeedInitStatus =0;
		BEMFDetect.FRStatus = mcFRState.FR;
		BEMFDetect.BEMFStatus = 0;
		BEMFDetect.BEMFSpeedBase =0;
		BEMFDetect.BEMFSpeed =0;
		
		BEMFDetect.BEMFTimeCount = BEMF_START_DETECT_TIME;
		
		//ʹ���˷�
		SetBit(CMP_CR2, CMP0EN, 1);
		SetBit(CMP_CR2, CMP1EN, 1);
		SetBit(CMP_CR2, CMP2EN, 1);
	}
}

uint8	GetBEMFStatus(void)
{
	uint8 BEMFStatus = 0;

	if(GetBit(CMP_SR, CMP2OUT))
	{
		BEMFStatus += 4;

//		GP11= 1;
	}
	else
	{
//		GP11 = 0;
	}
	
	if(GetBit(CMP_SR, CMP1OUT))
	{
		BEMFStatus += 2;

//		GP00 = 1;
	}
	else
	{
//		GP00 = 0;
		
	}
	
	if(GetBit(CMP_SR, CMP0OUT))
	{
		BEMFStatus += 1;
		GP01 = 1;

	}
	else
	{
		GP01 = 0;
	}
	
	return BEMFStatus;
	
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	uint8 CWCCWDetect(void)
	Description   :	���ܺ����������ת�򣬸�����������Hall״̬˳�����жϵ��ת��
	Input         :	��
  Output				:	MC_FR--���ת��ȡֵΪCW��CCW
-------------------------------------------------------------------------------------------------*/
uint8 CWCCWDetect(uint8 HallStatus)
{
	static uint8 MC_FR = 0;
	static uint8 MC_HallStatus = 0;
	
	if(MC_HallStatus == 0)
	{
		MC_HallStatus = HallStatus;
		MC_FR = CW;
		return MC_FR;
	}
	
	if(MC_HallStatus != HallStatus)
	{
		switch(MC_HallStatus)
		{
			case 1:
				if(HallStatus == 5)
				{
					MC_FR = CW;
				}
//				if(HallStatus == 3)
//				{
//					MC_FR = CW;
//				}
				break;
			case 2:
				if(HallStatus == 3)
				{
					MC_FR = CW;
				}
//				if(HallStatus == 6)
//				{
//					MC_FR = CW;
//				}
				break;
			case 3:
				if(HallStatus == 1)
				{
					MC_FR = CW;
				}
//				if(HallStatus == 1)
//				{
//					MC_FR = CW;
//				}
				break;
			case 4:
				if(HallStatus == 6)
				{
					MC_FR = CW;
				}
//				if(HallStatus == 5)
//				{
//					MC_FR = CW;
//				}
				break;
			case 5:
				if(HallStatus == 4)
				{
					MC_FR = CW;
				}
//				if(HallStatus == 1)
//				{
//					MC_FR = CW;
//				}
				break;
			case 6:
				if(HallStatus == 2)
				{
					MC_FR = CW;
				}
//				if(HallStatus == 4)
//				{
//					MC_FR = CW;
//				}
				break;
			default:
				break;
		}
		MC_HallStatus = HallStatus;
	}
	return MC_FR;
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void SoftSwitchApp1(void)
	Description   :	���ܺ�����SoftSwitch���ƣ�������EXTI�жϷ��������       
	Input         :	��
  Output				:	��
-------------------------------------------------------------------------------------------------*/
void BEMFSpeedDetect(void)
{	
	if(BEMFDetect.BEMFSpeedInitStatus == 0)
	{
		BEMFDetect.BEMFSpeedInitStatus =1;
		BEMFDetect.PeriodTime = 0;
		BEMFDetect.MC_StepTime[0] = 0;
		BEMFDetect.MC_StepTime[1] = 0;
		BEMFDetect.MC_StepTime[2] = 0;
		BEMFDetect.MC_StepTime[3] = 0;
		BEMFDetect.MC_StepTime[4] = 0;
		BEMFDetect.MC_StepTime[5] = 0;
		BEMFDetect.BEMFStep =0;
		BEMFDetect.StepTime =0;
		BEMFDetect.FirstCycle =0;
	}
	else
	{	                     
		BEMFDetect.StepTime = TIM2_CNTR;                            		 
		TIM2_CNTR = 0;
		
		BEMFDetect.MC_StepTime[BEMFDetect.BEMFStep] = BEMFDetect.StepTime;
		
		BEMFDetect.PeriodTime = BEMFDetect.MC_StepTime[0] + BEMFDetect.MC_StepTime[1] + BEMFDetect.MC_StepTime[2] + 
														BEMFDetect.MC_StepTime[3] + BEMFDetect.MC_StepTime[4] + BEMFDetect.MC_StepTime[5];
		
		BEMFDetect.BEMFStep++;		
		
		if(BEMFDetect.FirstCycle)
		{
			BEMFDetect.FlagSpeedCal = 1;	
			BEMFDetect.BEMFSpeedBase = TempBEMFSpeedBase;
		}
		else
		{
			BEMFDetect.FlagSpeedCal = 1;		
			BEMFDetect.BEMFSpeedBase = TempBEMFSpeedBase1;
			BEMFDetect.PeriodTime = BEMFDetect.StepTime;
		}
		
		if(BEMFDetect.BEMFStep == 6)                                     
		{	
			BEMFDetect.FirstCycle = 1;		
			BEMFDetect.BEMFStep = 0;
		}
		
	}	
}

void BEMFSpeedCal(void)
{
	if(BEMFDetect.FlagSpeedCal)
	{								
		BEMFDetect.BEMFSpeed	= MDU_DIV_U16(&BEMFDetect.BEMFSpeedBase, &BEMFDetect.PeriodTime);		
		BEMFDetect.FlagSpeedCal = 0;
	}
}

void BEMFDetectFunc(void)
{
	if(GetBit(CMP_SR, CMP0INTR)||GetBit(CMP_SR, CMP1INTR)||GetBit(CMP_SR, CMP2INTR))
	{	
		
		BEMFDetect.BEMFSpeedFlag = 254;
		
		//��⵱ǰBEMF״̬
		BEMFDetect.BEMFStatus = GetBEMFStatus();
		
		//����BEMF״̬�ж�FR״̬
		BEMFDetect.FRStatus = CWCCWDetect(BEMFDetect.BEMFStatus);
		
		//�ٶȼ��
		BEMFSpeedDetect();
		
		//�ٶȼ���
		BEMFSpeedCal();
		
		//ǿ��������־ʹ��ʱ
		if(BEMFDetect.BEMFStartStatus)
		{
			//CWʱU��BEMF������������CCWʱV��BEMF����������
			if(((mcFRState.FR == CW)&&(BEMFDetect.BEMFStatus == 5))||((mcFRState.FR == CCW)&&(BEMFDetect.BEMFStatus == 3)))
			{
				//ִ��ֱ�ӱջ���������
				FOCCloseLoopStart();
				BEMFDetect.BEMFStartStatus =0;
			}
		}
		
		CLR(CMP_SR, CMP0INTR);		
		CLR(CMP_SR, CMP1INTR);	
		CLR(CMP_SR, CMP2INTR);			
	}
}
