#ifndef __FOCSPI_H_
#define __FOCSPI_H_


extern void FocSpi_Init(void);


#endif