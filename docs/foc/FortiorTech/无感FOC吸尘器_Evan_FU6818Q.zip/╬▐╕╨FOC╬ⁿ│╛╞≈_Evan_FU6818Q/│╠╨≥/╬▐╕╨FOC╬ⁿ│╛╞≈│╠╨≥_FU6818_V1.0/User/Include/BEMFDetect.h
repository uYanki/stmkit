#ifndef __BEMFDETECT_H_
#define __BEMFDETECT_H_


//���巴�����Ƿ���Ϊ˳��������
#define		BEMF_DETECT_ENABLE							(1)

//����ʹ��BEMF����ʱATO_BWֵ
#define 	ATO_BW_BEMF_START								600.0 	

#define 	OBSW_KP_GAIN_BEMF_START					_Q12(2*_2PI*ATT_COEF*ATO_BW_BEMF_START/BASE_FREQ)
#define 	OBSW_KI_GAIN_BEMF_START					_Q12(_2PI*ATO_BW_BEMF_START*ATO_BW_BEMF_START*TPWM_VALUE/BASE_FREQ)

//����ʹ��BEMF����ʱDKI QKIֵ
#define 	DKI_BEMF_START									_Q12(1.0)	
#define 	QKI_BEMF_START									_Q12(1.0)	

//����ʹ��BEMF�������ת��,ROM
#define		BEMFMotorStartSpeed							_Q15(400.0/MOTOR_SPEED_BASE) 	
#define		BEMFMotorStartSpeedHigh		  			_Q15(20000.0/MOTOR_SPEED_BASE) 	

//����ʹ��BEMF���ʱ��,ms
#define		BEMF_START_DETECT_TIME					(1500)

//����ʹ��BEMF���������ʱ,ms
#define		BEMF_START_DELAY_TIME						(20)

#define 	TempBEMFSpeedBase									(int32)(32767.0*(TIM2_Fre*60/Pole_Pairs/MOTOR_SPEED_BASE))
#define 	TempBEMFSpeedBase1								(int32)(32767.0/6.0*(TIM2_Fre*60/Pole_Pairs/MOTOR_SPEED_BASE))

typedef struct
{
	uint16	BEMFSpeed;
	uint32	BEMFSpeedBase;	
	
	uint8 	BEMFStatus;
	uint8		FRStatus;
	
	uint32	PeriodTime;					
	uint32	MC_StepTime[6];
	uint16	StepTime;
	uint8		FirstCycle;
	uint8		BEMFStep;
	uint8		BEMFSpeedInitStatus;
	uint8		FlagSpeedCal;
	
	uint8		BEMFStartStatus;
	uint16  BEMFTimeCount;
	uint8		BEMFSpeedFlag;
}BEMFDetect_TypeDef;


extern BEMFDetect_TypeDef BEMFDetect;

extern void BEMFSpeedDetect(void);
extern uint8 CWCCWDetect(uint8 HallStatus);
extern uint8 GetBEMFStatus(void);
extern void BEMFDetectInit(void);
extern void BEMFDetectFunc(void);
extern void BEMFSpeedCal(void);

#endif 