/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : AddFunction.c
* Author             : Fortiortech  Appliction Team
* Version            : V1.0
* Date               : 2017-12-26
* Description        : This file contains all the add function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
// #include <AddFunction.h>
#include <FU68xx_2.h>
#include <Myproject.h>

/* Private variables ---------------------------------------------------------*/
FaultStateType			       mcFaultSource;
PWMINPUTCAL        idata   mcPwmInput;
FaultVarible       idata   mcFaultDect;
MotorRSDTypeDef    idata   RSDDetect;
CurrentVarible     idata   mcCurVarible;
ProtectVarible     idata   mcProtectTime;

OUTLOOP						 xdata   SpeedPICtrl;
FOCCTRL            xdata   mcFocCtrl;
ADCSample          xdata   AdcSampleValue;
ONVarible          xdata   ONOFFTest;
MCLedDisplay       xdata   mcLedDisplay;
MCRAMP             xdata   mcSpeedRamp;
SLEEPMODE          xdata   SleepSet;
MotorFRTypeDef		 xdata   mcFRState;
MCLedD_TYPEDEF     xdata   mcLed;
int16 						 xdata   VSP;

const int16  PowerGiven[10] ={0,500,1000,2200,2900,4300,5900,7300,7900,8550};

/*---------------------------------------------------------------------------*/
/* Name     :   void OutLoopParameterSet(void)
/* Input    :   NO
/* Output   :   NO
/* Description: 
/*---------------------------------------------------------------------------*/
void OutLoopParameterSet(void)
{
	memset(&SpeedPICtrl,0, sizeof(OUTLOOP));																// SpeedControl clear

	mcFocCtrl.SpeedLoopTime = SPEED_LOOP_TIME;
	mcFocCtrl.SpeedRampTime = SPEEDRAMPTIME;
	
	mcSpeedRamp.IncValue		= SPEEDRAMPSTARTINC;
	mcSpeedRamp.DecValue		= SPEEDRAMPSTARTDEC;

	SpeedPICtrl.ExtKP 			= SKP;
	SpeedPICtrl.ExtKI 			= SKI;
	SpeedPICtrl.ExtOutMax 	= SOUTMAX;
	SpeedPICtrl.ExtOutMin 	= SOUTMIN;
	
	PI_KP 		= SpeedPICtrl.ExtKP;
	PI_KI 		= SpeedPICtrl.ExtKI;
	PI_UKMAX 	= SpeedPICtrl.ExtOutMax;
	PI_UKMIN 	= SpeedPICtrl.ExtOutMin;
	
	PI_UK			= IQ_RUN_CURRENT;
}
/*---------------------------------------------------------------------------*/
/* Name		:	int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
/* Input	:	INVlaue，OutLastValue
/* Output	:	int16的变量
/* Description:	滤波函数,用乘法器做的
/*---------------------------------------------------------------------------*/
int16 KLPF_VALUE(int16 INVlaue, int16 OutLastValue)
{
	int16 Result = 0;
	MDU_MA = (INVlaue-OutLastValue);
	MDU_MB = (int16)480;		           			/*写被乘数和乘数*/

	Result = MDU_MB;
	Result += OutLastValue;
	return(Result);
}

/*---------------------------------------------------------------------------*/
/* Name		:	void FaultProcess(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护处理函数，关闭FOC输出，同时将状态变为mcFault
/*---------------------------------------------------------------------------*/
void FaultProcess(void)
{
	MOE     = 0;
	ClrBit(DRV_CR, FOCEN);	//关闭FOC
	mcState = mcFault;

}

/*---------------------------------------------------------------------------*/
/* Name		:	int16 Abs_F16(int16 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint16 Abs_F16(int16 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	int32 Abs_F32(int32 value)
/* Input	:	value
/* Output	:	int16
/* Description:	对变量取16位的绝对值
/*---------------------------------------------------------------------------*/
uint32 Abs_F32(int32 value)
{
	if(value < 0)
	{
		return (- value);
	}
	else
	{
		return (value);
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	void APP_DIV(void)
/* Input	:	void
/* Output	:	void
/* Description:	将所有用到除法的地方，放在同一个中断，以避免中断串扰
/*---------------------------------------------------------------------------*/
void APP_DIV(void)
{
    if( mcPwmInput.PWMDivFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcPwmInput.PWMDuty = MDU_DIV_IDATA_U32(&mcPwmInput.pwm.PWMCompareAMP, &mcPwmInput.PWMARRUpdate);
       mcPwmInput.PWMDivFlag=0;
    }
    if( mcFocCtrl.ESDIVFlag==1)  //启动除法器，避免与过调值中的除法冲突
    {
       mcFocCtrl.SQUSpeedDIVEs = MDU_DIV_XDATA_U32(&mcFocCtrl.SQUSysSpeed,&mcFocCtrl.EsValue);
       mcFocCtrl.ESDIVFlag=0;
    }
}



/*---------------------------------------------------------------------------*/
/* Name		:	void ONOFF_Starttest(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	启动测试
/*---------------------------------------------------------------------------*/
void ONOFF_Starttest(ONVarible  *h_test)
{
	if(h_test->ONOFF_Flag==1)
	{
		 h_test->ON_Count++;
		if(h_test->ON_Count>StartON_Time)
		{
			h_test->ON_Count=0;
			h_test->ONOFF_Times++;
			h_test->ONOFF_Flag=0;
		  mcSpeedRamp.FlagONOFF = 0;
			mcSpeedRamp.TargetValue = 0;

		}
  }
	else
	{
		if(mcState!=mcFault)
		{
		  h_test->OFF_Count++;
			if(h_test->OFF_Count>StartOFF_Time)
			{
				h_test->OFF_Count=0;
				h_test->ONOFF_Flag=1;
				 mcSpeedRamp.FlagONOFF = 1;
				 mcSpeedRamp.TargetValue = Motor_Min_Speed;

			}
	  }

  }
}

/*---------------------------------------------------------------------------*/
/* Name		:	void Speed_response(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	速度响应函数，可根据需求加入控制环，如恒转矩控制、恒转速控制、恒功率控制
/*---------------------------------------------------------------------------*/


void Speed_response(void)
{
		uint16  UqMinTemp = 0;
		if((mcState == mcRun)||(mcState == mcStop))
		{
      if(mcFocCtrl.RunStateCnt < MotorStartHoldTime)													// MotorStartHoldTime目标转速为启动转速
      {
          mcFocCtrl.RunStateCnt++;
          if(mcSpeedRamp.FlagONOFF == 1)																			// PWM开机
          mcSpeedRamp.TargetValue = Motor_Start_Hold_Speed;                   //上油时间内维持上油转速
      }
      else																												            //如果达到上油转速后，将起动速度环增量变为运行速度环增量
      {
          if(mcSpeedRamp.IncValue	== SpeedRampStartInc)  			
          {
              mcSpeedRamp.IncValue	= SPEEDRAMPINC;      				              //运行速度环增量
              mcSpeedRamp.DecValue	= SPEEDRAMPDEC;
          }
          #if (FRDetectMethod != FOCMethod)																			//延迟MotorStartHoldTime，用于清RSDCCWFlag,BEMFCCWFlag
          {
              BEMFDetect.BEMFCCWFlag= 0;
              RSDDetect.RSDCCWFlag  = 0;
          }
          #endif
      }

			switch(mcFocCtrl.CtrlMode)
			{
				case 0:
					{
						if(Time.Start_CNT < 200)												                    //前200ms维持参考电流
						{
							Time.Start_CNT ++;
						}
						else 					
						{
							if(FOC__EOME > Motor_Loop_Speed)                                  //>=MOTOR_LOOP_RPM
								{
									mcFocCtrl.CtrlMode = 1;
									FOC_DQKP = DQKPRUN;
									FOC_DQKI = DQKIRUN;
									# if (Motor_Speed_Control_Mode == SPEED_LOOP_CONTROL)
									{
//											mcSpeedRamp.ActualValue = Motor_Start_Hold_Speed;
										if(FOC__EOME < _Q15(1800 / MOTOR_SPEED_BASE))
										{
												mcSpeedRamp.ActualValue = _Q15(1800 / MOTOR_SPEED_BASE);    //
										}
										else if(FOC__EOME > mcSpeedRamp.TargetValue)
										{
												mcSpeedRamp.ActualValue = mcSpeedRamp.TargetValue;
										}
										else
										{
												mcSpeedRamp.ActualValue = FOC__EOME;
										}
									}
									#elif (Motor_Speed_Control_Mode == POWER_LOOP_CONTROL)
									{
										mcSpeedRamp.ActualValue = mcFocCtrl.Powerlpf;
									}
									#endif

									OutLoopParameterSet();
								}
							else
              {
//										UqMinTemp = FOC_QMIN;
//										if(UqMinTemp < QOUTMINSTEND)
//											{
//												UqMinTemp += 10 ;
//												FOC_QMIN = UqMinTemp;
//											}
              }
							}
						}
					break;
					case 1:
					{			
								mcFocCtrl.SpeedRampTime++;
								if(mcFocCtrl.SpeedRampTime > SPEEDRAMPTIME)
								{
										mcFocCtrl.SpeedRampTime = 0;
										mc_ramp(&mcSpeedRamp);       //外环速度爬坡或减速。每SpeedRampTime执行一次
								}
								
								mcFocCtrl.SpeedLoopTime++;
								if(mcFocCtrl.SpeedLoopTime > SPEED_LOOP_TIME)  //外环调节周期
								{
									 mcFocCtrl.SpeedLoopTime=0;						
                   SpeedPICtrl.ExtRef = mcSpeedRamp.ActualValue;
                   SpeedPICtrl.ExtFed = mcFocCtrl.SpeedFlt;
                   HW_PI_Control(&SpeedPICtrl);             //
                   FOC_IQREF = SpeedPICtrl.ExtOut;
								}
								/*******弱磁函数**********/
								#if (FiledWeakenCompEnable == 1)
								{
									mcFieldWeakenComp();
								}
								#endif
                if (FOC__UQ > 6000)
                {
                    SetBit(FOC_CR2,F5SEG);
                }
                if (FOC__UQ < 5000)
                {
                    ClrBit(FOC_CR2,F5SEG);
                }
				 	// 判断FOC_QMIN值恢复到正常值
					UqMinTemp = FOC_QMIN;
					if(UqMinTemp > QOUTMIN)
					{
						UqMinTemp -- ;
						FOC_QMIN = UqMinTemp;
					}	
	

					 if(FOC_EK2 < OBS_K2T_Actual-10)
					 {
						 mcFocCtrl.Smo_EK2=FOC_EK2;
						 mcFocCtrl.Smo_EK2+=10;
						 FOC_EK2=mcFocCtrl.Smo_EK2;
					 }
					 else if(FOC_EK2 > OBS_K2T_Actual+10)
					 {
						 mcFocCtrl.Smo_EK2=FOC_EK2;
						 mcFocCtrl.Smo_EK2-=10;
						 FOC_EK2=mcFocCtrl.Smo_EK2;
					 }
					 else
					 {
						 FOC_EK2=OBS_K2T_Actual;
					 }
						
				}
				break;
			}
		}
}


/*---------------------------------------------------------------------------*/
/* Name		:	void FGOutput(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	FG信号输出
/*---------------------------------------------------------------------------*/
void FGOutput(void)
{//FG可用中断FGIF进行判断
	if(mcState==mcRun)
	{
		if((FOC__THETA>=0)&&(FOC__THETA<32768))//0-180
		{
			ResetFGPin;
		}
		else if((FOC__THETA>=32768)&&(FOC__THETA<65536))//180-360
		{
			SetFGPin;
		}
  }
	else if(mcState == mcFault)
	{
			SetFGPin;
	}
	else
	{
			ResetFGPin;
	}
}
/*---------------------------------------------------------------------------*/
/* Name		:	 uint16 SoftLPF(uint16 Xn1, uint16 Xn0, uint16 K)
/* Input	:	uint16 Xn1, uint16 Xn0, uint16 K
/* Output	:	uint16
/* Description:	软件低通滤波
/*---------------------------------------------------------------------------*/
 int16 SoftLPF(int16 Xn1, int16 Xn0, int16 K)
 {
 	 int16 Temp16 = 0;
 	 int32 Temp32 = 0;

 	 Temp32 = (((int32)Xn1 - (int32)Xn0) * (int32)K) >> 15;
 	 Temp16 = Xn0 + (int16)Temp32;
 	 return Temp16;
 }




/*---------------------------------------------------------------------------*/
/* Name		:	void mc_ramp(void)
/* Input	:	hTarget,MC_RAMP *hSpeedramp
/* Output	:	NO
/* Description:
/*---------------------------------------------------------------------------*/

void mc_ramp(MCRAMP *hSpeedramp)
{
	if( --hSpeedramp->DelayCount < 0)
	{
		hSpeedramp->DelayCount = hSpeedramp->DelayPeriod;

		if (hSpeedramp->ActualValue < hSpeedramp->TargetValue)
		{
				if(hSpeedramp->ActualValue + hSpeedramp->IncValue < hSpeedramp->TargetValue)
				{
						hSpeedramp->ActualValue += hSpeedramp->IncValue;
				}
				else
				{
						hSpeedramp->ActualValue = hSpeedramp->TargetValue;
				}
		}
		else
		{
				if(hSpeedramp->ActualValue - hSpeedramp->DecValue > hSpeedramp->TargetValue)
				{

						hSpeedramp->ActualValue -= hSpeedramp->DecValue;
				}
				else
				{
						hSpeedramp->ActualValue = hSpeedramp->TargetValue;
				}
		}
	}
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_One_PI(int16 Xn1, int16 Yn0, int16 Xn2)
	Description   :	PI控制
	Input         :	Xn1--E(K)
	Output		  :	PI_UK--当前PI输出值,执行时间us
-------------------------------------------------------------------------------------------------*/
int16 HW_One_PI(int16 Xn1)
{
	  PI_EK =  Xn1;	      												//填入EK
		SetBit(PI_LPF_CR,PISTA);										// Start PI
//	  PI_LPF_CR |= 0x02;	  											// Start PI
	  _nop_();  _nop_();  _nop_();  _nop_();  _nop_();
	  PI_UK += ((SKP>>12) +1);
	  return PI_UK;
}

void HW_PI_Control(OUTLOOP *PIPara)
{
	  PIPara->ExtErr = PIPara->ExtRef - PIPara->ExtFed;
		PI_EK =  PIPara->ExtErr;	      																						//填入本次EK 误差值
//		PI_UK =  PIPara->ExtOutL;	      																						//填入上一次UL
		SetBit(PI_LPF_CR,PISTA);																										// Start PI
	  _nop_();  _nop_();  _nop_();  _nop_();  _nop_();
		
		PIPara->ExtOut = PI_UK + 1;																									// 补偿PI输出误差
}

/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 HW_TWO_PI(int16 Err1, int16 ErrL, int16 Out1, int16 OutL)
	Description   :	程序中连续调用PI控制
	Input         :	Xn1--E(K)
	Output		  	:	反馈计算值
-------------------------------------------------------------------------------------------------*/
//void HW_TWO_PI(OUTLOOP *PIPara)
//{
//		// 写入上一次ERR值
//	  PI_EK =  PIPara->ExtErrL;	      																						//填入上次EKL
//		SetBit(PI_LPF_CR,PISTA);																										// Start PI
//	  _nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//	
//		//
//		PIPara->ExtErr = PIPara->ExtRef - PIPara->ExtFed;
//		PI_EK =  PIPara->ExtErr;	      																						//填入本次EK
//		PI_UK =  PIPara->ExtOutL;	      																						//填入上一次UL
//		SetBit(PI_LPF_CR,PISTA);																										// Start PI
//	  _nop_();  _nop_();  _nop_();  _nop_();  _nop_();
//		
////	  PIPara->ExtOut = PI_UK + ((SKP>>12) +1);																		// 补偿PI输出误差
//		PIPara->ExtOut = PI_UK + 1;																									// 补偿PI输出误差
//	
//		PIPara->ExtErrL = PIPara->ExtErr;																						// 保存误差值
//		PIPara->ExtOutL = PIPara->ExtOut;																						// 保存输出值
//}
/*-------------------------------------------------------------------------------------------------
	Function Name :	int16 LPF(int16 Xn1, int16 Xn0, int8 K)
	Description   :	LFP控制
	Input         :	Xn1--当前输入值
	                Xn0--上一次滤波输出值
									K--LPF滤波系数
  Output				:	LPF_Y--当前滤波输出值，执行时间为4us。
-------------------------------------------------------------------------------------------------*/
int16 LPFFunction(int16 Xn1, int16 Xn0, int8 K)
{
	LPF_K = K;
	LPF_X = Xn1;
	LPF_Y = Xn0;
	SetBit(PI_LPF_CR, LPFSTA);
	_nop_();_nop_();_nop_();_nop_();_nop_();
	return LPF_Y;
}

/*---------------------------------------------------------------------------*/
/* Name		:	void VSPSample(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	VSP采样
/*---------------------------------------------------------------------------*/
void VSPSample(void)
{
	/*****VREF的采样获取值并滤波******/
	AdcSampleValue.ADCVref = (ADC7_DR<<3);//采集对应端口
	VSP=LPFFunction(AdcSampleValue.ADCVref,VSP,30);//低通滤波

	  if((VSP > ONPWMDuty)&&(VSP <= OFFPWMDutyHigh))//在ONPWMDuty-OFFPWMDutyHigh之间，电机有转速运行
	  {
		  mcSpeedRamp.FlagONOFF = 1;
	  }
	  else if((VSP < OFFPWMDuty)||(VSP > OFFPWMDutyHigh))//电机停机
	  {
			mcSpeedRamp.FlagONOFF = 0;
	  }
		//转速曲线计算
		if(mcSpeedRamp.FlagONOFF==1)//
		{
      #if (Motor_Speed_Control_Mode == SPEED_LOOP_CONTROL)
      {
        if(VSP <= MINPWMDuty)    //最小转速运行
        {
          mcSpeedRamp.TargetValue = Motor_Min_Speed;
        }
        else if(VSP < MAXPWMDuty)//调速
        {
          mcSpeedRamp.TargetValue = Motor_Min_Speed + SPEED_K*(VSP-MINPWMDuty);
        }
        else		     //最大转速运行
        {
          mcSpeedRamp.TargetValue	=	Motor_Max_Speed;
        }
      }
      #elif (Motor_Speed_Control_Mode == POWER_LOOP_CONTROL)
      {
        if(VSP <= MINPWMDuty)    //最小转速运行
        {
          mcSpeedRamp.TargetValue = Motor_Min_Power;
        }
        else if(VSP < MAXPWMDuty)//调速
        {
          mcSpeedRamp.TargetValue = Motor_Min_Power + POWER_K*(VSP-MINPWMDuty);
        }
        else		     //最大转速运行
        {
          mcSpeedRamp.TargetValue	=	Motor_Max_Power;
        }
      }
      #endif

		}
		else
		{
			mcSpeedRamp.TargetValue =0;
		}
}
/*---------------------------------------------------------------------------*/
/* Name		:	void Sleepmode(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	睡眠模式测试
/*---------------------------------------------------------------------------*/
 void Sleepmode(void)
 {
	 	SleepSet.SleepDelayCout++;
		if(SleepSet.SleepDelayCout>=20000)//最大65530，若要再大，需改数据类型
		{
//				FOC_EFREQMIN 	= -Motor_Omega_Ramp_Min;
//				FOC_EFREQHOLD = -Motor_Omega_Ramp_End;
			mcSpeedRamp.TargetValue=0;
			MOE     = 0;
			ClrBit(DRV_CR, FOCEN);	//关闭FOC
			SleepSet.SleepDelayCout=0;
			SleepSet.SleepFlag=1;
			SetBit(P1_IE, P11);   // config P11 as the source of EXTI1
			SetBit(PCON, STOP);
		}

 }
/*---------------------------------------------------------------------------*/
/* Name		:	void StarRampDealwith(void)
/* Input	:	NO
/* Output	:	NO
/* Description:
/*---------------------------------------------------------------------------*/
void StarRampDealwith(void)
{
		if((mcState == mcRun))
		{
			if(mcFocCtrl.State_Count == 900)//700
			{
				FOC_EKP = OBSW_KP_GAIN_RUN;	                          // 估算器里的PI的KP
				FOC_EKI	= OBSW_KI_GAIN_RUN;				                    // 估算器里的PI的KI
			}
			else if(mcFocCtrl.State_Count == 700)//600
			{
				FOC_EKP = OBSW_KP_GAIN_RUN1;	                        // 估算器里的PI的KP
				FOC_EKI	= OBSW_KI_GAIN_RUN1;				                  // 估算器里的PI的KI
			}
			else if(mcFocCtrl.State_Count == 500)//500
			{
				FOC_EKP = OBSW_KP_GAIN_RUN2;	                        // 估算器里的PI的KP
				FOC_EKI	= OBSW_KI_GAIN_RUN2;				                  // 估算器里的PI的KI
			}
			else if(mcFocCtrl.State_Count ==300)//300
			{
				FOC_EKP = OBSW_KP_GAIN_RUN3;	                        // 估算器里的PI的KP
				FOC_EKI	= OBSW_KI_GAIN_RUN3;				                  // 估算器里的PI的KI
			}
			else if(mcFocCtrl.State_Count == 100) //100
			{
				FOC_EKP = OBSW_KP_GAIN_RUN4;	                        // 估算器里的PI的KP
				FOC_EKI	= OBSW_KI_GAIN_RUN4;				                  // 估算器里的PI的KI
			}
			else;
		}
}



void Led_Display(void)
{
	if (mcFaultSource)
//  if (1)
	{
//		mcLed.LedFlickerTimesDatum = 1;
    mcLed.LedFlickerTimesDatum = mcFaultSource;
    
		if (mcLed.LedDelayTimeCount < LED_DelayTime)                      //¹ÊÕÏ·¢Éú ÑÓ³ÙÒ»¶ÎÊ±¼äÔÙ½øÐÐÏÔÊ¾
		{
			mcLed.LedDelayTimeCount++;
		}
		else
		{		
			if (mcLed.LedAlertsCount <= mcLed.LedAlertsDatum)  							//±¨¾¯´ÎÊý,ÔÚÂú×ã±¨¾¯´ÎÊýºó½«¹Ø±ÕÏÔÊ¾
			{
				
				if (mcLed.LedFlickerTimesCount < mcLed.LedFlickerTimesDatum)  //Ã¿Ò»´Î±¨¾¯µÄÉÁË¸´ÎÊý, ÓÃÓÚÇø·Ö¹ÊÕÏÂë
				{
					mcLed.LedCount++;
					if (mcLed.LedCount <= LED_OFFTime)
					{
						LED_PIN = 1;
					}
					else if (mcLed.LedCount > LED_OFFTime && mcLed.LedCount < LED_ONOFFTime)
					{
						LED_PIN = 0;
					}
					else
					{
						LED_PIN = 1;
						mcLed.LedFlickerTimesCount++;
						mcLed.LedCount = 0;
					}
				}
				else
				{
					mcLed.LedIntervalTimeCount++;
					if (mcLed.LedIntervalTimeCount > LED_IntervalTime)  //Ã¿´Î±¨¾¯Ö®¼äµÄ¼ä¸ôÊ±¼ä
					{
						mcLed.LedIntervalTimeCount = 0;
						mcLed.LedFlickerTimesCount = 0;
						mcLed.LedAlertsCount++;
					}
				}
			}
		}
	}
  else
  {
    LED_PIN = 1;
  }
	
}





/*****************************************************************************
 * Function:		 void	Fault_OverVoltage(mcFaultVarible *h_Fault)
 * Description:	 过压欠压保护函数：程序每5ms判断一次，母线电压大于过压保护值时，计数器加一，计数器值超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
                 同理，欠压保护。
	               电机过欠压保护状态下，母线电压恢复到欠压恢复值以上，过压恢复值以下时，计数器加一，超过200次后，恢复。根据档位信息来决定恢复到哪个状态。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/

void Fault_OverUnderVoltage(FaultVarible *h_Fault)
{
	//过压保护
		if(FaultNoSource == mcFaultSource)//程序无其他保护下
		{
				if(mcFocCtrl.mcDcbusFlt > OVER_PROTECT_VALUE)	 //母线电压大于过压保护值时，计数，超过20次，判断为过压保护，关闭输出;反之，计数器慢慢减
				{
					h_Fault->OverVoltDetecCnt++;
					if(h_Fault->OverVoltDetecCnt > 500)//检测100ms
					{
						h_Fault->OverVoltDetecCnt = 0;
						mcFaultSource = FaultOverVoltage;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->OverVoltDetecCnt > 0)
					{
						h_Fault->OverVoltDetecCnt--;
					}
				}

			
				if(mcFocCtrl.mcDcbusFlt< UNDER_PROTECT_VALUE)    /*Under Voltage*/
				{
					h_Fault->UnderVoltDetecCnt++;

					if(h_Fault->UnderVoltDetecCnt > 500)
					{
						h_Fault->UnderVoltDetecCnt = 0;
						mcFaultSource=FaultUnderVoltage;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->UnderVoltDetecCnt>0)
					{
						h_Fault->UnderVoltDetecCnt--;
					}
				}
		}

		/*******过压欠压保护恢复*********/
		if((mcState == mcFault) &&((mcFaultSource==FaultUnderVoltage)||(mcFaultSource==FaultOverVoltage)))
		{
			if((mcFocCtrl.mcDcbusFlt< OVER_RECOVER_VALUE)&&(mcFocCtrl.mcDcbusFlt> UNDER_RECOVER_VALUE))
			{
				h_Fault->VoltRecoverCnt++;
				if(h_Fault->VoltRecoverCnt>2000)//连续检测1s，若正常则恢复
				{
          mcState = mcReady;
					mcFaultSource=FaultNoSource;
					h_Fault->VoltRecoverCnt = 0;
				}
			}
			else
			{
				h_Fault->VoltRecoverCnt = 0;
			}
	 }
}


/*****************************************************************************
 * Function:		 void	Fault_Power(mcFaultVarible *h_Fault)
 * Description:	 功率保护函数
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Power(FaultVarible *h_Fault)
{
		if(mcFaultSource == FaultNoSource)//程序无其他保护下
		{
				if(mcFocCtrl.Powerlpf > PowerLimit)	 //功率大于保护值时计数，超过20次，判断为过载保护，关闭输出;反之，计数器慢慢减
				{
					h_Fault->OverPowerDetecCnt++;
					if(h_Fault->OverPowerDetecCnt > 1000)
					{
						h_Fault->OverPowerDetecCnt = 0;
						mcFaultSource=FaultOverPower;
						FaultProcess();
					}
				}
				else
				{
					if(h_Fault->OverPowerDetecCnt>0)
					{
						h_Fault->OverPowerDetecCnt--;
					}
				}
		}
}


/*****************************************************************************
 * Function:		 void Fault_Overcurrent(CurrentVarible *h_Cur)
 * Description:	 电机运行或者启动时，当三相中某一相最大值大于OverCurrentValue，则OverCurCnt加1。
								 连续累加3次，判断为软件过流保护。执行时间约30.4us。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_Overcurrent(CurrentVarible *h_Cur)
{
	if((mcState == mcRun)||(mcState == mcStart))						// check over current in rum and open mode
	{

		h_Cur->Abs_ia = Abs_F16(FOC__IA);
		h_Cur->Abs_ib = Abs_F16(FOC__IB);
		h_Cur->Abs_ic = Abs_F16(FOC__IC);
		if(h_Cur->Abs_ia> h_Cur->Max_ia)                      // 此部分既用于软件过流保护，又用于缺相保护
		{
			 h_Cur->Max_ia = h_Cur->Abs_ia;
		}
		if(h_Cur->Abs_ib > h_Cur->Max_ib)
		{
			 h_Cur->Max_ib = h_Cur->Abs_ib;
		}
		if(h_Cur->Abs_ic > h_Cur->Max_ic)
		{
			 h_Cur->Max_ic = h_Cur->Abs_ic;
		}

		if((h_Cur->Max_ia>=OverSoftCurrentValue)||(h_Cur->Max_ib>=OverSoftCurrentValue)||(h_Cur->Max_ic>=OverSoftCurrentValue))
		{
			h_Cur->OverCurCnt++;
			if(h_Cur->OverCurCnt>=3)
			{
        GP36=~GP36;
				h_Cur->Max_ia=0;
				h_Cur->Max_ib=0;
				h_Cur->Max_ic=0;
				h_Cur->OverCurCnt=0;
			  mcFaultSource=FaultSoftOVCurrent;
			  FaultProcess();
			}
		}
    else
		{
			if(h_Cur->OverCurCnt>0)
			{
				h_Cur->OverCurCnt--;
			}
		}
	}
}


/*****************************************************************************
 * Function:		 void	Fault_OverCurrentRecover(mcFaultVarible *h_Fault)
 * Description:	 软硬件过流保护恢复
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_OverCurrentRecover(FaultVarible *h_Fault)
{
	if((mcState == mcFault)&&((mcFaultSource==FaultSoftOVCurrent)||(mcFaultSource==FaultHardOVCurrent))&&(mcProtectTime.CurrentPretectTimes<5))
	{
		h_Fault->CurrentRecoverCnt++;
		if(h_Fault->CurrentRecoverCnt>=OverCurrentRecoverTime)//1000*5=5s
		{
			h_Fault->CurrentRecoverCnt=0;
			mcProtectTime.CurrentPretectTimes++;
			mcState = mcReady;
			mcFaultSource=FaultNoSource;
    }
  }
}

/*****************************************************************************
 * Function:		 void	Fault_OverPowerRecover(mcFaultVarible *h_Fault)
 * Description:	 功率保护恢复函数
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
void Fault_OverPowerRecover(FaultVarible *h_Fault)
{
	if((mcState == mcFault)&&(mcFaultSource==FaultOverPower)&&(mcProtectTime.PowerPretectTimes<5))
	{
		h_Fault->OverPowerDetecCnt++;
		if(h_Fault->OverPowerDetecCnt>=OverPowerRecoverTime)
		{
			h_Fault->OverPowerDetecCnt=0;
			mcProtectTime.PowerPretectTimes++;
			mcState = mcReady;
			mcFaultSource=FaultNoSource;
    }
  }
}



/*****************************************************************************
 * Function:		 void	Fault_Start(mcFaultVarible *h_Fault)
 * Description:	 启动保护函数，电机运行状态下，电机在前5s估算转速达到堵转保护值或者5s后反电动势值太低(此方法未验证)
                  或4s内还在CtrlMode状态，即速度低于MOTOR_LOOP_RPM，程序判断为启动失败，电机停机。
                  当程序判断为启动失败后，若重启次数少于或等于5次，程序立即进入校准状态，等待重启。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
  void Fault_Start(FaultVarible *h_Fault)
  {
		/*******启动保护恢复*********/
//		h_Fault->mcEsValue = FOC__ESQU;

		if(mcState == mcRun)
		{
			//方法一，5s内速度大于最大速度，同时反电动势值低于一定值
			if(h_Fault->StartSpeedCnt<=5000)
			{
			  h_Fault->StartSpeedCnt++;
				if((mcFocCtrl.SpeedFlt > Motor_Max_Speed)&&(mcFocCtrl.EsValue<50))
				{
					h_Fault->StartSpeedCnt = 0;
					mcFaultSource=FaultStart;
					FaultProcess();
					mcProtectTime.SecondStartTimes++;
					mcProtectTime.StartFlag  =  1;
        }
      }
     //方法二
			if(h_Fault->StartEsCnt<=6000)//前6s，等待1.5s后，开始判断Es，如果超过一定次数，则失败
			{
				h_Fault->StartEsCnt++;
				h_Fault->StartDelay++;
				if(h_Fault->StartDelay>=1500)				// 1.5s
				{
					 h_Fault->StartDelay=1500;
					 if((mcFocCtrl.EsValue <20))//&&(mcFocCtrl.CtrlMode==0))
						{
							h_Fault->StartESCount++;
							if(h_Fault->StartESCount>=50)     //50次Es小于设定值，启动失败
							{
								mcFaultSource=FaultStart;
								FaultProcess();
								mcProtectTime.SecondStartTimes++;
								h_Fault->StartDelay=0;
								h_Fault->StartESCount=0;
								mcProtectTime.StartFlag  =  2;
							}
						}
            else
						{
							if(h_Fault->StartESCount>0)
								h_Fault->StartESCount--;
						}
			 }
		 }
     else
     {
       h_Fault->StartESCount=0;
     }
		 
		 
		 	//方法三，长时间在CtrlMode=0状态
			if(mcFocCtrl.CtrlMode==0)         
			{
				h_Fault->StartFocmode++;
				if(h_Fault->StartFocmode>=8000)   //在MODE0模式超过8s起动失败
				{
					h_Fault->StartFocmode=0;
					mcFaultSource=FaultStart;
					FaultProcess();
					mcProtectTime.SecondStartTimes++;
          mcProtectTime.StartFlag  =  3;
        }
			}
			
	  }
    
		//起动保护恢复
 #if (!StartONOFF_Enable)    //起停测试时屏蔽起动保护恢复
		{
		 if((mcFaultSource==FaultStart)&&(mcState == mcFault)&&(mcProtectTime.SecondStartTimes<=StartProtectRestartTimes))
		 {
			 
			 h_Fault->StartRecoverDelayCnt++;
			 if(h_Fault->StartRecoverDelayCnt > StartRecoverDelayTimes)   //启动保护延时恢复时间
	     {
					h_Fault->StartRecoverDelayCnt = 0;
				  mcFaultSource=FaultNoSource;
					mcState = mcInit;
			 }
		 }
    }
	#endif
		
	}

 


 /*****************************************************************************
 * Function:		 void	Fault_Stall(mcFaultVarible *h_Fault)
 * Description:	 堵转保护函数，有三种保护方式，
	               第一种，
	               第二种，电机运行状态下，延迟4s判断，估算速度绝对值超过堵转速度连续5次；
	               第三种，电机运行状态下，当U,V两相电流绝对值大于堵转电流保护值连续6次；
	               当以上三种的任何一种保护触发时，电机停机，程序判断为堵转保护；
	               当堵转保护状态下，U相采集值低于堵转恢复值时，若堵转次数小于或等于堵转重启次数8次，
	               程序延迟mcStallRecover重新启动，进行校准状态。
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
//堵转保护
void Fault_Stall(FaultVarible *h_Fault,CurrentVarible *h_Cur)
{
//	h_Fault->mcEsValue = FOC__ESQU;
	if(mcState == mcRun)
	{
		if(h_Fault->StallDelayCnt <=5000)// 启动后延时5s判断是否堵转保护
		{
			h_Fault->StallDelayCnt ++;
		}
		else
		{
	    //method 1，当反电动势太小 或当 转速太大但反电动势却很小时进入保护
      if((&mcFocCtrl.EsValue< 20)||((FOC__EOME > _Q15(1200.0/MOTOR_SPEED_BASE))&&(mcFocCtrl.EsValue< 50)))
			{
				h_Fault->StallDectEs++;
				if(h_Fault->StallDectEs >= 50)   //判断满足条件达到设置次数，保护动作
				{
					h_Fault->StallDectEs=0;
					mcFaultSource=FaultStall;
					mcProtectTime.StallTimes++;        //堵转次数+1
					FaultProcess();
					h_Fault->StallDelayCnt = 0;        //保护后重启开始重新计数，保持5S延迟
					mcProtectTime.StallFlag  =  1;
				}
			}
			else
			{
        if(	h_Fault->StallDectEs>0)
				  h_Fault->StallDectEs--;
			}
			
			//method 2，判断速度低于堵转最小值或者超过堵转最大值
			if((mcFocCtrl.SpeedFlt<Motor_Stall_Min_Speed)||(mcFocCtrl.SpeedFlt > Motor_Stall_Max_Speed))
			{
				h_Fault->StallDectSpeed++;
				if(h_Fault->StallDectSpeed >= 20)   //判断满足条件达到设置次数，保护动作
				{
					h_Fault->StallDectSpeed=0;
					mcFaultSource=FaultStall;
					mcProtectTime.StallTimes++;				//堵转次数+1
					FaultProcess();
					h_Fault->StallDelayCnt = 0; 			//保护后重启开始重新计数，保持5S延迟
 					mcProtectTime.StallFlag =2;
				}
			}
			else
			{
        if(h_Fault->StallDectSpeed>0)
				h_Fault->StallDectSpeed--;
			}
			
			//method 3		  A/B/C三相任意一相相电流大于堵转电流，堵转保护
		if((h_Cur->Max_ia >= StallCurrentValue)||
			 (h_Cur->Max_ib >= StallCurrentValue)||
		   (h_Cur->Max_ic >= StallCurrentValue))
		{			 
			h_Fault->mcStallDeCurrent++;              
			if(h_Fault->mcStallDeCurrent >= 20)					//判断满足条件达到设置次数，保护动作
			{
				h_Fault->mcStallDeCurrent=0;
				mcFaultSource=FaultStall;	
				mcProtectTime.StallTimes++;
				FaultProcess();		
				h_Fault->StallDelayCnt = 0; 			//保护后重启开始重新计数，保持5S延迟
				mcProtectTime.StallFlag  =  3;
			}						 
		}	
		else
			{
        if(h_Fault->mcStallDeCurrent>0)
				h_Fault->mcStallDeCurrent--;
			}
  }
}
   
 #if (!StartONOFF_Enable)
{
		 /*******堵转保护恢复*********/
        if((mcFaultSource==FaultStall)&&(mcState == mcFault)&&(mcProtectTime.StallTimes<=4))  //堵转重启次数
        {
          h_Fault->StallReCount++;
          if(h_Fault->StallReCount>=StallRecoverTime)
          {
            h_Fault->StallReCount=0;        //16000
            mcFaultSource=FaultNoSource;
            mcState =   mcInit;
          }
        }
        else
        {
          h_Fault->StallReCount=0;
        }
}
#endif
    
}

/*****************************************************************************
 * Function:		 void	Fault_Temperature(mcFaultVarible *h_Fault)
 * Description:	 
 * Parameter:		 mcFaultVarible *h_Fault               
 * Return:			 no
 *****************************************************************************/
void Fault_Temperature(FaultVarible *h_Fault)
{
  if(mcFocCtrl.mcTempDecFlt < OVER_Temperature)
  {
     h_Fault->TemperCnt++; 				
     if(h_Fault->TemperCnt > OverTemperTime)								
     {	
        h_Fault->TemperCnt        = 0;
        h_Fault->TemperRecoverCnt    = 0;	
        mcFaultSource             = FaultOverPCBTH;
        FaultProcess();
     }	   
  }
  else
  {
     h_Fault->TemperCnt = 0;	
  }
  
  if((mcState == mcFault)&&(mcFaultSource==FaultOverPCBTH))
	{
    if (mcFocCtrl.mcTempDecFlt > UNDER_Temperature)
    {
      h_Fault->TemperRecoverCnt++;
      if(h_Fault->TemperRecoverCnt >= OverTemperTime)
      {
        h_Fault->TemperRecoverCnt=0;
        mcState = mcReady;
        mcFaultSource=FaultNoSource;
      }
    }
    else
    {
      h_Fault->OverPowerDetecCnt = 0;
    }
  }
  
  
}

 /*****************************************************************************
 * Function:		 void	Fault_phaseloss(mcFaultVarible *h_Fault)
 * Description:	 缺相保护函数，当电机运行状态下，10ms取三相电流的最大值，
	               1.5s判断各相电流最大值，若存在两相电流值大于一定值，而第三相电流值却非常小，则判断为缺相保护，电机停机；
 * Parameter:		 mcFaultVarible *h_Fault
 * Return:			 no
 *****************************************************************************/
  void Fault_phaseloss(FaultVarible *h_Fault)
  {
			if(mcState == mcRun)
			{
				if(h_Fault->LossPhaseDelayCnt < 5000)
				{
					h_Fault->LossPhaseDelayCnt++;
				}
				else
				{								
				h_Fault->Lphasecnt++;
				if(h_Fault->Lphasecnt>100)//100*5=500ms  500ms判断一次
				{
					 h_Fault->Lphasecnt=0;
					 if(((mcCurVarible.Max_ia>(mcCurVarible.Max_ib*3))||(mcCurVarible.Max_ia>(mcCurVarible.Max_ic*3)))&&(mcCurVarible.Max_ia>PhaseLossCurrentValue))
					 {
							h_Fault->AOpencnt++;
					 }
					 else
					 {
						if(h_Fault->AOpencnt>0)
							h_Fault->AOpencnt --;
					 }
					 if(((mcCurVarible.Max_ib >(mcCurVarible.Max_ia*3))||(mcCurVarible.Max_ib >(mcCurVarible.Max_ic*3)))&&(mcCurVarible.Max_ib >PhaseLossCurrentValue))
					 {
						 h_Fault->BOpencnt++;
					 }
					else
					 {
             if(h_Fault->BOpencnt>0)
							h_Fault->BOpencnt --;
					 }
					 if(((mcCurVarible.Max_ic >(mcCurVarible.Max_ia*3))||(mcCurVarible.Max_ic >(mcCurVarible.Max_ib*3)))&&(mcCurVarible.Max_ic >PhaseLossCurrentValue))
					 {
						 h_Fault->COpencnt++;
					 }
					else
					 {
             if(h_Fault->COpencnt>0)
							h_Fault->COpencnt --;
					 }
						mcCurVarible.Max_ia = 0;
						mcCurVarible.Max_ib = 0;
						mcCurVarible.Max_ic = 0;
					if(h_Fault->AOpencnt > 10|| h_Fault->BOpencnt > 10 || h_Fault->COpencnt > 10)
					 {
							mcProtectTime.LossPHTimes++;
							mcFaultSource=FaultLossPhase;
							FaultProcess();
					 }
				}
			}	
			}

		 /*******缺相保护恢复*********/
#if (!StartONOFF_Enable)           //起停测试时屏蔽缺相保护恢复
{
      if((mcFaultSource==FaultLossPhase)&&(mcState == mcFault)&&(mcProtectTime.LossPHTimes<5))//可重启5次
			 {
					 h_Fault->mcLossPHRecCount++;
					 if(h_Fault->mcLossPHRecCount>=PhaseLossRecoverTime)
					 {
						 h_Fault->AOpencnt=0;
						 h_Fault->BOpencnt=0;
						 h_Fault->COpencnt=0;
						 mcState = mcReady;
						 mcFaultSource=FaultNoSource;
           }
       }
    else
			 {
			     h_Fault->mcLossPHRecCount=0;
			 }
}
#endif
			 		 
    }



/*---------------------------------------------------------------------------*/
/* Name		:	void Fault_Detection(void)
/* Input	:	NO
/* Output	:	NO
/* Description:	保护函数，因保护的时间响应不会很高，采用分段处理，每5个定时器中断执行一次对应的保护
	              常见保护有过欠压、过温、堵转、启动、缺相等保护，调试时，可根据需求，一个个的调试加入。
/*---------------------------------------------------------------------------*/
void Fault_Detection(void)
{
  /*过流保护恢复使能*/
  #if (CurrentRecoverEnable)
  {
    Fault_OverCurrentRecover(&mcFaultDect);
  }
  #endif
  
  /*功率保护恢复使能*/
  #if (PowerRecoverEnable)
  {
    Fault_OverPowerRecover(&mcFaultDect);
  }
  #endif
  
  /*过欠压保护使能*/
  #if (VoltageProtectEnable==1)
  {
    Fault_OverUnderVoltage(&mcFaultDect);
  }
  #endif
  
  /*功率保护使能*/
  #if (OverPowerProtectEnable==1) 
  {
    Fault_Power(&mcFaultDect);
  }				
  #endif		
  
  /*启动保护使能*/
  #if (StartProtectEnable==1)
  {
    Fault_Start(&mcFaultDect);
  }
  #endif		
  
  /*堵转保护使能*/
  #if (StallProtectEnable==1)
  {
    Fault_Stall(&mcFaultDect,&mcCurVarible);
  }
  #endif
  
  /*缺相保护使能*/
  #if (PhaseLossProtectEnable==1)
  {
    Fault_phaseloss(&mcFaultDect);
  }
  #endif  
  //过温保护
	#if (TemperatureProtectEnable == 1)
	{				
		Fault_Temperature(&mcFaultDect);
	}
	#endif
}