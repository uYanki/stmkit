/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : PWMScan.c
* Author             : Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-27
* Description        : This file contains main function used for Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/


/* Includes -------------------------------------------------------------------------------------*/
#include <FU68xx_2.h>
#include <Myproject.h>


/* Private typedef ------------------------------------------------------------------------------*/
/* Private define -------------------------------------------------------------------------------*/
/* Private macro --------------------------------------------------------------------------------*/
/* Private variables ----------------------------------------------------------------------------*/
PWMFREQINPUTTRPE xdata mcPWMFreqInputCtrl;
PWMCaptureTypeDef PwmInput;
/* Private function prototypes ------------------------------------------------------------------*/
/* Private functions ----------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
	Function Name :	void PWMIN_Init(void)
	Description   :	PWM��������ʼ��
	Input         :	��
	Output		  :	��
-------------------------------------------------------------------------------------------------*/
//void PWMIN_Init(void)
//{
//	memset(&mcPWMFreqInputCtrl,0, sizeof(PWMFREQINPUTTRPE));											// ����mcPWMFreqInputCtrl
//}

/*-------------------------------------------------------------------------------------------------
	Function Name :	void PWMScan(void)
	Description   : PWMɨ��
	Input         :	��
	Output		  :	��
-------------------------------------------------------------------------------------------------*/
void PWMScan(void)
{
  if (PwmInput.UpdataFlg == 1)
  {
    if (PwmInput.Periodmscnt > 200)
    {
      PwmInput.Fre = 100000/PwmInput.Periodmscnt;
    }
    else
    {
      PwmInput.Fre = 18750000/PwmInput.PeriodARR;
    }
    PwmInput.UpdataFlg    = 0;	
  }
  
  if (PwmInput.Fre > STARTFre)
  {
    if (mcSpeedRamp.FlagONOFF == 0) mcSpeedRamp.FlagONOFF = 1;
  }

  if (PwmInput.Fre < STOPFre)
  {
    mcSpeedRamp.FlagONOFF = 0;
  }

  if(mcSpeedRamp.FlagONOFF == 1)
  {
    if(PwmInput.Fre <= STARTFre)
    {
      mcSpeedRamp.TargetValue = Motor_Min_Speed;
    }
    else if(PwmInput.Fre <= MAXFre)
    {
      mcSpeedRamp.TargetValue = Motor_Min_Speed + SPEED_K*(PwmInput.Fre - STARTFre);
    }
    else
    {
      mcSpeedRamp.TargetValue	=	Motor_Max_Speed;
    }
  }
  else
  {
    mcSpeedRamp.TargetValue =0;
  }
   

}
