/**************************** (C) COPYRIGHT 2017 Fortiortech shenzhen *****************************
* File Name          : Customer.h
* Author             : Vina Peng, Fortiortech Appliction Team
* Version            : V1.0
* Date               : 2017-12-21
* Description        : This file contains all the common data types used for
*                      Motor Control.
***************************************************************************************************
* All Rights Reserved
**************************************************************************************************/

/* Define to prevent recursive inclusion --------------------------------------------------------*/
#ifndef __CUSTOMER_H_
#define __CUSTOMER_H_

#define I_ValueX(Curr_Value)            (Curr_Value * HW_RSHUNT * HW_AMPGAIN / HW_ADC_REF)
#define I_Value(Curr_Value)             _Q15(I_ValueX(Curr_Value))
/*芯片参数值-------------------------------------------------------------------*/
 /*CPU and PWM Parameter*/
 #define MCU_CLOCK                      (24.0)                                  // (MHz) 主频
 #define PWM_FREQUENCY                  (25.0)                                  // (kHz) 载波频率

 /*deadtime Parameter*/
 #define PWM_DEADTIME                   (1.1)      //1.6                               // (us) 死区时间

 /*single resistor sample Parameter*/
 #define MIN_WIND_TIME                  (PWM_DEADTIME+1.4)                                   // (us) 单电阻最小采样窗口，建议值死区时间+0.9us

///*电机参数值-------------------------------------------------------------------*/// 未知名电机
//#define Pole_Pairs                      (1.0)                                     // 极对数
//#define LD                              (0.00001511*0.50)  // (0.0022)             // (H) D轴电感
//#define LQ                              (0.00001511*0.50)  //(0.0022)              // (H) Q轴电感
//#define RS                             	(0.01491*1.0)                                // (Ω) 相电阻
//#define Ke                              (0.151355*1.0)	      //18   18.0 *0.4

///*电机参数值-------------------------------------------------------------------*/// 浙江创虹第一次电机
//#define Pole_Pairs                      (1.0)                                     // 极对数
//#define LD                              (0.00003936*0.7)  // (0.0022)             // (H) D轴电感
//#define LQ                              (0.00003936*0.7)  //(0.0022)              // (H) Q轴电感
//#define RS                             	(0.02940516*1.0)                                // (Ω) 相电阻
//#define Ke                              (0.18994140*1.0)	      //18   18.0 *0.4

//浙江创虹第一次电机
#define Pole_Pairs                      (1.0)                                     // 极对数
#define LD                              (0.00002647*0.7)  // (0.0022)             // (H) D轴电感
#define LQ                              (0.00002647*0.7)  //(0.0022)              // (H) Q轴电感
#define RS                             	(0.02102366*1.0)                                // (Ω) 相电阻
#define Ke                              (0.15415*1.0)	      //18   18.0 *0.4

/////*电机参数值-------------------------------------------------------------------*/// 蓝威电机 ok
//#define Pole_Pairs                      (2.0)                                     // 极对数
//#define LD                              (0.00001423*0.5)  // (0.00002605)             // (H) D轴电感
//#define LQ                              (0.00001423*0.5)  //(0.0022)              // (H) Q轴电感
//#define RS                             	(0.01371*0.9)                                // (Ω) 相电阻
//#define Ke                              (0.148241*1.2)	      //18   18.0 *0.4

/*电机参数值-------------------------------------------------------------------*/// 蓝威电机
//#define Pole_Pairs                      (2.0)                                     // 极对数
//#define LD                              (0.00001423*2.0)  // (0.00002605)             // (H) D轴电感
//#define LQ                              (0.00001423*2.0)  //(0.0022)              // (H) Q轴电感
//#define RS                             	(0.01371*0.9)                                // (Ω) 相电阻
//#define Ke                              (0.144835*1.2)	      //18   18.0 *0.4


/*电机参数值-------------------------------------------------------------------*/// 蓝威电机
//#define Pole_Pairs                      (2.0)                                     // 极对数
//#define LD                              (0.00002605*1.0)  // (0.0022)             // (H) D轴电感
//#define LQ                              (0.00002605*1.0)  //(0.0022)              // (H) Q轴电感
//#define RS                             	(0.032*1.0)                                // (Ω) 相电阻
//#define Ke                              (0.1425*1.0)	      //18   18.0 *0.4


 #define MOTOR_SPEED_BASE               (160000.0)                                // (RPM) 速度基准
 
/*硬件板子参数设置值------------------------------------------------------------*/
 /*PWM high or low level Mode*/
 /*根据驱动芯片的类型选择，大部分芯片为High_Level*/
 #define High_Level                     (0)                                     // 驱动高电平有效
 #define Low_Level                      (1)                                     // 驱动低电平有效
 #define UP_H_DOWN_L                    (2)                                     // 上桥臂高电平有效，下桥臂低电平有效
 #define UP_L_DOWN_H                    (3)                                     // 上桥臂低电平有效，下桥臂高电平有效
 #define PWM_Level_Mode                 (UP_H_DOWN_L)

 /*hardware current sample Parameter*/
 /*电流基准的电路参数*/
 /*weizhen*/
 #define HW_RSHUNT                      (0.01)                                 	// (Ω)  采样电阻
 #define HW_ADC_REF                     (4.5)                                   // (V)  ADC参考电压
 #define HW_AMPGAIN                     (10.0) //(10.0)                                   // 运放放大倍数
 /* current set value */

 /*hardware voltage sample Parameter*/
 /*母线电压采样分压电路参数*/
 #define RV1                            (10.0)                                 // (kΩ) 母线电压分压电阻1
 #define RV2                            (10.0)                                 // (kΩ) 母线电压分压电阻2
 #define RV3                            (1.0)                                   // (kΩ) 母线电压分压电阻3
 #define VC1                            (1.0)                                   // 电压补偿系数
 #define RV                             ((RV1 + RV2 + RV3) / RV3)               // 分压比
 #define HW_BOARD_VOLT_MAX              (HW_ADC_REF * RV)                       // (V)  ADC可测得的最大母线电压
/*时间设置值-------------------------------------------------------------------*/
 #define Calib_Time                     (1000)                                  // 校正次数，固定1000次，单位:次
 #define Charge_Time                    (20)                                     // (ms) 预充电时间，单位：ms
 #define Align_Time                     (0)                                     // (ms) 预定位时间，单位：ms
/*正常运行时估算算法的参数设置值-------------------------------------------------*/
 #define OBS_KSLIDE                     _Q15(0.85)                              // SMO算法里的滑膜增益值
 #define E_BW_Wind                      (600.0)//(BASE_FREQ*2)                  // PLL算法里的反电动势滤波值
 
 #define E_BW                           (400.0)//(BASE_FREQ*2)                  // PLL算法里的反电动势滤波值
/*逆风判断时的估算算法设置值-----------------------------------------------------*/
 #define TailWind_Time                  (100)                                   // (ms) 顺逆风检测时间
 #define ATO_BW_Wind                    (120.0)//120.0-PLL 120.0-smo            // 逆风判断观测器带宽的滤波值，经典值为8.0-100.0
 #define SPD_BW_Wind                    (10.0)//10.0-PLL  ,10.0-smo             // 逆风判断速度带宽的滤波值，经典值为5.0-40.0

 /**逆风顺风状态下的KP、KI****/
 #define DQKP_TailWind                  _Q12(0.8)                               //_Q12(1.0)-PLL ,   _Q12(1.5)   -smo
 #define DQKI_TailWind                  _Q15(0.01)                              //_Q15(0.08)-PLL  ,_Q15(0.2)-smo
/*启动参数参数值----------------------------------------------------------------*/
 /*********** RPD parameter ***********/
 /******* 初始位置检查参数 **********/
 #define PosCheckEnable                 (0)                                     // 初始位置使能
 #define AlignTestMode                  (0)                                     // 预定位测试模式
 /*脉冲注入时间长于2ms 或 低于2ms*/
 #define Long_Inject                    (0)                                     // 脉冲注入时间长于2ms,若时间长于4ms，则要修改定时器分频
 #define Short_Inject                   (1)                                     // 脉冲注入时间低于2ms
 #define InjectTime                     (Short_Inject)

 #define RPD_Time                       (3)                                     // (ms) 每次RPD的时间
 #define RPD_CurValue                   (6.5)                                   // (A)  RPD过流值
 #define DAC_RPDCurValue                _Q7(I_ValueX(RPD_CurValue * 2))

 /***预定位的Kp、Ki****/
 #define DQKP_Alignment                 _Q12(0.5)                               // 预定位的KP
 #define DQKI_Alignment                 _Q12(0.008)                              // 预定位的KI
 #define ID_Align_CURRENT               I_Value(0.0)                            // (A) D轴定位电流
 #define IQ_Align_CURRENT               I_Value(0.05)                            // (A) Q轴定位电流
 #define Align_Angle                    (0)                                   // (°) 预定位角度

 /***启动电流****/
 #define ID_Start_CURRENT               I_Value(0.0)                            // (A) D轴启动电流
 #define IQ_Start_CURRENT               I_Value(11.0)    //7.9      12.0                  // (A) Q轴启动电流

 /***运行电流****/
 #define ID_RUN_CURRENT                 I_Value(0.0)                            // (A) D轴运行电流
 #define IQ_RUN_CURRENT                 I_Value(10.0)                            // (A) Q轴运行电流

 /***限制电流****/
 #define LIMIT_MIN_CURRENT              I_Value(0.10)                           // (A) Q轴限制电流

 ///********Omega启动的参数**********/

 #define ATO_BW                         (50.0)                                  // 观测器带宽的滤波值，经典值为1.0-200.0

// #define ATO_BW_RUN                     (50.0)
// #define ATO_BW_RUN1                    (160.0)
// #define ATO_BW_RUN2                    (220.0)
// #define ATO_BW_RUN3                    (300.0)
// #define ATO_BW_RUN4                    (400.0)

 #define ATO_BW_RUN                     (50.0)
 #define ATO_BW_RUN1                    (70.0)
 #define ATO_BW_RUN2                    (110.0)
 #define ATO_BW_RUN3                    (150.0)
 #define ATO_BW_RUN4                    (180.0)

 #define SPD_BW                         (15.0)                                  // 速度带宽的滤波值，经典值为5.0-40.0
 #define ATT_COEF                       (0.85)                                  // 无需改动
/*转速参数值-------------------------------------------------------------------*/
 /* motor start speed value */
 //open 算法启动参数
 #define MOTOR_OPEN_ACC                 (200)                                  // 强拖启动的增量(每载波周期加一次)
 #define MOTOR_OPEN_ACC_MIN             (0)                                   // 强拖启动的初始速度
 #define MOTOR_OPEN_ACC_CNT             (100)                                 // 强拖启动的执行次数(MOTOR_OPEN_ACC_CNT*256)
 #define MOTOR_OPEN_ACC_CYCLE           (1)                                     // 强拖启动循环拖动的次数

 //OMEGA启动参数
 #define Motor_Omega_Ramp_ACC_Antiwind  (1.0)                                   // omega启动的增量   12
 #define Motor_Omega_Ramp_ACC           (2.0)                                   // 12 omega启动的增量   12
 #define MOTOR_OMEGA_ACC_MIN            (400.0)                                  // 400 (RPM) omega启动的最小切换转速
 #define MOTOR_OMEGA_ACC_END            (2000.0)                                  // 1000 (RPM) omega启动的限制转速

 /* motor loop control speed value */
 #define MOTOR_LOOP_RPM                 (3000.0)                                 // 2000 (RPM) 由mode 0到mode1切换转速，即闭环切换转速

 /* motor run speed value */
 //电机运行时最大最小转速、堵转保护转速
 #define MOTOR_SPEED_SMOMIN_RPM         (4080.0)                                 // (RPM) SMO运行最小转速
 #define MOTOR_SPEED_MIN_RPM            (15000.0)                                // (RPM) 运行最小转速
 #define MOTOR_SPEED_MAX_RPM            (30000.0)                                // (RPM) 运行最大转速
 #define MOTOR_SPEED_LIMIT_RPM          (5000.0)
 #define MOTOR_SPEED_STAL_MAX_RPM       (3500.0)                                // (RPM) 堵转保护转速
 #define MOTOR_SPEED_STAL_MIN_RPM       (45.0)
 

// #define MOTOR_SPEED_STOP_RPM           (20000.0)                                 // (RPM) 运行最小转速

 #define Motor_Max_Power                (6000)//5500 --> 450W  4900 --> 400W  2636 10.2A
 #define Motor_Min_Power                (320)// 320-->65W 
 
/*电机开机、关机的设置----------------------------------------------------------*/
 /* motor ON/0FF value */
 #define OFFPWMDuty                     _Q15(0.09)                              // 关机PWM占空比，小于该占空比关机                                                                                //关机PWM占空比，小于该占空比时关机
 #define OFFPWMDutyHigh                 _Q15(1.0)                               // 关机PWM占空比，大于该占空比关机
 #define ONPWMDuty                      _Q15(0.15)                              // 开机PWM占空比，大于该占空比时开机
 #define MINPWMDuty                     _Q15(0.1)                              // 速度曲线上最小PWM占空比
 #define MAXPWMDuty                     _Q15(0.85)                               // 速度曲线上最大PWM占空比
 #define MAXPWMOFFDuty                  _Q15(0.90)                               // 速度曲线上最大PWM占空比 

 /*******运行时的参数*****************/
/*电流环参数设置值--------------------------------------------------------------*/
 #define DQKPStart                      _Q12(1.0)                               // DQ轴KP
 #define DQKIStart                      _Q15(0.005)                              // DQ轴KI

 #define DQKP                           _Q12(0.5)                               // DQ轴KP 0.5
 #define DQKI                           _Q15(0.005)                              // DQ轴KI 0.05
 /* D轴参数设置 */
 #define DOUTMAX                        _Q15(0.2)                              //0.6 D轴最大限幅值，单位：输出占空比
 #define DOUTMIN                        _Q15(-0.2)                             // 0.6 D轴最小限幅值，单位：输出占空比
 /* Q轴参数设置，默认0.99即可 */
 #define QOUTMAX                        _Q15(0.95)                              //0.78 Q轴最大限幅值，单位：输出占空比
 #define QOUTMIN                        _Q15(-0.95)                             // Q轴最小限幅值，单位：输出占空比
 #define QOUTINC                        (2)                                    // Q轴电流增大步进值,开环控制时有效
 #define QOUTCURRENT                    (19.0) //15.0 before  23-25.2V 18.2A  22.5- 25.2V 17.1A // (A) Q轴输出电流,开环控制时有效
 #define QOUTVALUE                    I_Value(QOUTCURRENT) //I_Value(10.0)
/*外环参数设置值----------------------------------------------------------------*/
 #define SPEED_LOOP_TIME                (2)                                    // 0 (ms) 速度环调节周期 风扇速度环50，功率环5

 #define SKP                            _Q12(1.0)                               // 外环KP 2.93
 #define SKI                            _Q12(0.01)                              // 外环KI  0.02

 #define SOUTMAX                        I_Value(20.0)                           // (A) 外环最大限幅值
 #define SOUTMIN                        I_Value(0.00)                           // (A) 外环最小限幅值

 #define SPEED_INC                      (800.0)                                  // 速度环增量
 #define SPEED_DEC                      (800.0)                                  // 速度环减量

 /*外环使能*/
 #define OUTLoop_Disable                (0)                                     // 关闭外环
 #define OUTLoop_Enable                 (1)                                     // 使能外环
 #define OUTLoop_Mode                   (OUTLoop_Enable)

 /*外环选择功率环或速度环*/
 #define POWER_LOOP_CONTROL             (0)                                     //恒功率
 #define SPEED_LOOP_CONTROL             (1)                                     //恒转速
 #define Motor_Speed_Control_Mode       (POWER_LOOP_CONTROL)

 //调速模式
 #define PWMMODE                        (0)                                     // PWM调速
 #define SREFMODE                       (1)                                     // 模拟调速
 #define NONEMODE                       (2)                                     // 直接给定值，不调速
 #define SPEED_MODE                     (PWMMODE)
/*模式选择设置值----------------------------------------------------------------*/
 /*IPM测试模式*/
 #define IPMtest                        (0)                                     // IPM测试或者MOS测试，MCU输出固定占空比
 #define NormalRun                      (1)                                     // 正常按电机状态机运行
 #define IPMState                       (NormalRun)

 /*估算器模式选择*/
 #define SMO                            (0)                                     // SMO ,滑膜估算
 #define PLL                            (1)                                     // PLL ,锁相环
 #define EstimateAlgorithm              (SMO)

 /*顺逆风判断设置*/
 #define NoTailWind                     (0)                                     // 无逆风顺风判断
 #define TailWind                       (1)                                     // 逆风顺风判断
 #define TailWind_Mode                  (TailWind)

 /*顺逆风判断方法*/
 #define RSDMethod                      (0)                                     // RSD比较器方法
 #define BEMFMethod                     (1)                                     // BEMF方法
 #define FOCMethod                      (2)                                     // FOC计算方法
 #define FRDetectMethod                 (BEMFMethod)

 /*开环启动模式选择*/
 #define Open_Start                     (0)                                     // 开环强拖启动
 #define Omega_Start                    (1)                                     // Omega启动
 #define Open_Omega_Start               (2)                                     // 先开环启，后Omega启动
 #define Open_Start_Mode                (Omega_Start)

 /*电流采样模式*/
 #define Single_Resistor                (0)                                     // 单电阻电流采样模式
 #define Double_Resistor                (1)                                     // 双电阻电流采样模式
 #define Three_Resistor                 (2)                                     // 三电阻电流采样模式
 #define Shunt_Resistor_Mode            (Single_Resistor)

 #define OverModulation                 (0)                                     // 0-禁止过调制，1-使能过调制
 #define IRMODE                         (1)                                     // 正反转模式，正转为0，反转为1
/*保护参数值-------------------------------------------------------------------*/
 /*硬件过流保护*/
 #define Hardware_FO_Protect            (1)                                     // 硬件FO过流保护使能，适用于IPM有FO保护的场合
 #define Hardware_CMP_Protect           (2)                                     // 硬件CMP比较过流保护使能，适用于MOS管应用场合
 #define Hardware_FO_CMP_Protect        (3)                                     // 硬件CMP比较和FO过流保护都使能
 #define Hardware_Protect_Disable       (4)                                     // 硬件过流保护禁止，用于测试
 #define HardwareCurrent_Protect        (Hardware_CMP_Protect)                  // 硬件过流保护实现方式

 /*硬件过流保护比较值来源*/
 #define Compare_DAC                    (0)                                     // DAC设置硬件过流值
 #define Compare_Hardware               (1)                                     // 硬件设置硬件过流值
 #define Compare_Mode                   (Compare_DAC)                           // 硬件过流值的来源

 #define OverHardcurrentValue           (150.0)                                   // (A) DAC模式下的硬件过流值 Imax = 112.5A

 /*软件过流保护*/
 #define OverSoftCurrentValue           I_Value(50.0)                            // (A) 软件过流值 “27”---17A

 /*过流恢复*/
 #define CurrentRecoverEnable           (0)                                     // 过流保护使能位, 0，不使能；1，使能
 #define OverCurrentRecoverTime         (1000)                                  // (ms) 过流保护恢复时间

 #define VoltageProtectEnable           (1)                                     // 电压保护，0,不使能；1，使能
 #define StartProtectEnable             (0)                                     // 启动保护，0,不使能；1，使能
 #define StallProtectEnable             (0)                                     // 堵转保护，0,不使能；1，使能
 #define PhaseLossProtectEnable         (1)                                     // 缺相保护，0,不使能；1，使能

 /*过欠压保护*/
 #define Over_Protect_Voltage           (36.0)                                    // (V) 直流电压过压保护值 32
 #define Over_Recover_Vlotage           (37.0)                                    // 不用恢复(V) 直流电压过压保护恢复值 27
 #define Under_Protect_Voltage          (20.0)                                  // (V) 直流电压欠压保护值 17.5
 #define Under_Recover_Vlotage          (21.0)                                  // (V) 直流电压欠压保护恢复值 18.5

 /*缺相保护*/
 #define PhaseLossCurrentValue          I_Value(1.8)                            // (A)  缺相电流值
 #define PhaseLossRecoverTime           (600)                                   // (ms) 缺相保护时间

 /*堵转保护*/
 #define StallCurrentValue1             I_Value(4.4)                            // (A)  堵转过流值
 #define StallRecoverTime               (1000)                                  // (ms) 启动运行时间
 
 /*NTC过温保护*/
 #define 	TemperatureProtectEnable		(1)														       // Æô¶¯±£»¤£¬0,²»Ê¹ÄÜ£»1£¬Ê¹ÄÜ
 /**********
 90--3.9K    85--4.5K   80--5.5K   75--6.5K 
 70--7.5K    60--11.0K  50--17.0K  40--25.0K  30--37.0K
 **********/
 #define   Tempera_Value(NTC_Value) 		_Q15((5.0*NTC_Value/(4.7+NTC_Value))/4.5)											 // 10K上拉电阻时，NTC阻值对应Q15_AD值，单位：KΩ

 #define   OVER_Temperature 		       	Tempera_Value(1.67)										 // 过温保护阈值，		根据NTC曲线设定，10K上拉电阻，80℃
 #define   UNDER_Temperature          	Tempera_Value(2.23)										 // 过温保护恢复阈值，根据NTC曲线设定，10K上拉电阻，70℃
 #define 	 OverTemperRecoverTime			  300													           // 过温保护温度恢复后，重启等待时间，单位：ms

 /*堵转超速保护*/
 #define 	OverSpeedProtectEnable		(1)	
 
 #define	 MOTOR_SPEED_OVER_RPM						(95000)                               	// (RPM) 堵转保护最大速度
 #define	 MOTOR_SPEED_OVER_RecoverRPM		(60000)                               	// (RPM) 堵转保护最大速度
 
 #define	 OVER_SpeedRecoverTime				 300
 

 /*启动保护*/
 #define StartProtectRestartTimes       (5)                                     // 启动保护重启次数，单位：次

 /******启停测试参数******/
 #define StartONOFF_Enable              (0)
 #define StartON_Time                   (10000)                                  // (ms) 启动运行时间
 #define StartOFF_Time                  (6000)                                  // (ms) 停止时间

 #define StopBrakeFlag                  (1)
 #define StopWaitTime                   (1000)                                  // (ms)  刹车时间
 #define MOTOR_SPEED_STOP_RPM           (15000.0)                               // (RPM) 刹车速度

#endif
