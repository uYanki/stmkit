return uartData:gsub("\\r","\r"):gsub("\\n","\n")
--这个是加上换行回车
