return uartData:fromHex()
--这是表示输入值为16进制数

--比如31 32 33 34
--会被处理成1234