/********************************** (C) COPYRIGHT *******************************
* File Name          : main.c
* Author             : WCH
* Version            : V1.0.0
* Date               : 2021/06/06
* Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/

/*
 *@Note
 USART Print debugging routine:
 USART1_Tx(PA9).
 This example demonstrates using USART1(PA9) as a print debug port output.

*/

#include "debug.h"
//#include "ch32v30x_usbfs_device.h"

/* Global typedef */

/* Global define */

/* Global Variable */
void cdc_acm_multi_init(void);

/*********************************************************************
 * @fn      GPIO_Toggle_INIT
 *
 * @brief   Initializes GPIOA.0
 *
 * @return  none
 */
void GPIO_Toggle_INIT(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

#define T_COUNT_MAX     5000000
/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
extern volatile uint8_t cdc_dev_configured;
int main(void)
{
    int t = 0;
    int n = 0;

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	SystemCoreClockUpdate();
	Delay_Init();
	USART_Printf_Init(115200);	
	printf("SystemClk:%d\r\n",SystemCoreClock);
	printf( "ChipID:%08x\r\n", DBGMCU_GetCHIPID() );
	printf("This is printf example\r\n");
	LogFlushOut();

	GPIO_Toggle_INIT();

    /* USB20 device init */
    printf("initial USB\r\n");
    LogFlushOut();
    //USBFS_RCC_Init( );
    //USBFS_Device_Init( ENABLE );
    cdc_acm_multi_init();

	while(1)
    {
	    t++;
	    if ( t == (T_COUNT_MAX>>1) )
	    {
            GPIO_SetBits(GPIOC, GPIO_Pin_4);
            GPIO_ResetBits(GPIOC, GPIO_Pin_5);
            LogFlushOut();
	    }
	    else if ( t == T_COUNT_MAX )
	    {
            t = 0;
            GPIO_ResetBits(GPIOC, GPIO_Pin_4);
            GPIO_SetBits(GPIOC, GPIO_Pin_5);
            if ( 0==cdc_dev_configured )
            {
                if ( ++n >= 2 )
                {
                    n = 0;
                    printf("cdc_dev_configured=0\r\n");
                }
            }
            LogFlushOut();
	    }
	    else if ( t > T_COUNT_MAX )
	    {
	        t = 0;
	    }
	}
}

