# ChangeLog

## v0.0.3 - 2023-09-06

* Rename component name to `cherryusb_esp32` to keep consistency with upstream

## v0.0.2 - 2023-09-05

* Fix github build action

## v0.0.1 - 2023-09-04

* Initial release based on CherryUSB v0.10.1
* Examples:
    * Add `device/cherryusb_device_cdc` example
