# Change Log

## [1.0.0] - 2024-03-28:

All changes

### Added
  - first commit
  - [feat] update samples/hpm/barebone_uart, use uart isr recv
  - [feat] add samples/hpm/freertos_uart, use uart isr recv
