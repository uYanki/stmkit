# game

![version](https://img.shields.io/badge/version-1.0.0-brightgreen.svg)
![standard](https://img.shields.io/badge/standard-c99-brightgreen.svg)
![build](https://img.shields.io/badge/build-2021.07.18-brightgreen.svg)
![license](https://img.shields.io/badge/license-MIT-brightgreen.svg)

## 简介

这是一个仅供娱乐的组件，移植了几个命令行的游戏

| 游戏 | 来源                                             |
| ---- | ------------------------------------------------ |
| 2048 | [mevdschee/2048](https://github.com/mevdschee/2048.c) |
