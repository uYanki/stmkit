autoreconf --install || exit 1
