Air601公测固件的说明

首先感谢各位参与固件公测, 如有任何问题或建议请访问下列网站进行反馈

issue反馈: https://gitee.com/openLuat/LuatOS/issues

固件基本情况:
1. LuatOS-SoC_V1020_AIR601.soc 是测试用的固件包, 支持Air601开发板, 使用LuaTools刷机
2. 本固件为测试用途
3. 固件已开启的功能有: socket/http/mqtt/websocket 等网络库及基础外设库
4. 库文件与其soc固件一样, 通用的, 可以通刷
5. 测试wifi相关功能, 可参考 demo/wlan, 均通用
6. 配网仅支持airkiss, 当前不支持esptouch或蓝牙配网


关于测试脚本:
1. main.lua 和 rtkv.lua 已包含http测试和数据上报功能
2. 联网后可以根据日志查看数据页面 http://rtkv.air32.cn/d/XXX 其中XXX是设备的MAC地址

硬件软件基本信息:
1. 内核XT804, 最高主频240M
2. 当前测试固件的可用内存是 72k
3. 文件系统可用大小是 48k
4. 脚本区大小是 64k
