
-- LuaTools需要PROJECT和VERSION这两个信息
PROJECT = "rtkvdemo"
VERSION = "1.0.0"

--[[
本demo需要http库, 大部分能联网的设备都具有这个库
http也是内置库, 无需require
]]

-- sys库是标配
_G.sys = require("sys")
--[[特别注意, 使用http库需要下列语句]]
_G.sysplus = require("sysplus")

rtkv = require "rtkv"

if mcu then
    mcu.setClk(240)
end


sys.taskInit(function()
    -----------------------------
    -- 统一联网函数, 可自行删减
    ----------------------------
    if wlan and wlan.connect then
        -- wifi 联网, ESP32系列均支持
        local ssid = "luatos1234"
        local password = "12341234"
        log.info("wifi", ssid, password)
        -- LED = gpio.setup(12, 0, gpio.PULLUP)
        wlan.init()
        wlan.setMode(wlan.STATION)
        wlan.connect(ssid, password, 1)
        local result, data = sys.waitUntil("IP_READY", 1200000)
        log.info("wlan", "IP_READY", result, data)
    end
    log.info("已联网")
    sys.publish("net_ready")
end)

sys.taskInit(function()
    sys.waitUntil("net_ready")
    sys.wait(100)
    rtkv.setup()
    adc.open(adc.CH_CPU)
    adc.open(adc.CH_VBAT)
    while 1 do
        -- local ok = rtkv.set("vbat", adc.get(adc.CH_VBAT))
        -- ok = ok and rtkv.set("cputemp", adc.get(adc.CH_CPU))
        local data = {
            vbat = adc.get(adc.CH_VBAT),
            cputemp = adc.get(adc.CH_CPU),
            uptime = mcu.ticks(),
            bsp = rtos.bsp()
        }
        local total, used, max_used = rtos.meminfo()
        data["mem_lua_used"] = used
        data["mem_lua_max"] = max_used
        local total, used, max_used = rtos.meminfo("sys")
        data["mem_sys_used"] = used
        data["mem_sys_max"] = max_used
        local ok = rtkv.sets(data)
        log.info("rtkv", "上报结果", ok)
        sys.wait(5000)
    end
end)


-- 用户代码已结束---------------------------------------------
-- 结尾总是这一句
sys.run()
-- sys.run()之后后面不要加任何语句!!!!!
