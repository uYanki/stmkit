################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Lib/Debug/Debug.c \
../Lib/Debug/printf_gcc.c 

OBJS += \
./Lib/Debug/Debug.o \
./Lib/Debug/printf_gcc.o 

C_DEPS += \
./Lib/Debug/Debug.d \
./Lib/Debug/printf_gcc.d 


# Each subdirectory must supply rules for building sources it contributes
Lib/Debug/%.o Lib/Debug/%.su: ../Lib/Debug/%.c Lib/Debug/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/BSP" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/Commons" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/Debug" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/User" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/User/SnakeGame" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Lib-2f-Debug

clean-Lib-2f-Debug:
	-$(RM) ./Lib/Debug/Debug.d ./Lib/Debug/Debug.o ./Lib/Debug/Debug.su ./Lib/Debug/printf_gcc.d ./Lib/Debug/printf_gcc.o ./Lib/Debug/printf_gcc.su

.PHONY: clean-Lib-2f-Debug

