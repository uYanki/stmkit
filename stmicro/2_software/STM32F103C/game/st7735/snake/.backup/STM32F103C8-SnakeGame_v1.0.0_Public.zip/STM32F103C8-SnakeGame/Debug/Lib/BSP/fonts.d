Lib/BSP/fonts.o: ../Lib/BSP/fonts.c ../Lib/BSP/fonts.h
../Lib/BSP/fonts.h:
