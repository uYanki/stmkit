Lib/BSP/Fonts/font24.o: ../Lib/BSP/Fonts/font24.c \
 ../Lib/BSP/Fonts/fonts.h
../Lib/BSP/Fonts/fonts.h:
