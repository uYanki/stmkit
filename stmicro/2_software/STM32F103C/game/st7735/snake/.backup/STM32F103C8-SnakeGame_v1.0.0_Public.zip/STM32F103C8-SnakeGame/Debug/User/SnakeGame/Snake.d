User/SnakeGame/Snake.o: ../User/SnakeGame/Snake.c \
 ../User/SnakeGame/Snake.h
../User/SnakeGame/Snake.h:
