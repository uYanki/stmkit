User/SnakeAssets.o: ../User/SnakeAssets.c ../User/Snake.h
../User/Snake.h:
