################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Lib/BSP/Fonts/font12.c \
../Lib/BSP/Fonts/font16.c \
../Lib/BSP/Fonts/font20.c \
../Lib/BSP/Fonts/font24.c \
../Lib/BSP/Fonts/font8.c 

OBJS += \
./Lib/BSP/Fonts/font12.o \
./Lib/BSP/Fonts/font16.o \
./Lib/BSP/Fonts/font20.o \
./Lib/BSP/Fonts/font24.o \
./Lib/BSP/Fonts/font8.o 

C_DEPS += \
./Lib/BSP/Fonts/font12.d \
./Lib/BSP/Fonts/font16.d \
./Lib/BSP/Fonts/font20.d \
./Lib/BSP/Fonts/font24.d \
./Lib/BSP/Fonts/font8.d 


# Each subdirectory must supply rules for building sources it contributes
Lib/BSP/Fonts/%.o Lib/BSP/Fonts/%.su: ../Lib/BSP/Fonts/%.c Lib/BSP/Fonts/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/BSP" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/Commons" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/Debug" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/User" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/User/SnakeGame" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Lib-2f-BSP-2f-Fonts

clean-Lib-2f-BSP-2f-Fonts:
	-$(RM) ./Lib/BSP/Fonts/font12.d ./Lib/BSP/Fonts/font12.o ./Lib/BSP/Fonts/font12.su ./Lib/BSP/Fonts/font16.d ./Lib/BSP/Fonts/font16.o ./Lib/BSP/Fonts/font16.su ./Lib/BSP/Fonts/font20.d ./Lib/BSP/Fonts/font20.o ./Lib/BSP/Fonts/font20.su ./Lib/BSP/Fonts/font24.d ./Lib/BSP/Fonts/font24.o ./Lib/BSP/Fonts/font24.su ./Lib/BSP/Fonts/font8.d ./Lib/BSP/Fonts/font8.o ./Lib/BSP/Fonts/font8.su

.PHONY: clean-Lib-2f-BSP-2f-Fonts

