Lib/BSP/Fonts/font8.o: ../Lib/BSP/Fonts/font8.c ../Lib/BSP/Fonts/fonts.h
../Lib/BSP/Fonts/fonts.h:
