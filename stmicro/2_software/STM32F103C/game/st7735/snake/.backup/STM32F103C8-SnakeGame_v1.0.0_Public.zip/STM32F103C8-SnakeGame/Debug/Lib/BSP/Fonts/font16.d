Lib/BSP/Fonts/font16.o: ../Lib/BSP/Fonts/font16.c \
 ../Lib/BSP/Fonts/fonts.h
../Lib/BSP/Fonts/fonts.h:
