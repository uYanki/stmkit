Lib/Debug/Debug.o: ../Lib/Debug/Debug.c
