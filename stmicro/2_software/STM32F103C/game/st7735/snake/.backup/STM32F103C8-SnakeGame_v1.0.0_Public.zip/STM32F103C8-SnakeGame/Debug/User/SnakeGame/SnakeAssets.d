User/SnakeGame/SnakeAssets.o: ../User/SnakeGame/SnakeAssets.c \
 ../User/SnakeGame/Snake.h
../User/SnakeGame/Snake.h:
