Lib/BSP/Fonts/font12.o: ../Lib/BSP/Fonts/font12.c \
 ../Lib/BSP/Fonts/fonts.h
../Lib/BSP/Fonts/fonts.h:
