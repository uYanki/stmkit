################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (10.3-2021.10)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../User/UserMain.c 

OBJS += \
./User/UserMain.o 

C_DEPS += \
./User/UserMain.d 


# Each subdirectory must supply rules for building sources it contributes
User/%.o User/%.su: ../User/%.c User/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/BSP" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/Commons" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/Lib/Debug" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/User" -I"D:/Workspace/STM32CubeIDE/STM32F103C8-SnakeGame/User/SnakeGame" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-User

clean-User:
	-$(RM) ./User/UserMain.d ./User/UserMain.o ./User/UserMain.su

.PHONY: clean-User

