Lib/Debug/printf_gcc.o: ../Lib/Debug/printf_gcc.c
