Lib/BSP/Fonts/font20.o: ../Lib/BSP/Fonts/font20.c \
 ../Lib/BSP/Fonts/fonts.h
../Lib/BSP/Fonts/fonts.h:
