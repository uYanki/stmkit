.\output\debug\air001xx_it.o: ..\Src\air001xx_it.c
.\output\debug\air001xx_it.o: ..\Inc\main.h
.\output\debug\air001xx_it.o: T:\keil\MDK536\ARM\ARMCC\Bin\..\include\stdio.h
.\output\debug\air001xx_it.o: T:\keil\MDK536\ARM\ARMCC\Bin\..\include\stdint.h
.\output\debug\air001xx_it.o: T:\keil\MDK536\ARM\ARMCC\Bin\..\include\stdbool.h
.\output\debug\air001xx_it.o: ..\Inc\air001xx_it.h
