.\output\debug\air001xx_hal_msp.o: ..\Src\air001xx_hal_msp.c
.\output\debug\air001xx_hal_msp.o: ..\Inc\main.h
.\output\debug\air001xx_hal_msp.o: T:\keil\MDK536\ARM\ARMCC\Bin\..\include\stdio.h
.\output\debug\air001xx_hal_msp.o: T:\keil\MDK536\ARM\ARMCC\Bin\..\include\stdbool.h
