/*!
 * @file        apm32e10x_it.c
 *
 * @brief       Main Interrupt Service Routines
 *
 * @version     V1.0.0
 *
 * @date        2021-07-26
 *
 */

#include "main.h"
#include "apm32e10x_it.h"

uint32_t g_time_tick;
/*!
 * @brief   This function handles NMI exception   
 *
 * @param   None
 *
 * @retval  None
 *
 */     
void NMI_Handler(void)
{
}

/*!
 * @brief   This function handles Hard Fault exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */ 
void HardFault_Handler(void)
{
    /* Go to infinite loop when Hard Fault exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles Memory Manage exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */
void MemManage_Handler(void)
{
    /* Go to infinite loop when Memory Manage exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles Bus Fault exception  
 *
 * @param   None
 *
 * @retval  None
 *
 */
void BusFault_Handler(void)
{
    /* Go to infinite loop when Bus Fault exception occurs */
    while (1)
    {
    }
}
/*!
 * @brief   This function handles Usage Fault exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void UsageFault_Handler(void)
{
    /* Go to infinite loop when Usage Fault exception occurs */
    while (1)
    {
    }
}

/*!
 * @brief   This function handles SVCall exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void SVC_Handler(void)
{
}

/*!
 * @brief   This function handles Debug Monitor exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void DebugMon_Handler(void)
{
}

/*!
 * @brief   This function handles PendSV_Handler exception 
 *
 * @param   None
 *
 * @retval  None
 *
 */

void PendSV_Handler(void)
{
}

/*!
 * @brief   This function handles SysTick Handler 
 *
 * @param   None
 *
 * @retval  None
 *
 */
void SysTick_Handler(void)
{
	if(g_time_tick)	g_time_tick --;
}


/*!
 * @brief   This function handles External USB wakeup request
 *
 * @param   None
 *
 * @retval  None
 *
 */
void USBDWakeUp_IRQHandler(void)
{
    EINT_ClearIntFlag(EINT_LINE_18);
}
