./objects/usb_glue_st.o: ..\..\common\cherryusb\port\dwc2\usb_glue_st.c \
  ..\Core\Inc\usb_config.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ..\..\common\cherryusb\port\dwc2\usb_dwc2_reg.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Device\ST\STM32H7xx\Include\stm32h7xx.h
