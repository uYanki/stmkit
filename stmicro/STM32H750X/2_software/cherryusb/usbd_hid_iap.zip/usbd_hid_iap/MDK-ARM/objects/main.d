./objects/main.o: ..\Core\Src\main.c ..\Core\Inc\main.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal.h \
  ..\Core\Inc\stm32h7xx_hal_conf.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_rcc.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_def.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Device\ST\STM32H7xx\Include\stm32h7xx.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Device\ST\STM32H7xx\Include\stm32h750xx.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Include\core_cm7.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Include\cmsis_version.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Include\cmsis_compiler.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Include\cmsis_armclang.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_compat.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_acle.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Include\mpu_armv7.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\CMSIS\Device\ST\STM32H7xx\Include\system_stm32h7xx.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stddef.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\math.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_rcc_ex.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_gpio.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_gpio_ex.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_dma.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_dma_ex.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_mdma.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_exti.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_cortex.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_flash.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_flash_ex.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_hsem.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_i2c.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_i2c_ex.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_pwr.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_pwr_ex.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_qspi.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_uart.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_uart_ex.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_pcd.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_ll_usb.h \
  C:\emkit\libc\stmicro\STM32Cube_FW_H7_V1.11.0\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_pcd_ex.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdio.h ..\IAP\flash_if.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdbool.h ..\IAP\partition.h \
  ..\IAP\flash_if.h ..\IAP\iap.h ..\IAP\gconf.h
