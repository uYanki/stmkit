./objects/partition.o: ..\IAP\partition.c ..\IAP\partition.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h ..\IAP\flash_if.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdbool.h
