./objects/usbd_hid.o: ..\..\common\CherryUSB\class\hid\usbd_hid.c \
  ..\..\common\cherryusb\core\usbd_core.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\string.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  ..\Core\Inc\usb_config.h ..\..\common\cherryusb\common\usb_util.h \
  ..\..\common\cherryusb\common\usb_errno.h \
  ..\..\common\cherryusb\common\usb_def.h \
  ..\..\common\cherryusb\common\usb_list.h \
  ..\..\common\cherryusb\common\usb_log.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdio.h \
  ..\..\common\cherryusb\common\usb_dc.h \
  ..\..\common\cherryusb\common\usb_memcpy.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stddef.h \
  ..\..\common\cherryusb\common\usb_version.h \
  ..\..\common\CherryUSB\class\hid\usbd_hid.h \
  ..\..\common\CherryUSB\class\hid\usb_hid.h
