./objects/iap.o: ..\IAP\iap.c \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdbool.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\string.h ..\IAP\iap.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h ..\IAP\gconf.h \
  ..\IAP\flash_if.h
