//file name:       top_fpga.v
//author:           ETree
//date:             2017.9.9
//function:        top file of project
//log:              led light

module top_fpga(
    //global signal
    input clk,  //50MHz
    input rst_n,//low active
	 
	 //TFT2.4
	 output tft_cs,				//液晶屏片选，低电平有效
	 output tft_wr,
	 output tft_rs,
	 output tft_rd,
	 output tft_reset,			//液晶屏复位，低电平有效
	 output [15:0] tft_data,
	 output tft_blk,				//液晶屏背光，高电平有效
	 //TFT Touch
	 output tft_tclk,
	 output tft_tcs,
	 output tft_tmosi,
	 input  tft_tmiso,
	 input  tft_tpen,
	 
	 //NET
	 output e_xi,
	 output e_txen,
	 output [1:0] e_tx,
 
	 input e_rxer,
	 input e_rxdv,
	 input e_rxclk,
	 input [1:0] e_rx,
	 
	 //STM32
	 //FSMC Bus
	 input [15:0] fsmc_data,
	 input fsmc_noe,
	 input fsmc_nwe,
	 input fsmc_nbl0,
	 input fsmc_nbl1,
	 input fsmc_ne1, 
	 input fsmc_a23,
	 input fsmc_a22,
	 input fsmc_a21,
	 input fsmc_a20,
	 input fsmc_a19,
	 input fsmc_a18,
	 input fsmc_a17,
	 input fsmc_a16,
	 input fsmc_nwait,
	 input fsmc_clk,
	 //STM32 RMII
	 input stm_rmii_txen,
	 input stm_rmii_txd0,
	 input stm_rmii_txd1,
	 output stm_rmii_refclk,
	 output stm_rmii_crsdv, 
	 output stm_rmii_rxd0,
	 output stm_rmii_rxd1,
	 //STM32
	 input stm_pb8,
	 
	 //uart
	 input uart_rx,
	 input uart_tx,
    
    //led
    output  led //high active
);

wire clk_25m;
wire locked;

mypll mypll_inst(
	.inclk0(clk),
	.c0(clk_25m),
	.locked(locked)
);

assign tft_blk = stm_pb8;
assign tft_reset = rst_n;
assign tft_data = fsmc_data;
assign tft_rd = fsmc_noe;
assign tft_wr = fsmc_nwe;
assign tft_rs = fsmc_a18;
assign tft_cs = fsmc_ne1;


assign e_xi = clk_25m;
assign e_txen = stm_rmii_txen;
assign e_tx[0] = stm_rmii_txd0;
assign e_tx[1] = stm_rmii_txd1;
assign stm_rmii_crsdv = e_rxdv;
assign stm_rmii_rxd0 = e_rx[0];
assign stm_rmii_rxd1 = e_rx[1];
assign stm_rmii_refclk = e_rxclk;


 
endmodule

