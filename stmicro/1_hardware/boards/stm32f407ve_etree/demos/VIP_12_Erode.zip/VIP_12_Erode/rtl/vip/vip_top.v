//file name:	vip_top.v
//author:      shugen.yin
//date:		   2017.10.18
//function:		VIP top file
//log:

module vip_top(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output cmos_href_o,
	output cmos_vsync_o,
	output [7:0] cmos_data_o
);

wire [10:0] v_cnt;
wire cmos_href_gray;
wire cmos_vsync_gray;
wire [7:0] cmos_data_gray;

gray gray_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync) ,	// input  cmos_vsync_sig
	.cmos_data(cmos_data) ,	// input [7:0] cmos_data_sig
	.v_cnt(v_cnt),
	.cmos_href_o(cmos_href_gray) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_gray) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_gray) 	// output [7:0] cmos_data_o_sig
);

wire cmos_href_sobel;
wire cmos_vsync_sobel;
wire [7:0] cmos_data_sobel;

filter_sobel filter_sobel_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href_gray) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync_gray) ,	// input  cmos_vsync_sig
	.cmos_data(cmos_data_gray) ,	// input [7:0] cmos_data_sig
	.cmos_href_o(cmos_href_sobel) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_sobel) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_sobel) 	// output [7:0] cmos_data_o_sig
);

wire cmos_href_erode;
wire cmos_vsync_erode;
wire [7:0] cmos_data_erode;

filter_erode filter_erode_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href_sobel) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync_sobel) ,	// input  cmos_vsync_sig
	.cmos_data(cmos_data_sobel) ,	// input [7:0] cmos_data_sig
	.cmos_href_o(cmos_href_erode) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_erode) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_erode) 	// output [7:0] cmos_data_o_sig
);

assign cmos_vsync_o = cmos_vsync_erode;
assign cmos_data_o  = (v_cnt==0)?0:cmos_data_erode;
assign cmos_href_o  = cmos_href_erode;


endmodule
