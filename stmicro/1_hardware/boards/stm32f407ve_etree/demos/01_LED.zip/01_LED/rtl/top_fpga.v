//file name:       top_fpga.v
//author:           ETree
//date:             2017.9.9
//function:        top file of project
//log:              led light

module top_fpga(
    //global signal
    input clk,  //50MHz
    input rst_n,//low active
    
    //led
    output  led //high active
);

//寄存器定义
reg [31:0] timer=0;
reg led_r=0;

assign led = led_r;

always @(posedge clk or negedge rst_n)
    if (~rst_n)
        timer <= 0; //计数器清零
    else if (timer == 32'd49_999_999) //0.5 秒计数(50M-1=49_999_999)
        timer <= 0; //计数器清零
    else
        timer <= timer + 1'b1; //计数器加 1

//LED控制
always @(posedge clk or negedge rst_n)
    if (~rst_n)
        led_r <= 1'b0; //LED 灯灭
    else if (timer == 32'd24_999_999) //计数器计到 0.5 秒，
        led_r <= 1'b1; //LED 点亮
    else if (timer == 32'd49_999_999) //计数器计到 1 秒，
        led_r <= 1'b0; //LED灯灭
    else
        led_r <= led_r;
    
endmodule

