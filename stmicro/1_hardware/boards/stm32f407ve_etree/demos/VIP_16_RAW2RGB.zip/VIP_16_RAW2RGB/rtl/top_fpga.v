//file name:	top_fpga.v
//author:		ETree
//date:			2017.10.1
//function:		top file of project
//log:

module top_fpga(
	//global signal                           
	input  clk,
	input  rst_n,

	//CMOS Port
	output cam_scl,
	inout  cam_sda,
	input [7:0] cam_data,
	
	input cam_vsync,	
	input cam_hsync,
	input cam_pclk,
	output cam_xclk,

	output cam_pdown,
	output cam_reset,	
	
	
	//NET
	output e_xi,
	output e_txen,
	output [1:0] e_tx,

	input e_rxer,
	input e_rxdv,
	input e_rxclk,
	input [1:0] e_rx,
	
	//LED
	output led
	
);
	
//----------Soft reset----------
reg [15:0] rst_cnt; 
reg rstn;

always @(posedge clk)
	if(rst_cnt>='hfffa)
		rst_cnt <= rst_cnt;
	else
		rst_cnt <= rst_cnt + 1'b1;
		
always @(posedge clk)
	if(rst_cnt>='hfff0)
		rstn <= 1'b1;
	else
		rstn <= 0;

wire locked;
wire clk_25m;
wire clk_xi;
	
alt_pll alt_pll_inst(
	.inclk0(clk),
	.c0(clk_25m),
	.c1(clk_xi),
	.locked(locked)
	);	
	
assign e_xi = clk_xi;

	
//---------------CMOS--------------------
wire [7:0] cam_data_out;
wire cam_vsync_out;
wire cam_hsync_out;

camera_if camera_if_inst
(
	.clk(clk_25m) ,	// input  clk_sig
	.rst_n(rstn) ,	// input  rst_n_sig
	.cam_scl(cam_scl) ,	// output  cam_scl_sig
	.cam_sda(cam_sda) ,	// inout  cam_sda_sig
	
	.cam_data(cam_data) ,	// input [7:0] cam_data_sig
	
	.cam_vsync(cam_vsync) ,	// input  cam_vsync_sig
	.cam_hsync(cam_hsync) ,	// input  cam_hsync_sig
	.cam_pclk(cam_pclk) ,	// input  cam_pclk_sig
	.cam_xclk(cam_xclk) ,	// output  cam_xclk_sig
	
	.cam_pdown(cam_pdown) ,	// output  cam_pdown_sig
	.cam_reset(cam_reset) ,	// output  cam_reset_sig
	
	.cam_data_out(cam_data_out),
	.cam_vsync_out(cam_vsync_out),
	.cam_hsync_out(cam_hsync_out),
	.line_count(line_count),
	.cam_en(1'b1)	// input  cam_en_sig
);	

defparam camera_if_inst.IMG_H = 640;		

//------------Video Image Process--------------

wire [15:0] dvp_data_o;
wire dvp_href_o;
wire dvp_vsync_o;

vip_top vip_top_inst
(
	.cmos_pclk(cam_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cam_hsync_out) ,	// input  cmos_href_sig
	.cmos_vsync(cam_vsync_out) ,	// input  cmos_vsync_sig
	.cmos_data(cam_data_out) ,	// input [7:0] cmos_data_sig
	.cmos_href_o(dvp_href_o) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(dvp_vsync_o) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(dvp_data_o) 	// output [7:0] cmos_data_o_sig
);
		
//-------------CMOS FIFO-----------------
wire [11 : 0] fifo_data_count;
wire [7:0] fifo_data;
wire fifo_rd_en;
wire fifo_full;
wire fifo_empty;

cmos1_fifo cmos1_fifo_inst (
  .aclr                     (~rstn),   // input rst
  .wrclk                    (cam_pclk),                   // input wr_clk
  .data                     (dvp_data_o),                   // input [7 : 0] din
  .wrreq                    (dvp_href_o),                    // input wr_en
  
  .rdclk                    (fifo_rdclk),                         // input rd_clk
  .rdreq                    (fifo_rd_en),                    // input rd_en
  .q                        (fifo_data),                     // output [7 : 0] dout
  .wrfull                   (fifo_full),                     // output full
  .rdempty                  (fifo_empty),                    // output empty
  .rdusedw                  (fifo_data_count),               // output [10 : 0] rd_data_count
  .wrusedw                  ()
);
		
//-----------ETHernet-------------

wire [10:0] frame_index;
wire fifo_rdclk;

assign frame_index = 0;

udp udp_inst(
	.reset_n                 (rstn),
	.e_rxc                   (e_rxclk),
	.e_rxd                   (e_rx),
   .e_rxdv                  (e_rxdv),
	.e_txen                  (e_txen),
	.e_txd                   (e_tx),	

	.fifo_rdclk					 (fifo_rdclk),
	.fifo_data               (fifo_data),           //FIFO读出的8bit数据/
	.fifo_data_count         (fifo_data_count),     //FIFO中的数据数量
   .fifo_rd_en              (fifo_rd_en),          //FIFO读使能 
	.fifo_empty              (fifo_empty),

	.frame_index             (frame_index), 
	
	.tx_total_length         ('d1308),            //发送IP包的总长度/
	.tx_data_length          ('d1288)             //发送IP包的数据长度/		
);


//LED 使能控制
wire led_en=1;
reg  led_r;
reg  [31:0] timer;
		
assign led = led_r;

always @(posedge clk)
	 if(rst_n)
		 if (timer == 32'd49_999_999) //0.5 秒计数(50M-1=49_999_999)
			  timer <= 0; //计数器清零
		 else
			  timer <= timer + 1'b1; //计数器加 1
	 else
		 timer <= timer;

//LED控制
always @(posedge clk)
	 if(rst_n)
		 if (timer == 32'd24_999_999) //计数器计到 0.5 秒，
			  led_r <= 1'b1; //LED 点亮
		 else if (timer == 32'd49_999_999) //计数器计到 1 秒，
			  led_r <= 1'b0; //LED灯灭
		 else
			  led_r <= led_r;
	 else
		 led_r <= led_r;


endmodule


