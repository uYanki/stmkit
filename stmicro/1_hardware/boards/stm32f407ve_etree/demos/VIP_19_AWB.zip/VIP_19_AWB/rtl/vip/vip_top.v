//file name:	vip_top.v
//author:      shugen.yin
//date:		   2017.10.18
//function:		VIP top file
//log:

module vip_top(
	input clk,
	input rst_n,
	
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output cmos_href_o,
	output cmos_vsync_o,
	output [7:0] cmos_data_o
);

wire [15:0] v_cnt;
wire cmos_href_awb;
wire cmos_vsync_awb;
wire [7:0] cmos_data_awb;

awb awb_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync) ,	// input  cmos_vsync_sig
	.cmos_data(cmos_data) ,	// input [7:0] cmos_data_sig
	.v_cnt(v_cnt),
	.cmos_href_o(cmos_href_awb) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_awb) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_awb) 	// output [7:0] cmos_data_o_sig
);

//白平衡前视频
//assign cmos_vsync_o = cmos_vsync;
//assign cmos_href_o  = cmos_href;
//assign cmos_data_o  = cmos_data;

//白平衡后视频
assign cmos_vsync_o = cmos_vsync_awb;
assign cmos_href_o  = cmos_href_awb;
assign cmos_data_o  = (v_cnt==0)?0:cmos_data_awb;



endmodule
