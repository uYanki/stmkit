//file name:	alpha.v
//author:      shugen.yin
//date:		   2017.12.30
//function:	   Alpha算法
//log:

module alpha(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [7:0] cmos_data_o
);

reg [15:0] h_cnt;
reg [15:0] v_cnt;
reg [7:0]  data;

//always @(posedge cmos_pclk)
//	if(cmos_vsync)
//		h_cnt <= 0;
//	else if(cmos_href)
//		h_cnt <= h_cnt + 1'b1;
//	else
//		h_cnt <= 0;
//
//always @(posedge cmos_pclk)
//	if(cmos_vsync)
//		v_cnt <= 0;
//	else if(h_cnt>=640)
//		v_cnt <= v_cnt + 1'b1;
//	else
//		v_cnt <= v_cnt;
		

always @(posedge cmos_pclk)
	if(cmos_href)
		if(data>=79)
			data <= 0;
		else
			data <= data + 1'b1;
	else
		data <= 0;
		
always @(posedge cmos_pclk)
	cmos_href_o <= cmos_href;
	
always @(posedge cmos_pclk)
	cmos_vsync_o <= cmos_vsync;

wire [9:0] temp;

assign temp = data + (cmos_data*2+cmos_data);	//TEMP = data + cmos_data*3
	
always @(posedge cmos_pclk)
	cmos_data_o <= temp[9:2];





endmodule
