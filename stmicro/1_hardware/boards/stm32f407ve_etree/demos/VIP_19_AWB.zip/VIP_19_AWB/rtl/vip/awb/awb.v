//file name:	awb.v
//author:      shugen.yin
//date:		   2018.12.31
//function:		自动白平衡算法
//log:

module awb(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg [15:0] v_cnt,
	output cmos_href_o,
	output cmos_vsync_o,
	output [7:0] cmos_data_o
);

reg cmos_href_awb;
reg cmos_vsync_awb;
reg [7:0] cmos_data_awb;

parameter IMG_H = 640;
parameter IMG_V = 480;

assign cmos_href_o = cmos_href_awb;
assign cmos_vsync_o = cmos_vsync_awb;
assign cmos_data_o = cmos_data_awb;

reg [11:0] hcnt;
reg [10:0] vcnt;
reg [25:0] sum0;
reg [25:0] sum1;
reg [25:0] sum2;
reg [25:0] sum3;
reg [8:0] average0;
reg [8:0] average1;
reg [8:0] average2;
reg [8:0] average3;

always @(posedge cmos_pclk)
	if(cmos_vsync)
		hcnt <= 0;
	else if(cmos_href)
		hcnt <= hcnt + 1'b1;
	else	
		hcnt <= 0;
	
always @(posedge cmos_pclk)
	if(cmos_vsync)
		vcnt <= 0;
	else if(hcnt==(IMG_H-1))
		vcnt <= vcnt + 1'b1;
	else
		vcnt <= vcnt;
		

always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		sum0 <= 0;
		sum1 <= 0;
		sum2 <= 0;
		sum3 <= 0;
	end
	else if(cmos_vsync==1'b0)
	begin
		if(cmos_href)
		case({hcnt[0],vcnt[0]})
		2'b00:
		begin
			sum0 <= sum0 + cmos_data;
		end
		2'b01:
		begin
			sum1 <= sum1 + cmos_data;
		end
		2'b10:
		begin
			sum2 <= sum2 + cmos_data;
		end
		2'b11:
		begin
			sum3 <= sum3 + cmos_data;
		end
		default:;
		endcase
	end
	else
	begin
		sum0 <= sum0;
		sum1 <= sum1;
		sum2 <= sum2;
		sum3 <= sum3;
	end
	

always @(posedge cmos_pclk)
	if((hcnt==(IMG_H-2)) && (vcnt==(IMG_V-1)))
	begin
		average0 <= sum0/76800;
		average1 <= sum1/76800;
		average2 <= sum2/76800;
		average3 <= sum3/76800;
	end
	else
	begin
		average0 <= average0;
		average1 <= average1;
		average2 <= average2;
		average3 <= average3;	
	end
		
	
wire [10:0] average0_reciprocal;
wire [10:0] average1_reciprocal;
wire [10:0] average2_reciprocal;
wire [10:0] average3_reciprocal;

reciprocal reciprocal_inst0
(
	.datain(average0[7:0]) ,	// input [7:0] datain_sig
	.dataout(average0_reciprocal) 	// output [10:0] dataout_sig
);

reciprocal reciprocal_inst1
(
	.datain(average1[7:0]) ,	// input [7:0] datain_sig
	.dataout(average1_reciprocal) 	// output [10:0] dataout_sig
);


reciprocal reciprocal_inst2
(
	.datain(average2[7:0]) ,	// input [7:0] datain_sig
	.dataout(average2_reciprocal) 	// output [10:0] dataout_sig
);

reciprocal reciprocal_inst3
(
	.datain(average3[7:0]) ,	// input [7:0] datain_sig
	.dataout(average3_reciprocal) 	// output [10:0] dataout_sig
);

wire [8:0] average;
assign average = (average0+average1+average2+average3)/4;

always @(posedge cmos_pclk)
begin
	cmos_vsync_awb <= cmos_vsync;
	cmos_href_awb <= cmos_href;
	if(cmos_href)
		case({hcnt[0],vcnt[0]})
		2'b00: cmos_data_awb <= (((cmos_data*average*average0_reciprocal)/1024)>=255)?255:(cmos_data*average*average0_reciprocal)/1024;
		2'b01: cmos_data_awb <= (((cmos_data*average*average1_reciprocal)/1024)>=255)?255:(cmos_data*average*average1_reciprocal)/1024;
		2'b10: cmos_data_awb <= (((cmos_data*average*average2_reciprocal)/1024)>=255)?255:(cmos_data*average*average2_reciprocal)/1024;
		2'b11: cmos_data_awb <= (((cmos_data*average*average3_reciprocal)/1024)>=255)?255:(cmos_data*average*average3_reciprocal)/1024;
		default:;
		endcase
	else
		cmos_data_awb <= 0;
end

//reg [15:0] v_cnt;
reg [15:0] h_cnt;
reg cmos_vsync_r0;
reg cmos_vsync_r1;

wire cmos_vsync_pos;
assign cmos_vsync_pos = (cmos_vsync_r0==1'b1 && cmos_vsync_r1==1'b0);

always @(posedge cmos_pclk)
begin
	cmos_vsync_r0 <= cmos_vsync_awb;
	cmos_vsync_r1 <= cmos_vsync_r0;
end

always @(posedge cmos_pclk)
	if(cmos_href_awb)
		h_cnt <= h_cnt + 1'b1;
	else
		h_cnt <= 0;

always @(posedge cmos_pclk)
	if(cmos_vsync_awb)
		v_cnt <= 0;
	else if(h_cnt==(IMG_H-1))
		v_cnt <= v_cnt + 1'b1;
	else
		v_cnt <= v_cnt;



endmodule
