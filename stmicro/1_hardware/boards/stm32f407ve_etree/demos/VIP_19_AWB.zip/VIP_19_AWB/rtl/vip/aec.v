//file name:	aec.v
//author:		shugenyin
//date:			2018.12.24
//function:		白天/晚上自动增益和曝光切换控制
//log:

module aec(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	input config_done,
	output reg [23:0] config_data,
	output reg start_config
);

parameter IMG_HDISP = 640;

//------------平均亮度统计--------------
//行列计数器
reg [10:0] h_cnt;
reg [9:0] v_cnt;
//平均亮度
reg [31:0] luminance;

always @(posedge cmos_pclk)
	if(cmos_href)
		h_cnt <= h_cnt + 1'b1;
	else
		h_cnt <= 0;

always @(posedge cmos_pclk)
	if(~cmos_vsync)
		v_cnt <= 0;
	else if(h_cnt==(IMG_HDISP-1))
			v_cnt <= v_cnt + 1'b1;	
	else
		v_cnt <= v_cnt;


always @(posedge cmos_pclk)
	if(cmos_vsync_neg)
		luminance <= 0;
	else if(h_cnt>=64 && h_cnt<(IMG_HDISP-64) && v_cnt>=112 && v_cnt<(480-112))//512*256
		luminance <= luminance + cmos_data;
	else
		luminance <= luminance;

reg cmos_vsync_r0;
reg cmos_vsync_r1;

always @(posedge cmos_pclk)
begin
	cmos_vsync_r0 <= ~cmos_vsync;
	cmos_vsync_r1 <= cmos_vsync_r0;
end

wire cmos_vsync_pos;
assign cmos_vsync_pos = (cmos_vsync_r0==1'b1 && cmos_vsync_r1==1'b0);
assign cmos_vsync_neg = (cmos_vsync_r0==1'b0 && cmos_vsync_r1==1'b1);

reg [0:0] cmos_frame_cnt;

always @(posedge cmos_pclk)
	if(cmos_vsync_pos)
		cmos_frame_cnt <= cmos_frame_cnt + 1'b1;
	else
		cmos_frame_cnt <= cmos_frame_cnt;
		
reg [0:0] cmos_reg_cnt;

always @(posedge cmos_pclk)
	if(cmos_vsync_pos && config_done && cmos_frame_cnt==0)
		cmos_reg_cnt <= cmos_reg_cnt + 1'b1;
	else
		cmos_reg_cnt <= cmos_reg_cnt;
		
always @(posedge cmos_pclk)
	if(cmos_vsync_pos && config_done && cmos_frame_cnt==0)
	begin
		if(luminance[31:17]>=8'hCF)
		begin
			if(cmos_reg_cnt==1'b0)
				config_data <= 24'h09_0023;//曝光
			else
				config_data <= 24'h35_0313;//增益
			start_config <= 1'b1;
		end
		else if(luminance[31:17]<=8'h28)
		begin
			if(cmos_reg_cnt==1'b0)
				config_data <= 24'h09_01CF;//曝光
			else
				config_data <= 24'h35_0355;//增益
			start_config <= 1'b1;
		end
		else
		begin
			config_data <= config_data;
			start_config <= 1'b1;
		end
	end
	else
	begin
			config_data <= config_data;
			if(v_cnt==1 && config_done)
				start_config <= 1'b1;
			else
				start_config <= 1'b0;
	end

reg [7:0] cnt_config;

always @(posedge cmos_pclk)
	if(cmos_vsync_pos)
		cnt_config <= cnt_config + 1'b1;
	else
		cnt_config <= cnt_config;

		
		
endmodule
