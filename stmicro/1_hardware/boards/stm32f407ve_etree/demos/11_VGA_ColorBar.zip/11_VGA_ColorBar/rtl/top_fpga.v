//file name:	top_fpga.v
//author:		ETree
//date:			2017.12.9
//function:		top file of project

module top_fpga(
	//global signal                           
	input  clk,
	input  rst_n,
	
	//VGA
	output vga_hsync,
	output vga_vsync,
	output [4:0] vga_red,
	output [5:0] vga_green,
	output [4:0] vga_blue,

   //ledsm
	output [7:0] sm_dat,
	output [1:0] sm_sel,
	
	//led
	output led
	
);

//------------PLL----------------
wire clk_25m;
wire locked;
	
my_pll my_pll_inst(
	.inclk0 ( clk ),
	.c0 ( clk_25m ),
	.locked ( locked )
	);	
		

//--------------VGA----------------- 
vga_show	vga_show_inst
(
	//global clock
	.vga_clk			   (clk_25m),			//vga clock
	.rst_n				(rst_n),		      //global reset
	
	//vga port
	.vga_hsync			(vga_hsync),		//vga horizontal sync 
	.vga_vsync			(vga_vsync),		//vga vertical sync
	.vga_r			   (vga_red),			//vga red data	
	.vga_g			   (vga_green),		//vga red data		
	.vga_b			   (vga_blue)			//vga red data	
);



endmodule
