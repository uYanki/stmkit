//file name:	vga_show.v
//author:		ETree
//date:			2021.10.2
//function:		VGA显示器驱动
//log:

module vga_show(
	input        vga_clk,
	input        rst_n, 		        //VGA复位，低电平有效
	
	output       vga_hsync,
	output       vga_vsync,
	output [4:0] vga_r,
	output [5:0] vga_g,
	output [4:0] vga_b
);

parameter RED		= 16'b11111_000000_00000;
parameter GREEN	= 16'b00000_111111_00000;
parameter BLUE    = 16'b00000_000000_11111;
parameter YELLOW  = 16'b11111_111111_00000;

// 水平扫描参数的设定640*480 VGA 60FPS_25MHz
parameter LinePeriod   = 800;            //行周期数
parameter H_SyncPulse  = 96;             //行同步脉冲（Sync a）
parameter H_BackPorch  = 48 ;            //显示后沿（Back porch b）
parameter H_ActivePix  = 640;            //显示时序段（Display interval c）
parameter H_FrontPorch = 16;             //显示前沿（Front porch d）
parameter Hde_start    = 144;
parameter Hde_end      = 784;

// 垂直扫描参数的设定640*480 VGA
parameter FramePeriod  = 525;            //列周期数
parameter V_SyncPulse  = 2;              //列同步脉冲（Sync o）
parameter V_BackPorch  = 33 ;            //显示后沿（Back porch p）
parameter V_ActivePix  = 480;            //显示时序段（Display interval q）
parameter V_FrontPorch = 10;             //显示前沿（Front porch r）
parameter Vde_start    = 35;
parameter Vde_end      = 515;


reg [10 : 0] h_cnt;
reg [9 : 0]  v_cnt;
reg [4 : 0]  vga_r_reg;
reg [5 : 0]  vga_g_reg;
reg [4 : 0]  vga_b_reg;  


reg hsync_r;
reg vsync_r; 
reg vsync_de;
reg hsync_de;

//水平扫描计数
always @(posedge vga_clk)
	if(~rst_n)    
		h_cnt <= 1;
	else if(h_cnt==LinePeriod) 
		h_cnt <= 1;
	else 
		h_cnt <= h_cnt+ 1'b1;
		 
//水平扫描信号hsync,hsync_de产生
always @(posedge vga_clk)
begin
	if(~rst_n) 
		hsync_r <= 1'b1;
	else if(h_cnt==1) 
		hsync_r <= 1'b0;	//产生hsync信号
	else if(h_cnt==H_SyncPulse) 
		hsync_r <= 1'b1;
			
	if(~rst_n) 
		hsync_de <= 1'b0;
	else if(h_cnt==Hde_start) 
		hsync_de <= 1'b1;	//产生hsync_de信号
	else if(h_cnt==Hde_end) 
		hsync_de <= 1'b0;					 
	
end

//垂直扫描计数
always @(posedge vga_clk)
	if(~rst_n) 
		v_cnt <= 1;
	else if(v_cnt==FramePeriod) 
		v_cnt <= 1;
	else if(h_cnt==LinePeriod) 
		v_cnt <= v_cnt + 1'b1;
	

// 垂直扫描信号vsync, vsync_de产生
always @(posedge vga_clk)
begin
	if(~rst_n) 
		vsync_r <= 1'b1;
	else if(v_cnt==1) 
		vsync_r <= 1'b0;    //产生vsync信号
	else if(v_cnt==V_SyncPulse) vsync_r <= 1'b1;

	if(~rst_n) 
		vsync_de <= 1'b0;
	else if(v_cnt==Vde_start) 
		vsync_de <= 1'b1;    //产生vsync_de信号
	else if(v_cnt==Vde_end) 
		vsync_de <= 1'b0;	 
end

//生成彩条测试数据	
always @(posedge vga_clk)
begin			
	if(~rst_n) 
		{vga_r_reg,vga_g_reg,vga_b_reg} <= 0;
	else if(h_cnt>=Hde_start && h_cnt<(Hde_start+160) && vsync_de) 
		{vga_r_reg,vga_g_reg,vga_b_reg} <= RED;
	else if(h_cnt>=(Hde_start+160) && h_cnt<(Hde_start+320) && vsync_de)
		{vga_r_reg,vga_g_reg,vga_b_reg} <= GREEN;
	else if(h_cnt>=(Hde_start+320) && h_cnt<(Hde_start+480) && vsync_de)
		{vga_r_reg,vga_g_reg,vga_b_reg} <= BLUE;
	else if(h_cnt>=(Hde_start+480) && h_cnt<(Hde_start+640) && vsync_de)
		{vga_r_reg,vga_g_reg,vga_b_reg} <= YELLOW;
	else  
		{vga_r_reg,vga_g_reg,vga_b_reg} <= 0;					 
end
	

assign vga_hsync = hsync_r;
assign vga_vsync = vsync_r;  
assign vga_r = vga_r_reg;
assign vga_g = vga_g_reg;
assign vga_b = vga_b_reg;


  
endmodule
