//file name:	top_fpga.v
//author:		ETree
//date:			2017.10.1
//function:		top file of project
//log:

module top_fpga(
	//global signal                           
	input  clk,
	input  rst_n,
	
	//NET
	output e_xi,
	output e_txen,
	output [1:0] e_tx,

	input e_rxer,
	input e_rxdv,
	input e_rxclk,
	input [1:0] e_rx,
	
	//LED
	output led
	
);

//parameter define
//parameter   BOARD_MAC   = 48'h03_08_35_01_AE_C2 ;   //板卡MAC地址
parameter   BOARD_MAC   = 48'h12_34_56_78_9A_BC ;   //板卡MAC地址
parameter   BOARD_IP    = 32'hC0_A8_03_02       ;   //板卡IP地址
parameter   BOARD_PORT  = 16'd32768             ;   //板卡端口号
parameter   PC_MAC      = 48'hFF_FF_FF_FF_FF_FF ;   //PC机MAC地址
parameter   PC_IP       = 32'hC0_A8_03_03       ;   //PC机IP地址
parameter   PC_PORT     = 16'd32768             ;   //PC机端口号


//wire define
wire            rec_end         ;   //单包数据接收完成信号
wire            rec_en          ;   //接收数据使能信号
wire   [31:0]   rec_data        ;   //接收数据
wire   [15:0]   rec_data_num    ;   //接收有效数据字节数
wire            send_end        ;   //发送完成信号
wire            read_data_req   ;   //读数据请求信号
wire            send_en         ;   //数据开始发送信号
wire   [31:0]   send_data       ;   //发送数据
wire            eth_rxdv        ;   //输入数据有效信号(mii)
wire    [3:0]   eth_rx_data     ;   //输入数据(mii)
wire            eth_tx_en       ;   //输出数据有效信号(mii)
wire    [3:0]   eth_tx_data     ;   //输出数据(mii)

//reg   define
reg             clk_25m         ;   //mii时钟
	
//clk_25m:mii时钟
always @(negedge e_rxclk or negedge rst_n)
    if(~rst_n)
        clk_25m <=  1'b0;
    else
        clk_25m <= ~clk_25m;
		  

wire locked;

alt_pll alt_pll_inst(
	.inclk0(clk),
	.c0(e_xi),
	.locked(locked)
);
		  

//------------- eth_udp_inst -------------
eth_udp
#(
    .BOARD_MAC      (BOARD_MAC      ),  //板卡MAC地址
    .BOARD_IP       (BOARD_IP       ),  //板卡IP地址
    .BOARD_PORT     (BOARD_PORT     ),  //板卡端口号
    .PC_MAC         (PC_MAC         ),  //PC机MAC地址
    .PC_IP          (PC_IP          ),  //PC机IP地址
    .PC_PORT        (PC_PORT        )   //PC机端口号
)
eth_udp_inst
(
    .eth_rx_clk     (clk_25m        ),  //mii时钟,接收
    .rst_n          (rst_n          ),  //复位信号,低电平有效
    .eth_rxdv       (eth_rxdv       ),  //输入数据有效信号(mii)
    .eth_rx_data    (eth_rx_data    ),  //输入数据(mii)
    .eth_tx_clk     (clk_25m        ),  //mii时钟,发送
    .send_en        (rec_end        ),  //开始发送信号
    .send_data      (send_data      ),  //发送数据
    .send_data_num  (rec_data_num   ),  //发送有效数据字节数

    .send_end       (send_end       ),  //单包数据发送完成信号
    .read_data_req  (read_data_req  ),  //读数据请求信号
    .rec_end        (rec_end        ),  //单包数据接收完成信号
    .rec_en         (rec_en         ),  //接收数据使能信号
    .rec_data       (rec_data       ),  //接收数据
    .rec_data_num   (rec_data_num   ),  //接收有效数据字节数
    .eth_tx_en      (eth_tx_en      ),  //输出数据有效信号(mii)
    .eth_tx_data    (eth_tx_data    )   //输出数据(mii)
);		  
		  
//------------- mii_to_rmii_inst -------------
mii_to_rmii mii_to_rmii_inst
(
    .eth_mii_clk    (clk_25m        ),  //mii时钟
    .eth_rmii_clk   (e_rxclk        ),  //rmii时钟
    .rst_n          (rst_n          ),  //复位信号
    .tx_dv          (eth_tx_en      ),  //输出数据有效信号(mii)
    .tx_data        (eth_tx_data    ),  //输出有效数据(mii)

    .eth_tx_dv      (e_txen         ),  //输出数据有效信号(rmii)
    .eth_tx_data    (e_tx           )   //输出数据(rmii)
);
	 
//------------- rmii_to_mii_inst -------------
rmii_to_mii rmii_to_mii_inst
(
    .eth_rmii_clk   (e_rxclk        ),  //rmii时钟
    .eth_mii_clk    (clk_25m        ),  //mii时钟
    .rst_n          (rst_n          ),  //复位信号
    .rx_dv          (e_rxdv         ),  //输入数据有效信号(rmii)
    .rx_data        (e_rx           ),  //输入数据(rmii)

    .eth_rx_dv      (eth_rxdv       ),  //输入数据有效信号(mii)
    .eth_rx_data    (eth_rx_data    )   //输入数据(mii)
);
		  
		  
//------------- fifo_inst -------------
//fifo模块，用于缓存单包数据
my_fifo    my_fifo_inst
(
    .aclr           (~rst_n        ),  //fifo清零信号
    .wrclk          (clk_25m        ),  //fifo写时钟
    .wrreq          (rec_en         ),  //fifo写请求
    .data           (rec_data       ),  //fifo写数据

    .rdclk          (clk_25m        ),  //fifo读时钟
    .rdreq          (read_data_req  ),  //fifo读请求
    .q              (send_data      )   //fifo读数据
);

endmodule


