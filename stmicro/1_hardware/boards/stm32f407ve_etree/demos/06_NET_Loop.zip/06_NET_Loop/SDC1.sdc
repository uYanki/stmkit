create_clock -name clk_50m -period 20.000 [get_ports {clk}]
create_clock -name clk_125m -period 20.000 [get_ports {e_rxclk}]

