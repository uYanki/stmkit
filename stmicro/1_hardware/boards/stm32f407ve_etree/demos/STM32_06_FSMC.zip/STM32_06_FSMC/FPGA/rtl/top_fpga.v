//file name:       top_fpga.v
//author:           ETree
//date:             2017.9.9
//function:        top file of project
//log:              led light

module top_fpga(
    //global signal
    input clk,  //50MHz
    input rst_n,//low active
	 
	 //key
	 input key0,
	 input key1,
	 input key2,
	 
	 //STM32
	 //FSMC Bus
	 inout [15:0] fsmc_data,
	 input fsmc_noe,
	 input fsmc_nwe,
	 input fsmc_nbl0,
	 input fsmc_nbl1,
	 input fsmc_ne1, 
	 input fsmc_a23,
	 input fsmc_a22,
	 input fsmc_a21,
	 input fsmc_a20,
	 input fsmc_a19,
	 input fsmc_a18,
	 input fsmc_a17,
	 input fsmc_a16,
	 input fsmc_nwait,
	 input fsmc_clk,

	 //uart
	 input uart_rx,
	 input uart_tx,
    
	 //ledsm
	 output [7:0] sm_dat,
	 output [1:0] sm_sel,
	 
    //led
    output  led //high active
);

wire clk_25m;
wire locked;

mypll mypll_inst(
	.inclk0(clk),
	.c0(clk_25m),
	.locked(locked)
);

wire [15:0] fsmc_register0;

fsmc_reg fsmc_reg_inst
(
	.clk(clk) ,	// input  clk_sig
	.rst_n(rst_n) ,	// input  rst_n_sig
	.fsmc_data(fsmc_data) ,	// inout [15:0] fsmc_data
	.fsmc_noe(fsmc_noe) ,	// input  fsmc_noe
	.fsmc_nwe(fsmc_nwe) ,	// input  fsmc_nwe
	.fsmc_ne1(fsmc_ne1) ,	// input  fsmc_ne1
	.fsmc_a23(fsmc_a23) ,	// input  fsmc_a23
	.fsmc_a22(fsmc_a22) ,	// input  fsmc_a22
	.fsmc_a21(fsmc_a21) ,	// input  fsmc_a21
	.fsmc_a20(fsmc_a20) ,	// input  fsmc_a20
	.fsmc_a19(fsmc_a19) ,	// input  fsmc_a19
	.fsmc_a18(fsmc_a18) ,	// input  fsmc_a18
	.fsmc_a17(fsmc_a17) ,	// input  fsmc_a17
	.fsmc_a16(fsmc_a16) ,	// input  fsmc_a16
	.fsmc_nwait(fsmc_nwait) ,	// input  fsmc_nwait
	.fsmc_register0(fsmc_register0) 	// output [15:0] fsmc_register0
);

//---------------数码管数字定义------------------
parameter ZERO    = 8'b0000_0011,//8'b1100_0000, 
			 ONE     = 8'b1001_1111,//8'b1111_1001,  
			 TWO     = 8'b0010_0101,//8'b1010_0100, 
			 THREE   = 8'b0000_1101,//8'b1011_0000,
			 FOUR    = 8'b1001_1001,//8'b1001_1001, 
			 FIVE    = 8'b0100_1001,//8'b1001_0010, 
			 SIX     = 8'b0100_0001,//8'b1000_0010,
			 SEVEN   = 8'b0001_1111,//8'b1111_1000, 
			 EIGHT   = 8'b0000_0001,//8'b1000_0000,
			 NINE    = 8'b0000_1001,//8'b1001_0000;
			 AA	   = 8'b0001_0001,
			 BB      = 8'b1100_0001,
			 CC      = 8'b0110_0011,
			 DD      = 8'b1000_0101,
			 EE      = 8'b0110_0001,
			 FF      = 8'b0111_0001;

reg [7:0] sm_dat_r;	//数码管段选
reg [1:0] sm_sel_r;	//数码管位选
reg [7:0] sm_dat_r0; //数码管段选寄存器0
reg [7:0] sm_dat_r1; //数码管段选寄存器1
reg [0:0] sm_cnt;		//数码管片选计数器
reg [19:0] timer1;	//10毫秒计数器

//--------数码管片选计数器-----------  
always @(posedge clk or negedge rst_n)
    if (~rst_n)
        timer1 <= 0; 						//计数器清零
    else if (timer1 == 32'd499_999)     //10ms计数(50M-1=499_999)
        timer1 <= 0;                    //计数器计到1秒，计数器清零
    else
        timer1 <= timer1 + 1'b1;         //计数器加 1		  
	  
always @(posedge clk or negedge rst_n)
	if(~rst_n)
		sm_cnt <= 0;
	else if(timer1==0)
		sm_cnt <= sm_cnt + 1'b1;
	else
		sm_cnt <= sm_cnt;

//----------数码管译码----------
always @ (*)
	case( fsmc_register0[3:0] )
	4'd0 : sm_dat_r0 <= ZERO;
	4'd1 : sm_dat_r0 <= ONE;
	4'd2 : sm_dat_r0 <= TWO;
	4'd3 : sm_dat_r0 <= THREE;
	4'd4 : sm_dat_r0 <= FOUR;
	4'd5 : sm_dat_r0 <= FIVE;
	4'd6 : sm_dat_r0 <= SIX;
	4'd7 : sm_dat_r0 <= SEVEN;
	4'd8 : sm_dat_r0 <= EIGHT;
	4'd9 : sm_dat_r0 <= NINE;
	4'd10: sm_dat_r0 <= AA ;
	4'd11: sm_dat_r0 <= BB ;
	4'd12: sm_dat_r0 <= CC ;
	4'd13: sm_dat_r0 <= DD ;
	4'd14: sm_dat_r0 <= EE ;
	4'd15: sm_dat_r0 <= FF ;
	default:sm_dat_r0 <= 8'hFF;
	endcase

always @ (*)
	case( fsmc_register0[7:4] )
	4'd0 : sm_dat_r1 <= ZERO;
	4'd1 : sm_dat_r1 <= ONE;
	4'd2 : sm_dat_r1 <= TWO;
	4'd3 : sm_dat_r1 <= THREE;
	4'd4 : sm_dat_r1 <= FOUR;
	4'd5 : sm_dat_r1 <= FIVE;
	4'd6 : sm_dat_r1 <= SIX;
	4'd7 : sm_dat_r1 <= SEVEN;
	4'd8 : sm_dat_r1 <= EIGHT;
	4'd9 : sm_dat_r1 <= NINE;
	4'd10: sm_dat_r1 <= AA ;
	4'd11: sm_dat_r1 <= BB ;
	4'd12: sm_dat_r1 <= CC ;
	4'd13: sm_dat_r1 <= DD ;
	4'd14: sm_dat_r1 <= EE ;
	4'd15: sm_dat_r1 <= FF ;
	default:sm_dat_r1 <= 8'hFF;
	endcase


//---------数码管显示---------	
always @(sm_cnt)
	case(sm_cnt)
	'd0:
	begin
		sm_sel_r <= 2'b01;
		sm_dat_r <= sm_dat_r0;	
	end
	'd1:
	begin
		sm_sel_r <= 2'b10;
		sm_dat_r <= sm_dat_r1;	
	end	
	default:
	begin
		sm_sel_r <= 2'b11;
		sm_dat_r <= ZERO;
	end
	endcase
	
assign sm_sel = sm_sel_r;
assign sm_dat = sm_dat_r;

 
endmodule

