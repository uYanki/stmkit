//file name:	sdram_ops.v
//author:		ETree
//date:			2021.9.1
//function:		SDRAM READ AND WRITE OF AVALON

module sdram_ops(
	input clk,
	input rst_n,
	
	input wr_en,
	input rd_en,
	input [15:0] wrdata_i,
	input [23:0] address_i,
	
	output reg [23:0] av_address,
	output reg av_chipselect,
	output reg [15:0] av_writedata,
	output reg av_read_n,
	output reg av_write_n,
	input  [15:0] av_readdata,
	input  av_readdatavalid,
	input  av_waitrequest,
	
	output reg rddatavalid,
	output reg [15:0] readdata
);


parameter ST_IDLE    = 0;
parameter ST_WRITE   = 1;
parameter ST_READ    = 2;
parameter ST_DONE    = 3;

reg [1:0] mystate;

always @(posedge clk)
	if(~rst_n)
	begin
		mystate <= ST_IDLE;
		av_chipselect <= 0;
		av_address <= 0;
		av_writedata <= 0;
		av_write_n <= 1'b1;
		av_read_n  <= 1'b1;
	end
	else
	case(mystate)
	ST_IDLE:
	begin
		av_chipselect <= 1;
		if(wr_en)
		begin
			mystate <= ST_WRITE;
			av_writedata <= wrdata_i;
			av_write_n <= 1'b0;
			av_read_n  <= 1'b1;
			av_address <= address_i;
		end
		else if(rd_en)
		begin
			mystate <= ST_READ;
			av_write_n <= 1'b1;
			av_read_n  <= 1'b0;
			av_address <= address_i;
		end
		else
		begin
			mystate <= ST_IDLE;
			av_writedata <= 0;
			av_write_n <= 1'b1;
			av_read_n  <= 1'b1;
			av_address <= 0;
		end		
	end
	ST_WRITE:
	begin
		av_chipselect <= 1;
		if(av_waitrequest)
		begin
				av_address <= av_address;
				av_write_n <= 1'b0;
				av_read_n  <= 1'b1;
				av_writedata <= av_writedata;	
				mystate <= ST_WRITE;
		end
		else
		begin
			av_address <= av_address;	
			av_writedata <= av_writedata;
			av_read_n  <= 1'b1;
			av_write_n <= 1'b1;
			mystate <= ST_DONE;
		end	
	end
	ST_READ:
	begin
		av_chipselect <= 1;
		if(av_waitrequest)
		begin
			av_address <= av_address;
			av_write_n <= 1'b1;
			av_read_n  <= 1'b0;
			mystate <= ST_READ;
		end
		else
		begin
			av_address <= av_address;	
			av_write_n <= 1'b1;
			av_read_n <= 1'b1;
			mystate <= ST_DONE;
		end
	end
	ST_DONE:
	begin
		av_chipselect <= 1;
		mystate <= ST_IDLE;
		av_address <= 0;
		av_writedata <= 0;
		av_write_n <= 1'b1;
		av_read_n  <= 1'b1;
	end
	default:
	begin
		av_chipselect <= 0;
		mystate <= ST_IDLE;
		av_address <= 0;
		av_writedata <= 0;
		av_write_n <= 1'b1;
		av_read_n  <= 1'b1;
	end
	endcase

	
always @(posedge clk)
	if(~rst_n)
		rddatavalid <= 0;
	else
		rddatavalid <= av_readdatavalid;
		
always @(posedge clk)
	if(~rst_n)
		readdata <= 0;
	else if(av_readdatavalid)
		readdata <= av_readdata;
	else
		readdata <= readdata;
	
	
endmodule
	