//file name: tft.v
//author:    ETree
//date:		 2018.1.6
//function:  
//log:

module tft24(
	input clk,
	input rst_n,
	
	output reg tft_cs,
	output reg tft_rs,
	output reg tft_rd,
	output reg tft_wr,
	output reg [15:0] tft_dat,
	output reg tft_res,
	
	output reg config_done
);
	

reg [7:0] lut_index;
reg [7:0] lut_data;

parameter RED		= 16'hf800;
parameter GREEN	= 16'h07e0;
parameter BLUE		= 16'h001f;
parameter YELLOW	= 16'hffe0;

reg [15:0] data_temp;
										
//-------------------------------
always @(*)
begin
	case(lut_index)
	0	:	lut_data	<= 8'hCF;	//
	1	:	lut_data <= 8'h00;
	2	:	lut_data <= 8'hD9;
	3	:	lut_data <= 8'h30;
	
	4	:	lut_data <= 8'hED;	//
	5	:	lut_data <= 8'h64;
	6	:	lut_data <= 8'h03;
	7	:	lut_data <= 8'h12;
	8	:	lut_data <= 8'h81;
	
	9	:	lut_data <= 8'hE8;	//
	10	:	lut_data <= 8'h85;
	11	:	lut_data <= 8'h10;
	12	:	lut_data <= 8'h78;
	
	13	:	lut_data <= 8'hCB;	//
	14	:	lut_data <= 8'h39;
	15	:	lut_data <= 8'h2C;
	16	:	lut_data <= 8'h00;	
	17	:	lut_data <= 8'h34;
	18	:	lut_data <= 8'h02;
	
	19	:	lut_data <= 8'hF7;	//
	20	:	lut_data <= 8'h20;
	
	21	:	lut_data <= 8'hEA;	//
	22	:	lut_data <= 8'h00;
	23	:	lut_data <= 8'h00;
	
	24	:	lut_data <= 8'hC0;	//Power control
	25	:	lut_data <= 8'h21;	
	
	26	:	lut_data <= 8'hC1;	//Power control
	27	:	lut_data <= 8'h12;
	
	28	:	lut_data <= 8'hC5;	//VCM control
	29	:	lut_data <= 8'h32;
	30	:	lut_data <= 8'h3C;
	
	31	:	lut_data <= 8'hC7;	//VCM control2 
	32	:	lut_data <= 8'hC1;
	
	33	:	lut_data <= 8'h36;	//Memory Access Control
	34	:	lut_data <= 8'h08;
	
	35	:	lut_data <= 8'h3A;	//
	36	:	lut_data <= 8'h55;
	
	37	:	lut_data <= 8'hB1;	//
	38	:	lut_data <= 8'h00;
	39	:	lut_data <= 8'h18;
	
	40	:	lut_data <= 8'hB6;	//
	41	:	lut_data <= 8'h0A;
	42	:	lut_data <= 8'hA2;
	
	43	:	lut_data <= 8'hF2;	//
	44	:	lut_data <= 8'h00;
	
	45	:	lut_data <= 8'h26;	//
	46	:	lut_data <= 8'h01;
	
	47	:	lut_data <= 8'hE0;	//SET Gamma
	48	:	lut_data <= 8'h0F;
	49	:	lut_data <= 8'h20;
	50	:	lut_data <= 8'h1E;
	51	:	lut_data <= 8'h09;
	52	:	lut_data <= 8'h12;
	53	:	lut_data <= 8'h0B;
	54	:	lut_data <= 8'h50;
	55	:	lut_data <= 8'hBA;
	56	:	lut_data <= 8'h44;
	57	:	lut_data <= 8'h09;
	58	:	lut_data <= 8'h14;
	59	:	lut_data <= 8'h05;
	60	:	lut_data <= 8'h23;
	61	:	lut_data <= 8'h21;
	62	:	lut_data <= 8'h00;
	
	63	:	lut_data <= 8'hE1;	//Set Gamma
	64	:	lut_data <= 8'h00;	
	65	:	lut_data <= 8'h19;
	66	:	lut_data <= 8'h19;
	67	:	lut_data <= 8'h00;
	68	:	lut_data <= 8'h12;
	69	:	lut_data <= 8'h07;
	70	:	lut_data <= 8'h2D;
	71	:	lut_data <= 8'h28;
	72	:	lut_data <= 8'h3F;
	73	:	lut_data <= 8'h02;	
	74	:	lut_data <= 8'h0A;
	75	:	lut_data <= 8'h08;
	76	:	lut_data <= 8'h25;
	77	:	lut_data <= 8'h2D;
	78	:	lut_data <= 8'h0F;
	
	79	:	lut_data <= 8'h11;	//EXIT SLEEP
//	80	:	lut_data <= 8'h29;	//Display on
//	81	:	lut_data <= 8'h29;	//Display on
	82	:	lut_data <= 8'h29;	//Display on
	
	83	:	lut_data <= 8'h2A;	//X region
	84	:	lut_data <= 8'h00;
	85	:	lut_data <= 8'h00;	
	86	:	lut_data <= 8'h00;	//239-->0x00EF
	87	:	lut_data <= 8'hEF;	
	
	88	:	lut_data <= 8'h2B;	//Y region
	89	:	lut_data <= 8'h00;	
	90	:	lut_data <= 8'h00;	
	91	:	lut_data <= 8'h01;	//319-->0x013F	
	92	:	lut_data <= 8'h3F;	
	
	93	:	lut_data <= 8'h2C;	//
	default: lut_data <= 0;
	endcase;
end
	
//--------------------------------
parameter ST_IDLE		= 3'd0;
parameter ST_RESET	= 3'd1;
parameter ST_INIT		= 3'd2;
parameter ST_DISP		= 3'd3;
parameter ST_END		= 3'd4;

reg [2:0] my_state;
reg [7:0] cnt_state;
reg [16:0] cnt_disp;
reg [22:0] cnt_rst;
reg fifo_rd_r0;
reg fifo_rd_r1;

always @(posedge clk or negedge rst_n)
	if(~rst_n)
	begin
		my_state <= ST_IDLE;
		lut_index <= 0;
		cnt_rst <= 0;
		cnt_disp <= 0;
		config_done <= 0;
		fifo_rd_r0 <= 0;
	end
	else
	begin
		case(my_state)
		ST_IDLE:
		begin
			my_state <= ST_RESET;
			cnt_state <= 0;
			lut_index <= 0;
			cnt_rst <= 0;
			cnt_disp <= 0;
			config_done <= 0;
			fifo_rd_r0 <= 0;
		end
		ST_RESET:
		begin
			if(cnt_rst>='h7F_FFFF)
			begin
				my_state <= ST_INIT;
				cnt_rst <= 0;
			end
			else
			begin
				my_state <= ST_RESET;
				cnt_rst <= cnt_rst + 1'b1;
			end
		end
		ST_INIT:
		begin
				if(cnt_state>=1)
					cnt_state <= 0;
				else
					cnt_state <= cnt_state + 1'b1;
			
				if(cnt_state==1)
					lut_index <= lut_index + 1'b1;
					
				if(lut_index>=94)
				begin
					my_state <= ST_DISP;
					config_done <= 1'b1;
				end
				else
				begin
					my_state <= ST_INIT;	
					config_done <= 0;
				end

		end
		ST_DISP:
		begin
				if(cnt_state>=1)
					cnt_state <= 0;
				else
					cnt_state <= cnt_state + 1'b1;
					
				if(cnt_state==1)
				begin
					if(cnt_disp<(240*320-1))
					begin
						cnt_disp <= cnt_disp + 1'b1;
					end
					else
					begin
						cnt_disp <= 0;
						
					end
					fifo_rd_r0 <= 1'b1;
					
					if(cnt_disp<240*320/4-1)
						data_temp <= RED;
					else if(cnt_disp<240*320*2/4-1)
						data_temp <= GREEN;
					else if(cnt_disp<240*320*3/4-1)
						data_temp <= BLUE;
					else if(cnt_disp<240*320-1)
						data_temp <= YELLOW;
					else
						data_temp <= RED;
					
					if(cnt_disp>=240*320-1)
						my_state <= ST_DISP;
					else
						my_state <= ST_DISP;
				end
				else
				begin
					fifo_rd_r0 <= 1'b0;
				end			
		end
		ST_END:
		begin
			cnt_state <= 0;
			cnt_disp <= 0;
			my_state <= ST_END;
		end
		default: my_state <= ST_IDLE;
		endcase
		
	end
	
always @(posedge clk or negedge rst_n)
	if(~rst_n)
	begin
		tft_cs  <= 1;
		tft_rd <= 1;
		tft_wr <= 1;
		tft_dat <= 0;
		tft_res <= 0;
	end
	else
	begin
		case(my_state)
		ST_IDLE:
		begin
			tft_cs  <= 1;
			tft_rd <= 1;
			tft_wr <= 1;
			tft_dat <= 0;
			tft_res <= 0;	
		end
		ST_RESET:
		begin
			if(cnt_rst>='h3F_FFFF)
			begin
				tft_res <= 1'b1;
				tft_cs <= 0;
			end
			else
			begin
				tft_res <= 1'b0;
				tft_cs <= 1'b1;
			end
		end
		ST_INIT:
		begin
			case(cnt_state)
			0	:	
			begin
				tft_cs <= 1'b0;
				tft_rd <= 1'b1;
				tft_wr <= 1'b0;
				tft_dat<= {8'h00,lut_data};
			end
			1	:	
			begin
				tft_cs <= 1'b0;
				tft_rd <= 1'b1;
				tft_wr <= 1'b1;
				tft_dat<= {8'h00,lut_data};
			end			
			default:;
			endcase
		end
		ST_DISP:
		begin
				case(cnt_state)
				0	:	
				begin
					tft_cs <= 1'b0;
					tft_rd <= 1'b1;
					tft_wr <= 1'b0;
					tft_dat<= data_temp;
				end
				1	:	
				begin
					tft_cs <= 1'b0;
					tft_rd <= 1'b1;
					tft_wr <= 1'b1;
					tft_dat<= data_temp;
				end
				default:;
				endcase
			
		end
		ST_END:
		begin
			tft_cs <= 1'b1;
			tft_rd <= 1'b1;
			tft_wr <= 1'b1;
			tft_dat<= 0;
		end
		default:;
		endcase
	end	
	

always @(posedge clk)
	if(~rst_n)
		tft_rs  <= 0;
	else
		case(lut_index)
		0	: tft_rs <= 1'b0;
		4	: tft_rs <= 1'b0;
		9	: tft_rs <= 1'b0;
		13	: tft_rs <= 1'b0;
		19	: tft_rs <= 1'b0;
		21	: tft_rs <= 1'b0;
		24	: tft_rs <= 1'b0;
		26	: tft_rs <= 1'b0;
		28	: tft_rs <= 1'b0;
		31	: tft_rs <= 1'b0;
		33	: tft_rs <= 1'b0;
		35	: tft_rs <= 1'b0;
		37	: tft_rs <= 1'b0;
		40	: tft_rs <= 1'b0;
		43	: tft_rs <= 1'b0;
		45	: tft_rs <= 1'b0;
		47	: tft_rs <= 1'b0;
		63	: tft_rs <= 1'b0;
		79	: tft_rs <= 1'b0;
//		80	: tft_rs <= 1'b0;
//		81	: tft_rs <= 1'b0;
		82	: tft_rs <= 1'b0;
		83	: tft_rs <= 1'b0;
		88	: tft_rs <= 1'b0;
		93	: tft_rs <= 1'b0;
		default: tft_rs <= 1'b1;
		endcase


endmodule
