//file name:	top_fpga.v
//author:		ETree
//date:			2021.7.11
//function:		top file of project
//log:

module top_fpga(
	//global signal                           
	input  clk,
	input  rst_n,
			
	//TFT2.8
	output tft_cs,				//液晶屏片选，低电平有效
	output tft_wr,
	output tft_rs,
	output tft_rd,
	output tft_reset,			//液晶屏复位，低电平有效
	output [15:0] tft_data,
	output tft_blk,			//液晶屏背光，高电平有效
	
	output led		//用于测试的LED指示灯
	
);

//-----------TFT-------------	

wire config_done;

tft24 tft28_inst
(
	.clk(clk) ,	// input  clk_sig
	.rst_n(rst_n) ,	// input  rst_n_sig
	.tft_cs(tft_cs) ,	// output  tft_cs_sig
	.tft_rs(tft_rs) ,	// output  tft_rs_sig
	.tft_rd(tft_rd) ,	// output  tft_rd_sig
	.tft_wr(tft_wr) ,	// output  tft_wr_sig
	.tft_dat(tft_data) ,	// output [15:0] tft_dat_sig
	.tft_res(tft_reset) ,	// output  tft_res_sig
	.config_done(config_done) 	// output  config_done_sig
);

assign tft_blk = 1'b1;
	
endmodule
