//file name:	vip_top.v
//author:      shugen.yin
//date:		   2017.10.18
//function:		VIP top file
//log:

module vip_top(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output cmos_href_o,
	output cmos_vsync_o,
	output [7:0] cmos_data_o
);

wire [10:0] v_cnt;
wire cmos_href_gray;
wire cmos_vsync_gray;
wire [7:0] cmos_data_gray;

gray gray_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync) ,	// input  cmos_vsync_sig
	.cmos_data(cmos_data) ,	// input [7:0] cmos_data_sig
	.v_cnt(v_cnt),
	.cmos_href_o(cmos_href_gray) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_gray) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_gray) 	// output [7:0] cmos_data_o_sig
);

wire cmos_href_mean;
wire cmos_vsync_mean;
wire [7:0] cmos_data_mean;

filter_mean filter_mean_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href_gray) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync_gray) ,	// input  cmos_vsync_sig
	.cmos_data(cmos_data_gray) ,	// input [7:0] cmos_data_sig
	.cmos_href_o(cmos_href_mean) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_mean) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_mean) 	// output [7:0] cmos_data_o_sig
);


//assign cmos_vsync_o = cmos_vsync;
//assign cmos_href_o  = cmos_href;
//assign cmos_data_o  = (v_cnt==0)?0:cmos_data;

assign cmos_vsync_o = cmos_vsync_mean;
assign cmos_href_o  = cmos_href_mean;
assign cmos_data_o  = (v_cnt==0)?0:cmos_data_mean;


endmodule
