//file name:	gray.v
//author:      shugen.yin
//date:		   2017.10.18
//function:		单通道数据提取
//log:

module gray(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg [10:0] v_cnt,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [7:0] cmos_data_o
);

parameter IMG_H = 640;

//reg [10:0] v_cnt; 	
reg [11:0] h_cnt;

always @(posedge cmos_pclk)
	if(cmos_href)
		h_cnt <= h_cnt + 1'b1;
	else
		h_cnt <= 0;
	
always @(posedge cmos_pclk)
	if(cmos_vsync)
		v_cnt <= 0;
	else if(h_cnt==(IMG_H-1))
		v_cnt <= v_cnt + 1'b1;
	else
		v_cnt <= v_cnt;

reg [10:0] rdaddress;
reg [10:0] wraddress;
reg cmos_href_r;
reg cmos_vsync_r;
reg rden;

wire [7:0] q;

always @(posedge cmos_pclk)
begin
	cmos_href_r  <= cmos_href;
	cmos_vsync_r <= cmos_vsync;
end

always @(posedge cmos_pclk)
	if(cmos_vsync_r)
		wraddress <= 0;
	else if(cmos_href_r)
		if(wraddress<(IMG_H*2-1))
			wraddress <= wraddress + 1'b1;
		else
			wraddress <= 0;
	else
		wraddress <= wraddress;

always @(posedge cmos_pclk)
	if(cmos_vsync_r)
		rdaddress <= 0;
	else if(cmos_href_r)
		if(rdaddress<(IMG_H-1))
			rdaddress <= rdaddress + 1'b1;
		else
			rdaddress <= 0;
	else
		rdaddress <= rdaddress;
		
always @(posedge cmos_pclk)
	if(cmos_vsync_r)
		rden <= 0;
	else
		rden <= cmos_href_r;
	
	
dpram dpram_inst
(
	.clock(cmos_pclk) ,		// input  clock_sig
	.data(cmos_data) ,		// input [7:0] data_sig
	.rdaddress({rdaddress[10:1],1'b0}) ,	// input [10:0] rdaddress_sig
	.rden(rden) ,				// input  rden_sig
	.wraddress(wraddress) ,	// input [10:0] wraddress_sig
	.wren(cmos_href_r) ,		// input  wren_sig
	.q(q) 						// output [7:0] q_sig
);

always @(posedge cmos_pclk)
begin
	cmos_href_o <= rden;
	cmos_vsync_o <= cmos_vsync_r;
	cmos_data_o  <= (q>=8'hDF)?8'hff:(q+8'h20);  //亮度增强
end


endmodule
