//file name:	filter_sharp.v
//author:      shugen.yin
//date:		   2017.10.23
//function:		锐化
//log:

module filter_sharp(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [7:0] cmos_data_o
);


wire [7:0] shiftout;
wire [7:0] taps0x;
wire [7:0] taps1x;
wire [7:0] taps2x;

shift_ram shift_ram_inst
(
	.clock(cmos_pclk) ,		// input  clock_sig
	.clken(cmos_href),
	.shiftin(cmos_data) ,	// input [7:0] shiftin_sig
	.shiftout(shiftout) ,	// output [7:0] shiftout_sig
	.taps0x(taps0x) ,			// output [7:0] taps0x_sig
	.taps1x(taps1x) ,			// output [7:0] taps1x_sig
	.taps2x(taps2x)
);

reg [7:0] cmos_data_r0;
reg [7:0] cmos_data_r1;
reg [9:0] cmos_data_result;
reg [7:0] taps0x_r0;
reg [7:0] taps0x_r1;
reg [7:0] taps1x_r0;
reg [7:0] taps1x_r1;
reg [7:0] taps2x_r0;
reg [7:0] taps2x_r1;

		
always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps0x_r0 <= 0;
		taps0x_r1 <= 0;
	end
	else
	begin
		taps0x_r0 <= taps0x;
		taps0x_r1 <= taps0x_r0;
	end


always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps1x_r0 <= 0;
		taps1x_r1 <= 0;
	end
	else
	begin
		taps1x_r0 <= taps1x;
		taps1x_r1 <= taps1x_r0;
	end

always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps2x_r0 <= 0;
		taps2x_r1 <= 0;
	end
	else
	begin
		taps2x_r0 <= taps2x;
		taps2x_r1 <= taps2x_r0;
	end	

wire [9:0] cmos_data_tmp0;
wire [9:0] cmos_data_tmp1;
	
assign cmos_data_tmp0 = taps1x_r0*4;
assign cmos_data_tmp1 = (taps0x_r0 + taps1x) + (taps1x_r1 + taps2x_r0);
	
always @(posedge cmos_pclk)
	if(cmos_vsync)
		cmos_data_result <= 0;
	else 
		cmos_data_result <= (cmos_data_tmp0>=cmos_data_tmp1)?(cmos_data_tmp0-cmos_data_tmp1):(cmos_data_tmp1-cmos_data_tmp0);		
	
reg cmos_data_result_flag;

always @(posedge cmos_pclk)
	if(cmos_vsync)
		cmos_data_result_flag <= 0;
	else
		cmos_data_result_flag <= (cmos_data_tmp0>=cmos_data_tmp1)?0:1'b1;
	
reg cmos_href_r;
reg cmos_vsync_r;

always @(posedge cmos_pclk)
begin
	cmos_href_r <= cmos_href;
	cmos_vsync_r <= cmos_vsync;
end
					
always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		cmos_href_o  <= 0;
		cmos_vsync_o <= 0;
		cmos_data_o  <= 0;
	end	
	else
	begin
		cmos_href_o  <= cmos_href_r;
		cmos_vsync_o <= cmos_vsync_r;
		cmos_data_o <= (cmos_data_result_flag==0)?(((cmos_data_result+taps1x_r1)>='hff)?8'hff:(cmos_data_result+taps1x_r1)):
							( (taps1x_r1>cmos_data_result)?(taps1x_r1-cmos_data_result):8'h01 );
//		cmos_data_o  <= ((cmos_data_result+taps1x_r1)>='hff)?8'hff:(cmos_data_result+taps1x_r1);
	end
	

endmodule
