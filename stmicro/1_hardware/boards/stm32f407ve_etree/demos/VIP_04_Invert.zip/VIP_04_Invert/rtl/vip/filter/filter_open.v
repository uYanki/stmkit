//file name:	filter_open.v
//author:      shugen.yin
//date:		   2017.10.27
//function:		开运算
//log:

module filter_open(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output [7:0] cmos_data_old,
	
	output  cmos_href_o,
	output  cmos_vsync_o,
	output  [7:0] cmos_data_o
);

wire cmos_href_dilate;
wire cmos_vsync_dilate;
wire [7:0] cmos_data_dilate;

wire [7:0] cmos_data_erode_old;

filter_erode filter_erode_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync) ,	// input  cmos_vsync_sig
	.cmos_data_old(cmos_data_erode_old),
	.cmos_data(cmos_data) ,	// input [7:0] cmos_data_sig
	.cmos_href_o(cmos_href_dilate) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_dilate) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_dilate) 	// output [7:0] cmos_data_o_sig
);


filter_dilate filter_dilate_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href_dilate) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync_dilate) ,	// input  cmos_vsync_sig
	.cmos_data_old_in(cmos_data_erode_old),
	.cmos_data_old(cmos_data_old),
	.cmos_data(cmos_data_dilate) ,	// input [7:0] cmos_data_sig
	.cmos_href_o(cmos_href_o) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_o) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_o) 	// output [7:0] cmos_data_o_sig
);


endmodule
