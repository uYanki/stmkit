//file name:	filter_sobel.v
//author:      shugen.yin
//date:		   2017.10.18
//function:		Sobel边缘检测
//log:

module filter_sobel(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [7:0] cmos_data_o
);

wire [7:0] shiftout;
wire [7:0] taps0x;
wire [7:0] taps1x;
wire [7:0] taps2x;

shift_ram shift_ram_inst
(
	.clock(cmos_pclk) ,		// input  clock_sig
	.clken(cmos_href),
	.shiftin(cmos_data) ,	// input [7:0] shiftin_sig
	.shiftout(shiftout) ,	// output [7:0] shiftout_sig
	.taps0x(taps0x) ,			// output [7:0] taps0x_sig
	.taps1x(taps1x) ,			// output [7:0] taps1x_sig
	.taps2x(taps2x)
);

reg [7:0] taps0x_r0;
reg [7:0] taps0x_r1;
reg [7:0] taps1x_r0;
reg [7:0] taps1x_r1;
reg [7:0] taps2x_r0;
reg [7:0] taps2x_r1;
	
always @(posedge cmos_pclk)
	begin
		taps0x_r0 <= taps0x;
		taps0x_r1 <= taps0x_r0;
	end


always @(posedge cmos_pclk)
	begin
		taps1x_r0 <= taps1x;
		taps1x_r1 <= taps1x_r0;
	end

always @(posedge cmos_pclk)
	begin
		taps2x_r0 <= taps2x;
		taps2x_r1 <= taps2x_r0;
	end

wire [10:0] sum0_gx;
wire [10:0] sum1_gx;
wire [11:0] sobel_gx;	

assign sum0_gx = ({3'b000,taps0x_r1} + {2'b00,taps1x_r1,1'b0}) + {3'b000,taps2x_r1};
assign sum1_gx = ({3'b000,taps0x} + {2'b00,taps1x,1'b0}) + {3'b000,taps2x};					
//assign sobel_gx = (sum0_gx>=sum1_gx)?(sum0_gx-sum1_gx):(sum1_gx-sum0_gx);
assign sobel_gx = {1'b0,sum0_gx} + {1'b1,(~(sum1_gx) + 11'h001)};

wire [10:0] sum0_gy;
wire [10:0] sum1_gy;
wire [11:0] sobel_gy;	

assign sum0_gy = ({3'b000,taps0x} + {2'b00,taps0x_r0,1'b0}) + {3'b000,taps0x_r1};
assign sum1_gy = ({3'b000,taps2x} + {2'b00,taps2x_r0,1'b0}) + {3'b000,taps2x_r1};
//assign sobel_gy = (sum0_gy>=sum1_gy)?(sum0_gy-sum1_gy):(sum1_gy-sum0_gy);
assign sobel_gy = {1'b0,sum0_gy} + {1'b1,(~(sum1_gy) + 11'h001)};	

//-------------Method 1-------------------	
reg [11:0] sobel_result;
wire [10:0] sobel_gx_not;
wire [10:0] sobel_gy_not;
assign sobel_gx_not = {~sobel_gx[10],~sobel_gx[9],~sobel_gx[8],~sobel_gx[7],~sobel_gx[6],
							  ~sobel_gx[5],~sobel_gx[4],~sobel_gx[3],~sobel_gx[2],~sobel_gx[1],~sobel_gx[0]};
assign sobel_gy_not = {~sobel_gy[10],~sobel_gy[9],~sobel_gy[8],~sobel_gy[7],~sobel_gy[6],
							  ~sobel_gy[5],~sobel_gy[4],~sobel_gy[3],~sobel_gy[2],~sobel_gy[1],~sobel_gy[0]};

always @(posedge cmos_pclk)
//		sobel_result <= sobel_gx + sobel_gy;	
		sobel_result <= ((sobel_gx[11]==0)?(sobel_gx[10:0]):(sobel_gx_not+11'b1)) + 
							 ((sobel_gy[11]==0)?(sobel_gy[10:0]):(sobel_gy_not+11'b1));		

//-------------Method 2---------------	
	
reg [22:0] sobel_gxgy;

always @(posedge cmos_pclk)	
begin
//	sobel_gxgy <= (sobel_gx*sobel_gx) + (sobel_gy*sobel_gy);
	sobel_gxgy <= ((sobel_gx[11]==0)?(sobel_gx[10:0]*sobel_gx[10:0]):(sobel_gx_not+11'h01)*(sobel_gx_not+11'h01)) + 
					  ((sobel_gy[11]==0)?(sobel_gy[10:0]*sobel_gy[10:0]):(sobel_gy_not+11'h01)*(sobel_gy_not+11'h01));
end
	
wire [11:0] sqrt_q;	
	
alt_sqrt	alt_sqrt_inst (
	.radical ( sobel_gxgy ),
	.q ( sqrt_q ),
	.remainder ( )
	);	
	
always @(posedge cmos_pclk)
//	if(sobel_result>'d58)		//method 1
	if(sqrt_q>='d30)				//method 2
		cmos_data_o <= 8'h01;
	else
		cmos_data_o <= 8'hff;

	
reg cmos_vsync_r0;
reg cmos_vsync_r1;
reg cmos_vsync_r2;		
reg cmos_href_r0;
reg cmos_href_r1;
reg cmos_href_r2;

always @(posedge cmos_pclk)
begin
	cmos_vsync_r0 <= cmos_vsync;
	cmos_vsync_r1 <= cmos_vsync_r0;
	cmos_vsync_r2 <= cmos_vsync_r1;
	cmos_vsync_o  <= cmos_vsync_r2;
end

always @(posedge cmos_pclk)
begin
	cmos_href_r0 <= cmos_href;
	cmos_href_r1 <= cmos_href_r0;
	cmos_href_r2 <= cmos_href_r1;
	cmos_href_o  <= cmos_href_r2;
end


endmodule
