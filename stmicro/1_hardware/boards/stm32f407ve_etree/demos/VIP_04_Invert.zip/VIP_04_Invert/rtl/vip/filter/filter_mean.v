//file name:	filter_mean.v
//author:      shugen.yin
//date:		   2017.10.18
//function:		均值滤波
//log:

module filter_mean(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [7:0] cmos_data_o
);

wire [7:0] shiftout;
wire [7:0] taps0x;
wire [7:0] taps1x;
wire [7:0] taps2x;

shift_ram shift_ram_inst
(
	.clock(cmos_pclk) ,		// input  clock_sig
	.clken(cmos_href),
	.shiftin(cmos_data) ,	// input [7:0] shiftin_sig
	.shiftout(shiftout) ,	// output [7:0] shiftout_sig
	.taps0x(taps0x) ,			// output [7:0] taps0x_sig
	.taps1x(taps1x) ,			// output [7:0] taps1x_sig
	.taps2x(taps2x)
);

reg [7:0] cmos_data_r0;
reg [7:0] cmos_data_r1;
reg [11:0] cmos_data_result;
reg [7:0] taps0x_r0;
reg [7:0] taps0x_r1;
reg [7:0] taps1x_r0;
reg [7:0] taps1x_r1;
reg [7:0] taps2x_r0;
reg [7:0] taps2x_r1;

		
always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps0x_r0 <= 0;
		taps0x_r1 <= 0;
	end
	else
	begin
		taps0x_r0 <= taps0x;
		taps0x_r1 <= taps0x_r0;
	end


always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps1x_r0 <= 0;
		taps1x_r1 <= 0;
	end
	else
	begin
		taps1x_r0 <= taps1x;
		taps1x_r1 <= taps1x_r0;
	end

always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		taps2x_r0 <= 0;
		taps2x_r1 <= 0;
	end
	else
	begin
		taps2x_r0 <= taps2x;
		taps2x_r1 <= taps2x_r0;
	end	
	
always @(posedge cmos_pclk)
	if(cmos_vsync)
		cmos_data_result <= 0;
	else 
		cmos_data_result <= (((taps0x + taps0x_r0) + taps0x_r1) + 
								  ((taps1x + taps1x_r0) + taps1x_r1)) +
								  ((taps2x + taps2x_r0) + taps2x_r1);
	
wire [17:0] result0;
wire [16:0] result1;
wire [15:0]	result2;
wire [12:0]	result3;
//wire [11:0]	result4=0;
//wire [11:0]	result5=0;
//wire [11:0]	result6=0;
//wire [11:0]	result7=0;
wire [18:0] result;
							
assign result0 = cmos_data_result * 64;
assign result1 = cmos_data_result * 32;
assign result2 = cmos_data_result * 16;
assign result3 = cmos_data_result;
assign result  = (result0 + result1) + (result2 + result3);		
					
					
always @(posedge cmos_pclk)
	if(cmos_vsync)
	begin
		cmos_href_o  <= 0;
		cmos_vsync_o <= 0;
		cmos_data_o  <= 0;
	end	
	else
	begin
		cmos_href_o  <= cmos_href;
		cmos_vsync_o <= cmos_vsync;
		cmos_data_o  <= result[17:10];
	end
	

endmodule
