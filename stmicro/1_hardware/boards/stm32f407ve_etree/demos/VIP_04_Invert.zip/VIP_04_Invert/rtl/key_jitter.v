//file name:       key_jitter.v
//author:           etree
//date:             2017.7.23
//function:       
//log:              

module key_jitter(
		input clk,				//50MHz
		input key_n,			//低电平有效
		output reg key_valid //高电平有效
);

reg [7:0] cnt0;

always @(posedge clk)
begin
	cnt0 <= cnt0 + 1'b1;
end


always @(posedge clk)
begin
	key_valid <= (cnt0<'hf);
end


endmodule


