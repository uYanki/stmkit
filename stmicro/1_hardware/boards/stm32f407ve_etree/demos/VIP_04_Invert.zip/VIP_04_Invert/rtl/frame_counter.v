//file name			: frame_counter.v
//data				: 2017.10.1
//author				: shugen.yin
//function			: frame counter
//log					:

module frame_counter(
	input clk, 							//时钟信号，50MHz
	input rst_n,						//复位信号，低电平有效
	
	input cmos_vsync,					//帧同步信号
	output reg [7:0] frame_out		//帧率结果输出
);

//--------frame count--------
reg [25:0] cnt_1sec;	//1秒钟计数器
reg [7:0] cnt_freq;  //帧率计数器
reg [1:0] cmos_vsync_r;//帧同步信号缓存

always @(posedge clk)
	cmos_vsync_r <= {cmos_vsync_r[0],cmos_vsync};
	
wire cmos_vsync_pos = (cmos_vsync_r==2'b01);	

always @(posedge clk)
	if(~rst_n)
		cnt_1sec <= 0;
	else if(cnt_1sec==49_999_999)
		cnt_1sec <= 0;
	else
		cnt_1sec <= cnt_1sec + 1'b1;

		
always @(posedge clk)
	if(~rst_n)
	begin
		cnt_freq <= 0;
	end
	else if(cnt_1sec<49_999_999)
	begin
		if(cmos_vsync_pos)
			cnt_freq <= cnt_freq + 1'b1;
		else
			cnt_freq <= cnt_freq;
	end
	else
		cnt_freq <= 0;

always @(posedge clk)
	if(~rst_n)
		frame_out <= 0;
	else if(cnt_1sec==49_999_998)
		frame_out <= cnt_freq;
	else
		frame_out <= frame_out;


endmodule

