//file name:	filter_tophat.v
//author:      shugen.yin
//date:		   2017.10.27
//function:		开运算
//log:

module filter_tophat(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output  cmos_href_o,
	output  cmos_vsync_o,
	output  [7:0] cmos_data_o
);

wire [7:0] cmos_data_open;
wire [7:0] cmos_data_old;

filter_open filter_open_inst
(
	.cmos_pclk(cmos_pclk) ,	// input  cmos_pclk_sig
	.cmos_href(cmos_href) ,	// input  cmos_href_sig
	.cmos_vsync(cmos_vsync) ,	// input  cmos_vsync_sig
	.cmos_data_old(cmos_data_old),
	.cmos_data(cmos_data) ,	// input [7:0] cmos_data_sig
	.cmos_href_o(cmos_href_o) ,	// output  cmos_href_o_sig
	.cmos_vsync_o(cmos_vsync_o) ,	// output  cmos_vsync_o_sig
	.cmos_data_o(cmos_data_open) 	// output [7:0] cmos_data_o_sig
);

assign cmos_data_o = (cmos_data_old>=cmos_data_open)?(cmos_data_old-cmos_data_open):8'h01;


endmodule
