//file name:	filter_threshold.v
//author:      shugen.yin
//date:		   2017.10.18
//function:		阈值分割
//log:

module filter_threshold(
	input cmos_pclk,
	input cmos_href,
	input cmos_vsync,
	input [7:0] cmos_data,
	
	output reg cmos_href_o,
	output reg cmos_vsync_o,
	output reg [7:0] cmos_data_o
);

reg cmos_href_r;
reg cmos_vsync_r;
reg [7:0] cmos_data_r;

always @(posedge cmos_pclk)
begin
	cmos_href_r  <= cmos_href;
	cmos_vsync_r <= cmos_vsync;
	cmos_data_r  <= (cmos_data<=8'h3F && cmos_data>=8'h0F)?8'h01:8'hf0;
end

always @(posedge cmos_pclk)
begin
	cmos_href_o  <= cmos_href_r;
	cmos_vsync_o <= cmos_vsync_r;
	cmos_data_o  <= cmos_data_r;
end


endmodule
