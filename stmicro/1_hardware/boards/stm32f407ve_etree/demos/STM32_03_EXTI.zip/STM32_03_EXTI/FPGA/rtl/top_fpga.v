//file name:       top_fpga.v
//author:           ETree
//date:             2017.9.9
//function:        top file of project
//log:              led light

module top_fpga(
    //global signal
    input clk,  //50MHz
    input rst_n,//low active
	 
	 //key
	 input key0,
	 input key1,
	 input key2,
	 
	 //STM32
	 input  stm_pa1,
	 input  stm_pb6,
	 output stm_pb7,
    
    //led
    output  led //high active
);

assign led = stm_pb6;
assign stm_pb7 = key0;
    
endmodule

