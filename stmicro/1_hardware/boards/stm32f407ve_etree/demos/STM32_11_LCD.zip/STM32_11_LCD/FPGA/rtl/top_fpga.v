//file name:	top_fpga.v
//author:		ETree
//date:			2017.12.9
//function:		top file of project

module top_fpga(
	//global signal                           
	input  clk,
	input  rst_n,
	
	//STM32
	//FSMC Bus
	inout [15:0] fsmc_data,
	input fsmc_noe,
	input fsmc_nwe,
	input fsmc_nbl0,
	
	input fsmc_nbl1,
	input fsmc_ne1, 
	input fsmc_a23,
	input fsmc_a22,
	input fsmc_a21,
	input fsmc_a20,
	input fsmc_a19,
	input fsmc_a18,
	input fsmc_a17,
	input fsmc_a16,
	input fsmc_nwait,
	input fsmc_clk,
	
	//sdram port
	output [12:0] sdram_addr, 
	output [1:0]  sdram_ba,   
	output sdram_cas_n,
	output sdram_cke  ,
	output sdram_cs_n ,
	inout  [15:0] sdram_dq,   
	output [1:0] sdram_dqm , 
	output sdram_ras_n,
	output sdram_we_n, 
	output sdram_clk,
	
	//VGA
	output vga_hsync,
	output vga_vsync,
	output [4:0] vga_red,
	output [5:0] vga_green,
	output [5:0] vga_blue,
	
	//TFT2.8
	output tft_cs,				//液晶屏片选，低电平有效
	output tft_wr,
	output tft_rs,
	output tft_rd,
	output tft_reset,			//液晶屏复位，低电平有效
	output [15:0] tft_data,
	output tft_blk,				//液晶屏背光，高电平有效
	//TFT Touch
	output tft_tclk,
	output tft_tcs,
	output tft_tmosi,
	input  tft_tmiso,
	input  tft_tpen,

   //ledsm
//	output [7:0] sm_dat,
	output [1:0] sm_sel,
	
	//led
	output led
	
);

//------------PLL----------------
wire clk_100m;
wire clk_100m_p;
wire locked;

my_pll my_pll_inst(
	.areset ( 0 ),
	.inclk0 ( clk ),
	.c0 ( clk_100m ),
	.c1 ( clk_100m_p ),
	.locked ( locked )
	);	
	
assign sm_sel = 2'b11;

//---------------Soft Reset--------------
reg [19:0] rst_cnt; 
reg rstn;

always @(posedge clk)
	if(~rst_n)
		rst_cnt <= 0;
	else if(rst_cnt>='hffffa)
		rst_cnt <= rst_cnt;
	else
		rst_cnt <= rst_cnt + 1'b1;
		
always @(posedge clk)
	if(rst_cnt>='hffff0)
		rstn <= 1'b1;
	else
		rstn <= 0;	

//----------FSMC-----------	

assign tft_cs = fsmc_ne1;
assign tft_wr = fsmc_nwe;
assign tft_rs = fsmc_a16;
assign tft_data = fsmc_data;
assign tft_rd = 1'b1;
assign tft_reset = 1'b1;
assign tft_blk = 1'b1;


endmodule
